export const environment = {
  production: false,
  AWS_ACCESS_KEY: "AKIAVXOKGRIMNZICXT6B",
  // AWS_SECRET_KEY: 'VGk2FXVjUr8ZZZJgSCNj44rDTvxIHOluXXHOrs5/JNK',
  AWS_SECRET_KEY: "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",
  AWS_REGION: "us-east-1",

  apiUrl: "http://localhost:8080",
  // apiUrl: 'https://demo.elevatepethealth.com/api',
  key:
    "pk_test_51Q2ClRDb6WVg8hg0K0ISzTb6Tnlr2OFBWlj7VcfX286FBtm6LkNNR6EW6OQgUK0uMoLlHyx0fv5hLelGlsq651dr00JasArIKC"
};
