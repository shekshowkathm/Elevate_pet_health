export const environment = {
  production: true,
  AWS_ACCESS_KEY: 'AKIAVXOKGRIMNZICXT6B',
  // AWS_SECRET_KEY: 'VGk2FXVjUr8ZZZJgSCNj44rDTvxIHOluXXHOrs5/JNK',
  AWS_SECRET_KEY: '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',
  AWS_REGION: 'us-east-1',

  // apiUrl : "http://localhost:8080"

  apiUrl: 'https://demo.elevatepethealth.com/api',
};
