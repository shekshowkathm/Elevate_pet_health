declare module 'pica' {
  interface PicaOptions {
    quality?: number;
    alpha?: boolean;
    unsharpAmount?: number;
    unsharpRadius?: number;
    unsharpThreshold?: number;
    cancelToken?: any;
  }

  interface Pica {
    resize(
      from: HTMLImageElement | HTMLCanvasElement,
      to: HTMLCanvasElement,
      options?: PicaOptions
    ): Promise<HTMLCanvasElement>;

    toBlob(
      canvas: HTMLCanvasElement,
      mimeType?: string,
      quality?: number
    ): Promise<Blob>;
  }

  const pica: {
    new (): Pica;
  };

  export default pica;
}
