import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment.development';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthResponse, Login } from '../model/login';
import { Observable } from 'rxjs';
import {
  ActiveClinic,
  ClinicOwnerRegister,
} from '../model/clinic-owner-register';
import { RequestPetOwnerRegister } from '../model/pet-owner-register';

interface Password {
  email: string;
  password: string;
}

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  private API_END_POINT = environment.apiUrl;
  private loginUrl = environment.apiUrl + '/register/login';
  private requestAsClinicOwnerApi =
    environment.apiUrl + '/clinic-details/clinicRegisterRequest';
  private activeClinicApi = environment.apiUrl + '/clinic-details/active';
  private requestAsPetOwnerApi =
    environment.apiUrl + '/pet-detials/addPetOwner';
  private emailVerificationAPI = environment.apiUrl + '/register/generateOtp/';
  private otpVerificationAPI = environment.apiUrl + '/register/verify-otp/';
  private passwordUpdatinsAPI = environment.apiUrl + '/register/forgetPassword';
  private getHeadQuartersAPI =
    environment.apiUrl + '/clinic-details/get-headquaters';
  constructor(private http: HttpClient) {}

  authenticate(login: Login): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(this.loginUrl, login);
  }

  requestAsClinicOwner(
    clinicOwnerRequest: ClinicOwnerRegister,
  ): Observable<string> {
    return this.http.post(this.requestAsClinicOwnerApi, clinicOwnerRequest, {
      responseType: 'text',
    });
  }

  getActiveClinics(): Observable<ActiveClinic[]> {
    return this.http.get<ActiveClinic[]>(this.activeClinicApi);
  }

  requestAsPetOwner(
    petOwnerRequest: RequestPetOwnerRegister,
  ): Observable<string> {
    return this.http.post(this.requestAsPetOwnerApi, petOwnerRequest, {
      responseType: 'text',
    });
  }

  emailVerify(userEmail: string) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      // Add auth token if required
    });
    return this.http.post(this.emailVerificationAPI + userEmail, '', {
      responseType: 'text',
    });
  }
  otpVerify(userEmail: string, userOTP: string) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      // Add auth token if required
    });
    return this.http.post(
      this.otpVerificationAPI + userEmail + '/' + userOTP,
      '',
      { responseType: 'text' },
    );
  }
  passwordUpdations(passwordObject: Password) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      // Add auth token if required
    });
    return this.http.post(this.passwordUpdatinsAPI, passwordObject, {
      responseType: 'text',
    });
  }

  getHeadQuarters(): Observable<any[]> {
    return this.http.get<any[]>(this.getHeadQuartersAPI);
  }

  suggestClinic(suggestion: {
    clinicName: string;
    city: string;
    zipCode: string;
    fromMail: string;
    state: string;
  }) {
    return this.http.post(
      `${this.API_END_POINT}/register/sendInfoEmail`,
      suggestion,
      { responseType: 'text' },
    );
  }

  stayInTouch(payload: { email: string }) {
    return this.http.post(`${this.API_END_POINT}/subscribe/add`, payload, {
      responseType: 'text',
    });
  }
}
