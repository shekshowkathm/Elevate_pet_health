import {
  ApplicationRef,
  Component,
  ElementRef,
  Renderer2,
  signal,
} from '@angular/core';
import { HeaderComponent } from '../../../shared/component/header/header.component';
import { FooterComponent } from '../../../shared/component/footer/footer.component';
import { CommonModule } from '@angular/common';
import { first } from 'rxjs';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [HeaderComponent, FooterComponent, CommonModule],
  templateUrl: './about.component.html',
  styleUrl: './about.component.scss',
})
export class AboutComponent {
  whoWeAre: string =
    'We are team of professionals with over 65 years of experience in all aspects of the veterinary industry. Over the years and in countless conversations with veterinarians. Practice managers and Pet owners , we have heard the desire to bring a customizable plan of wellness to private veterinary practices. However, the cost of implementing such a plan has always been too significant for any one individual practice to consider, until now! Welcome to Elevate Pet Health.';
  helping: string =
    'Most private veterinary practices lack the time and resources to create a custom system for managing wellness programs. Challenges like plan structure, staff training, payment processing, and business management hinder effective pet care. At Elevate Pet Health, we offer a streamlined process to help private practitioners overcome these obstacles and successfully implement their wellness systems.';
  approach: string =
    'We have developed a system that empowers private veterinarians to deliver the well-planned pet care they have always envisioned. By providing individualized care tailored to each pets needs, our system addresses common challenges and offers the necessary training and support. Our goal is to promote the health and longevity of all pets, making well-planned pet care a reality for both veterinarians and pet owners.';

  images: { src: string; text: string; subText: string }[] = [
    {
      src: '../../../../assets/about/slide-01.jpg',
      text: 'Your veterinary clinic will provide guidance',
      subText: 'Let us Help',
    },
    {
      src: '../../../../assets/about/slide-02.jpg',
      text: 'Help us keep your pets healthier and happier',
      subText: 'Get Started',
    },
    {
      src: '../../../../assets/about/slide-03.jpg',
      text: 'We offer customized wellness plans for your pet',
      subText: 'Well-Planned Pet Care',
    },
  ];

  currentIndex = signal<number>(0);
  autoplayInterval: any;
  wellPlannedCareList: { icon: string; heading: string; subHeading: string }[] =
    [
      {
        icon: '../../../../assets/about/icon-04-36x43.png',
        heading: 'Custom Plans',
        subHeading: 'Wellness plans, your way, every day',
      },
      {
        icon: '../../../../assets/about/icon-02-34x52.png',
        heading: 'Tailored Reminders',
        subHeading: 'Appointment reminders, your way',
      },
      {
        icon: '../../../../assets/about/icon-03-34x52.png',
        heading: 'Savings Benefit',
        subHeading: 'Reduced costs for essential services',
      },
      {
        icon: '../../../../assets/about/icon-01-34x52.png',
        heading: 'Additional Benefits',
        subHeading: 'Added perks from your clinic for active wellness plans',
      },
    ];

  constructor(
    private applicationRef: ApplicationRef,
    private renderer: Renderer2,
    private el: ElementRef
  ) {}
  ngOnInit() {
    this.applicationRef.isStable
      .pipe(first((isStable) => isStable))
      .subscribe(() => {
        this.startAutoplay();
      });
  }

  ngOnDestroy() {
    clearInterval(this.autoplayInterval);
  }

  private startAutoplay() {
    this.autoplayInterval = setInterval(() => {
      this.nextImage();
    }, 5000);
  }

  private nextImage() {
    this.currentIndex.set((this.currentIndex() + 1) % this.images.length);
    this.triggerAnimation();
  }

  selectImage(index: number) {
    this.currentIndex.set(index);
    this.triggerAnimation();
  }

  private triggerAnimation() {
    const textElement = this.el.nativeElement.querySelector('.animate-div');
    this.renderer.removeClass(textElement, 'fadeInUp');
    void textElement.offsetWidth;
    this.renderer.addClass(textElement, 'fadeInUp');
  }
}
