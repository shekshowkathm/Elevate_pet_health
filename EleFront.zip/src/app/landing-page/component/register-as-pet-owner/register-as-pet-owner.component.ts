import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { HeaderComponent } from '../../../shared/component/header/header.component';
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
  FormsModule,
} from '@angular/forms';
import { LoginService } from '../../service/login.service';
import { ActiveClinic } from '../../model/clinic-owner-register';
import { CommonModule, isPlatformBrowser, NgFor, NgIf } from '@angular/common';
import { RequestPetOwnerRegister } from '../../model/pet-owner-register';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextModule } from 'primeng/inputtext';
import { HttpErrorResponse, HttpStatusCode } from '@angular/common/http';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TIME_ZONES } from '../../../shared/constants/timeZone';

@Component({
  selector: 'app-register-as-pet-owner',
  standalone: true,
  imports: [
    HeaderComponent,
    ReactiveFormsModule,
    CommonModule,
    FormsModule,
    DropdownModule,
    InputTextModule,
    ToastModule,
    ProgressSpinnerModule,
  ],
  templateUrl: './register-as-pet-owner.component.html',
  styleUrl: './register-as-pet-owner.component.scss',
  providers: [MessageService],
})
export class RegisterAsPetOwnerComponent {
  activeClinics: ActiveClinic[] = [];
  selectedClinic: ActiveClinic | null = null;
  timeZones: { label: string; value: string }[] = TIME_ZONES.map((t) => ({
    label: `${t.fullName} (${t.abbreviation})`,
    value: t.abbreviation,
  }));

  petOwnerForm = new FormGroup({
    clinicName: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    contact: new FormControl('', [Validators.required]),
    firstName: new FormControl('', [Validators.required]),
    lastName: new FormControl('', [Validators.required]),
    timezone: new FormControl('', [Validators.required]),
  });
  loader: boolean = false;

  constructor(
    private loginService: LoginService,
    private messageService: MessageService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit() {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.getActiveClinics();
    }
  }

  submitPetOwnerForm() {
    if (this.petOwnerForm.invalid) {
      return;
    }
    this.loader = true;
    const clinicId = this.selectedClinic ? this.selectedClinic.id : undefined;
    const email = this.petOwnerForm.value.email!;
    const contact = this.petOwnerForm.value.contact!;
    const firstName = this.petOwnerForm.value.firstName!;
    const lastName = this.petOwnerForm.value.lastName!;
    const timezone = this.petOwnerForm.value.timezone!;
    const petOwnerDetails: RequestPetOwnerRegister = {
      email: email,
      contact: contact,
      clinicId: clinicId,
      role: 'PET_OWNER',
      firstName: firstName,
      lastName: lastName,
      timezone: timezone,
    };
    this.loginService.requestAsPetOwner(petOwnerDetails).subscribe({
      next: (response: any) => {
        this.loader = false;
        this.messageService.add({
          severity: 'success',
          summary: 'Thank you for your submission!',
          detail:
            'Your request has been received. Our team will review and verify the information provided. You will be notified once your request has been approved',
          life: 10000,
        });
        this.petOwnerForm.reset();
      },
      error: (error: HttpErrorResponse) => {
        this.loader = false;
        if (error.status === HttpStatusCode.Conflict) {
          this.messageService.add({
            severity: 'error',
            summary: 'Email Already Exists',
            detail: 'Please use different Email address',
          });
          return;
        }
        this.messageService.add({
          severity: 'error',
          summary: 'Submission Failed',
          detail:
            'There was an error processing your request. Please try again later or contact support if the issue persists.',
        });
      },
    });
  }

  getActiveClinics() {
    this.loginService.getActiveClinics().subscribe((response) => {
      this.activeClinics = response;
    });
  }

  formatPhoneNumber(): void {
    let input = this.petOwnerForm.get('contact')?.value || ''; // Set default empty string if undefined
    input = input.replace(/\D/g, ''); // Remove non-numeric characters

    let formattedInput: string = ''; // Declare as string

    if (input.length > 0) {
      formattedInput = `(${input.substring(0, 3)}`; // Add opening parenthesis
    }
    if (input.length >= 4) {
      formattedInput += `) ${input.substring(3, 6)}`; // Add closing parenthesis and space
    }
    if (input.length >= 7) {
      formattedInput += `-${input.substring(6, 10)}`; // Add hyphen before the last 4 digits
    }

    // Set the formatted value back to the form control
    this.petOwnerForm
      .get('contact')
      ?.setValue(formattedInput, { emitEvent: false });

    // Add the pattern validator only when the full phone number is entered
    if (input.length === 10) {
      this.petOwnerForm
        .get('contact')
        ?.setValidators([
          Validators.required,
          Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/),
        ]);
    } else {
      // Remove pattern validator if the input is not yet complete
      this.petOwnerForm.get('contact')?.setValidators([Validators.required]);
    }

    this.petOwnerForm
      .get('contact')
      ?.updateValueAndValidity({ emitEvent: false });
  }
}
