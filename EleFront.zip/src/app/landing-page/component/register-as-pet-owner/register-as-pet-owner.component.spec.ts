import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterAsPetOwnerComponent } from './register-as-pet-owner.component';

describe('RegisterAsPetOwnerComponent', () => {
  let component: RegisterAsPetOwnerComponent;
  let fixture: ComponentFixture<RegisterAsPetOwnerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RegisterAsPetOwnerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegisterAsPetOwnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
