import { Component } from '@angular/core';
import { HeaderComponent } from "../../../shared/component/header/header.component";
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgFor, NgIf } from '@angular/common';
import { LoginService } from '../../service/login.service';
import { MessageService } from 'primeng/api';
import { Router } from '@angular/router';
import { ToastModule } from 'primeng/toast';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [MatButtonModule, FormsModule, ReactiveFormsModule, NgIf, ToastModule, MatProgressSpinnerModule],
  templateUrl: './forgot-password.component.html',
  styleUrl: './forgot-password.component.scss',
  providers: [MessageService],
})
export class ForgotPasswordComponent {
  userEmail: string = "";
  userOTP: string = "";


  showSpinner: boolean = false;

  isEmailForm: boolean = true;
  isOTPForm: boolean = false;
  isPasswordForm: boolean = false;


  minutes: number = 5; // Timer starts at 5 minutes
  seconds: number = 0;
  timerInterval: any;
  otpError: string = "";
  emailError: string = "";


  password: string = '';
  confirmPassword: string = '';


  constructor(private loginService: LoginService, private messageService: MessageService, private router: Router) {

  }


  ngOnInit(): void {

  }

  emailSubmit(form: any) {
    if (form.valid) {
      console.log("Form Submitted", this.userEmail);
      this.showSpinner = true
      this.loginService.emailVerify(this.userEmail).subscribe({
        next: (response) => {
          console.log('Post request successful:', response);
          this.showSpinner = false

          if (response === "Email Not Exist") {
            this.emailError = response
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: "Email does not exist.",
            });

            setTimeout(() => {
              this.messageService.clear();
            }, 2000);
          } else {
            this.isEmailForm = false;
            this.isOTPForm = true;
            this.startTimer();
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: "Email verified successfully.",
            });

            setTimeout(() => {
              this.messageService.clear();
            }, 2000);
          }


        },
        error: (error) => {
          console.error('Error occurred while posting data:', error);
          this.showSpinner = false
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: "An error occurred. Please try again.",
          });

          setTimeout(() => {
            this.messageService.clear();
          }, 2000);

        },
      });

    }
  }

  otpSubmit(form: any): void {
    if (form.valid) {
      console.log('OTP Submitted:', this.userOTP);

      this.loginService.otpVerify(this.userEmail, this.userOTP).subscribe({
        next: (response) => {
          console.log('Post request successful:', response);

          if (response === "Invalid or expired Password") {
            this.otpError = response
          } else {
            this.isEmailForm = false;
            this.isOTPForm = false;
            this.isPasswordForm = true;
          }

        },
        error: (error) => {
          console.error('Error occurred while posting data:', error);

        },
      });
    }
  }


  submitPassword(form: any): void {
    if (form.valid) {
      console.log('Password form submitted', {
        password: this.password,
        confirmPassword: this.confirmPassword,
      });
      console.log(this.userEmail);
      const passwordObject = {
        "email": this.userEmail,
        "password": this.password
      }
      console.log(passwordObject);
      this.loginService.passwordUpdations(passwordObject).subscribe({
        next: (response) => {

          this.messageService.add({
            severity: 'success',
            summary: 'Password Updated',
            detail: 'Please login now',
          });
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 1000);
        },
        error: (error) => {
          console.error('Error occurred while posting data:', error);
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Failed to update password. Please try again.',
          });

        },
      });
    }
  }

  get formattedSeconds(): string {
    return this.seconds.toString().padStart(2, '0');
  }

  startTimer(): void {
    this.timerInterval = setInterval(() => {
      if (this.seconds > 0) {
        this.seconds--;
      } else {
        if (this.minutes > 0) {
          this.minutes--;
          this.seconds = 59;
        } else {
          // Timer reached 00:00, trigger the resend OTP method
          this.resendOTP();
        }
      }
    }, 1000);
  }

  resendOTP(): void {
    clearInterval(this.timerInterval);

    console.log('Resend OTP triggered');
    this.messageService.add({
      severity: 'error',
      summary: 'Time Up',
      detail: 'Please resend your otp',
    });
    // Logic to trigger the resend OTP functionality
    this.minutes = 5;
    this.seconds = 0;
    // this.startTimer(); // Restart the timer after resending OTP
    this.isEmailForm = true;
    this.isOTPForm = false;
    this.isPasswordForm = false;
  }

  ngOnDestroy(): void {
    // Clear interval on component destroy to avoid memory leaks
    clearInterval(this.timerInterval);
  }



}
