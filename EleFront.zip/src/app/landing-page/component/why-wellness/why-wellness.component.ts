import { Component } from '@angular/core';
import { HeaderComponent } from "../../../shared/component/header/header.component";
import { FooterComponent } from "../../../shared/component/footer/footer.component";
import { Router } from '@angular/router';


@Component({
  selector: 'app-why-wellness',
  standalone: true,
  imports: [HeaderComponent, FooterComponent],
  templateUrl: './why-wellness.component.html',
  styleUrl: './why-wellness.component.scss'
})
export class WhyWellnessComponent {
  planType: string = '';
  constructor(private router : Router){

  }
  viewwellnessplan(planType: string){
    this.router.navigate(['view'], {
      queryParams: {
        plan:planType
      },
    });
  }




}
