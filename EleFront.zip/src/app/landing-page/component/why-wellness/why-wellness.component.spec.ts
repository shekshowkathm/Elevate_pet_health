import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WhyWellnessComponent } from './why-wellness.component';

describe('WhyWellnessComponent', () => {
  let component: WhyWellnessComponent;
  let fixture: ComponentFixture<WhyWellnessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WhyWellnessComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WhyWellnessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
