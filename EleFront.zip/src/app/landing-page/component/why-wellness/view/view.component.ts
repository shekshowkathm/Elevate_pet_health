
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HeaderComponent } from "../../../../shared/component/header/header.component";

@Component({
  selector: 'app-view',
  standalone: true,
  imports: [CommonModule, HeaderComponent],
  templateUrl: './view.component.html',
  styleUrl: './view.component.scss'
})
export class ViewComponent {
  planType: string = '';
  constructor(private route : ActivatedRoute){

  }
  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.planType = params['plan'];
    });
  }


}
