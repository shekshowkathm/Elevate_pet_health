import { Component } from "@angular/core";
import { HeaderComponent } from "../../../shared/component/header/header.component";
import { FormsModule, NgForm } from "@angular/forms";
import { NgClass, NgIf } from "@angular/common";
import { AuthResponse, Login } from "../../model/login";
import { LoginService } from "../../service/login.service";
import { Route, Router } from "@angular/router";
import { ToastModule } from "primeng/toast";
import { MessageService } from "primeng/api";
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: "app-login",
  standalone: true,
  imports: [HeaderComponent, FormsModule, NgIf, NgClass, ToastModule, MatProgressSpinnerModule],
  templateUrl: "./login.component.html",
  styleUrl: "./login.component.scss",
  providers: [MessageService]
})
export class LoginComponent {
  login: Login = new Login();
  passwordVisible: boolean = false;
  isloaderVisible: boolean = false;

  constructor(private loginService: LoginService, private router: Router, private messageService: MessageService) { }

  togglePasswordVisibility() {
    this.passwordVisible = !this.passwordVisible;
  }

  // authenticateForm(loginForm: NgForm) {
  //   if (loginForm.valid) {
  //     this.login = loginForm.value;
  //     this.loginService.authenticate(this.login).subscribe(
  //       (response: AuthResponse) => {
  //         this.messageService.add({
  //           severity: 'success',
  //           summary: 'Login Successful',
  //           detail: `Welcome ${response.username}!`,
  //         });
  //         console.log("Authenticated", response);
  //         localStorage.setItem("email", response.username);
  //         localStorage.setItem("token", response.token);
  //         localStorage.setItem("role", response.role);
  //         localStorage.setItem("id", response.id.toString());
  //         localStorage.setItem(
  //           "terms",
  //           JSON.stringify(response.termsAndConditions)
  //         );
  //         localStorage.setItem("user_tz", response.timezone);
  //         if (response.role === "SUPER_ADMIN") {
  //           this.router.navigate(["/superAdmin"]);
  //         } else if (
  //           ["CLINIC_OWNER", "CLINIC_ADMIN", "CLINIC_ASSOCIATE"].includes(
  //             response.role
  //           )
  //         ) {
  //           this.router.navigate(["/clinic"]);
  //         } else if (response.role === "PET_OWNER") {
  //           this.router.navigate(["/petOwners/pet-owner-home"]);
  //           sessionStorage.setItem(
  //             "stripeCustomerId",
  //             response.stripeCustomerId
  //           );
  //         } else if (response.role === "SALES_REP") {
  //           this.router.navigate(["/salesRep"]);
  //         }
  //         loginForm.resetForm();
  //       },
  //       error => {
  //         console.error("Authentication failed", error);

  //         loginForm.resetForm();
  //       }
  //     );
  //   } else {
  //     loginForm.resetForm();
  //   }
  // }

  authenticateForm(loginForm: NgForm) {
    if (loginForm.valid) {
      this.login = loginForm.value;
      this.isloaderVisible = true
      // this.loginService.authenticate(this.login).subscribe(
      //   (response: AuthResponse) => {
      //     this.isloaderVisible = false
      //     this.messageService.add({
      //       severity: 'success',
      //       summary: 'Login Successful',
      //       detail: `Welcome ${response.username}!`,
      //     });

      //     localStorage.setItem('email', response.username);
      //     localStorage.setItem('token', response.token);
      //     localStorage.setItem('role', response.role);
      //     localStorage.setItem('id', response.id.toString());
      //     localStorage.setItem(
      //       'terms',
      //       JSON.stringify(response.termsAndConditions)
      //     );
      //     localStorage.setItem('user_tz', response.timezone);

      //     setTimeout(() => {
      //       if (response.role === 'SUPER_ADMIN') {
      //         this.router.navigate(['/superAdmin']);
      //       } else if (
      //         ['CLINIC_OWNER', 'CLINIC_ADMIN', 'CLINIC_ASSOCIATE'].includes(
      //           response.role
      //         )
      //       ) {
      //         this.router.navigate(['/clinic']);
      //       } else if (response.role === 'PET_OWNER') {
      //         this.router.navigate(['/petOwners/pet-owner-home']);
      //         sessionStorage.setItem(
      //           'stripeCustomerId',
      //           response.stripeCustomerId
      //         );
      //       } else if (response.role === 'SALES_REP') {
      //         this.router.navigate(['/salesRep']);
      //       }
      //     }, 600);

      //   },
      //   (error) => {
      //     const errorMessage =
      //       error.status === 404
      //         ? 'No username found'
      //         : error.status === 401
      //           ? 'Invalid Login'
      //           : 'Login failed. Please try again.';
      //     this.isloaderVisible = false
      //     this.messageService.add({
      //       severity: 'error',
      //       summary: 'Login Failed',
      //       detail: errorMessage,
      //     });

      //     loginForm.resetForm();
      //   }
      // );

      this.loginService.authenticate(this.login).subscribe({
        next: (response: AuthResponse) => {
          console.log(response);
          this.isloaderVisible = false
          this.messageService.add({
            severity: 'success',
            summary: 'Login Successful',
            detail: `Welcome ${response.username}!`,
          });

          localStorage.setItem('email', response.username);
          localStorage.setItem('token', response.token);
          localStorage.setItem('role', response.role);
          localStorage.setItem('id', response.id.toString());
          localStorage.setItem(
            'terms',
            JSON.stringify(response.termsAndConditions)
          );
          localStorage.setItem('user_tz', response.timezone);

          setTimeout(() => {
            if (response.role === 'SUPER_ADMIN') {
              this.router.navigate(['/superAdmin']);
            } else if (
              ['CLINIC_OWNER', 'CLINIC_ADMIN', 'CLINIC_ASSOCIATE'].includes(
                response.role
              )
            ) {
              this.router.navigate(['/clinic']);
            } else if (response.role === 'PET_OWNER') {
              this.router.navigate(['/petOwners/pet-owner-home']);
              sessionStorage.setItem(
                'stripeCustomerId',
                response.stripeCustomerId
              );
            } else if (response.role === 'SALES_REP') {
              this.router.navigate(['/salesRep']);
            }
          }, 600);
        },
        error: (error) => {
          const errorMessage =
            error.status === 404
              ? 'No username found'
              : error.status === 401
                ? 'Invalid Login'
                : 'Login failed. Please try again.';
          this.isloaderVisible = false
          this.messageService.add({
            severity: 'error',
            summary: 'Login Failed',
            detail: errorMessage,
          });

          loginForm.resetForm();
        },
      });
    } else {
      this.messageService.add({
        severity: 'warn',
        summary: 'Invalid Input',
        detail: 'Please fill out all required fields correctly.',
      });
      loginForm.resetForm();
    }
  }
}
