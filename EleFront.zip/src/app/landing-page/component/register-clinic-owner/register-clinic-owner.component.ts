import { TIME_ZONES, TimeZone } from './../../../shared/constants/timeZone';
import { ClinicOwnerRegister } from './../../model/clinic-owner-register';
import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from '../../../shared/component/header/header.component';
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { LoginService } from '../../service/login.service';
import { CommonModule, NgIf } from '@angular/common';
import { US_STATES, UsaStates } from '../../../shared/constants/usa-states';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { HttpErrorResponse, HttpStatusCode } from '@angular/common/http';
import { NumberInputDirective } from '../../../shared/directives/number-input.directive';

@Component({
  selector: 'app-register-clinic-owner',
  standalone: true,
  imports: [
    HeaderComponent,
    ReactiveFormsModule,
    NgIf,
    CommonModule,
    ProgressSpinnerModule,
    ToastModule,
    NumberInputDirective,
  ],
  templateUrl: './register-clinic-owner.component.html',
  styleUrl: './register-clinic-owner.component.scss',
  providers: [MessageService],
})
export class RegisterClinicOwnerComponent {
  clinicOwnerForm = new FormGroup({
    firstName: new FormControl('', [Validators.required]),
    lastName: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    clinicName: new FormControl('', [Validators.required]),
    clinicAddress: new FormControl('', [Validators.required]),
    city: new FormControl('', [Validators.required]),
    state: new FormControl('', [Validators.required]),
    contact: new FormControl('', [Validators.required]),
    zipCode: new FormControl('', [
      Validators.required,
      Validators.pattern('^\\d{5}(-\\d{4})?$'),
    ]),
    timezone: new FormControl('', [Validators.required]),
    isHeadquarters: new FormControl(false),
    selectHeadquarters: new FormControl(''),
  });

  loader: boolean = false;
  states: UsaStates[] = US_STATES;
  timeZones: TimeZone[] = TIME_ZONES;
  headQuarter: any[] = [];
  constructor(
    private loginService: LoginService,
    private messageService: MessageService
  ) {}

  ngOnInit() {
    this.getHeadQuarter();
    this.clinicOwnerForm
      .get('isHeadquarters')
      ?.valueChanges.subscribe((isHQ) => {
        const selectHeadquartersControl =
          this.clinicOwnerForm.get('selectHeadquarters');

        if (isHQ) {
          selectHeadquartersControl?.clearValidators();
        } else {
          selectHeadquartersControl?.setValidators(Validators.required);
        }

        selectHeadquartersControl?.updateValueAndValidity();
      });
  }

  submitClinicOwner() {
    this.loader = true;
    if (this.clinicOwnerForm.invalid) {
      return;
    }
    const clinicOwnerPayload: ClinicOwnerRegister = {
      email: this.clinicOwnerForm.value.email!,
      clinicName: this.clinicOwnerForm.value.clinicName!,
      clinicAddress: this.clinicOwnerForm.value.clinicAddress!,
      city: this.clinicOwnerForm.value.city!,
      contact: this.clinicOwnerForm.value.contact!.toString(),
      zipCode: this.clinicOwnerForm.value.zipCode!.toString(),
      role: 'CLINIC_OWNER',
      firstName: this.clinicOwnerForm.value.firstName!,
      lastName: this.clinicOwnerForm.value.lastName!,
      state: this.clinicOwnerForm.value.state!,
      headquater: this.clinicOwnerForm.value.isHeadquarters!,
      headquaters: this.clinicOwnerForm.value.selectHeadquarters!,
      timezone: this.clinicOwnerForm.value.timezone!
    };
    this.loginService.requestAsClinicOwner(clinicOwnerPayload).subscribe({
      next: (response: string) => {
        this.loader = false;
        console.log('Response is success', response);
        this.clinicOwnerForm.reset();
        this.messageService.add({
          severity: 'success',
          summary: 'Thank you for your submission!',
          detail:
            'Your request has been received. Our team will review and verify the information provided. You will be notified once your request has been approved',
          life: 10000,
        });
      },
      error: (error: HttpErrorResponse) => {
        this.loader = false;
        console.log('Request Register Owner Error', error);
        if (error.status === HttpStatusCode.Conflict) {
          this.messageService.add({
            severity: 'error',
            summary: 'Email Already Exists',
            detail: 'Please use different Email address',
          });
          return;
        }
        this.messageService.add({
          severity: 'error',
          summary: 'Submission Failed',
          detail:
            'There was an error processing your request. Please try again later or contact support if the issue persists.',
        });
      },
    });
  }

  formatPhoneNumber(): void {
    let input = this.clinicOwnerForm.get('contact')?.value || '';
    input = input.replace(/\D/g, '');

    let formattedInput: string = '';

    if (input.length > 0) {
      formattedInput = `(${input.substring(0, 3)}`;
    }
    if (input.length >= 4) {
      formattedInput += `) ${input.substring(3, 6)}`;
    }
    if (input.length >= 7) {
      formattedInput += `-${input.substring(6, 10)}`;
    }

    this.clinicOwnerForm
      .get('contact')
      ?.setValue(formattedInput, { emitEvent: false });

    if (input.length === 10) {
      this.clinicOwnerForm
        .get('contact')
        ?.setValidators([
          Validators.required,
          Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/),
        ]);
    } else {
      this.clinicOwnerForm.get('contact')?.setValidators([Validators.required]);
    }

    this.clinicOwnerForm
      .get('contact')
      ?.updateValueAndValidity({ emitEvent: false });
  }

  getHeadQuarter() {
    this.loginService.getHeadQuarters().subscribe((response) => {
      this.headQuarter = response;
    });
  }
}
