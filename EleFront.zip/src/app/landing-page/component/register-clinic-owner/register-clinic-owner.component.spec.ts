import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterClinicOwnerComponent } from './register-clinic-owner.component';

describe('RegisterClinicOwnerComponent', () => {
  let component: RegisterClinicOwnerComponent;
  let fixture: ComponentFixture<RegisterClinicOwnerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RegisterClinicOwnerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegisterClinicOwnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
