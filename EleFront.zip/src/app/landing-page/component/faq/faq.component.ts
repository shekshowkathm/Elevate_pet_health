import { Component } from '@angular/core';
import { HeaderComponent } from '../../../shared/component/header/header.component';
import { FooterComponent } from '../../../shared/component/footer/footer.component';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { NgClass, NgFor } from '@angular/common';

@Component({
  selector: 'app-faq',
  standalone: true,
  imports: [
    NgClass,
    HeaderComponent,
    MatButtonModule,
    MatExpansionModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    NgFor,
    FooterComponent,
  ],
  templateUrl: './faq.component.html',
  styleUrl: './faq.component.scss',
})
export class FaqComponent {
  selectedIndex: number | null = null;
  faqs = [
    {
      question: 'What is Elevate Pet Health?',
      answer:
        'Elevate Pet Health is a pet wellness plan tailored towards your individual pet’s needs. Your doctor and technician will use your pet’s history and current health to build a plan designed to keep your pet happy and healthy for as long as possible.',
    },
    {
      question: 'What is Elevate Pet Health?',
      answer:
        'Elevate Pet Health is a pet wellness plan tailored towards your individual pet’s needs. Your doctor and technician will use your pet’s history and current health to build a plan designed to keep your pet happy and healthy for as long as possible.',
    },
    {
      question: 'What is Elevate Pet Health?',
      answer:
        'Elevate Pet Health is a pet wellness plan tailored towards your individual pet’s needs. Your doctor and technician will use your pet’s history and current health to build a plan designed to keep your pet happy and healthy for as long as possible.',
    },
    {
      question: 'What is Elevate Pet Health?',
      answer:
        'Elevate Pet Health is a pet wellness plan tailored towards your individual pet’s needs. Your doctor and technician will use your pet’s history and current health to build a plan designed to keep your pet happy and healthy for as long as possible.',
    },
    {
      question: 'What is Elevate Pet Health?',
      answer:
        'Elevate Pet Health is a pet wellness plan tailored towards your individual pet’s needs. Your doctor and technician will use your pet’s history and current health to build a plan designed to keep your pet happy and healthy for as long as possible.',
    },
    {
      question: 'What is Elevate Pet Health?',
      answer:
        'Elevate Pet Health is a pet wellness plan tailored towards your individual pet’s needs. Your doctor and technician will use your pet’s history and current health to build a plan designed to keep your pet happy and healthy for as long as possible.',
    },
  ];

  contactDetails: { icon: string; title: string; description: string }[] = [
    {
      icon: 'phone_android',
      title: 'Call Us',
      description: '(509) 367 - 9252',
    },
    {
      icon: 'chat',
      title: 'Contact Us',
      description: 'info@elevatepethealth.com',
    },
    {
      icon: 'local_post_office',
      title: 'Chat Us',
      description: 'Take to Real live Person',
    },
  ];
  faqsColumn2: any;


  selectIndex(i: number) {
    if (this.selectedIndex == i) {
      this.selectedIndex = null;
    } else {
      this.selectedIndex = i;
    }
  }
}

