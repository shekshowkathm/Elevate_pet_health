import { Component, inject, OnInit, signal } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { NumberInputDirective } from '../../../shared/directives/number-input.directive';
import { HttpErrorResponse } from '@angular/common/http';
import { LoginService } from '../../service/login.service';
import { ActiveClinic } from '../../model/clinic-owner-register';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';

@Component({
  selector: 'app-search-clinic',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    ProgressSpinnerModule,
    NumberInputDirective,
    ToastModule,
  ],
  templateUrl: './search-clinic.component.html',
  styleUrl: './search-clinic.component.scss',
  providers: [MessageService],
})
export class SearchClinicComponent implements OnInit {
  private loginService = inject(LoginService);
  searchClinic: FormGroup;
  loader: boolean = false;
  isSearched: boolean = false;

  filteredClinics = signal<ActiveClinic[]>([]);
  ClinicsList = signal<ActiveClinic[]>([]);

  suggestClinicForm = new FormGroup({
    clinicName: new FormControl('', Validators.required),
    city: new FormControl(''),
    state: new FormControl(''),
    zipcode: new FormControl(''),
    userEmail: new FormControl('', [Validators.required, Validators.email]),
  });

  constructor(private messageService: MessageService) {
    this.searchClinic = new FormGroup({
      clinicName: new FormControl('', [Validators.required]),
      city: new FormControl('', [Validators.required]),
      state: new FormControl('', [
        Validators.required,
        this.stateCodeValidator,
      ]),
      zipcode: new FormControl('', [
        Validators.required,
        this.zipcodeValidator,
      ]),
    });
  }
  ngOnInit(): void {
    this.fetchClinicList();
  }
  fetchClinicList() {
    this.loader = true;
    this.loginService.getActiveClinics().subscribe({
      next: (clinics: ActiveClinic[]) => {
        this.ClinicsList.set(clinics);
        this.loader = false;
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        console.log('errr fetch active clinics', err);
      },
    });
  }

  onSubmit() {
    this.isSearched = true;
    const { clinicName, city, state, zipcode } = this.searchClinic.value;
    if (clinicName || city || state || zipcode) {
      this.filteredClinics.set(
        this.ClinicsList().filter((clinic) => {
          return (
            (!clinicName ||
              clinic.clinicName
                .toLowerCase()
                .includes(clinicName.toLowerCase())) &&
            (!city || clinic.city.toLowerCase().includes(city.toLowerCase())) &&
            (!state || clinic.state.toLowerCase() === state.toLowerCase()) &&
            (!zipcode || clinic.zipCode === zipcode)
          );
        }),
      );
    } else {
      this.filteredClinics.set([]); // [...this.ClinicsList()];
    }
  }

  stateCodeValidator(control: AbstractControl) {
    const stateCodePattern = /^[a-zA-Z]{2}$/;
    return stateCodePattern.test(control.value)
      ? null
      : { invalidStateCode: true };
  }

  zipcodeValidator(control: AbstractControl) {
    const zipcodePattern = /^\d{5}$/;
    return zipcodePattern.test(control.value) ? null : { invalidZipcode: true };
  }

  onSuggestClinic() {
    if (this.suggestClinicForm.valid) {
      this.loader = true;
      const suggestion: {
        clinicName: string;
        city: string;
        zipCode: string;
        fromMail: string;
        state: string;
      } = {
        clinicName: this.suggestClinicForm.value.clinicName!,
        city: this.suggestClinicForm.value.city || '',
        zipCode: this.suggestClinicForm.value.zipcode || '',
        fromMail: this.suggestClinicForm.value.userEmail!,
        state: this.suggestClinicForm.value.state || '',
      };
      this.loginService.suggestClinic(suggestion).subscribe({
        next: (res: any) => {
          this.loader = false;
          this.suggestClinicForm.reset();
          this.messageService.add({
            severity: 'success',
            summary: 'Thank you for your submission!',
            detail: res,
          });
        },
        error: (err: HttpErrorResponse) => {
          console.log('err', err);
          this.loader = false;
          this.messageService.add({
            severity: 'error',
            summary: 'Submission Failed',
            detail:
              'There was an error processing your request. Please try again later or contact support if the issue persists.',
          });
        },
      });
    }
  }
}
