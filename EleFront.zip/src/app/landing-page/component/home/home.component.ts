import { AfterViewInit, Component, ElementRef } from '@angular/core';
import { HeaderComponent } from '../../../shared/component/header/header.component';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { FooterComponent } from '../../../shared/component/footer/footer.component';
import { RouterLink } from '@angular/router';
import { NgClass, NgIf } from '@angular/common';
import {
  DialogService,
  DynamicDialogModule,
  DynamicDialogRef,
} from 'primeng/dynamicdialog';
import { SearchClinicComponent } from '../search-clinic/search-clinic.component';
import { LoginService } from '../../service/login.service';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    HeaderComponent,
    FormsModule,
    FooterComponent,
    ReactiveFormsModule,
    RouterLink,
    NgClass,
    DynamicDialogModule,
    NgIf,
    ToastModule,
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
  providers: [DialogService, MessageService],
})
export class HomeComponent implements AfterViewInit {
  wellPlanedCareViewMore: boolean = false;
  emailForm = new FormGroup({
    emailAddress: new FormControl('', [Validators.required, Validators.email]),
  });
  ref: DynamicDialogRef | undefined;
  sroll_imgs: string[] = [
    'https://elevatepethealth-imagestorage.s3.us-east-1.amazonaws.com/media/rectangle-1.png',
    'https://elevatepethealth-imagestorage.s3.us-east-1.amazonaws.com/media/rectangle-2.png',
    'https://elevatepethealth-imagestorage.s3.us-east-1.amazonaws.com/media/rectangle-3.png',
    'https://elevatepethealth-imagestorage.s3.us-east-1.amazonaws.com/media/rectangle-4.png',
    'https://elevatepethealth-imagestorage.s3.us-east-1.amazonaws.com/media/rectangle-5.png',
  ];

  WhyChooseClinicList: {
    img: string;
    imgClass: string;
    heading: string;
    headingClass: string;
    subHeading: string;
    subHeadingClass: string;
    description: string;
    descriptionClass: string;
  }[] = [
    {
      img: '/assets/medical-checkup0.png',
      heading: 'Proactive Preventive Care',
      subHeading:
        'Regularly scheduled exams, vaccinations, and diagnostic screenings.',
      description: `Take control of your pet’s health by catching potential problems early, saving you emotional and financial strain in the long run. Early intervention leads to a happier, healthier pet and fewer surprises down the road.`,
      imgClass:
        'bg-[#007cda] rounded-full w-24 h-24 flex justify-center items-center mb-2 transform group-hover:-translate-y-20 transition-transform duration-500 ease-in-out',
      headingClass:
        'text-center font-semibold text-xl transform group-hover:-translate-y-20 transition-transform duration-500 ease-in-out',
      subHeadingClass:
        'text-center max-sm:text-sm max-sm:leading-none font-normal text-pretty transform opacity-0 group-hover:opacity-100 group-hover:-translate-y-20 transition-transform duration-500 ease-in-out leading-tight',
      descriptionClass:
        'text-xs text-center text-pretty absolute bottom-0 opacity-0 group-hover:opacity-100  transition-all duration-500 ease-in-out px-8 group-hover:translate-y-[-1%] [@media(min-width:400px)]:group-hover:translate-y-[-10%]',
    },
    {
      img: '/assets/medical-checkup1.png',
      heading: 'Cost Savings on Essential Care',
      subHeading: ' Bundled services at a discounted rate',
      description: `Wellness plans let you save money while ensuring your pet gets comprehensive care. By planning ahead, you reduce out-of-pocket expenses, creating financial stability without sacrificing your pet’s health.`,
      imgClass:
        'bg-[#007cda] rounded-full w-24 h-24 flex justify-center items-center mb-2 transform group-hover:-translate-y-20 transition-transform duration-500 ease-in-out',
      headingClass:
        'text-center font-semibold text-xl transform group-hover:-translate-y-20 transition-transform duration-500 ease-in-out',
      subHeadingClass:
        'text-center font-normal text-pretty transform opacity-0 group-hover:opacity-100 group-hover:-translate-y-20 transition-transform duration-500 ease-in-out leading-tight',
      descriptionClass:
        'text-xs text-center text-pretty absolute bottom-0 opacity-0 group-hover:opacity-100 group-hover:translate-y-[-10%] transition-all duration-500 ease-in-out px-8 max-sm:group-hover:translate-y-[-8%]',
    },
    {
      img: '/assets/medical-checkup2.png',
      heading: 'Tailored Plans for Every Life Stage',
      subHeading: 'Customized wellness plans for puppies, adults, and seniors',
      description: `Because every life stage has unique needs, wellness plans provide age-appropriate care tailored to your pet’s development, activity level, and risk factors. Your pet’s health stays optimized at every stage of life.`,
      imgClass:
        'bg-[#007cda] rounded-full w-24 h-24 flex justify-center items-center mb-2 transform group-hover:-translate-y-20 transition-transform duration-500 ease-in-out',
      headingClass:
        'text-center font-semibold text-xl transform group-hover:-translate-y-20 transition-transform duration-500 ease-in-out',
      subHeadingClass:
        'text-center font-normal text-pretty transform opacity-0 group-hover:opacity-100 group-hover:-translate-y-20 transition-transform duration-500 ease-in-out leading-tight',
      descriptionClass:
        'text-xs text-center text-pretty absolute bottom-0 opacity-0 group-hover:opacity-100 group-hover:translate-y-[-10%] transition-all duration-500 ease-in-out px-8 max-sm:group-hover:translate-y-[-1%]',
    },
    {
      img: '/assets/medical-checkup3.png',
      heading: 'Stress-Free Budgeting',
      subHeading: 'Affordable monthly payment options.',
      description: `Make pet care predictable and affordable. Monthly payments spread the cost of care, giving you peace of mind without the worry of unexpected expenses when your pet needs it most.`,
      imgClass:
        'bg-[#007cda] rounded-full w-24 h-24 flex justify-center items-center mb-2 transform group-hover:-translate-y-20 transition-transform duration-500 ease-in-out',
      headingClass:
        'text-center font-semibold text-xl transform group-hover:-translate-y-20 transition-transform duration-500 ease-in-out',
      subHeadingClass:
        'text-center font-normal text-pretty transform opacity-0 group-hover:opacity-100 group-hover:-translate-y-16 transition-transform duration-500 ease-in-out leading-tight',
      descriptionClass:
        'text-xs text-center text-pretty absolute bottom-0 opacity-0 group-hover:opacity-100 group-hover:translate-y-[-5%] group-hover:[@media(min-width:390px)]:translate-y-[-25%] group-hover:md:translate-y-[-25%] transition-all duration-500 ease-in-out px-8',
    },
    {
      img: '/assets/medical-checkup4.png',
      heading: 'Exclusive Member Perks',
      subHeading:
        'Discounts on additional services, easy access to pet records, and more',
      description: `Enjoy added value through exclusive offers, savings on services outside the plan, and 24/7 access to your pet’s health records for printing or emailing. The Elevate Pet blog keeps you informed with expert advice, empowering you to make the best decisions for your pet.`,
      imgClass:
        'bg-[#007cda] rounded-full w-24 h-24 flex justify-center items-center mb-2 transform group-hover:-translate-y-20 transition-transform duration-500 ease-in-out',
      headingClass:
        'text-center font-semibold text-lg max-sm:leading-none transform group-hover:-translate-y-20 transition-transform duration-500 ease-in-out',
      subHeadingClass:
        'text-center font-normal max-sm:text-sm max-sm:leading-none text-pretty transform opacity-0 group-hover:opacity-100 group-hover:-translate-y-20 transition-transform duration-500 ease-in-out leading-none [@media(min-width:400px)]:group-hover:-translate-y-16',
      descriptionClass:
        'text-xs text-center text-pretty absolute bottom-0 opacity-0 group-hover:opacity-100 group-hover:translate-y-[-1%] group-hover:md:translate-y-[-5%] transition-all duration-500 ease-in-out px-1 [@media(min-width:400px)]:px-4 sm:px-6 md:px-8',
    },
  ];
  constructor(
    private el: ElementRef,
    private dialogService: DialogService,
    private loginService: LoginService,
    private messageService: MessageService,
  ) {}

  ngOnInit() {
    if (typeof localStorage !== 'undefined') {
      localStorage.clear();
    }
  }
  ngAfterViewInit(): void {
    if (typeof IntersectionObserver !== 'undefined') {
      const sections =
        this.el.nativeElement.querySelectorAll('.animate-on-scroll');

      const observerOptions = {
        threshold: 0.5,
      };

      const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
          }
        });
      }, observerOptions);

      sections.forEach((section: Element) => {
        observer.observe(section);
      });
    }
  }

  submitEmailAddress() {
    if (this.emailForm.invalid) {
      this.emailForm.markAllAsTouched(); // Mark fields as touched to trigger validation
      return;
    }
    const email = this.emailForm.value.emailAddress;
    if (email) {
      this.loginService.stayInTouch({ email }).subscribe((res: any) => {
        console.log(res);
        this.messageService.add({
          severity: 'success',
          summary: 'Thank you for your submission!',
          detail: 'We\'re excited to have you join our community',
        });
        this.emailForm.reset();
      });
    } else {
      this.emailForm.reset();
    }
  }

  openSearchForClinics() {
    console.log('open to search clinic');

    this.ref = this.dialogService.open(SearchClinicComponent, {
      header:
        'Search nearby clinicSearch for a Participating Veterinary Clinic',
      styleClass: 'w-[80%] max-md:w-[90%]',
      contentStyle: { overflow: 'auto', 'min-height': '200px' },
      baseZIndex: 10000,
      maximizable: true,
    });
  }
}
