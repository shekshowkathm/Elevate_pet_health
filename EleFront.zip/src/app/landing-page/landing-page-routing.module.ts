import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './component/home/home.component';
import { AboutComponent } from './component/about/about.component';
import { WhyWellnessComponent } from './component/why-wellness/why-wellness.component';
import { FaqComponent } from './component/faq/faq.component';
import { LoginComponent } from './component/login/login.component';
import { RegisterAsPetOwnerComponent } from './component/register-as-pet-owner/register-as-pet-owner.component';
import { RegisterClinicOwnerComponent } from './component/register-clinic-owner/register-clinic-owner.component';
import { ForgotPasswordComponent } from './component/forgot-password/forgot-password.component';
import { ViewComponent } from './component/why-wellness/view/view.component';

const routes: Routes = [
  {
    path:"",
    component:HomeComponent
  },
  {
    path:"about",
    component:AboutComponent
  },
  {
    path:"why-wellness",
    component:WhyWellnessComponent,
  },
 {
    path:"view",
    component:ViewComponent,
  },
  {
    path:"faq",
    component:FaqComponent
  },
  {
    path:"login",
    component:LoginComponent
  },
  {
    path: "register-pet-owner",
    component: RegisterAsPetOwnerComponent
  },
  {
    path: "register-clinic-owner",
    component: RegisterClinicOwnerComponent
  },
  {
    path: "forgot-password",
    component: ForgotPasswordComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LandingPageRoutingModule { }
