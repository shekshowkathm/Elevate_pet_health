export class Login {
  username!: string;
  password!: string;
}

export class AuthResponse {

    id!:string;
    username!: string;
    token!:string;
    role!:string;
    response!:string
    termsAndConditions!: boolean
    stripeConnectedCustomerId!:string
    stripeCustomerId!:string
  timezone!: string;

}
