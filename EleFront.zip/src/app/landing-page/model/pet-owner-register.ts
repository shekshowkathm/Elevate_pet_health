export interface RequestPetOwnerRegister {
  id?: number;
  email: string;
  clinicName?: string;
  contact: string;
  clinicId?: number;
  role: string;
  firstName: string;
  lastName: string;
  timezone: string;
}
