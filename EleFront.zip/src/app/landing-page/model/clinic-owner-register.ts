export interface ClinicOwnerRegister {
  id?: number;
  email: string;
  clinicName: string;
  clinicAddress: string;
  city: string;
  contact: string;
  zipCode: string;
  role: string;
  firstName: string;
  lastName: string;
  state: string;
  headquater?: boolean;
  headquaters?: string;
  timezone: string;
}

export interface ActiveClinic {
  id?: number;
  clinicName: string;
  address: string;
  zipCode: string;
  city: string;
  state: string;
}

export interface ApprovedClinic {
  clinicName: string;
  clinicId: number;
  status: boolean;
}
