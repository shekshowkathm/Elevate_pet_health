import { ClinicAssociateComponent } from './components/clinic-associate/clinic-associate.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from './components/layout/layout.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ClinicAdminComponent } from './components/clinic-admin/clinic-admin.component';
import { PetOwnerComponent } from './components/pet-owner/pet-owner.component';
import { WellnessPlanSetupComponent } from './components/wellness-plan-setup/wellness-plan-setup.component';
import { ScheduledAppointmentsComponent } from './components/scheduled-appointments/scheduled-appointments.component';
import { SupportComponent } from './components/support/support.component';
import { ClinicDetailsComponent } from './components/clinic-details/clinic-details.component';
import { ClinicUserProfileComponent } from './components/clinic-user-profile/clinic-user-profile.component';
import { UpdateClinicDetailsComponent } from './components/update-clinic-details/update-clinic-details.component';
import { ClinicAdminCrudComponent } from './components/clinic-admin-crud/clinic-admin-crud.component';
import { ClinicNotificationComponent } from './components/clinic-notification/clinic-notification.component';
import { AddClinicAssociateComponent } from './components/add-clinic-associate/add-clinic-associate.component';
import { ViewClinicAssociateComponent } from './components/view-clinic-associate/view-clinic-associate.component';
import { ViewPetComponent } from './components/view-pet/view-pet.component';
import { RequestNewClinicComponent } from './components/request-new-clinic/request-new-clinic.component';
import { ServiceListPageComponent } from './components/service-list-page/service-list-page.component';
import { AddPetOwnerComponent } from './components/add-pet-owner/add-pet-owner.component';
import { AddWellnwssPlanComponent } from './components/add-wellnwss-plan/add-wellnwss-plan.component';
import { ChoosenPlansComponent } from './components/choosen-plans/choosen-plans.component';
import { CalendarComponent } from './components/calendar/calendar.component';
import { Roles } from '../shared/enum/roles';
import { authGuard } from '../shared/guards/auth.guard';
import { UpdateAddNewPlansComponent } from './components/update-add-new-plans/update-add-new-plans.component';
import { WellnessplanViewComponent } from './components/wellnessplan-view/wellnessplan-view.component';
import { TransactionDetailsComponent } from './components/transaction-details/transaction-details.component';
import { AlertsComponent } from './components/alerts/alerts.component';

const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: 'dashboard',
        component: DashboardComponent,
      },
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full',
      },
      {
        path: 'clinic-detail',
        component: ClinicDetailsComponent,
      },
      {
        path: 'update-clinic-detail',
        component: UpdateClinicDetailsComponent,
        canActivate: [authGuard],
        data: {
          roles: [Roles.CLINIC_OWNER, Roles.CLINIC_ADMIN],
        },
      },
      {
        path: 'clinic-admin',
        component: ClinicAdminComponent,
        canActivate: [authGuard],
        data: {
          roles: [Roles.CLINIC_OWNER],
        },
      },
      {
        path: 'add-clinic-admin',
        component: ClinicAdminCrudComponent,
        canActivate: [authGuard],
        data: {
          roles: [Roles.CLINIC_OWNER],
        },
      },
      {
        path: 'update-clinic-admin',
        component: ClinicAdminCrudComponent,
        canActivate: [authGuard],
        data: {
          roles: [Roles.CLINIC_OWNER],
        },
      },
      {
        path: 'clinic-associate',
        component: ClinicAssociateComponent,
        canActivate: [authGuard],
        data: {
          roles: [Roles.CLINIC_OWNER, Roles.CLINIC_ADMIN],
        },
      },
      {
        path: 'add-clinic-associate',
        component: AddClinicAssociateComponent,
        canActivate: [authGuard],
        data: {
          roles: [Roles.CLINIC_OWNER, Roles.CLINIC_ADMIN],
        },
      },
      {
        path: 'pet-owners',
        component: PetOwnerComponent,
      },
      {
        path: 'wellness-plan-details',
        component: WellnessPlanSetupComponent,
      },
      {
        path: 'scheduled-appointments',
        component: ScheduledAppointmentsComponent,
      },
      {
        path: 'support',
        component: SupportComponent,
      },
      {
        path: 'profile',
        component: ClinicUserProfileComponent,
      },
      {
        path: 'update-profile',
        component: ClinicUserProfileComponent,
      },
      {
        path: 'clinicNotification',
        component: ClinicNotificationComponent,
        canActivate: [authGuard],
        data: {
          roles: [Roles.CLINIC_OWNER, Roles.CLINIC_ADMIN],
        },
      },
      {
        path: 'view-associate/:id',
        component: ViewClinicAssociateComponent,
        canActivate: [authGuard],
        data: {
          roles: [Roles.CLINIC_OWNER, Roles.CLINIC_ADMIN],
        },
      },
      {
        path: 'transactions',
        component: TransactionDetailsComponent,
        canActivate: [authGuard],
        data: {
          roles: [Roles.CLINIC_OWNER, Roles.CLINIC_ADMIN],
        },
      },
      {
        path: 'service-list',
        component: ServiceListPageComponent,
      },
      {
        path: 'all-alerts',
        component: AlertsComponent,
      },
      {
        path: 'pet-owner/:ownerId/pet/:petId',
        component: ViewPetComponent,
      },
      {
        path: 'request-clinic',
        component: RequestNewClinicComponent,
        canActivate: [authGuard],
        data: {
          roles: [Roles.CLINIC_OWNER],
        },
      },
      {
        path: 'add-pet-owner',
        component: AddPetOwnerComponent,
      },
      {
        path: 'add-wellnes-plan/:petId',
        component: AddWellnwssPlanComponent,
      },
      {
        path: 'choosen-plans/:petId',
        component: ChoosenPlansComponent,
      },
      {
        path: 'calendar',
        component: CalendarComponent,
      },
      {
        path: 'update-new-plans/:wellnessPlanName/:managePetWellnessPlanId/:petId',
        component: UpdateAddNewPlansComponent,
      },
      {
        path: 'add-new-plans/:wellnessPlanName/:petId',
        component: UpdateAddNewPlansComponent,
      },
      {
        path: 'wellnessplan/view',
        component: WellnessplanViewComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ClinicRoutingModule {}
