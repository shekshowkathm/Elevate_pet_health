export interface ServiceDropdown {
  id: number;
  dropdown: string;
  priceBased: string;
  industryStandardPrice: string;
  priceForSmall: string;
  priceForMedium: string;
  priceForLarge: string;
  priceForXLarge: string;
  priceForQuantity: string;
}

export interface ServiceList {
  id: number;
  petType: string;
  service: string;
  dropdowns: ServiceDropdown[];
  status: boolean;
}

export interface transformedServiceList {
  id: number;
  petType: string;
  service: string;
  status: boolean;
  dropdownid: number;
  dropdown: string;
  priceBased: string;
  industryStandardPrice: string;
}
