export interface DashBoardsStats {
  associatesCount: number;
  petOwnersCount: number;
  petCounts:number;
  activePlansCount: number;
  expiringPlanCounts: number;
  creditCardIssuesCounts: number;
  todayPaymentsCount: number;
  salesRepsCount: number;
  totalClinicsCount: number;
  promotions: PromotionReminder[]; 
}
export interface PromotionReminder {
  promotion: string;
  expiryDate: string;
  pendingDays: number;
}