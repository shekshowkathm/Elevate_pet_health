export interface ClinicUser {
  id?: number;
  firstName: string;
  lastName: string;
  email?: string;
  profile?: string;
  designation?: string;
  contactNumber?: string;
  doctor?: boolean;
  state?: string;
  city?: string;
  zipcode?: string;
  address?: string;
  role?: string; // for payload
  timezone?: string;
  doctorsHistory?: DoctorFulfilmentHistory[];
}

export interface DoctorFulfilmentHistory {
  regId: number;
  serviceName: string;
  dropdownName: string;
  fulfilledStatus: string;
  paidAmount: number | null;
  doctorPercentage: string; // ex . "1"
  fulfilledOn: string;
  clinicName: string;
  petName: string;
}