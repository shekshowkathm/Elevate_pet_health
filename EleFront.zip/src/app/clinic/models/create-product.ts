export class CreateProduct {
  accountId?: string;
  productName?: string;
  price?: number;
  productDescription?: string;
  clinicWellnessUpdateId?: number;
  type?: string;
  discountpriceInCentsMedium?: number;
  discountpriceInCentsLarge?: number;
  discountpriceInCentsXLarge?: number;
  discountpriceInCentsSmall?: number;

  updatedPriceForLarge?: number;
  updatedPriceForMedium?: number;
  updatedPriceForSmall?: number;
  updatedPriceForXLarge?: number;

  stripeProductIdSmall?: string;
  stripeProductIdMedium?: string;
  stripeProductIdLarge?: string;
  stripeProductIdXLarge?: string;

  stripePriceIdSmall?: string;
  stripePriceIdMedium?: string;
  stripePriceIdLarge?: string;
  stripePriceIdXLarge?: string;

  size: any;
  productId?: string;
  priceId?: string;
}
