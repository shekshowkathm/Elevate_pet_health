export interface weightRangeResponse {
  petType: string;
  weight: string;
  size: string;
  updatedWeight: string;
  clinicWeightRangeId: number;
}
