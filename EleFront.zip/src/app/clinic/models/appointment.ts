export interface Appointment {
  petOwnerName: string;
  email: string;
  phoneNumber: string;
  petName: string;
  petType: string;
  dateOfAppoinment: string;
  status:string;
}
export interface CalendarAppointment {
  petName: string;
  serviceName: string;
  dropDown: string;
  clinicName: string;
  scheduledDateAndTime: string;
}
