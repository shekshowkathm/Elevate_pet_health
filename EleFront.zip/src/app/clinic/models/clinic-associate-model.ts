export interface ClinicAssociateDTO {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  designation: string;
  contact: string;
  profile: string;
  city: string;
  state: string;
  zipcode: string;
  clinicName: string;
  clinicEmail: string;
  doctor?: boolean;
  address?: string;
}

export interface AddClinicAssociate {
  email?: string;
  clinicId?: IdObject;
  role?: string;
  state?: string;
  city?: string;
  zipcode?: string;
  createdBy?: IdObject;
  firstName: string;
  lastName: string;
  doctor?: boolean;
  designation?: string;
  contactNumber?: string;
  address?: string;
  timezone?: string;
}
interface IdObject {
  id: number;
}
