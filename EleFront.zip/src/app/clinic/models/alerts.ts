export interface Alerts {
  name: string;
  phoneNumber: string;
  message: string;
  status: string;
  petId: number;
  petOwnerId: number;
  image: string;
}
