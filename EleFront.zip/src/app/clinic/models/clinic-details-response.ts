export interface ClinicDetailResponse {
  id?: number; // clinic id
  clinicName: string;
  address: string;
  zipCode: string;
  city: string;
  clinicOwnerId?: string;
  contactNumber?: string;
  email?: string;
  clinicImage?: string;
  clinicAdminId?: number;
  state?: string;
  qrCode?: string;
  // Added fields 31-12-2024
  clinicLogo?: string;
  socialLinkOne?: string;
  socialLinkTwo?: string;
  socialLinkThree?: string;
  socialLinkFour?: string;
}
