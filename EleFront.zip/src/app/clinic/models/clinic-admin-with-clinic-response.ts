export interface ClinicAdminWithClinicResponse {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  clinicName: string;
  city: string;
  profile: string;
  state: string;
  zipcode: string;
  contactNumber: string;
  clinicEmail: string;
  designation: string;
  status: boolean;
}
