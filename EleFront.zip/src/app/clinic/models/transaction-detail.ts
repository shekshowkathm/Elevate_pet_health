export interface TransactionDetail {
  id: number;
  invoiceNumber: string;
  paymentStatus: 'Paid' | 'Pending' | 'Overdue';
  dateReceived: string;
  amount: number;
}
