interface ClinicDropDown {
  id: number;
  dropdown: string;
}

interface ClinicWellnessPlan {
  clinicWellnessPlanId: number;
  petType: string;
  ageGroup: string;
  wellnessPlanName: string;
  serviceName: string;
  clinicDropDowns: ClinicDropDown[];
  petPlanStatus?: boolean;
}

interface WellnessPlanUpdate {
  wellnessUpdateId: number;
  updateRecommendation: string;
  discountPercentage: string;
  doctorPercentage: number | null;
  status: boolean;

  discountPriceForQuantity?: string;
  discountPriceForSmall?: string;
  discountPriceForMedium?: string;
  discountPriceForLarge?: string;
  discountPriceForXLarge?: string;

  updatedPriceForLarge?: string;
  updatedPriceForMedium?: string;
  updatedPriceForQuantity?: string;
  updatedPriceForSmall?: string;
  updatedPriceForXLarge?: string;

  priceBased: string;
}

export interface ChoosenPlans {
  choosePlanId: number;
  petId: number;
  petName: string;
  petImage: string;
  petOwnerId: number;
  petOwnerFirstName: string;
  petOwnerLastName: string;
  clinicWellnessPlan: ClinicWellnessPlan;
  wellnessPlanUpdate: WellnessPlanUpdate;
  status: string;
  pending?: boolean;
  confirmed?: boolean;
  petSize: string;
  serviceCount: number; // for Ui calculation purpose only
  choosePlanIds: number[]; // for store choose plan id to send in API

  // newly added props
  managePetWellnessPlanId?: number;
  startDate?: string;
  endDate?: string;
  promotions: string[];
}
