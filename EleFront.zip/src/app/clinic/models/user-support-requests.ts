export interface UserSupportRequest {
  id: number;
  name: string;
  email: string;
  phonenumber: string;
  message: string;
  image: string;
  replyMessage?: string;
  status?: string; // Pending , Responded
}
