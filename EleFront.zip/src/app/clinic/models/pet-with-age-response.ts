export interface PetWithAgeResponse {
  id: number;
  petType: string;
  breed: string;
  breedType: string;
  ageForPuppy: string;
  ageForKitten: string;
  ageForAdult: string;
  ageForSenior: string;
}
