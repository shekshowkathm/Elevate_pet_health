export interface RequestClinic {
  clinicName: string;
  address: string;
  zipCode: string;
  city: string;
  clinicOwnerId?: number;
  contactNumber: string;
  email: string;
  state: string;
  clinicImage?: string;
}
