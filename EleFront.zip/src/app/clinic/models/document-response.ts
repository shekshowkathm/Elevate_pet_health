export interface DocumentResponse {
  id?: number;
  documentUrl: string;
  uploadedByRole: string;
  uploadedById: number;
  targetType: string;
  targetId?: number | null;
  clinicId: number;
  uploadDate: string;
  description: string;
  fileSize: string;
}
