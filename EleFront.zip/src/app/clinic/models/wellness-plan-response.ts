export interface WellnessUpdate {
  wellnessUpdateId: number;
  updateRecommendation: string;
  clinicPrice: string;
  discountPercentage?: string;
  discountPrice: string;
  price: string;
  doctorPercentage: string;
  status: boolean;
  stripePriceId?: string;
  stripeProductId?: string;
  stipeAccountId?: string;
  // New fields
  discountPriceForQuantity?: string;
  discountPriceForSmall?: string;
  discountPriceForMedium?: string;
  discountPriceForLarge?: string;
  discountPriceForXLarge?: string;

  updatedPriceForLarge?: string;
  updatedPriceForMedium?: string;
  updatedPriceForQuantity?: string;
  updatedPriceForSmall?: string;
  updatedPriceForXLarge?: string;

  stripeProductIdSmall?: string;
  stripeProductIdMedium?: string;
  stripeProductIdLarge?: string;
  stripeProductIdXLarge?: string;

  stripePriceIdSmall?: string;
  stripePriceIdMedium?: string;
  stripePriceIdLarge?: string;
  stripePriceIdXLarge?: string;
  productId?: string;
  priceId?: string;
  priceBased: string;
}

export interface BasePrice {
  priceForSmall?: string;
  priceForMedium?: string;
  priceForLarge?: string;
  priceForXLarge?: string;
  priceForQuantity?: string;
}

export interface ClinicDropDown extends BasePrice {
  dropdown: string;
  priceBased: string;
  industryStandardPrice: string;
  recommendation: string;
  wellnessUpdate: WellnessUpdate;
}

export interface ClinicWellnessPlanWithPromotions {
  promotions: PromotionWithAvailabityStatus[];
  wellnessPlans: ClinicWellnessPlan[];
}

export interface PromotionWithAvailabityStatus {
  id: number;
  name: string;
  status: boolean;
}
export interface ClinicWellnessPlan {
  clinicWellnessPlanId?: number;
  petType: string;
  ageGroup: string;
  wellnessPlanName: string;
  serviceName: string;
  planStatus: string;
  clinicDropDowns: ClinicDropDown[];
  serviceFrequency: number;
}
export interface TransformedClinicWellnessPlan {
  clinicWellnessPlanId?: number;
  petType: string;
  ageGroup: string;
  wellnessPlanName: string;
  serviceName: string;
  dropdown: string;
  priceBased: string;
  industryStandardPrice: string | null;
  recommendation: string | null;
  wellnessUpdate: WellnessUpdate;
  serviceCount?: number; // calculation pupose only in Frontend
}

export interface UpdateNewSetPlansDTO {
  petId: number;
  clinicWellnessPlanId: number;
  clinicWellnessUpdateId: number;
  assignedById: number;
  managePetWellnessPlanId: number;
  serviceFrequency: number;
}

export interface AddNewSetPlans {
  petId: number;
  clinicWellnessPlanId: number;
  clinicWellnessUpdateId: number;
  assignedById: number;
  startDate: string;
  endDate: string;
  serviceFrequency: number;
}
