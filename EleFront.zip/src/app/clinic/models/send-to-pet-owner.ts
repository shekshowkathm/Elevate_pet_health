export interface SendToPetOwner {
  petId: number;
  petOwnerId?: number; // not need for add ne plans and update existing plans
  clinicWellnessPlan: number;
  clinicWellnessUpdate: number;
  sentBy: number;
  serviceFrequency: number;
  managePetWellnessPlanId?: number; // only for update existing plan
}
export interface SendToPetOwnerWithPromotions {
  promotionDiscounts: { id: number }[];
  choosePlans: SendToPetOwner[];
}
