export interface PetResponse {
  petName: string;
  petType: string;
  gender: string;
  petBreed: string;
  petAge: string;
  weight: string;
  image: string;
  dob: string;
}

export interface PetAndOwnerWithWellnessPlan {
  petOwnerId: number;
  petOwnerFirstName: string;
  petOwnerLastName: string;
  petOwnerEmail: string;
  petOwnerContact: string;
  petOwnerAddress: string | null;
  petOwnerState: string | null;
  petOwnerCity: string | null;
  petOwnerImage: string;
  petOwnerZipcode: string | null;
  petId: number;
  petName: string | null;
  petGender: string | null;
  petType: string | null;
  petBreed: string | null;
  petAge: string | null;
  petDOB: string | null;
  petWeight: string | null;
  petProfile: string;
  petSize: string;
  ageGroup: string | null;
  // newly added or modified fields
  historyPlans: PlanSets;
  ongoingPlans: PlanSets;
  futurePlans: PlanSets;
  stripeSubscriptionId: string | null;
  stripeCustomerId: string | null;
}
export interface PlanSets {
  [key: string]: PetWellnessPlan[];
}

export interface PetWellnessPlan {
  petId: number;
  petWellnessPlanId: number;
  petType: string | null;
  ageGroup: string | null;
  wellnessPlanName: string;
  serviceName: string;
  dropdownName: string;
  clinicPrice: string;
  discountPrice: string;
  clinicWellnessUpdate: number;
  clinicWellnessPlan: number;
  fulfilledBy: FulfilledBy | null;
  // fulfilled: boolean;
  scheduledDateAndTime: string;
  managePetWellnessPlan: any;
  updatedPrice?: string; // used in veiw pet table
  promotions: string[];
  status: string; // for ex: "FULFILLED", "ACTIVE"
}

export interface ManagePetWellnessPlans {
  id: number;
  startDate: string;
  endDate: string;
  petWellnessPlans: PetWellnessPlan[];
}

export interface FulfilledBy {
  regId: number;
  doctorName: string;
}
