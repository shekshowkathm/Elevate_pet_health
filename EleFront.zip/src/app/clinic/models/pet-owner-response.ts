export interface PetOwnerResponse {
  id?: number;
  ownerName: string;
  email: string;
  contact: string;
  petName: string;
  petType: string;
  petWeight: string;
}
export interface NotVerifiedPerOwner {
  email: string;
  contact: string;
  firstName: string;
  lastName: string;
  clinicId: number;
  role: string;
  id: number;
  profile: string;
  state: string;
  city: string;
  address: string;
  petId: number;
}
