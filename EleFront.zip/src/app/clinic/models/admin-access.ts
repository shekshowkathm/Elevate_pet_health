export interface AdminAccess {
  clinicAdminId: number;
  updateWeightRange: boolean;
  updateClinicPrice: boolean;
  updateRecommendation: boolean;
  updateDiscountPercentage: boolean;
  updateDiscountPrice: boolean;
  updateDoctorPercentage: boolean;
  viewPayment: boolean;
}
