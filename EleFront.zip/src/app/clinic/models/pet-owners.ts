export interface PetListWithOwnerIdDTO {
  id: number;
  ownerFirstName: string | null;
  ownerLastName: string | null;
  email: string;
  contact: string;
  petName: string;
  petType: string;
  petBreed: string;
  weight: string;
  profile: string | null; // Owner profile
  image: string | null; // Pet profile
  dob: string | null;
  clinicName?: string;
  clinicEmail?: string;
  clinicState?: string;
  clinicCity?: string;
  state: string | null;
  city: string | null;
  ageGroup?: string;
  ownerId: number;
  gender?: string;
  petAge?: string;
  // added fields(22-11-2024)
  pending?: boolean; 
  confirmedPlan?: boolean;
  paymentStatus?: string | null;
  petId?: number | null;
  petSize?: string;
}
