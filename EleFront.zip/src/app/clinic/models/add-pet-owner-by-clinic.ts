export interface AddPetOwnerByClinic {
  email: string;
  contact: string;
  firstName: string;
  lastName: string;
  petName: string;
  clinicId: number;
  role: string;
  createdById?: idObj;
  stripeAccountId: string;
  timezone: string;
}

interface idObj {
  id: number;
}
