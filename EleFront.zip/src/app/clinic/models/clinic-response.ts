export interface ClinicResponse {
  id: number;
  clinicName: string;
  address: string;
  zipCode: string;
  color?: string; // for showing differnt colors
  city?: string;
  contactNumber?: string;
  email?: string;
  clinicImage?: string;
  clinicStatus?: boolean;
  stripeAccountId: string;

  state?: string;
  headquater?: boolean;
  headquaters?: string;
}
