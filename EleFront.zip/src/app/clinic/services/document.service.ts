import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { environment } from '../../../environments/environment.development';
import { ClinicAuthService } from './clinic-auth.service';
import { DocumentResponse } from '../models/document-response';

@Injectable({
  providedIn: 'root',
})
export class DocumentService {
  private readonly API_END_POINT = environment.apiUrl;
  private clinicAuthService = inject(ClinicAuthService);
  private http = inject(HttpClient);
  constructor() {}

  /**
   * Returns the HTTP headers with authorization token.
   *
   * @returns {HttpHeaders} - HTTP headers with 'Content-Type' and 'Authorization' token.
   */
  getHeader(): HttpHeaders {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + this.clinicAuthService.getToken(),
    });
  }

  /**
   * Fetches documents uploaded by the SuperAdmin for the current clinic.
   *
   * @returns {Observable<DocumentResponse[]>} - An observable containing the list of documents uploaded by the SuperAdmin for the clinic.
   */
  fetchDoumentsUploadBySuperAdmin(): Observable<DocumentResponse[]> {
    const clinicId = this.clinicAuthService.getSelectedClinic();
    return this.http.get<DocumentResponse[]>(
      `${this.API_END_POINT}/api/documents/superadmin/clinic/${clinicId()}`,
      { headers: this.getHeader() },
    );
  }

  /**
   * Fetches documents uploaded by the clinic to the SuperAdmin.
   *
   * @returns {Observable<DocumentResponse[]>} - An observable containing the list of documents uploaded by the clinic to the SuperAdmin.
   */
  fetchDocumentUploadedByClinic(): Observable<DocumentResponse[]> {
    const clinicId = this.clinicAuthService.getSelectedClinic();
    return this.http.get<DocumentResponse[]>(
      `${this.API_END_POINT}/api/documents/clinic/${clinicId()}/superadmin`,
      { headers: this.getHeader() },
    );
  }

  /**
   * Uploads a document from the clinic to the SuperAdmin.
   *
   * @param {DocumentResponse} doc - The document object to be uploaded, containing information such as URL, upload date, description, and more.
   * @returns {Observable<DocumentResponse>} - An observable containing the response from the document upload operation.
   */
  uploadDocumentByClinicToSuperAdmin(
    doc: DocumentResponse,
  ): Observable<DocumentResponse> {
    return this.http.post<DocumentResponse>(
      `${this.API_END_POINT}/api/documents/upload`,
      doc,
      {
        headers: this.getHeader(),
      },
    );
  }

  /**
   * Fetches documents uploaded by the clinic to All pet owners.
   *
   * @returns {Observable<DocumentResponse[]>} - An observable containing the list of documents uploaded by the clinic to All pet owners.
   */
  fetchDocumentUploadedByClinicToAllPetOwners(): Observable<
    DocumentResponse[]
  > {
    const clinicId = this.clinicAuthService.getSelectedClinic()();
    return this.http.get<DocumentResponse[]>(
      `${this.API_END_POINT}/api/documents/clinic/${clinicId}/petowners/all`,
      {
        headers: this.getHeader(),
      },
    );
  }

  /**
   * Fetches documents uploaded by the clinic to the individual pet owner.
   * @param {number} petOwnerId - passing petowner id
   * @returns {Observable<DocumentResponse[]>} - An observable containing the list of documents uploaded by the clinic to individual pet owner.
   */
  fetchDocumentsUploadedByClinicToIndividualPetOwners(
    petId: number,
  ): Observable<DocumentResponse[]> {
    const clinicId = this.clinicAuthService.getSelectedClinic()();
    return this.http.get<DocumentResponse[]>(
      `${this.API_END_POINT}/api/documents/clinic/${clinicId}/to-petowner/${petId}`,
      {
        headers: this.getHeader(),
      },
    );
  }

  /**
   * Fetches documents uploaded by pet owner to the Clinic.
   * @param {number} petOwnerId - passing petowner id
   * @returns {Observable<DocumentResponse[]>} - An observable containing the list of documents uploaded by the  pet owner to the Clinic.
   */
  fetchDocumentsUploadedByIndividualPetOwnerToClinic(
    petOwnerId: number,
  ): Observable<DocumentResponse[]> {
    const clinicId = this.clinicAuthService.getSelectedClinic()();
    return this.http.get<DocumentResponse[]>(
      `${this.API_END_POINT}/api/documents/clinic/${clinicId}/from-petowner/${petOwnerId}`,
      {
        headers: this.getHeader(),
      },
    );
  }
}
