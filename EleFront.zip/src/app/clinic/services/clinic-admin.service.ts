import { AdminAccess } from './../models/admin-access';
import { inject, Injectable, signal } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment.development';
import { ClinicAuthService } from './clinic-auth.service';
import { ClinicAdminWithClinicResponse } from '../models/clinic-admin-with-clinic-response';

@Injectable({
  providedIn: 'root',
})
export class ClinicAdminService {
  clinicAdminDetail$ = signal<ClinicAdminWithClinicResponse | null>(null);
  private readonly API_END_POINT = environment.apiUrl;
  private clinicAuthService = inject(ClinicAuthService);
  private http = inject(HttpClient);
  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: 'Bearer ' + this.clinicAuthService.getToken(),
  });
  constructor() {}

  getClinicAdminDetails() {
    return this.http.get(
      `${
        this.API_END_POINT
      }/clinic-details/get-Clinic-admin/${this.clinicAuthService.getSelectedClinic()()}`,
      { headers: this.headers }
    );
  }

  AddclinicAdminAndAssociate(payloadObj: any) {
    const body = {
      ...payloadObj,
      createdBy: {
        id: this.clinicAuthService.getUserId(),
      },
      clinicId: {
        id: this.clinicAuthService.getSelectedClinic()(),
      },
    };
    return this.http.post(
      `${this.API_END_POINT}/clinic-details/addClinicAdminAndAssociate`,
      body,
      {
        headers: this.headers,
        responseType: 'text',
      }
    );
  }

  fetchClinicAdminAccess(clinicAdminId: number) {
    return this.http.get(
      `${this.API_END_POINT}/clinic-details/getAdminAccess/${clinicAdminId}`,
      { headers: this.headers }
    );
  }

  updateClinicAdminAccess(adminAccess: AdminAccess) {
    return this.http.put(
      `${this.API_END_POINT}/clinic-details/updateAdminAccess`,
      adminAccess,
      { headers: this.headers, responseType: 'text' }
    );
  }
}
