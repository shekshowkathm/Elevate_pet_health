import { TestBed } from '@angular/core/testing';

import { ClinicAssociateService } from './clinic-associate.service';

describe('ClinicAssociateService', () => {
  let service: ClinicAssociateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ClinicAssociateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
