import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { environment } from '../../../environments/environment.development';
import { ClinicAuthService } from './clinic-auth.service';
import { Observable } from 'rxjs';
import { loadStripe, Stripe, StripeElements } from '@stripe/stripe-js';
declare var Stripe: any;

@Injectable({
  providedIn: 'root',
})
export class StripeService {
  public baseUrl = environment.apiUrl + '/stripe';
  private apiUrl1 = environment.apiUrl + '/stripe/create-checkout-session';

  constructor(private http: HttpClient) {}
  private clinicAuthService = inject(ClinicAuthService);
  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: 'Bearer ' + this.clinicAuthService.getToken(),
  });

  createProduct(data: any) {
    return this.http.put(this.baseUrl + '/createProduct', data, {
      headers: this.headers,
      responseType: 'text',
    });
  }
  priceUpdateStripe(data: any) {
    return this.http.put(this.baseUrl + '/update-stripe-price', data, {
      headers: this.headers,
      responseType: 'text',
    });
  }

  createCheckoutSession(priceId: string, customerId: string): Observable<any> {
    return this.http.post<any>(this.apiUrl1, { priceId, customerId });
  }
  createSubscription(data: any) {
    return this.http.post(this.baseUrl + '/createSubscription', data, {
      headers: this.headers,
      responseType: 'text' as 'json',
    });
  }
  getAllStripeProduct() {
    return this.http.get(this.baseUrl + '/get-all-stripe-product', {
      headers: this.headers,
    });
  }
  getPaymentStatus(data: any) {
    return this.http.get(this.baseUrl + '/getPaymentStatus', {
      headers: this.headers,
    });
  }
  getExpiringCard() {
    return this.http.get(this.baseUrl + '/getExpiringCard', {
      headers: this.headers,
    });
  }
  stripeAccountStatus(stripeId: string) {
    return this.http.get(`${this.baseUrl}/stripe-account-status/${stripeId}`, {
      headers: this.headers,
    });
  }
  gettodayEaringByclinic(stripeId: string) {
    return this.http.get(`${this.baseUrl}/todayEarningByClinic/${stripeId}`, {
      headers: this.headers,
    });
  }
  getCardDetails(cusomerId: string | null) {
    return this.http.get(`${this.baseUrl}/getCardDetails/${cusomerId}`, {
      headers: this.headers,
    });
  }
  initiateCard() {
    return this.http.get(this.baseUrl + '/initiateCard', {
      headers: this.headers,
    });
  }
  addCard(token: any, customerId: any) {
    return this.http.post(
      this.baseUrl + '/addcard',
      { token, customerId },
      { headers: this.headers, responseType: 'text' },
    );
  }
  attachCardDetails(
    customerId: string,
    paymentMethodId: string,
    isDefaultPayment: boolean,
  ): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + this.clinicAuthService.getToken(),
    });
    const body = { customerId, paymentMethodId, isDefaultPayment };
    return this.http.post<any>(this.baseUrl + '/attach-card', body, {
      headers,
    });
  }
  UpdateStripeStatus(regId: any): Observable<string> {
    return this.http.put<string>(
      `${this.baseUrl}/UpdateStripeStatus/${regId.registerId}`,
      regId,
      { headers: this.headers, responseType: 'text' as 'json' },
    );
  }

  UpdateStripe(regId: any): Observable<string> {
    return this.http.put<string>(
      `${this.baseUrl}/UpdateStripeStatus/${regId.id}`,
      regId,
      { headers: this.headers, responseType: 'text' as 'json' },
    );
  }

  getCards(customerId: string) {
    return this.http.get(`${this.baseUrl}/getcard/${customerId}`, {
      headers: this.headers,
    });
  }
  removeCard(data: any) {
    return this.http.put(
      `${this.baseUrl}/removeCard/${data.customerId}`,
      data,
      { headers: this.headers },
    );
  }
  stripeSubscriptionId(stripeSubscriptionId: any) {
    return this.http.get(
      `${this.baseUrl}/getSubscriptionId/${stripeSubscriptionId}`,
      { headers: this.headers },
    );
  }
  stripeSchedSubscriptionId(stripeSubscriptionId: any) {
    return this.http.get(
      `${this.baseUrl}/getSchSubscriptionId/${stripeSubscriptionId}`,
      { headers: this.headers },
    );
  }
  cancelStripeSubscription(stripeSubscriptionId: any) {
    return this.http.get(
      `${this.baseUrl}/cancelSubscription/${stripeSubscriptionId}`,
      { headers: this.headers },
    );
  }
  updateSubscription(data: any) {
    return this.http.put(`${this.baseUrl}/updateSubscription`, data, {
      headers: this.headers,
    });
  }
  creactCoupanCode(data: any) {
    return this.http.post(this.baseUrl + '/generateCoupon', data, {
      headers: this.headers,
      responseType: 'text',
    });
  }
  validateCoupon(data: any) {
    return this.http.put(
      `${this.baseUrl}/validateCoupon/${data.clinicId}/${data.promotionType}`,
      data,
      {
        headers: this.headers,
        responseType: 'text' as 'json',
      },
    );
  }
  deleteCoupon(data: any) {
    return this.http.put(
      `${this.baseUrl}/deleteCoupon/${data.stripeCouponId}`,
      data,
      {
        headers: this.headers,
        responseType: 'text' as 'json',
      },
    );
  }
  getLastSixMonthsPayments():Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl + '/last-six-months', {
      headers: this.headers,
    });
  }
  getBalance():Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl + '/balance', { headers: this.headers });
  }

  upcomingPayments() {
    return this.http.get(this.baseUrl + '/upcomingPayments', {
      headers: this.headers,
    });
  }
  getPetDetails(data: any) {
    return this.http.get(`${this.baseUrl}/getPetDetails/${data}`, {
      headers: this.headers,
    });
  }

  getExpiryDetailsByClinic(accountId: string) {
    return this.http.get(
      `${this.baseUrl}/getExpiryDetailsByClinic/${accountId}`,
      { headers: this.headers },
    );
  }
  getExpiryDetailscustomer(cusomerId: string) {
    return this.http.get(
      `${this.baseUrl}/getExpiryDetailscustomer/${cusomerId}`,
      { headers: this.headers },
    );
  }
  getSalesExpDetails(salesRepsId: number) {
    return this.http.get(`${this.baseUrl}/getSalesExpDetails/${salesRepsId}`, {
      headers: this.headers,
    });
  }
  refreshAccountLink(data: any) {
    return this.http.post(`${this.baseUrl}/refreshAccountLink`, data, {
      headers: this.headers,
      responseType: 'text' as 'json',
    });
  }
  reSendAccountLink(data: any) {
    return this.http.post(`${this.baseUrl}/reSendAccountLink`, data, {
      headers: this.headers, responseType: 'text' as 'json',
    });
  }
  getPaidMonthsForSubscription(data:String){
    return this.http.get(`${this.baseUrl}/getPaidMonthsForSubscription/${data}`,{headers:this.headers})
  }
  reActiveSubscription(data:any){
    return this.http.post(this.baseUrl+"/reActiveSubscription",data,{
      headers: this.headers,
      responseType: 'text' as 'json',
    })
  }
  cardExpiration(customerId:string | null){
    return this.http.get(`${this.baseUrl}/checkCardExpiration/${customerId}`,{headers:this.headers})
  }
}
