import {
  Injectable,
  Inject,
  PLATFORM_ID,
  signal,
  computed,
} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class ClinicAuthService {
  private selectedClinic = signal<number | null>(null);

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {
    if (isPlatformBrowser(this.platformId)) {
      const selectedClinic = JSON.parse(
        localStorage.getItem('selectedClinic') as string,
      );
      if (selectedClinic) {
        this.selectedClinic.set(selectedClinic);
      }
    }
  }
  computedSelectedClinic = computed(() => this.selectedClinic());

  getTerms() {
    if (isPlatformBrowser(this.platformId)) {
      const terms = localStorage.getItem('terms');
      return terms ? JSON.parse(terms) : null;
    }
    return null;
  }

  setTermsAndConditions(arg: boolean) {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('terms', JSON.stringify(arg));
    }
  }

  getRole() {
    if (isPlatformBrowser(this.platformId)) {
      return localStorage.getItem('role') ?? '';
    }
    return '';
  }

  getEmail() {
    if (isPlatformBrowser(this.platformId)) {
      return localStorage.getItem('email') ?? '';
    }
    return '';
  }

  getUserId() {
    if (isPlatformBrowser(this.platformId)) {
      const id = localStorage.getItem('id');
      return id ? Number(id) : undefined;
    }
    return undefined;
  }

  getToken() {
    if (isPlatformBrowser(this.platformId)) {
      return localStorage.getItem('token') ?? '';
    }
    return '';
  }

  logout() {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.clear();
      this.clearSelectedClinic();
      sessionStorage.clear();
    }
  }

  setSelectedClinic(clinicId: number) {
    if (isPlatformBrowser(this.platformId)) {
      this.selectedClinic.set(clinicId);
      localStorage.setItem('selectedClinic', JSON.stringify(clinicId));
    }
  }

  getSelectedClinic() {
    return this.selectedClinic;
  }

  setSelectedClinicEmail(clinicEmail: string) {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('selectedClinicEmail', clinicEmail);
    }
  }

  getSelectedClinicEmail() {
    if (isPlatformBrowser(this.platformId)) {
      return localStorage.getItem('selectedClinicEmail') ?? '';
    }
    return '';
  }

  clearSelectedClinic() {
    if (isPlatformBrowser(this.platformId)) {
      this.selectedClinic.set(null);
      localStorage.removeItem('selectedClinic');
    }
  }

  getUserTimeZone(): string {
    if (isPlatformBrowser(this.platformId)) {
      return localStorage.getItem('user_tz') ?? '';
    }
    return '';
  }

  setUserTimeZone(timeZone: string) {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('user_tz', timeZone);
    }
  }

  getHeadquarterId(): number | null {
    return JSON.parse(localStorage.getItem('elevate_clhq') as string);
  }

  setHeadquarterId(id: number | null) {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('elevate_clhq', JSON.stringify(id));
    }
  }
  removeHeadquarters() {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('elevate_clhq');
    }
  }

  setPromotions(length: number) {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('elevate_clpmo', JSON.stringify(length));
    }
  }

  getPromotions(): number {
    const promolength = JSON.parse(
      localStorage.getItem('elevate_clpmo') as string,
    ) as number;
    return promolength ?? 0;
  }
  removePromotion() {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('elevate_clpmo');
    }
  }
}
