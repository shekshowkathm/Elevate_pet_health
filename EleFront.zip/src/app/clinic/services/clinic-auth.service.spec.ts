import { TestBed } from '@angular/core/testing';

import { ClinicAuthService } from './clinic-auth.service';

describe('ClinicAuthService', () => {
  let service: ClinicAuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ClinicAuthService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
