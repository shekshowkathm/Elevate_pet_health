import { inject, Injectable, signal } from '@angular/core';
import { ClinicAuthService } from './clinic-auth.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment.development';
import {
  AddClinicAssociate,
  ClinicAssociateDTO,
} from '../models/clinic-associate-model';
import { ClinicUser } from '../models/clinic-user';
import { tap } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ClinicAssociateService {
  clinicAssociateDetails = signal<ClinicAssociateDTO[]>([]);
  currentClinicAssociate = signal<ClinicUser | null>(null);
  private clinicAuthService = inject(ClinicAuthService);
  private readonly API_END_POINT = environment.apiUrl;
  private http = inject(HttpClient);
  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: 'Bearer ' + this.clinicAuthService.getToken(),
  });
  constructor() {}

  getClinicAssociateDetails() {
    return this.http.get(
      `${
        this.API_END_POINT
      }/clinic-details/get-Clinic-associates/${this.clinicAuthService.getSelectedClinic()()}`,
      { headers: this.headers }
    );
  }

  AddclinicAssociate(payloadObj: any) {
    const body: AddClinicAssociate = {
      ...payloadObj,
      createdBy: {
        id: this.clinicAuthService.getUserId(),
      },
      clinicId: {
        id: this.clinicAuthService.getSelectedClinic()(),
      },
    };
    return this.http.post(
      `${this.API_END_POINT}/clinic-details/addClinicAdminAndAssociate`,
      body,
      {
        headers: this.headers,
        responseType: 'text',
      }
    );
  }

  /**
   *
   * @param associateId Fetch individula clinic associate
   * @returns ClinicUser
   */
  fetchClinicAssociateById(associateId: number) {
    return this.http
      .get(`${this.API_END_POINT}/clinic-details/get-profile/${associateId}`, {
        headers: this.headers,
      })
      .pipe(
        tap((clinicUser) => {
          this.currentClinicAssociate.set(clinicUser as ClinicUser);
        })
      );
  }
}
