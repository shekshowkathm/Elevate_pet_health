import {
  effect,
  Inject,
  inject,
  Injectable,
  OnDestroy,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { environment } from '../../../environments/environment.development';
import { ClinicAuthService } from './clinic-auth.service';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { ClinicDetailResponse } from '../models/clinic-details-response';
import { Observable, tap } from 'rxjs';
import { NotVerifiedPerOwner } from '../models/pet-owner-response';
import { ClinicUser } from '../models/clinic-user';
import { RequestClinic } from '../models/request-clinic';
import { AddPetOwnerByClinic } from '../models/add-pet-owner-by-clinic';
import { isPlatformBrowser } from '@angular/common';
import { DashBoardsStats } from '../models/dashboard-statts';
import { ClinicResponse } from '../models/clinic-response';
import { Alerts } from '../models/alerts';

@Injectable({
  providedIn: 'root',
})
export class ClinicService implements OnDestroy {
  private readonly API_END_POINT = environment.apiUrl;
  private clinicAuthService = inject(ClinicAuthService);
  private http = inject(HttpClient);
  public updateStatusOfPetAPI =
    environment.apiUrl + '/pet-detials/update-status/';

  notVerifiedPerOwnersSignal = signal<NotVerifiedPerOwner[] | null>(null);
  userDataSignal = signal<ClinicUser | null>(null);
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      if (this.clinicAuthService.getRole() !== 'CLINIC_ASSOCIATE') {
        effect(() => {
          const clinic = this.clinicAuthService.computedSelectedClinic();
          if (clinic) {
            this.callNotVerifiedOwnersMethod();
          }
        });
      }
    }
  }

  callNotVerifiedOwnersMethod() {
    const clinic = this.clinicAuthService.computedSelectedClinic();
    if (clinic) {
      this.notVerifiedPetOwner().subscribe({
        next: (val: NotVerifiedPerOwner[]) => {
          this.notVerifiedPerOwnersSignal.set(val);
        },
        error: (err: HttpErrorResponse) => {
          console.log('Errpr Fetch not verified petowners', err);
        },
      });
    }
  }

  ngOnDestroy(): void {
    this.userDataSignal.set(null);
    this.notVerifiedPerOwnersSignal.set(null);
  }

  private createHeaders(): HttpHeaders {
    const token = this.clinicAuthService.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: token ? `Bearer ${token}` : '',
    });
  }

  /**
   * API for get cliics
   * @returns list of clinis
   */
  getClinicList() {
    return this.http.get(
      `${
        this.API_END_POINT
      }/clinic-details/clinicDetails/${this.clinicAuthService.getUserId()}/${this.clinicAuthService.getRole()}`,
      { headers: this.createHeaders() },
    );
  }

  /**
   * here use User's register id that who accept the terms and conditions
   */
  updateTermsAndConditions() {
    return this.http.put(
      `${
        this.API_END_POINT
      }/register/terms-and-conditions/${this.clinicAuthService.getUserId()}`,
      null,
      { headers: this.createHeaders(), responseType: 'text' },
    );
  }

  /**
   * Update User Password
   */
  UpdatePassword(password: string) {
    const body = {
      regId: this.clinicAuthService.getUserId(),
      password,
    };
    return this.http.put(
      `${this.API_END_POINT}/register/updatePassword`,
      body,
      { headers: this.createHeaders(), responseType: 'text' },
    );
  }

  /**
   * Get current clinic status
   *
   *
   */
  getCurrentClinicalDetails() {
    const clinic = this.clinicAuthService.getSelectedClinic();
    return this.http.get(
      `${this.API_END_POINT}/clinic-details/get-Clinic/${clinic()}`,
      { headers: this.createHeaders() },
    );
  }

  /**
   * Update Current Clinic Details
   *
   * return `Clinic details updated successfully`
   */
  UpdateCurrentClinicDetails(cilicObj: ClinicDetailResponse) {
    return this.http.put(
      `${this.API_END_POINT}/clinic-details/update`,
      cilicObj,
      { headers: this.createHeaders(), responseType: 'text' },
    );
  }
  /**
   * @returns notVerifiedPetOwner
   */
  notVerifiedPetOwner(): Observable<NotVerifiedPerOwner[]> {
    const clinicId = this.clinicAuthService.getSelectedClinic()();
    return this.http.get<NotVerifiedPerOwner[]>(
      `${this.API_END_POINT}/pet-detials/notVerifiedPetOwners/${clinicId}`,
      { headers: this.createHeaders() },
    );
  }
  /**
   * @param regId
   * @returns
   */
  verifiedPetOwner(regId: any): Observable<string> {
    return this.http.put<string>(
      `${this.API_END_POINT}/register/updateRegisterStatus/${regId.id}`,
      regId,
      { headers: this.createHeaders(), responseType: 'text' as 'json' },
    );
  }

  /**
   * Method to update status of pet
   * @param petID
   * @returns
   */
  updatePetStatus(petID: number | null): Observable<any> {
    return this.http.put(this.updateStatusOfPetAPI + petID, '', {
      headers: this.createHeaders(),
    });
  }

  /**
   * Update User data clinic owner, clinic admin, clinic associate
   */
  UpadateClinicUser(payload: ClinicUser) {
    return this.http.put(
      `${this.API_END_POINT}/register/update-profile`,
      payload,
      { headers: this.createHeaders(), responseType: 'text' },
    );
  }

  /**
   * Get Current logged In user using userId
   */
  getCurrentClinicLoggedInUser(): Observable<ClinicUser> {
    return this.http
      .get<ClinicUser>(
        `${
          this.API_END_POINT
        }/clinic-details/get-profile/${this.clinicAuthService.getUserId()}`,
        { headers: this.createHeaders() },
      )
      .pipe(
        tap((user: ClinicUser) => {
          if (user.timezone) {
            this.clinicAuthService.setUserTimeZone(user.timezone);
          }
        }),
      );
  }

  /**
   * fetch user by userId(registerId)
   * return type ClinicUser
   */
  fetchUserById(userId: number) {
    return this.http.get(
      `${this.API_END_POINT}/clinic-details/get-profile/${userId}`,
      { headers: this.createHeaders() },
    );
  }

  /**
   * Retrieves a list of Pet Owners.
   * Accessible by Clinic Owner, Clinic Admin, and Clinic Associate roles.
   * Returns the Pet Owner list as a PetOwnersDTO type.
   */
  fetchPetOwnersList() {
    const clinicId = this.clinicAuthService.getSelectedClinic();
    return this.http.get(
      `${this.API_END_POINT}/clinic-details/get-pet-details/${clinicId()}`,
      { headers: this.createHeaders() },
    );
  }

  /**
   * Fetch pets by using pet owner ID
   * @param petOwnerId
   */
  fetchPetsByPetOwnerId(petOwnerId: number) {
    return this.http.get(
      `${this.API_END_POINT}/pet-detials/get-pets/${petOwnerId}`,
      { headers: this.createHeaders() },
    );
  }

  /**
   * Submits a request for establishing a new clinic. This request can be made by the clinic owner.
   * @param {RequestClinic} payload - The data required to process the clinic request.
   * @returns {string} - Confirmation message indicating the clinic has been added.
   */
  RequestForNewClinic(payload: RequestClinic): Observable<string> {
    const requstObject: RequestClinic = {
      ...payload,
      clinicOwnerId: this.clinicAuthService.getUserId(),
    };
    return this.http.post(
      `${this.API_END_POINT}/clinic-details/add-clinic`,
      requstObject,
      { headers: this.createHeaders(), responseType: 'text' },
    );
  }

  /**
   * Method to add Pet Owner by clinic
   *
   */
  addPetOwnerByClinic(addPetOwnerByClinic: AddPetOwnerByClinic) {
    const requestBody: AddPetOwnerByClinic = {
      ...addPetOwnerByClinic,
      createdById: {
        id: this.clinicAuthService.getUserId()!,
      },
      clinicId: this.clinicAuthService.getSelectedClinic()()!,
      stripeAccountId: localStorage.getItem('1') || '',
    };
    return this.http.post(
      `${this.API_END_POINT}/pet-detials/add-New-Pet-Owner`,
      requestBody,
      { headers: this.createHeaders(), responseType: 'text' },
    );
  }

  /**
   * Asscessible by Clinic Owner Clinic Admin
   * @returns {string} - QR conde link that has beed generated
   */
  generateQRCode() {
    const clinicId = this.clinicAuthService.getSelectedClinic()();
    return this.http.post(
      `${this.API_END_POINT}/clinic-details/generateQRCode/${clinicId}`,
      {},
      { headers: this.createHeaders(), responseType: 'text' },
    );
  }

  UpdateStripeStatus(regId: any): Observable<string> {
    return this.http.put<string>(
      `${this.API_END_POINT}/register/UpdateStripeStatus/${regId.id}`,
      regId,
      { headers: this.createHeaders(), responseType: 'text' as 'json' },
    );
  }

  fetchSupportQuries() {
    const clinicEmail = this.clinicAuthService.getSelectedClinicEmail();
    const url = `${this.API_END_POINT}/support/get/${clinicEmail}`;
    return this.http.get(url, { headers: this.createHeaders() });
  }

  /**
   * Fetches dashboard statistics for the selected clinic.
   *
   * @returns {Observable<DashBoardsStats>} An observable containing the clinic dashboard statistics.
   */
  fetchClinicDashBoardStats(): Observable<DashBoardsStats> {
    const clinicId = this.clinicAuthService.getSelectedClinic()();
    const url = `${this.API_END_POINT}/counts/clinic/${clinicId}`;
    return this.http.get<DashBoardsStats>(url, {
      headers: this.createHeaders(),
    });
  }

  fetchSubClinicList() {
    const headquarterId = this.clinicAuthService.getHeadquarterId();
    const url = `${this.API_END_POINT}/clinic-details/sub-clinics/${headquarterId}`;
    return this.http.get<ClinicResponse[]>(url, {
      headers: this.createHeaders(),
    });
  }

  /**
   * Fetches alerts for plans that need confirmation.
   * @returns {Observable<Alerts[]>} An observable emitting an array of appointment-related alerts.
   */
  fetchPlansToConfirmAlerts(): Observable<Alerts[]> {
    const clinicId = this.clinicAuthService.getSelectedClinic()();
    const url = `${this.API_END_POINT}/alert/plans-to-confirm/${clinicId}`;
    return this.http.get<Alerts[]>(url);
  }

  /**
   * Fetches alerts related to appointments.
   * @returns {Observable<Alerts[]>} An observable emitting an array of appointment-related alerts.
   */
  fetchAppointmentAlerts(): Observable<Alerts[]> {
    const clinicId = this.clinicAuthService.getSelectedClinic()();
    const url = `${this.API_END_POINT}/alert/appointments/${clinicId}`;
    return this.http.get<Alerts[]>(url);
  }

  /**
   * Fetches alerts for plans that are about to expire.
   * @returns {Observable<Alerts[]>} An observable emitting an array of appointment-related alerts.
   */
  fetchExpiringPlansAlerts(): Observable<Alerts[]> {
    const clinicId = this.clinicAuthService.getSelectedClinic()();
    const url = `${this.API_END_POINT}/alert/expiry-plans/${clinicId}`;
    return this.http.get<Alerts[]>(url);
  }


  /**
   * Method to reply Support Quries
   * @param {supportId: number; replyMessage: string} payload - payload contains suprot query id and reply message
   */
  sendReplymessage(payload:  { supportId: number; replyMessage: string }) {
    const url = `${this.API_END_POINT}/support/sendSupportReply`
    return this.http.post(url, payload);
  }
}
