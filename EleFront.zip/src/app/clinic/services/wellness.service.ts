import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpParams,
} from '@angular/common/http';
import { computed, inject, Injectable, Signal, signal } from '@angular/core';
import { environment } from '../../../environments/environment.development';
import { ClinicAuthService } from './clinic-auth.service';
import {
  AddNewSetPlans,
  ClinicWellnessPlan,
  ClinicWellnessPlanWithPromotions,
  UpdateNewSetPlansDTO,
  WellnessUpdate,
} from '../models/wellness-plan-response';
import {
  BehaviorSubject,
  catchError,
  Observable,
  of,
  tap,
  throwError,
} from 'rxjs';
import { ChoosenPlans } from '../models/choosen-plans';
import {
  SendToPetOwner,
  SendToPetOwnerWithPromotions,
} from '../models/send-to-pet-owner';

@Injectable({
  providedIn: 'root',
})
export class WellnessService {
  private readonly API_END_POINT = environment.apiUrl;
  private clinicAuthService = inject(ClinicAuthService);
  private http = inject(HttpClient);

  private _plansForUpdateConfirmationSignal = signal<ChoosenPlans[]>([]);
  managePetWellnessPlanId = signal<number>(0);

  /**
   * Readonly signal to access the plans for update confirmation.
   */
  public get plansForUpdateConfirmationSignal(): Signal<ChoosenPlans[]> {
    return this._plansForUpdateConfirmationSignal.asReadonly();
  }

  /**
   * Updates the plans for update confirmation signal.
   * @param plans - The updated array of ChoosenPlans.
   */
  public updatePlansForConfirmation(plans: ChoosenPlans[]): void {
    this._plansForUpdateConfirmationSignal.set(plans);
  }

  filteredPlansByManagedPetWellnessPlanIdForConfirmation = computed(() => {
    const fillterdPlans = this._plansForUpdateConfirmationSignal().filter(
      (p) => p.managePetWellnessPlanId === this.managePetWellnessPlanId(),
    );
    return fillterdPlans;
  });

  /**
   * Returns the HTTP headers with authorization token.
   *
   * @returns {HttpHeaders} - HTTP headers with 'Content-Type' and 'Authorization' token.
   */
  getHeader(): HttpHeaders {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + this.clinicAuthService.getToken(),
    });
  }

  constructor() {}

  /**
   * Fetches all pet breeds from the server.
   *
   * @returns {Observable<any>} - An observable containing the list of all pet breeds.
   */
  fetchPetwithBreed() {
    return this.http.get(`${this.API_END_POINT}/breed/getAll`, {
      headers: this.getHeader(),
    });
  }

  /**
   * Fetches weight range for the selected clinic.
   *
   * @returns {Observable<any>} - An observable containing the clinic's weight range data.
   */
  fetchWeightRange() {
    return this.http.get(
      `${
        this.API_END_POINT
      }/clinic-weight-range/get/${this.clinicAuthService.getSelectedClinic()()}`,
      {
        headers: this.getHeader(),
      },
    );
  }

  /**
   * Updates the weight range for a specific clinic.
   *
   * @param {number} id - The ID of the clinic weight range to be updated.
   * @param {string} updateWeightRange - The new weight range.
   * @returns {Observable<string>} - An observable containing the server's response.
   */
  updateWeightRange(id: number, updateWeightRange: string) {
    const params = new HttpParams()
      .set('id', id)
      .set('updateWeightRange', updateWeightRange);
    return this.http.put(
      `${this.API_END_POINT}/clinic-weight-range/update`,
      {},
      { headers: this.getHeader(), responseType: 'text', params },
    );
  }

  /**
   * Fetches the list of all services available.
   *
   * @returns {Observable<any>} - An observable containing the list of services.
   */
  fetchServiceList() {
    return this.http.get(`${this.API_END_POINT}/service/getAllServices`, {
      headers: this.getHeader(),
    });
  }

  /**
   * Fetches the wellness plan for the selected clinic.
   *
   * @returns {Observable<any>} - An observable containing the clinic's wellness plan data.
   */
  fetchWellnessPlan() {
    return this.http.get(
      `${
        this.API_END_POINT
      }/clinic-wellness-plan/get/${this.clinicAuthService.getSelectedClinic()()}`,
      {
        headers: this.getHeader(),
      },
    );
  }

  /**
   * Updates the clinic wellness data with the given wellness update object.
   *
   * @param {WellnessUpdate} wellnessUpdate - The updated wellness plan data.
   * @returns {Observable<string>} - An observable containing the server's response.
   */
  updateClinicWellnessData(wellnessUpdate: WellnessUpdate) {
    return this.http.put(
      `${this.API_END_POINT}/clinic-wellness-plan/update-clinic-wellness`,
      wellnessUpdate,
    );
  }

  /**
   * Fetches a wellness plan based on the pet type and wellness plan name for the selected clinic.
   *
   * @param {string} wellnessPlanName - The name of the wellness plan.
   * @param {string} petSize - The petSize of the wellness plan.
   * @param {number} petId - The petId of the wellness plan.
   * @returns {Observable<ClinicWellnessPlanWithPromotions>} - An observable containing the wellness plan data.
   */
  fetchWellnessPlanBasedOnPetandWellnesPlanNameAndPetSize(
    wellnessPlanName: string,
    petSize: string,
    petId: number,
  ): Observable<ClinicWellnessPlanWithPromotions> {
    const clinicId = this.clinicAuthService.getSelectedClinic()();
    const url = `${this.API_END_POINT}/clinic-wellness-plan/get-pet-wellness-plan/${clinicId}/${wellnessPlanName}/${petSize}/${petId}`;
    return this.http.get<ClinicWellnessPlanWithPromotions>(url);
  }

  /**
   * Confirms the selected wellness plans and assigns them to pets.
   *
   * @param {Array<Object>} payload - The payload containing the pet ID, pet owner ID, clinic wellness plan, wellness plan update, and assigned by ID.
   * @returns {Observable<string>} - An observable containing the server's response.
   */
  confirmSelectedWellnessPlans(
    payload: {
      petId: number;
      petOwnerId: number;
      clinicWellnessPlan: number;
      wellnessPlanUpdate: number;
      assignedBy: number;
    }[],
  ) {
    return this.http.post(
      `${this.API_END_POINT}/petWellnessPlan/add`,
      payload,
      {
        headers: this.getHeader(),
        responseType: 'text',
      },
    );
  }

  /**
   * Fetches wellness plans for a specific pet.
   *
   * @param {number} petId - The ID of the pet.
   * @returns {Observable<any>} - An observable containing the pet's wellness plans.
   */
  fetchWellnessPlanForPet(petId: number) {
    return this.http.get(
      `${this.API_END_POINT}/petWellnessPlan/getPetPlans/${petId}`,
      {
        headers: this.getHeader(),
      },
    );
  }

  /**
   * Fetches pet owner details and their associated pets and wellness plans.
   *
   * @param {number} petId - The unique ID of the pet.
   * @param {number} ownerId - The unique ID of the pet owner.
   * @returns {Observable<any>} - An observable containing the pet owner and pet details.
   */
  fetchPetOwnerAndPetDetails(petId: number, ownerId: number) {
    const url = `${this.API_END_POINT}/clinic-details/getPetById/${petId}/${ownerId}`;
    return this.http.get(url, { headers: this.getHeader() });
  }

  /**
   * Updates the scheduled appointment date for a specific pet wellness plan.
   *
   * @param {number} wellnessPlanId - The ID of the pet wellness plan.
   * @param {string} scheduledDateAndTime - The new scheduled appointment date in localdate time  format.
   * @returns {Observable<string>} - Returns an observable containing the API response as a string.
   *
   * @example
   * updateScheduledAppointment(1, '2024-11-05T20:10').subscribe(response => {
   *   console.log(response);
   * });
   */
  updateScheduledAppointment(
    wellnessPlanId: number,
    scheduledDateAndTime: string,
  ) {
    const url = `${this.API_END_POINT}/petWellnessPlan/updateScheduledAppointment/${wellnessPlanId}/${scheduledDateAndTime}`;
    return this.http.put(
      url,
      {},
      { headers: this.getHeader(), responseType: 'text' },
    );
  }

  /**
   * Sends an array of wellness plans to pet owners.
   *
   * @param { SendToPetOwnerWithPromotions } plans- The array of records to be sent to the pet owners.
   * @returns {Observable<string>} An observable of the response message as a string.
   *
   */
  sendWellnessPlansToPetOwner(
    plans: SendToPetOwnerWithPromotions,
  ): Observable<string> {
    return this.http.post(
      `${this.API_END_POINT}/clinic-wellness-plan/sendPlans`,
      plans,
      { headers: this.getHeader(), responseType: 'text' },
    );
  }

  sendWellnessPlansToPetOwnerWithAction(
    plans: SendToPetOwnerWithPromotions,
    action: string,
  ) {
    return this.http.post(
      `${this.API_END_POINT}/clinic-wellness-plan/sendUpdatedPlans/${action}`,
      plans,
      { headers: this.getHeader(), responseType: 'text' },
    );
  }

  getChoosenPlansByPetOwner(petId: number): Observable<ChoosenPlans[]> {
    const currentLoggedInUser = this.clinicAuthService.getRole();
    const choosePlanUrl = `${this.API_END_POINT}/petWellnessPlan/getPlanToChoose/${petId}/${currentLoggedInUser}`;
    return this.http.get<ChoosenPlans[]>(choosePlanUrl, {
      headers: this.getHeader(),
    });
  }

  /**
   * Updates confirmation for the specified wellness plans.
   *
   * @param {Object} payload - The request payload containing the details for updating confirmation.
   * @param {number[]} payload.petWellnessPlanIds - Array of pet wellness plan IDs to be updated.
   * @param {string} payload.startDate - The start date for the updated wellness plans in ISO format (YYYY-MM-DD).
   * @param {string} payload.endDate - The end date for the updated wellness plans in ISO format (YYYY-MM-DD).
   * @param {number} [payload.managePetWellnessPlanId] - Optional ID for managing the wellness plan if applicable.
   * @param {string} [payload.totalAmount] - Total amount of selected set plan discounted price.
   * @returns {Observable<string>} - An observable that emits the server response as a string.
   */
  updateConfirmPlans(payload: {
    petWellnessPlanIds: number[];
    startDate: string;
    endDate: string;
    managePetWellnessPlanId?: number;
    totalAmount?: string;
    updatedAmount?: string;
  }): Observable<string> {
    const url = `${this.API_END_POINT}/clinic-wellness-plan/updateConfirmPlans`;
    return this.http.put<string>(url, payload, {
      headers: this.getHeader(),
      responseType: 'text' as 'json',
    });
  }

  /**
   *Fetch Doctors list
   *
   */
  fetchDoctorList() {
    const clinicId = this.clinicAuthService.getSelectedClinic()();
    return this.http.get(
      `${this.API_END_POINT}/clinic-details/getDoctorsByClinic/${clinicId}`,
      { headers: this.getHeader() },
    );
  }

  updateFullfilmentStatus(petWellnessPlanId: number, regId: number) {
    return this.http.put(
      `${this.API_END_POINT}/clinic-wellness-plan/updateFulfilledStatus/${petWellnessPlanId}/${regId}`,
      {},
      {
        headers: this.getHeader(),
        responseType: 'text',
      },
    );
  }

  fetchUpdatePlans(
    clinicId: number,
    wellnessPlanName: string,
    managePetWellnessPlanId: number,
  ): Observable<any> {
    const url = `${this.API_END_POINT}/updatePlans/available/${clinicId}/${wellnessPlanName}/${managePetWellnessPlanId}`;
    return this.http.get(url, { headers: this.getHeader() });
  }

  updatePlans(plans: UpdateNewSetPlansDTO[]): Observable<string> {
    const url = `${this.API_END_POINT}/updatePlans/updateExistingPlans`;
    return this.http.post<string>(url, plans, {
      headers: this.getHeader(),
      responseType: 'text' as 'json',
    });
  }

  addNewSetPlans(plans: AddNewSetPlans[]): Observable<string> {
    const url = `${this.API_END_POINT}/updatePlans/addNewPlans`;
    return this.http.post<string>(url, plans, {
      headers: this.getHeader(),
      responseType: 'text' as 'json',
    });
  }

  fetchAddPlans(
    clinicId: number,
    wellnessPlanName: string,
    petSize: string,
    petId: number,
  ): Observable<ClinicWellnessPlanWithPromotions> {
    const url = `${this.API_END_POINT}/clinic-wellness-plan/get-pet-wellness-plan/${clinicId}/${wellnessPlanName}/${petSize}/${petId}`;
    return this.http.get<ClinicWellnessPlanWithPromotions>(url);
  }

  /**
   * Fetches plans pending confirmation for updating existing plans using the provided pet ID.
   *
   * @param {number} petId - The unique identifier of the pet for which to fetch pending plans.
   * @returns {Observable<ChoosenPlans[]>} - An observable containing the list of pending plans.
   *
   * ### Notes
   * - Ensure the `petId` is valid and exists in the backend system.
   * - The returned data conforms to the `ChoosenPlans` interface.
   */
  fetchPlansPendingConfirmationByPetId(
    petId: number,
  ): Observable<ChoosenPlans[]> {
    const loggedInUser = this.clinicAuthService.getRole();
    const url = `${this.API_END_POINT}/petWellnessPlan/getUpdatedPlans/${petId}/${loggedInUser}`;

    return this.http
      .get<ChoosenPlans[]>(url, { headers: this.getHeader() })
      .pipe(
        tap((res: ChoosenPlans[]) => {
          this._plansForUpdateConfirmationSignal.set(res);
        }),
        catchError((err: HttpErrorResponse) => {
          console.error('Error fetching plans', err);
          return throwError(() => err);
        }),
      );
  }

  /**
   * Retrieves accepted plans for clinic-side confirmation based on the provided pet ID.
   *
   * @param {number} petId - The ID of the pet whose accepted plans are to be fetched.
   * @returns {Observable<ChoosenPlans[]>} - An observable that emits an array of accepted plans.
   */
  fetchNewSetPlansByPetId(petId: number): Observable<ChoosenPlans[]> {
    const loggedInUser = this.clinicAuthService.getRole();
    const url = `${this.API_END_POINT}/petWellnessPlan/getNewSetPlans/${petId}/${loggedInUser}`;

    return this.http.get<ChoosenPlans[]>(url, {
      headers: this.getHeader(),
    });
  }
}
