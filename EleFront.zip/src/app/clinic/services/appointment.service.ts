import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { environment } from '../../../environments/environment.development';
import { ClinicAuthService } from './clinic-auth.service';
import { Observable } from 'rxjs';
import { Appointment } from '../models/appointment';

@Injectable({
  providedIn: 'root',
})
export class AppointmentService {
  private readonly API_END_POINT = environment.apiUrl;
  private clinicAuthService = inject(ClinicAuthService);
  private http = inject(HttpClient);

  /**
   * Returns the HTTP headers with authorization token.
   *
   * @returns {HttpHeaders} - HTTP headers with 'Content-Type' and 'Authorization' token.
   */
  getHeader(): HttpHeaders {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + this.clinicAuthService.getToken(),
    });
  }

  constructor() {}

  /**
   * Fetches the scheduled appointments for the selected clinic.
   *
   * This method retrieves the list of appointments associated with the currently
   * selected clinic ID
   *
   * @returns {Observable<Appointment[]>} An observable emitting an array of `Appointment` objects.
   *
   */
  fetchScheduledAppointments(): Observable<Appointment[]> {
    const clinicId = this.clinicAuthService.getSelectedClinic()();
    const timeZone = this.clinicAuthService.getUserTimeZone();
    return this.http.get<Appointment[]>(
      `${this.API_END_POINT}/petWellnessPlan/appoinment-status/${clinicId}/${timeZone}`,
      { headers: this.getHeader() }
    );
  }

  /**
   * Fetches appointments for to show in calendar
   *
   * @returns {Observable<CalendarAppointment[]>} an observable emitting an array of
   */
  fetchAppointToShowInCalender() {
    const clinicId = this.clinicAuthService.getSelectedClinic()();
    const timeZone = this.clinicAuthService.getUserTimeZone();
    return this.http.get(
      `${this.API_END_POINT}/petWellnessPlan/calender/${clinicId}/${timeZone}`,
      { headers: this.getHeader() }
    );
  }
}
