import { Component, input } from '@angular/core';
import { PetResponse } from '../../models/pet';

@Component({
  selector: 'app-pet-card',
  standalone: true,
  imports: [],
  templateUrl: './pet-card.component.html',
  styleUrl: './pet-card.component.scss',
})
export class PetCardComponent {
  petInfo = input.required<PetResponse>();
  index = input.required<number>();
}
