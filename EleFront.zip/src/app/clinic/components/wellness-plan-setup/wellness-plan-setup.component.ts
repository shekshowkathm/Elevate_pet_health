import { NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { BreedWithAgeComponent } from '../breed-with-age/breed-with-age.component';
import { WeightRangeComponent } from '../weight-range/weight-range.component';

@Component({
  selector: 'app-wellness-plan-setup',
  standalone: true,
  imports: [NgClass, BreedWithAgeComponent, WeightRangeComponent],
  templateUrl: './wellness-plan-setup.component.html',
  styleUrl: './wellness-plan-setup.component.scss',
})
export class WellnessPlanSetupComponent {
  activeTab = 'breed';

  setActiveTab(tab: string) {
    this.activeTab = tab;
  }
}
