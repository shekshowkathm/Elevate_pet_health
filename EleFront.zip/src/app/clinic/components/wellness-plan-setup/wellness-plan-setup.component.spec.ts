import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WellnessPlanSetupComponent } from './wellness-plan-setup.component';

describe('WellnessPlanSetupComponent', () => {
  let component: WellnessPlanSetupComponent;
  let fixture: ComponentFixture<WellnessPlanSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WellnessPlanSetupComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(WellnessPlanSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
