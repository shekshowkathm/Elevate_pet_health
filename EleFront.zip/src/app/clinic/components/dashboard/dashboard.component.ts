import {
  Component,
  Inject,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { ClinicAuthService } from '../../services/clinic-auth.service';
import { ClinicResponse } from '../../models/clinic-response';
import { ClinicService } from '../../services/clinic.service';
import { HttpErrorResponse } from '@angular/common/http';
import { isPlatformBrowser, NgClass, NgFor, NgIf } from '@angular/common';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { StripeService } from '../../services/stripe.service';
import { DashBoardsStats } from '../../models/dashboard-statts';
import { FormsModule } from '@angular/forms';
import { TrancationService } from '../../../pet-owner/service/trancation.service';
import { MatTooltipModule } from '@angular/material/tooltip';
import { DialogModule } from 'primeng/dialog';
import { TooltipModule } from 'primeng/tooltip';
import { Roles } from '../../../shared/enum/roles';
@Component({
  // selector: 'app-dashboard',
  standalone: true,
  imports: [
    NgClass,
    FormsModule,
    NgIf,
    NgFor,
    MatTooltipModule,
    DialogModule,
    TooltipModule,
  ],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
})
export class DashboardComponent implements OnInit {
  private clinicAuthService = inject(ClinicAuthService);
  private clinicService = inject(ClinicService);
  private router = inject(Router);
  slectedClinc = this.clinicAuthService.getSelectedClinic();
  userRole = this.clinicAuthService.getRole();
  todayPaymentsCount: any
  creditCardIssuesCounts: number = 0;

  dashBoardStats = signal<DashBoardsStats>({
    associatesCount: 0,
    petOwnersCount: 0,
    petCounts: 0,
    activePlansCount: 0,
    expiringPlanCounts: 0,
    creditCardIssuesCounts: 0,
    todayPaymentsCount: 0,
    salesRepsCount: 0,
    totalClinicsCount: 0,
    promotions: [],
  });

  clinics: ClinicResponse[] = [];

  subClinicList = signal<ClinicResponse[]>([]);
  showDetailsDialog: boolean = false;
  isClinicOwnerAndHaveHqClinic: boolean = false;

  bgColors = ['#ffe9d0', '#bbe9ff', '#fffed3', '#FFC7B6', '#E7D4B5'];
  isHeadquarterAndClinicOwner: boolean = false;
  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    private messageService: MessageService,
    private stripeService: StripeService,
    private trancationService: TrancationService,
  ) {}
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.fetchClinicDetaliList();
      this.fetchClinicDashBoardStats();
    }
  }

  /**
   * Method will fetch the clinic that associated with current user
   *
   */
  fetchClinicDetaliList() {
    this.clinicService.getClinicList().subscribe({
      next: (res: any) => {
        this.clinics = res;
        this.clinics.forEach((c) => (c['color'] = this.getbackgroundcolor()));
        if (this.clinicAuthService.getRole() === 'CLINIC_ASSOCIATE') {
          const currentClinic = this.clinics[0];
          this.clinicAuthService.setSelectedClinic(currentClinic.id);
          this.clinicAuthService.setSelectedClinicEmail(
            currentClinic.email ?? '',
          );
        }
        if (this.userRole === Roles.CLINIC_OWNER) {
          if (this.clinicAuthService.getHeadquarterId()) {
            this.isHeadquarterAndClinicOwner = true;
            this.fetchSubClinicList();
          } else {
            this.checkSelectedClinicIsHeaquater();
          }
          const foundHQClinic = this.clinics.find((c) => c.headquater);
          if (foundHQClinic) {
            this.isClinicOwnerAndHaveHqClinic = true;
          }
        }
      },
      error: (err: HttpErrorResponse) => {
        if (err.status === 401) {
          // this.clinicAuthService.logout();
          // this.router.navigateByUrl('');
        }
      },
    });
  }

  getbackgroundcolor() {
    const randomIndex = Math.floor(Math.random() * this.bgColors.length);
    return this.bgColors[randomIndex];
  }

  selectClinic(clinic: ClinicResponse, checkisNotMainclinic: boolean = false) {
    if (this.slectedClinc() === clinic.id) {
      return;
    }
    if (clinic.headquater && this.userRole === Roles.CLINIC_OWNER) {
      this.isHeadquarterAndClinicOwner = true;
      this.clinicAuthService.setHeadquarterId(clinic.id);
      this.fetchSubClinicList();
    }
    if (checkisNotMainclinic) {
      this.isHeadquarterAndClinicOwner = false;
      this.clinicAuthService.removeHeadquarters();
      this.subClinicList.set([]);
    }

    this.clinicAuthService.setSelectedClinic(clinic.id);
    this.clinicAuthService.setSelectedClinicEmail(clinic.email ?? '');
    localStorage.setItem('1', clinic.stripeAccountId);
    this.fetchClinicDashBoardStats();
    this.stripeService.stripeAccountStatus(clinic.stripeAccountId).subscribe(
      (doc: any) => {
        if (doc === false) {
          this.messageService.add({
            severity: 'Warning',
            summary: 'Warning',
            detail: 'Stripe status Still not updated',
          });
        } else {
        }
      },
      (error: any) => {},
    );
  }
  gettodayEarings() {
    const stripeAccountId = localStorage.getItem('1') || '';
    if (!stripeAccountId) {
      console.warn('Stripe account ID is not available in localStorage.');
    }
    this.trancationService.gettodayEaringByclinic(stripeAccountId).subscribe({
      next: (doc: any) => {
        const rawValue = doc || 0;
        this.todayPaymentsCount = isNaN(Number(rawValue))
          ? 0
          : Number(rawValue).toFixed(2);
      },
      error: (err: any) => {
        this.todayPaymentsCount = 0;
      },
      complete: () => {
        console.log('Earnings retrieval process completed.');
      },
    });
  }

  requestNewClinic() {
    this.router.navigateByUrl('/clinic/request-clinic');
  }

  navigatetoPages(pageUrl: string) {
    this.router.navigateByUrl(pageUrl);
  }
  navigateToWellnessPlan() {
    const tab = 'wellness-plan';
    this.router.navigate(['/clinic/service-list'], {
      queryParams: { tab },
    });
  }
  cardissue() {
    const stripeAccountId = localStorage.getItem('1') || '';
    if (!stripeAccountId) {
      console.warn('Stripe account ID is not available in localStorage.');
    }
    this.stripeService
      .getExpiryDetailsByClinic(stripeAccountId)
      .subscribe((doc: any) => {
        this.creditCardIssuesCounts = doc.count;
      });
  }

  fetchClinicDashBoardStats() {
    if (this.clinicAuthService.getSelectedClinic()()) {
      this.gettodayEarings();
      this.cardissue();
      this.clinicService.fetchClinicDashBoardStats().subscribe({
        next: (res: DashBoardsStats) => {
          this.dashBoardStats.set(res);
          const promo = this.dashBoardStats().promotions;
          if (promo.length > 0) {
            this.clinicAuthService.setPromotions(promo.length);
          } else {
            this.clinicAuthService.removePromotion();
          }
        },
        error: (err: HttpErrorResponse) => {
          console.log('Error fetch dashborad stats data', err);
        },
      });
    }
  }

  getRemainingPromotionsTooltip(): string {
    return this.dashBoardStats()
      .promotions.slice(2)
      .map((promo) => promo.promotion)
      .join(', ');
  }

  openDetailsDialog() {
    this.showDetailsDialog = true;
  }

  private fetchSubClinicList() {
    this.clinicService.fetchSubClinicList().subscribe({
      next: (res: ClinicResponse[]) => {
        this.subClinicList.set(res);
        this.subClinicList().forEach(
          (c) => (c['color'] = this.getbackgroundcolor()),
        );
      },
      error: (err: HttpErrorResponse) => {
        console.log('error fetch SubClinicList', err);
      },
    });
  }
  /**
   * This method will help while component initializtion selected clinic is headquarter,
   * and not fetch the sub clinic list it will help to fetch the sub clinic
   */
  private checkSelectedClinicIsHeaquater() {
    const selectedClinicId = this.clinicAuthService.getSelectedClinic()();
    const clinic: ClinicResponse | undefined = this.clinics.find(
      (c) => c.id === selectedClinicId,
    );
    if (clinic?.headquater && this.userRole === Roles.CLINIC_OWNER) {
      this.isHeadquarterAndClinicOwner = true;
      this.clinicAuthService.setHeadquarterId(clinic.id);
      this.fetchSubClinicList();
    }
  }
}
