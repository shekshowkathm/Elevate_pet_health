import { NgIf } from '@angular/common';
import { Component, inject, input, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { ToastModule } from 'primeng/toast';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { MessageService } from 'primeng/api';
import { Router } from '@angular/router';
import { ClinicService } from '../../services/clinic.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ClinicUser } from '../../models/clinic-user';
import { ClinicAssociateService } from '../../services/clinic-associate.service';
import { US_STATES } from '../../../shared/constants/usa-states';
import { CustomDropdownComponent } from '../custom-dropdown/custom-dropdown.component';
import { PhoneNumberDirective } from '../../../shared/directives/phone-number.directive';
import { NumberInputDirective } from '../../../shared/directives/number-input.directive';
import { TIME_ZONES } from '../../../shared/constants/timeZone';

@Component({
  selector: 'app-update-clinic-associate',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    NgIf,
    ToastModule,
    ProgressSpinnerModule,
    CustomDropdownComponent,
    PhoneNumberDirective,
    NumberInputDirective,
  ],
  templateUrl: './update-clinic-associate.component.html',
  styleUrl: './update-clinic-associate.component.scss',
  providers: [MessageService],
})
export class UpdateClinicAssociateComponent implements OnInit {
  clinicAssociate = input.required<ClinicUser>();
  private router = inject(Router);
  private clinicService = inject(ClinicService);
  private clinicAssociateService = inject(ClinicAssociateService);
  loader: boolean = false;
  clinicAssociateForm!: FormGroup;
  states = US_STATES;
  timeZones: { label: string; value: string }[] = TIME_ZONES.map((t) => ({
    label: `${t.fullName} (${t.abbreviation})`,
    value: t.abbreviation,
  }));
  constructor(private messageService: MessageService) {}
  ngOnInit(): void {
    this.initializeAndPatchUpdateForm();
  }
  private initializeAndPatchUpdateForm() {
    const {
      firstName,
      lastName,
      designation,
      contactNumber,
      // profile,
      address,
      city,
      state,
      zipcode,
      doctor,
      timezone,
    } = this.clinicAssociate();
    this.clinicAssociateForm = new FormGroup({
      firstName: new FormControl(firstName || '', [Validators.required]),
      lastName: new FormControl(lastName || '', [Validators.required]),
      timezone: new FormControl(timezone || '', [Validators.required]),
      contactNumber: new FormControl(contactNumber || '', [
        Validators.required,
        Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/),
      ]),
      address: new FormControl(address || '', [Validators.required]),
      city: new FormControl(city || '', [Validators.required]),
      state: new FormControl(state || '', [Validators.required]),
      designation: new FormControl(designation || '', [Validators.required]),
      zipcode: new FormControl(zipcode || '', [
        Validators.required,
        Validators.pattern('^\\d{5}(-\\d{4})?$'),
      ]),
      doctor: new FormControl(doctor || false),
    });
  }
  updateClinicAssociate() {
    this.loader = true;
    const payloadObj: ClinicUser = {
      ...this.clinicAssociateForm.value,
      email: this.clinicAssociate().email,
      role: 'CLINIC_ASSOCIATE',
      id: this.clinicAssociate().id,
    };
    this.clinicService.UpadateClinicUser(payloadObj).subscribe({
      next: (res: any) => {
        this.loader = false;
        this.clinicAssociateForm.reset();
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Clinic Associate updated sucessfully',
        });
        this.clinicAssociateService
          .fetchClinicAssociateById(this.clinicAssociate().id!)
          .subscribe();
        setTimeout(() => {
          this.router.navigate([
            '/clinic/view-associate',
            this.clinicAssociate().id,
          ]);
        }, 1000);
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        console.log(err);
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Cannot Update Associate, Try again!',
        });
      },
    });
  }
}
