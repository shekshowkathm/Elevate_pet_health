import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateClinicAssociateComponent } from './update-clinic-associate.component';

describe('UpdateClinicAssociateComponent', () => {
  let component: UpdateClinicAssociateComponent;
  let fixture: ComponentFixture<UpdateClinicAssociateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpdateClinicAssociateComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateClinicAssociateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
