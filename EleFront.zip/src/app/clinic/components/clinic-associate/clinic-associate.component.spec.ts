import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicAssociateComponent } from './clinic-associate.component';

describe('ClinicAssociateComponent', () => {
  let component: ClinicAssociateComponent;
  let fixture: ComponentFixture<ClinicAssociateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClinicAssociateComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClinicAssociateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
