import {
  Component,
  computed,
  Inject,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { TableModule } from 'primeng/table';
import { ClinicAssociateService } from '../../services/clinic-associate.service';
import { Router } from '@angular/router';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { HttpErrorResponse } from '@angular/common/http';
import { isPlatformBrowser } from '@angular/common';
import { SharedService } from '../../../shared/service/shared.service';
import { ClinicAssociateDTO } from '../../models/clinic-associate-model';
import { InputTextModule } from 'primeng/inputtext';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-clinic-associate',
  standalone: true,
  imports: [TableModule, ProgressSpinnerModule, InputTextModule, FormsModule],
  templateUrl: './clinic-associate.component.html',
  styleUrl: './clinic-associate.component.scss',
})
export class ClinicAssociateComponent implements OnInit {
  loader: boolean = false;
  private clinicAssociateService = inject(ClinicAssociateService);
  private sharedService = inject(SharedService);
  clinicAssociateDetaitls = this.clinicAssociateService.clinicAssociateDetails;
  private router = inject(Router);
  searchTerm = signal<string | null>(null);
  fiteredClinicAssociates = computed(() => {
    const searchTerm = this.searchTerm()?.toLowerCase();
    return this.clinicAssociateDetaitls().filter((associate) =>
      searchTerm
        ? associate.firstName.toLowerCase().includes(searchTerm) ||
          associate.lastName.toLowerCase().includes(searchTerm) ||
          associate.email.toLowerCase().includes(searchTerm) ||
          associate.designation.toLowerCase().includes(searchTerm) ||
          associate.contact.toLowerCase().includes(searchTerm)
        : true,
    );
  });

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.getClinicAssocates();
    }
  }

  gotoAddClinicAssociate() {
    this.router.navigateByUrl('/clinic/add-clinic-associate');
  }
  getClinicAssocates() {
    this.loader = true;
    this.clinicAssociateService.getClinicAssociateDetails().subscribe({
      next: (res: any) => {
        this.loader = false;
        this.clinicAssociateDetaitls.set(res);
      },
      error: (err: HttpErrorResponse) => {
        console.log(err);
        this.loader = false;
      },
    });
  }
  viewAssociate(id: number) {
    this.router.navigate(['/clinic/view-associate', id]);
  }

  exportAsExcel() {
    this.sharedService.exportAsExcelFile(
      this.clinicAssociateDetaitls(),
      'associate-details',
    );
  }
  clearFilter() {
    this.searchTerm.set(null);
  }
}
