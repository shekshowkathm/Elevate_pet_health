import { NgClass } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { ServiceListComponent } from '../service-list/service-list.component';
import { WellnessPlanComponent } from '../wellness-plan/wellness-plan.component';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-service-list-page',
  standalone: true,
  imports: [NgClass, ServiceListComponent, WellnessPlanComponent],
  templateUrl: './service-list-page.component.html',
  styleUrl: './service-list-page.component.scss',
})
export class ServiceListPageComponent implements OnInit {
  private activatedRoute = inject(ActivatedRoute);
  private router = inject(Router);
  activeTab = 'service-list';

  setActiveTab(tab: string) {
    this.activeTab = tab;
    this.router.navigate(['/clinic/service-list'], {
      queryParams: { tab },
    });
  }
  ngOnInit(): void {
    this.activatedRoute.queryParamMap.subscribe((params) => {
      const tab = params.get('tab');
      if (tab && (tab === 'wellness-plan' || 'service-list'))
        this.activeTab = tab;
    });
  }
}
