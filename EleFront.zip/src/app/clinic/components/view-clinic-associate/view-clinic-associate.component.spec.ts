import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewClinicAssociateComponent } from './view-clinic-associate.component';

describe('ViewClinicAssociateComponent', () => {
  let component: ViewClinicAssociateComponent;
  let fixture: ComponentFixture<ViewClinicAssociateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewClinicAssociateComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewClinicAssociateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
