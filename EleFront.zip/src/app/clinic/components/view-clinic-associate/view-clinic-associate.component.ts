import {
  Component,
  Inject,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UpdateClinicAssociateComponent } from '../update-clinic-associate/update-clinic-associate.component';
import { ClinicAssociateService } from '../../services/clinic-associate.service';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { HttpErrorResponse } from '@angular/common/http';
import { CurrencyPipe, DatePipe, isPlatformBrowser } from '@angular/common';
import { TableModule } from 'primeng/table';
import { DoctorFulfilmentHistory } from '../../models/clinic-user';

@Component({
  selector: 'app-view-clinic-associate',
  standalone: true,
  imports: [
    UpdateClinicAssociateComponent,
    ProgressSpinnerModule,
    ProgressSpinnerModule,
    TableModule,
    DatePipe,
    CurrencyPipe,
  ],
  templateUrl: './view-clinic-associate.component.html',
  styleUrl: './view-clinic-associate.component.scss',
})
export class ViewClinicAssociateComponent implements OnInit {
  loader: boolean = false;
  private activatedRoute = inject(ActivatedRoute);
  private clinicAssociateService = inject(ClinicAssociateService);
  private router = inject(Router);
  private associateId = signal<number>(0);
  mode: string | null = 'view';
  clinicAssociate = this.clinicAssociateService.currentClinicAssociate;
  doctorfulfillmentHistoryList: DoctorFulfilmentHistory[] = [];
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}
  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe((params) => {
      this.associateId.set(Number(params.get('id')));
    });
    this.activatedRoute.queryParamMap.subscribe((params) => {
      this.mode = params.get('mode');
    });
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.fetchClinicAssociate();
    }
  }

  fetchClinicAssociate() {
    this.loader = true;
    this.clinicAssociateService
      .fetchClinicAssociateById(this.associateId())
      .subscribe({
        next: (res: any) => {
          this.loader = false;
          console.log('clinic associate res', res);
          this.doctorfulfillmentHistoryList = res.doctorsHistory;
        },
        error: (err: HttpErrorResponse) => {
          this.loader = false;
          console.log('Error fetching clinic associate', err);
        },
      });
  }

  editAssociate() {
    this.router.navigate(['/clinic/view-associate', this.associateId()], {
      queryParams: { mode: 'edit' },
    });
  }
}
