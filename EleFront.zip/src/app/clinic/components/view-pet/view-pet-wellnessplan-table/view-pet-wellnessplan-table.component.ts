import { NgClass, NgIf, CurrencyPipe } from '@angular/common';
import {
  Component,
  computed,
  inject,
  input,
  OnInit,
  output,
  signal,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { ListboxModule } from 'primeng/listbox';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TableModule } from 'primeng/table';
import { ToastModule } from 'primeng/toast';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { TooltipModule } from 'primeng/tooltip';
import { PickDateComponent } from '../../pick-date/pick-date.component';
import {
  FulfilledBy,
  PetAndOwnerWithWellnessPlan,
  PetWellnessPlan,
} from '../../../models/pet';
import { WellnessService } from '../../../services/wellness.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Router } from '@angular/router';
import { StripeService } from '../../../services/stripe.service';
import { PromotionEligibilityPipe } from '../../../../shared/pipes/promotion-eligibility.pipe';

@Component({
  selector: 'app-view-pet-wellnessplan-table',
  standalone: true,
  imports: [
    ProgressSpinnerModule,
    NgClass,
    TableModule,
    PickDateComponent,
    ToggleButtonModule,
    FormsModule,
    DialogModule,
    ListboxModule,
    ConfirmDialogModule,
    ToastModule,
    TooltipModule,
    CurrencyPipe,
    PromotionEligibilityPipe,
  ],
  templateUrl: './view-pet-wellnessplan-table.component.html',
  styleUrl: './view-pet-wellnessplan-table.component.scss',
  providers: [ConfirmationService, MessageService, CurrencyPipe],
})
export class ViewPetWellnessplanTableComponent {
  private currencyPipe = inject(CurrencyPipe);
  private wellnessService = inject(WellnessService);
  private router = inject(Router);
  petWellnessPlans = input.required<PetWellnessPlan[]>();
  doctorsList = input.required<FulfilledBy[]>();
  petBreed = input<string>('');
  ageGroup = input<string>('');
  index = input.required<number>();
  showUpdateFunction = input.required<boolean>();
  petAndOwnerWithWellnessPlan =
    input.required<PetAndOwnerWithWellnessPlan | null>();

  fetchPlans = output<void>(); // for calling the get method
  showDialogForAddDoctor: boolean = false;
  loader: boolean = false;
  selectedWellnessPlan: PetWellnessPlan | null = null;

  selectedDoctor = signal<FulfilledBy>({
    regId: 0,
    doctorName: '',
  });
  promotions = computed(() => {
    return this.petWellnessPlans()[0].promotions;
  });

  isPlanHasUpdateConfimation = computed(() => {
    const managedPlanId: number = this.petWellnessPlans()[0]
      .managePetWellnessPlan as number;
    return this.wellnessService
      .plansForUpdateConfirmationSignal()
      .some((v) => v.managePetWellnessPlanId === managedPlanId);
  });

  constructor(
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private stripeService: StripeService,
  ) {}

  setSelectedDate(wellnessPlan: PetWellnessPlan) {
    this.selectedWellnessPlan = wellnessPlan;
  }

  updateScheduledAppointment(dateString: string) {
    this.loader = true;
    this.wellnessService
      .updateScheduledAppointment(
        this.selectedWellnessPlan?.petWellnessPlanId!,
        dateString,
      )
      .subscribe({
        next: (val: any) => {
          this.loader = false;
          this.fetchPlans.emit();
        },
        error: (err: HttpErrorResponse) => {
          console.log('Error updating scheduled appoinent date:', err);
          this.loader = false;
        },
      });
  }

  cancelDoctorSelection(wellnessPlan: PetWellnessPlan) {
    this.showDialogForAddDoctor = false;
    this.selectedDoctor.set({ regId: 0, doctorName: '' });
    this.selectedWellnessPlan = null;
  }
  confirmSelectdDoctor(wellnessPlan: PetWellnessPlan) {
    this.showDialogForAddDoctor = false;
  }

  editFulfilledBy(wellnessPlan: PetWellnessPlan): void {
    this.selectedWellnessPlan = null;
    this.showDialogForAddDoctor = true;
    this.selectedWellnessPlan = wellnessPlan;
    console.log(this.selectedWellnessPlan);
  }

  updateFullfilmentStatus(wellnessPlan: PetWellnessPlan) {
    if (this.selectedDoctor().regId === 0) {
      this.messageService.add({
        severity: 'error',
        summary: 'Error',
        detail: 'Please select docter before confirm',
      });
      return;
    }
    if (
      this.selectedWellnessPlan?.petWellnessPlanId !==
      wellnessPlan.petWellnessPlanId
    ) {
      this.messageService.add({
        severity: 'error',
        summary: 'Error',
        detail: 'Somthing went wrong. Please try again.',
      });
      return;
    }
    this.confirmationService.confirm({
      message: `Are you sure that you want to proceed?`,
      header: `Fullfilment Confirmation`,
      icon: 'pi pi-exclamation-triangle',
      acceptIcon: 'pi pi-check mr-2',
      rejectIcon: 'pi pi-times mr-2',
      acceptButtonStyleClass:
        'px-4 py-2 text-sm rounded-md text-white bg-[#007CDA] ms-6',
      rejectButtonStyleClass:
        'px-4 py-2 text-sm rounded-md text-white bg-red-500',
      accept: () => {
        this.loader = true;
        this.wellnessService
          .updateFullfilmentStatus(
            wellnessPlan.petWellnessPlanId,
            this.selectedDoctor().regId,
          )
          .subscribe({
            next: (val) => {
              console.log(val);
              this.fetchPlans.emit();
              this.resetOrCliear();
              this.selectedDoctor.set({ regId: 0, doctorName: '' });
              if (val == 'Pet Wellness Plan not found or not confirmed') {
                this.messageService.add({
                  severity: 'error',
                  summary: 'Error',
                  detail: 'Pet Wellness Plan not found or not confirmed',
                });
              }
              if (val === 'Updated') {
                this.messageService.add({
                  severity: 'success',
                  summary: 'Fullfillment confirmed',
                  detail: 'Fullfillment confirmed sucessfully',
                });
              }
              this.loader = false;
            },
            error: (err: HttpErrorResponse) => {
              console.log('Error updating fullfillment', err);
              this.loader = false;
            },
          });
      },
      reject: () => {
        this.selectedDoctor.set({ regId: 0, doctorName: '' });
        this.selectedWellnessPlan = null;
      },
    });
  }

  resetOrCliear() {
    this.selectedWellnessPlan = null;
  }

  computedSelectedWellnessPlanSignal = computed(() => {
    const total = this.petWellnessPlans().reduce(
      (acc, plan) => {
        const price = parseFloat(plan.updatedPrice?.replace('$', '').trim()!);
        const discountedPrice = parseFloat(
          plan.discountPrice?.replace('$', '').trim()!,
        );
        acc.totalPriceSum += isNaN(price) ? 0 : price;
        acc.totalDiscountedPriceSum += isNaN(discountedPrice)
          ? 0
          : discountedPrice
            ? discountedPrice
            : price;
        return acc;
      },
      { totalPriceSum: 0, totalDiscountedPriceSum: 0 },
    );
    const firstMonthPrice = total.totalDiscountedPriceSum / 12 + 49;
    const remainingMonthPrice = total.totalDiscountedPriceSum / 12 + 7;
    const totalPrice = firstMonthPrice + remainingMonthPrice * 11;

    return {
      totalPrice: this.currencyPipe.transform(total.totalPriceSum),
      totalDiscountedPrice: this.currencyPipe.transform(total.totalDiscountedPriceSum),
      firstMonthPrice: this.currencyPipe.transform(firstMonthPrice),
      remainingMonthPrice: this.currencyPipe.transform(remainingMonthPrice),
      totalPriceWithInstallments: this.currencyPipe.transform(totalPrice),
    };
  });

  private formatDateToUS(dateString: string): string {
    const date = new Date(dateString);
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${month}-${day}-${year}`;
  }
  confirmDelete() {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete this plan?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      acceptButtonStyleClass:
        'px-4 py-2 text-sm rounded-md text-white bg-red-500 ms-6',
      rejectButtonStyleClass:
        'px-4 py-2 text-sm rounded-md text-white bg-[#007CDA]',
      accept: () => {
        this.oncancelPlans();
      },
      reject: () => {
        console.log('Delete canceled');
      },
    });
  }
  oncancelPlans() {
    let data: any;
    data = this.petAndOwnerWithWellnessPlan();
    let data1 = data.stripeSubscriptionId;
    this.stripeService.cancelStripeSubscription(data1).subscribe((doc: any) => {
      this.messageService.add({
        severity: 'success',
        summary: 'Wellness plan confirmed',
        detail: 'Wellness plan canceled sucessfully',
      });
    });
  }
  onUpdatePlans() {
    const wellnessPlanName = this.petWellnessPlans()[0].wellnessPlanName;
    const managePetWellnessPlanId =
      this.petWellnessPlans()[0].managePetWellnessPlan;
    const petId = this.petWellnessPlans()[0].petId;
    const size = this.petAndOwnerWithWellnessPlan()?.petSize;
    this.router.navigate(
      [
        '/clinic/update-new-plans',
        wellnessPlanName,
        managePetWellnessPlanId,
        petId,
      ],
      { queryParams: { action: 'update', size } },
    );
  }

  NavigateToConfirmUpdatePlans() {
    const petId = this.petWellnessPlans()[0].petId;
    const planId = this.petWellnessPlans()[0].managePetWellnessPlan;
    const action = 'update-plans';
    this.router.navigate(['/clinic/choosen-plans', petId], {
      queryParams: { action, planId },
    });
  }
}
