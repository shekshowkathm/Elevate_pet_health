import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewPetWellnessplanTableComponent } from './view-pet-wellnessplan-table.component';

describe('ViewPetWellnessplanTableComponent', () => {
  let component: ViewPetWellnessplanTableComponent;
  let fixture: ComponentFixture<ViewPetWellnessplanTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewPetWellnessplanTableComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewPetWellnessplanTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
