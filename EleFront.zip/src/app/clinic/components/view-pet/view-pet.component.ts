import {
  Component,
  Inject,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { isPlatformBrowser } from '@angular/common';
import {
  FulfilledBy,
  PetAndOwnerWithWellnessPlan,
  PlanSets,
} from '../../models/pet';
import { WellnessService } from '../../services/wellness.service';
import { Router } from '@angular/router';
import { ViewPetWellnessplanTableComponent } from './view-pet-wellnessplan-table/view-pet-wellnessplan-table.component';
import { ChoosenPlans } from '../../models/choosen-plans';
import {
  DynamicDialogModule,
  DialogService,
  DynamicDialogRef,
} from 'primeng/dynamicdialog';
import { DocumentViewComponent } from '../document-view/document-view.component';
@Component({
  selector: 'app-view-pet',
  standalone: true,
  imports: [
    ProgressSpinnerModule,
    ViewPetWellnessplanTableComponent,
    DynamicDialogModule,
  ],
  templateUrl: './view-pet.component.html',
  styleUrl: './view-pet.component.scss',
  providers: [DialogService],
})
export class ViewPetComponent implements OnInit {
  private activatedRoute = inject(ActivatedRoute);
  private wellnessService = inject(WellnessService);

  petId = signal<number>(0);
  petOwnerId = signal<number>(0);
  petAndOwnerWithWellnessPlan = signal<PetAndOwnerWithWellnessPlan | null>(
    null,
  );
  showAll: boolean = false;

  DoctorNeedToSelect: FulfilledBy[] = [];

  loader: boolean = false;

  isNewSetPalnsAdded: boolean = false;
  ref: DynamicDialogRef | undefined;

  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    private router: Router,
    public dialogService: DialogService,
  ) {}

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe((params) => {
      this.petId.set(Number(params.get('petId')));
      this.petOwnerId.set(Number(params.get('ownerId')));
    });
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.loader = true;
      this.fetchPetAndOnwerAndWellnessPlans();
      this.fetchDoctorListForChosse();
      this.wellnessService
        .fetchPlansPendingConfirmationByPetId(this.petId())
        .subscribe();
      this.fetchNewSetPlansByPetId();
    }
  }
  /**
   * Helper function that helps to get object keys
   * @param plans
   * @returns
   */
  planSetsKeys = (plans: PlanSets) => Object.keys(plans);

  isObjectEmpty(obj: PlanSets): boolean {
    return obj && Object.keys(obj).length > 0;
  }

  fetchPetAndOnwerAndWellnessPlans() {
    this.loader = true;
    this.wellnessService
      .fetchPetOwnerAndPetDetails(this.petId(), this.petOwnerId())
      .subscribe({
        next: (res: any) => {
          this.loader = false;

          this.petAndOwnerWithWellnessPlan.set(res);
          console.log(this.petAndOwnerWithWellnessPlan(), '783r7gs');
        },
        error: (err: HttpErrorResponse) => {
          this.loader = false;
          console.log(
            'Error fetching pet-owner and pet with wellness plans: ',
            err,
          );
        },
      });
  }

  fetchDoctorListForChosse() {
    this.wellnessService.fetchDoctorList().subscribe({
      next: (val) => {
        this.DoctorNeedToSelect = val as FulfilledBy[];
      },
      error: (err: HttpErrorResponse) => {
        console.log("Error fetching Doctor's list", err);
      },
    });
  }

  addNewPlans(
    petAndOwnerWithWellnessPlan: PetAndOwnerWithWellnessPlan,
    action: string,
  ) {
    const wellnessPlanName = `${petAndOwnerWithWellnessPlan.petType} - ${petAndOwnerWithWellnessPlan.ageGroup}`;
    const petId = petAndOwnerWithWellnessPlan.petId;
    const size = petAndOwnerWithWellnessPlan.petSize;
    this.router.navigate(['/clinic/add-new-plans', wellnessPlanName, petId], {
      queryParams: { action: action, size },
    });
  }

  onAddPlans() {
    const petAndOwnerData = this.petAndOwnerWithWellnessPlan();
    if (petAndOwnerData) {
      this.addNewPlans(petAndOwnerData, 'add');
    } else {
      console.log('No pet and wellness plan data available');
    }
  }

  fetchNewSetPlansByPetId() {
    this.wellnessService.fetchNewSetPlansByPetId(this.petId()).subscribe({
      next: (res: ChoosenPlans[]) => {
        if (res && res.length > 0) {
          this.isNewSetPalnsAdded = true;
        } else {
          this.isNewSetPalnsAdded = false;
        }
      },
      error: (err: HttpErrorResponse) => {
        console.log(err);
      },
    });
  }

  confirmNewPlans() {
    const action = 'confirm-new-plans';
    this.router.navigate(['/clinic/choosen-plans', this.petId()], {
      queryParams: { action },
    });
  }

  openDocuments() {
    this.ref = this.dialogService.open(DocumentViewComponent, {
      width: '75vw',
      contentStyle: { overflow: 'auto' },
      breakpoints: {
        '1024px': '80vw',
        '640px': '90vw',
      },
      data: {
        view: 'INDIVIDUAL',
        petOwnerId: this.petOwnerId(),
        petId: this.petId(),
      },
    });

    this.ref.onClose.subscribe((response: any) => {});
  }
}
