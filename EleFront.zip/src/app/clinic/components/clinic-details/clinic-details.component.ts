import { Roles } from './../../../shared/enum/roles';
import {
  CurrencyPipe,
  DatePipe,
  isPlatformBrowser,
  NgClass,
} from '@angular/common';
import {
  Component,
  Inject,
  inject,
  OnDestroy,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { TableModule } from 'primeng/table';
import { ClinicService } from '../../services/clinic.service';
import { ClinicDetailResponse } from '../../models/clinic-details-response';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { ClinicAuthService } from '../../services/clinic-auth.service';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { DocumentService } from '../../services/document.service';
import { DocumentResponse } from '../../models/document-response';
import { FilesUploadComponent } from '../../../shared/component/files-upload/files-upload.component';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { UploadedFileDetail } from '../../../shared/model/upload-file-detail';
import { from, concatMap, finalize } from 'rxjs';
import { FileSizePipe } from '../../../shared/pipes/file-size.pipe';
import { US_STATES } from '../../../shared/constants/usa-states';

@Component({
  selector: 'app-clinic-details',
  standalone: true,
  imports: [
    TableModule,
    NgClass,
    ProgressSpinnerModule,
    DatePipe,
    FileSizePipe,
  ],
  templateUrl: './clinic-details.component.html',
  styleUrl: './clinic-details.component.scss',
  providers: [DialogService],
})
export class ClinicDetailsComponent implements OnInit, OnDestroy {
  private clinicService = inject(ClinicService);
  private clnicAuthService = inject(ClinicAuthService);
  private documentService = inject(DocumentService);
  private router = inject(Router);
  loader = false;
  superAdminDocloader = false;
  clinicDocloader = false;
  Roles = Roles;
  userRole = this.clnicAuthService.getRole();
  currentClinic: ClinicDetailResponse = {
    clinicName: '',
    address: '',
    zipCode: '',
    city: '',
    email: '',
  };
  documentsUploadedBySuperAdmin = signal<DocumentResponse[]>([]);
  documentsUploadedByClinic = signal<DocumentResponse[]>([]);
  ref: DynamicDialogRef | undefined;
  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    public dialogService: DialogService,
  ) {}
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.getClinic();
      this.fetchDoumentsUploadBySuperAdmin();
      this.fetchDocumentUploadedByClinic();
    }
  }

  getClinic() {
    this.loader = true;
    this.clinicService.getCurrentClinicalDetails().subscribe({
      next: (res: any) => {
        this.loader = false;
        this.currentClinic = res as ClinicDetailResponse;
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        console.log(err.error, err.message, err.status);
      },
    });
  }
  gotoUpdateClinic() {
    this.router.navigateByUrl('/clinic/update-clinic-detail');
  }
  gotoAddAdmin() {
    if (this.userRole === 'CLINIC_OWNER') {
      this.router.navigateByUrl('/clinic/add-clinic-admin');
    }
  }

  generateQRCode() {
    this.loader = true;
    this.clinicService.generateQRCode().subscribe({
      next: (val: any) => {
        this.getClinic();
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        console.log('Error generating QR code in Clinic Details', err);
      },
    });
  }

  fetchDoumentsUploadBySuperAdmin() {
    this.documentService.fetchDoumentsUploadBySuperAdmin().subscribe({
      next: (val: any) => {
        this.documentsUploadedBySuperAdmin.set(val as DocumentResponse[]);
      },
    });
  }

  viewDocument(doc: DocumentResponse) {
    window.open(doc.documentUrl, '_blank');
  }

  fetchDocumentUploadedByClinic() {
    this.documentService.fetchDocumentUploadedByClinic().subscribe({
      next: (val: any) => {
        this.documentsUploadedByClinic.set(val);
      },
      error: (err: HttpErrorResponse) => {
        console.log('Error fetch documents uploaded by clinic', err);
      },
    });
  }

  uploadDocuments(): void {
    this.openUploadDialog().onClose.subscribe(
      (files: UploadedFileDetail[] | undefined | null) => {
        if (files && files.length > 0) {
          this.loader = true;
          const documents = this.mapFilesToDocuments(files);
          this.uploadDocumentsToServer(documents);
        }
      },
    );
  }

  private openUploadDialog(): DynamicDialogRef {
    return this.dialogService.open(FilesUploadComponent, {
      header: 'Upload Files',
      width: '50vw',
      closable: false,
      contentStyle: { overflow: 'auto' },
      breakpoints: {
        '960px': '75vw',
        '640px': '90vw',
      },
    });
  }

  private mapFilesToDocuments(files: UploadedFileDetail[]): DocumentResponse[] {
    const role = this.clnicAuthService.getRole();
    const userId = this.clnicAuthService.getUserId()!;
    const clinicId = this.clnicAuthService.getSelectedClinic()()!;
    return files.map((file) => ({
      documentUrl: file.url,
      uploadedByRole: role,
      uploadedById: userId,
      targetType: 'SuperAdmin',
      targetId: 1,
      clinicId: clinicId,
      uploadDate: file.uploadDate,
      description: file.name,
      fileSize: file.size.toString(),
    }));
  }

  private uploadDocumentsToServer(documents: DocumentResponse[]): void {
    from(documents)
      .pipe(
        concatMap((doc) =>
          this.documentService.uploadDocumentByClinicToSuperAdmin(doc),
        ),
        finalize(() => {
          this.loader = false;
        }),
      )
      .subscribe({
        next: (doc: any) => {
          this.documentsUploadedByClinic.update((currentDocs) => [
            ...currentDocs,
            doc,
          ]);
        },
        error: (err: HttpErrorResponse) => {
          console.error('Error uploading document:', err);
        },
      });
  }

  ngOnDestroy() {
    if (this.ref) {
      this.ref.close();
    }
  }
  getStateNameWithCode(stateCode: string | undefined | null): string {
    if (!stateCode) return '';
    const state = US_STATES.find((s) => s.code === stateCode);
    return `${state?.name} (${state?.code})`;
  }

  getIcon(link: string) {
    if (link.includes('https://facebook.com')) return 'facebook.png';
    if (link.includes('https://x.com')) return 'twitter.png'; // Updated
    if (link.includes('https://instagram.com')) return 'instagram.png';
    if (link.includes('https://linkedin.com')) return 'linkedin.png';
    if (link.includes('https://youtube.com')) return 'youtube.png';
    return 'internet.png';
  }
}
