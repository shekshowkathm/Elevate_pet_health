import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PetOwnerComponent } from './pet-owner.component';

describe('PetOwnerComponent', () => {
  let component: PetOwnerComponent;
  let fixture: ComponentFixture<PetOwnerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PetOwnerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PetOwnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
