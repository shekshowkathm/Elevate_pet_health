import { Roles } from './../../../shared/enum/roles';
import {
  Component,
  computed,
  Inject,
  inject,
  OnDestroy,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TableModule } from 'primeng/table';
import { ClinicService } from '../../services/clinic.service';
import { PetListWithOwnerIdDTO } from '../../models/pet-owners';
import { HttpErrorResponse } from '@angular/common/http';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ClinicAuthService } from '../../services/clinic-auth.service';
import { Router } from '@angular/router';
import { isPlatformBrowser } from '@angular/common';
import { SharedService } from '../../../shared/service/shared.service';
import { NgIf } from '@angular/common';
import { NgClass } from '@angular/common';
import { TooltipModule } from 'primeng/tooltip';
import { FormsModule } from '@angular/forms';
import { PlanStatus } from '../../../shared/enum/plan-status';
import { WellnessService } from '../../services/wellness.service';
import { DocumentViewComponent } from '../document-view/document-view.component';
import {
  DialogService,
  DynamicDialogModule,
  DynamicDialogRef,
} from 'primeng/dynamicdialog';
@Component({
  selector: 'app-pet-owner',
  standalone: true,
  imports: [
    TableModule,
    ProgressSpinnerModule,
    InputSwitchModule,
    NgIf,
    NgClass,
    TooltipModule,
    FormsModule,
    DynamicDialogModule,
  ],
  templateUrl: './pet-owner.component.html',
  styleUrl: './pet-owner.component.scss',
  providers: [DialogService],
})
export class PetOwnerComponent implements OnInit, OnDestroy {
  private clinicService = inject(ClinicService);
  private clinicAuthService = inject(ClinicAuthService);
  private router = inject(Router);
  private sharedService = inject(SharedService);
  private wellnessService = inject(WellnessService);
  loader: boolean = false;
  planStatus = PlanStatus;
  Roles = Roles;
  userRole = '';
  clinicPetList = signal<PetListWithOwnerIdDTO[]>([]);
  searchTerm = signal<string | null>(null);
  fiteredClinicPetList = computed(() => {
    const searchTerm = this.searchTerm()?.toLowerCase();
    return this.clinicPetList().filter((associate) =>
      searchTerm
        ? (associate?.ownerFirstName ?? '')
            .toLowerCase()
            .includes(searchTerm) ||
          (associate?.ownerLastName ?? '').toLowerCase().includes(searchTerm) ||
          associate.email.toLowerCase().includes(searchTerm) ||
          associate.contact.toLowerCase().includes(searchTerm) ||
          (associate.petName ?? '').toLowerCase().includes(searchTerm) ||
          (associate.petType ?? '').toLowerCase().includes(searchTerm) ||
          (associate.petBreed ?? '').toLowerCase().includes(searchTerm) ||
          (associate.weight ?? '').toLowerCase().includes(searchTerm) ||
          (associate.city ?? '').toLowerCase().includes(searchTerm) ||
          (associate.state ?? '').toLowerCase().includes(searchTerm)
        : true,
    );
  });
  ref: DynamicDialogRef | undefined;
  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    public dialogService: DialogService,
  ) {}
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.fetchPetOwnersList();
      this.userRole = this.clinicAuthService.getRole();
      // TODO: Need to handle state initialization some other component.
      // for make the confimed plans state to initial stage
      this.wellnessService.updatePlansForConfirmation([]);
    }
  }
  ngOnDestroy(): void {
    if (this.ref) {
      this.ref.close();
    }
  }

  navigateToAddPetOwner() {
    this.router.navigateByUrl('/clinic/add-pet-owner');
  }

  fetchPetOwnersList() {
    this.loader = true;
    this.clinicService.fetchPetOwnersList().subscribe({
      next: (res: any) => {
        this.loader = false;
        this.clinicPetList.set(res as PetListWithOwnerIdDTO[]);
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        console.error('Error fetching pet owners list :', err);
      },
    });
  }

  viewPetOwner(pet: PetListWithOwnerIdDTO) {
    this.router.navigate(['/clinic/pet-owner', pet.ownerId, 'pet', pet.id]);
  }
  navigateToAddWellnessPlan(pet: PetListWithOwnerIdDTO) {
    this.router.navigate(['/clinic/add-wellnes-plan', pet.id]);
    sessionStorage.setItem(`selectedPet`, JSON.stringify(pet));
  }
  exportAsExcel() {
    this.sharedService.exportAsExcelFile(this.clinicPetList(), 'pet-list');
  }
  navigateToSeeChoice(pet: PetListWithOwnerIdDTO) {
    this.router.navigate(['/clinic/choosen-plans', pet.id]);
  }
  clearFilter() {
    this.searchTerm.set(null);
  }

  openDocuments() {
    this.ref = this.dialogService.open(DocumentViewComponent, {
      width: '75vw',
      contentStyle: { overflow: 'auto' },
      breakpoints: {
        '1024px': '80vw',
        '640px': '90vw',
      },
      data: { view: 'ALL' },
    });

    this.ref.onClose.subscribe((response: any) => {});
  }
}
