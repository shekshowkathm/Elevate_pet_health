import { Component, input } from '@angular/core';
import { InputSwitchModule } from 'primeng/inputswitch';
import { NgIf } from '@angular/common';
import {
  trigger,
  state,
  style,
  transition,
  animate,
} from '@angular/animations';
import { ClinicUser } from '../../models/clinic-user';
import { AdminAccess } from '../../models/admin-access';
@Component({
  selector: 'app-clinic-user-card',
  standalone: true,
  imports: [InputSwitchModule, NgIf],
  templateUrl: './clinic-user-card.component.html',
  styleUrl: './clinic-user-card.component.scss',
  animations: [
    trigger('slideInOut', [
      state(
        'void',
        style({
          height: '0px',
          opacity: 0,
          overflow: 'hidden',
        })
      ),
      state(
        '*',
        style({
          height: '*',
          opacity: 1,
          overflow: 'hidden',
        })
      ),
      transition('void <=> *', [animate('500ms ease-in-out')]),
    ]),
  ],
})
export class ClinicUserCardComponent {
  item = input.required<ClinicUser | any>();
  viewPlanDetails() {
    console.log('Method not implemented');
  }
}
