import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicUserCardComponent } from './clinic-user-card.component';

describe('ClinicUserCardComponent', () => {
  let component: ClinicUserCardComponent;
  let fixture: ComponentFixture<ClinicUserCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClinicUserCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClinicUserCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
