import { Component, input, OnInit, signal } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { NgClass } from '@angular/common';

@Component({
  selector: 'app-custom-dropdown',
  standalone: true,
  imports: [NgClass],
  templateUrl: './custom-dropdown.component.html',
  styleUrl: './custom-dropdown.component.scss',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: CustomDropdownComponent,
      multi: true,
    },
  ],
})
export class CustomDropdownComponent implements ControlValueAccessor, OnInit {
  options = input.required<any[]>();
  labelKey = input.required<string>();
  valueKey = input.required<string>();
  filter =input<boolean>(false);
  placeholder = input<string>('');
  
  dropdownOpen = signal(false);
  dropdownTop = signal(false);
  filteredOptions = signal<any[]>([]);
  selectedOption: any = {};

  private onChange: (value: any) => void = () => {};
  private onTouched: () => void = () => {};

  constructor() {}
  ngOnInit() {
    this.filteredOptions.set(this.options());
    this.onTouched();
  }

  toggleDropdown() {
    this.dropdownOpen.set(!this.dropdownOpen());
    this.onTouched();
  }

  filterOptions(event: any) {
    const searchTerm = event.target.value;
    this.filteredOptions.set(
      this.options().filter((option: any) =>
        option[this.labelKey()].toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  }

  selectOption(option: any) {
    this.selectedOption = option;
    this.dropdownOpen.set(false);
    this.onChange(option[this.valueKey()]);
    this.onTouched();
  }

  writeValue(value: any): void {
    const selected = this.options().find(
      (option) => option[this.valueKey()] === value
    );
    this.selectedOption = selected
      ? selected
      : { [this.labelKey()]: '', [this.valueKey()]: '' };
    this.onChange(value);
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean): void {}
}
