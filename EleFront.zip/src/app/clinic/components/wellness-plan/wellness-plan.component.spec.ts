import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WellnessPlanComponent } from './wellness-plan.component';

describe('WellnessPlanComponent', () => {
  let component: WellnessPlanComponent;
  let fixture: ComponentFixture<WellnessPlanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WellnessPlanComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WellnessPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
