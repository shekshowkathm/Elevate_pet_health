import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WellnessPlanEditableFieldComponent } from './wellness-plan-editable-field.component';

describe('WellnessPlanEditableFieldComponent', () => {
  let component: WellnessPlanEditableFieldComponent;
  let fixture: ComponentFixture<WellnessPlanEditableFieldComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WellnessPlanEditableFieldComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WellnessPlanEditableFieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
