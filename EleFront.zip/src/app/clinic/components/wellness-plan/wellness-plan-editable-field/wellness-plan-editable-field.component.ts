import { Roles } from './../../../../shared/enum/roles';
import { Component, inject, input, output } from '@angular/core';
import { ClinicAuthService } from '../../../services/clinic-auth.service';
import {
  ClinicDropDown,
  WellnessUpdate,
} from '../../../models/wellness-plan-response';
import { CurrencyPipe, NgClass } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NumberInputDirective } from '../../../../shared/directives/number-input.directive';

@Component({
  selector: 'app-wellness-plan-editable-field',
  standalone: true,
  imports: [NgClass, FormsModule, NumberInputDirective, CurrencyPipe],
  templateUrl: './wellness-plan-editable-field.component.html',
  styleUrl: './wellness-plan-editable-field.component.scss',
})
export class WellnessPlanEditableFieldComponent {
  private clinicAuthService = inject(ClinicAuthService);
  currentUser = this.clinicAuthService.getRole();

  // input signals
  editingField = input<string | null>(null);
  accessRights = input.required<boolean>();
  field = input.required<keyof WellnessUpdate>(); //field name
  isPercentage = input<boolean>(false);
  currentSelectedWellnessPlan = input<WellnessUpdate | null>(null);
  clinicDropDown = input.required<ClinicDropDown>();
  editField = output<{ wellnessUpdate: WellnessUpdate; field: string }>();

  //output signals
  edit(wellnessUpdate: WellnessUpdate, field: string) {
    this.editField.emit({ wellnessUpdate, field });
  }
  updateField = output<void>();
  cancelEdit = output<void>();

  isEditable(): boolean {
    if (this.currentUser === Roles.CLINIC_OWNER) {
      return true;
    } else if (this.currentUser === Roles.CLINIC_ADMIN && this.accessRights()) {
      return true;
    } else {
      return false;
    }
  }
}

// for reference and for example used 'clinicPrice'

// @if (
//   currentUser !== Roles.CLINIC_ADMIN ||
//   (currentUser === Roles.CLINIC_ADMIN && clinicAmdminAccess())
// ) {
//   <app-wellness-plan-editable-field
//     [accessRights]="clinicAmdminAccess().updateClinicPrice || false"
//     [field]="'clinicPrice'"
//     [isPercentage]="false"
//     [editingField]="editingField"
//     [currentSelectedWellnessPlan]="currentSelectedWellnessPlan"
//     [clinicDropDown]="clinicDropDown"
//     (editField)="editFieldFromChild($event)"
//     (updateField)="updateField(clinicDropDown.wellnessUpdate)"
//     (cancelEdit)="cancelEdit()"
//   />
// }
