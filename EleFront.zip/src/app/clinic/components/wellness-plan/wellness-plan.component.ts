import { Roles } from './../../../shared/enum/roles';
import { CurrencyPipe, isPlatformBrowser, NgClass } from '@angular/common';
import {
  Component,
  computed,
  inject,
  Inject,
  OnDestroy,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { WellnessService } from '../../services/wellness.service';
import { HttpErrorResponse } from '@angular/common/http';
import {
  ClinicDropDown,
  ClinicWellnessPlan,
  WellnessUpdate,
} from '../../models/wellness-plan-response';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TableModule } from 'primeng/table';
import { InputSwitchModule } from 'primeng/inputswitch';
import { FormsModule } from '@angular/forms';
import { ClinicAuthService } from '../../services/clinic-auth.service';
import { ClinicAdminService } from '../../services/clinic-admin.service';
import { AdminAccess } from '../../models/admin-access';
import { SharedService } from '../../../shared/service/shared.service';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { CreateProduct } from '../../models/create-product';
import { StripeService } from '../../services/stripe.service';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextModule } from 'primeng/inputtext';
import { WellnessPlanUpdateformComponent } from './wellness-plan-updateform/wellness-plan-updateform.component';
import {
  DialogService,
  DynamicDialogModule,
  DynamicDialogRef,
} from 'primeng/dynamicdialog';
import { Router } from '@angular/router';
import { TooltipModule } from 'primeng/tooltip';

@Component({
  selector: 'app-wellness-plan',
  standalone: true,
  imports: [
    TableModule,
    ProgressSpinnerModule,
    InputSwitchModule,
    FormsModule,
    NgClass,
    ConfirmDialogModule,
    DropdownModule,
    InputTextModule,
    DynamicDialogModule,
    CurrencyPipe,
    TooltipModule,
  ],
  templateUrl: './wellness-plan.component.html',
  styleUrl: './wellness-plan.component.scss',
  providers: [ConfirmationService, DialogService],
})
export class WellnessPlanComponent implements OnInit, OnDestroy {
  public creatProduct!: CreateProduct;
  loader: boolean = false;
  private clinicAuthService = inject(ClinicAuthService);
  private clinicAdminService = inject(ClinicAdminService);
  private wellnessService = inject(WellnessService);
  private sharedService = inject(SharedService);
  private router = inject(Router);
  wellnessPlans = signal<ClinicWellnessPlan[]>([]);
  public wellnessPlansDetails: ClinicWellnessPlan[] = [];
  public filteredWellnessPlans = signal<ClinicWellnessPlan[]>([]);
  clinicAmdminAccess = signal<AdminAccess>({
    clinicAdminId: 0,
    updateWeightRange: false,
    updateClinicPrice: false,
    updateRecommendation: false,
    updateDiscountPercentage: false,
    updateDiscountPrice: false,
    updateDoctorPercentage: false,
    viewPayment: false,
  });
  Roles = Roles;
  currentUser = '';
  currentSelectedWellnessPlan: WellnessUpdate | null = null;
  editingField: string | null = null;
  ref: DynamicDialogRef | undefined;
  petTypes: { name: string; value: string }[] = [
    {
      name: 'Dog',
      value: 'Dog',
    },
    {
      name: 'Cat',
      value: 'Cat',
    },
  ];
  petTypeFilter = signal<string | null>(null);
  wellnessPlanNameFilter = signal<string | null>(null);
  serviceNameFilter = signal<string | null>(null);

  filteredClinicWellnessPlans = computed(() => {
    const petType = this.petTypeFilter()?.toLowerCase();
    const wellnessPlanName = this.wellnessPlanNameFilter()?.toLowerCase();
    const serviceName = this.serviceNameFilter()?.toLowerCase();
    return this.wellnessPlans().filter(
      (item) =>
        (petType ? item.petType.toLowerCase() === petType : true) &&
        (wellnessPlanName
          ? item.wellnessPlanName.toLowerCase().includes(wellnessPlanName)
          : true) &&
        (serviceName
          ? item.serviceName.toLowerCase().includes(serviceName)
          : true),
    );
  });

  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    private confirmationService: ConfirmationService,
    private stripeService: StripeService,
    public dialogService: DialogService,
  ) {}
  ngOnDestroy(): void {
    if (this.ref) {
      this.ref.close();
    }
  }

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.fetchWellnessPlan();
      this.currentUser = this.clinicAuthService.getRole();
      if (this.currentUser === 'CLINIC_ADMIN') {
        this.fetchClinicAdminAccess();
      } else if (this.currentUser === 'CLINIC_OWNER') {
        this.creatProduct = new CreateProduct();
        this.creatProduct.accountId = localStorage.getItem('1') ?? undefined;
      }
      sessionStorage.removeItem('WI');
    }
  }

  /**
   * Method only called for Clinic Admin only
   * @returns {AdminAccess}
   */
  private fetchClinicAdminAccess() {
    const isAdminUser = this.clinicAuthService.getRole() === Roles.CLINIC_ADMIN;
    if (isAdminUser) {
      const clinicAdminId = Number(this.clinicAuthService.getUserId());
      if (!clinicAdminId) return;
      this.clinicAdminService.fetchClinicAdminAccess(clinicAdminId).subscribe({
        next: (val: any) => {
          this.clinicAmdminAccess.set(val as AdminAccess);
        },
        error: (err: HttpErrorResponse) => {
          console.log(
            'Error fetching clinic admin access in wellness plan coponent',
            err,
          );
        },
      });
    }
  }

  fetchWellnessPlan() {
    this.loader = true;
    this.wellnessService.fetchWellnessPlan().subscribe({
      next: (res: any) => {
        this.wellnessPlansDetails = res;
        this.wellnessPlans.set(res as ClinicWellnessPlan[]);
        this.loader = false;
      },
      error: (err: HttpErrorResponse) => {
        console.error('Error fetching wellness plans', err);
        this.loader = false;
      },
    });
  }

  editFieldFromChild($event: {
    wellnessUpdate: WellnessUpdate;
    field: string;
  }) {
    const { wellnessUpdate, field } = $event;
    this.editField(wellnessUpdate, field);
  }
  editField(wellnessUpdate: WellnessUpdate, field: string) {
    this.currentSelectedWellnessPlan = wellnessUpdate;
    this.editingField = field;
  }

  private updateClinicWellnessDataResuable(wellnessUpdate: WellnessUpdate) {
    this.wellnessService.updateClinicWellnessData(wellnessUpdate).subscribe({
      next: (val: any) => {
        this.updateClinicWellnessPrice(val);
        this.fetchWellnessPlan();
        this.cancelEdit();
      },
      error: (err: HttpErrorResponse) => {
        console.log('Error Updating wellness plan', err);
        this.fetchWellnessPlan();
      },
    });
  }

  /**
   * Method to update wellness plans
   * this method directly can be invoked (for status update can directly invoke from html)
   * @param wellnessUpdate
   */
  updateClinicWellnessPrice(wellnessUpdate: any) {
    console.log(wellnessUpdate);
    // let data1 = this.wellnessPlans().flatMap((plan, index) =>
    //   plan.clinicDropDowns
    //     .filter(
    //       (d) =>
    //         d.wellnessUpdate.wellnessUpdateId ===
    //         wellnessUpdate.wellnessUpdateId,
    //     )
    //     .map((d) => ({
    //       ...d,
    //       clinicWellnessPlanId: plan.clinicWellnessPlanId,
    //       wellnessPlanName: plan.wellnessPlanName,
    //       dropdownIndex: index,
    //     })),
    // );

    if (wellnessUpdate.status === true) {
      if (wellnessUpdate.dropDown.priceBased === 'QTY') {
        const updatedPriceForQuantity = wellnessUpdate.discountPriceForQuantity;
        if (
          updatedPriceForQuantity !== null &&
          updatedPriceForQuantity !== undefined &&
          !isNaN(parseFloat(updatedPriceForQuantity))
        ) {
          let priceInCents = Math.round(
            parseFloat(updatedPriceForQuantity) * 100,
          );
          this.creatProduct.price = priceInCents;
          this.creatProduct.type = wellnessUpdate.dropDown.priceBased;
          this.creatProduct.productId = wellnessUpdate.stripeProductId;
          this.creatProduct.priceId = wellnessUpdate.stripePriceId;
          this.creatProduct.clinicWellnessUpdateId = wellnessUpdate.id;
          console.log(this.creatProduct);

          const add = [];
          add.push(this.creatProduct);
          add.forEach((product) => {
            const newProducts = [
              {
                price: product.price,
                accountId: product.accountId,
                productId: wellnessUpdate.stripeProductId,
                priceId: wellnessUpdate.stripePriceId,
                clinicWellnessUpdateId: product.clinicWellnessUpdateId,
                type: product.type,
              },
            ];
            this.stripeService.priceUpdateStripe(newProducts).subscribe({
              next: (response: any) => {
                console.log('Product Updated successfully:', response);
              },
              error: (error: HttpErrorResponse) => {
                console.log('Error creating product:', error);
              },
            });
          });
        }
      } else {
        if (
          wellnessUpdate.updatedPriceForLarge &&
          wellnessUpdate.updatedPriceForMedium &&
          wellnessUpdate.updatedPriceForXLarge &&
          wellnessUpdate.updatedPriceForSmall
        ) {
          const add = [];
          const updatedPriceForLarge = Math.round(
            parseFloat(wellnessUpdate.updatedPriceForLarge) * 100,
          );
          const updatedPriceForMedium = Math.round(
            parseFloat(wellnessUpdate.updatedPriceForMedium) * 100,
          );
          const updatedPriceForXLarge = Math.round(
            parseFloat(wellnessUpdate.updatedPriceForXLarge) * 100,
          );
          const updatedPriceForSmall = Math.round(
            parseFloat(wellnessUpdate.updatedPriceForSmall) * 100,
          );

          this.creatProduct.updatedPriceForLarge = updatedPriceForLarge;
          this.creatProduct.updatedPriceForMedium = updatedPriceForMedium;
          this.creatProduct.updatedPriceForXLarge = updatedPriceForXLarge;
          this.creatProduct.updatedPriceForSmall = updatedPriceForSmall;
          this.creatProduct.type = wellnessUpdate.dropDown.priceBased;
          this.creatProduct.clinicWellnessUpdateId = wellnessUpdate.id;
          add.push(this.creatProduct);
          add.forEach((product) => {
            const newProducts = [
              {
                price: product.updatedPriceForLarge,
                accountId: product.accountId,
                productId: wellnessUpdate.stripeProductIdLarge,
                priceId: wellnessUpdate.stripePriceIdLarge,
                clinicWellnessUpdateId: product.clinicWellnessUpdateId,
                type: product.type,
                size: 'Large',
              },
              {
                price: product.updatedPriceForSmall,
                accountId: product.accountId,
                productId: wellnessUpdate.stripeProductIdSmall,
                priceId: wellnessUpdate.stripePriceIdSmall,
                clinicWellnessUpdateId: product.clinicWellnessUpdateId,
                type: product.type,
                size: 'Small',
              },
              {
                price: product.updatedPriceForXLarge,
                accountId: product.accountId,
                productId: wellnessUpdate.stripeProductIdXLarge,
                priceId: wellnessUpdate.stripePriceIdXLarge,
                clinicWellnessUpdateId: product.clinicWellnessUpdateId,
                type: product.type,
                size: 'XLarge',
              },
              {
                price: product.updatedPriceForMedium,
                accountId: product.accountId,
                productId: wellnessUpdate.stripeProductIdMedium,
                priceId: wellnessUpdate.stripePriceIdMedium,
                clinicWellnessUpdateId: product.clinicWellnessUpdateId,
                type: product.type,
                size: 'Medium',
              },
            ];

            console.log(newProducts, 'Product Variants');

            this.stripeService.priceUpdateStripe(newProducts).subscribe({
              next: (response: any) => {
                console.log('Product  update successfully:', response);
              },
              error: (error: HttpErrorResponse) => {
                console.log('Error creating product variants:', error);
              },
            });
          });
        }
      }
    }
  }
  private updateClinicWellnessData(wellnessUpdate: WellnessUpdate) {
    let data1 = this.wellnessPlans().flatMap((plan, index) =>
      plan.clinicDropDowns
        .filter(
          (d) =>
            d.wellnessUpdate.wellnessUpdateId ===
            wellnessUpdate.wellnessUpdateId,
        )
        .map((d) => ({
          ...d,
          clinicWellnessPlanId: plan.clinicWellnessPlanId,
          wellnessPlanName: plan.wellnessPlanName,
          dropdownIndex: index,
        })),
    );
    if (wellnessUpdate.status === false) {
      if (data1[0].priceBased === 'QTY') {
      } else {
        if (wellnessUpdate.discountPriceForLarge) {
          console.log('Discount price available for large');
        }
      }
    } else {
      if (data1[0].priceBased === 'QTY') {
        let arr = data1.map((data) => data.wellnessUpdate);
        const discountPriceForQuantity: string | null | undefined =
          arr[0].discountPriceForQuantity;

        if (
          discountPriceForQuantity !== null &&
          discountPriceForQuantity !== undefined &&
          !isNaN(parseFloat(discountPriceForQuantity))
        ) {
          let priceInCents = Math.round(
            parseFloat(discountPriceForQuantity) * 100,
          );
          this.creatProduct.price = priceInCents;
          this.creatProduct.type = data1[0].priceBased;
          this.creatProduct.productName = `${data1[0].wellnessPlanName} - ${this.wellnessPlans()[0].serviceName} - ${data1[0].dropdown}`;
          this.creatProduct.productDescription = `${data1[0].wellnessPlanName} - ${this.wellnessPlans()[0].serviceName} - ${data1[0].dropdown} - ${data1[0].priceBased}`;
          this.creatProduct.clinicWellnessUpdateId =
            wellnessUpdate.wellnessUpdateId;
          if (data1.length > 0) {
            const add = [];
            add.push(this.creatProduct);

            add.forEach((product) => {
              const newProducts = [
                {
                  price: product.price,
                  accountId: product.accountId,
                  productName: `${product.productName}`,
                  productDescription: `${product.productDescription}`,
                  clinicWellnessUpdateId: product.clinicWellnessUpdateId,
                  type: product.type,
                },
              ];

              this.stripeService.createProduct(newProducts).subscribe({
                next: (response: any) => {
                  console.log('Product created successfully:', response);
                  this.updateClinicWellnessDataResuable(wellnessUpdate);
                },
                error: (error: HttpErrorResponse) => {
                  console.log('Error creating product:', error);
                },
              });
            });
          }
        }
      } else {
        if (
          wellnessUpdate.discountPriceForLarge &&
          wellnessUpdate.discountPriceForMedium &&
          wellnessUpdate.discountPriceForXLarge &&
          wellnessUpdate.discountPriceForSmall
        ) {
          const add = [];
          const discountpriceInCentsLarge = Math.round(
            parseFloat(wellnessUpdate.discountPriceForLarge) * 100,
          );
          const discountpriceInCentsMedium = Math.round(
            parseFloat(wellnessUpdate.discountPriceForMedium) * 100,
          );
          const discountpriceInCentsXLarge = Math.round(
            parseFloat(wellnessUpdate.discountPriceForXLarge) * 100,
          );
          const discountpriceInCentsSmall = Math.round(
            parseFloat(wellnessUpdate.discountPriceForSmall) * 100,
          );

          this.creatProduct.discountpriceInCentsLarge =
            discountpriceInCentsLarge;
          this.creatProduct.discountpriceInCentsMedium =
            discountpriceInCentsMedium;
          this.creatProduct.discountpriceInCentsXLarge =
            discountpriceInCentsXLarge;
          this.creatProduct.discountpriceInCentsSmall =
            discountpriceInCentsSmall;
          this.creatProduct.type = data1[0].priceBased;
          this.creatProduct.productName = `${data1[0].wellnessPlanName} - ${this.wellnessPlans()[0].serviceName} - ${data1[0].dropdown}`;
          this.creatProduct.productDescription = `${data1[0].wellnessPlanName} - ${this.wellnessPlans()[0].serviceName} - ${data1[0].dropdown} - ${data1[0].priceBased}`;
          this.creatProduct.clinicWellnessUpdateId =
            wellnessUpdate.wellnessUpdateId;

          if (data1.length > 0) {
            add.push(this.creatProduct);

            add.forEach((product) => {
              const newProducts = [
                {
                  price: product.discountpriceInCentsLarge,
                  accountId: product.accountId,
                  productName: `${product.productName} - Large`,
                  productDescription: `${product.productDescription} - Large`,
                  clinicWellnessUpdateId: product.clinicWellnessUpdateId,
                  type: product.type,
                  size: 'Large',
                },
                {
                  price: product.discountpriceInCentsSmall,
                  accountId: product.accountId,
                  productName: `${product.productName} - Small`,
                  productDescription: `${product.productDescription} - Small`,
                  clinicWellnessUpdateId: product.clinicWellnessUpdateId,
                  type: product.type,
                  size: 'Small',
                },
                {
                  price: product.discountpriceInCentsXLarge,
                  accountId: product.accountId,
                  productName: `${product.productName} - XLarge`,
                  productDescription: `${product.productDescription} - XLarge`,
                  clinicWellnessUpdateId: product.clinicWellnessUpdateId,
                  type: product.type,
                  size: 'XLarge',
                },
                {
                  price: product.discountpriceInCentsMedium,
                  accountId: product.accountId,
                  productName: `${product.productName} - Medium`,
                  productDescription: `${product.productDescription} - Medium`,
                  clinicWellnessUpdateId: product.clinicWellnessUpdateId,
                  type: product.type,
                  size: 'Medium',
                },
              ];

              console.log(newProducts, 'Product Variants');

              this.stripeService.createProduct(newProducts).subscribe({
                next: (response: any) => {
                  console.log(
                    'Product variants created successfully:',
                    response,
                  );
                  this.updateClinicWellnessDataResuable(wellnessUpdate);
                },
                error: (error: HttpErrorResponse) => {
                  console.log('Error creating product variants:', error);
                },
              });
            });
          }
        }
      }
    }

    // if (wellnessUpdate.status === false) {
    //   this.updateClinicWellnessDataResuable(wellnessUpdate);
    // } else if (
    //   wellnessUpdate.status === true &&
    //   wellnessUpdate.stripePriceId !== null
    // ) {
    //   let clinicPrice = wellnessUpdate.clinicPrice;
    //   if (clinicPrice !== null && !isNaN(parseFloat(clinicPrice))) {
    //     let priceInCents = Math.round(parseFloat(clinicPrice) * 100);
    //     console.log('Price in cents:', priceInCents);
    //     let data = {
    //       price: priceInCents,
    //       accountId: this.creatProduct.accountId,
    //       priceId: wellnessUpdate.stripePriceId,
    //       productId: wellnessUpdate.stripeProductId,
    //       clinicWellnessUpdateId: wellnessUpdate.wellnessUpdateId,
    //     };
    //     console.log(data);

    //     this.stripeService.priceUpdateStripe(data).subscribe((doc: any) => {
    //       this.updateClinicWellnessDataResuable(wellnessUpdate);
    //     });
    //   }
    // } else {
    //   let clinicPrice = wellnessUpdate.clinicPrice;
    //   if (clinicPrice !== null && !isNaN(parseFloat(clinicPrice))) {
    //     let priceInCents = Math.round(parseFloat(clinicPrice) * 100);
    //     console.log('Price in cents:', priceInCents);
    //     console.log(this.wellnessPlans());

    //     let data1 = this.wellnessPlans().flatMap((plan, index) =>
    //       plan.clinicDropDowns
    //         .filter(
    //           (d) =>
    //             d.wellnessUpdate.wellnessUpdateId ===
    //             wellnessUpdate.wellnessUpdateId,
    //         )
    //         .map((d) => ({
    //           ...d,
    //           clinicWellnessPlanId: plan.clinicWellnessPlanId,
    //           wellnessPlanName: plan.wellnessPlanName,
    //           dropdownIndex: index,
    //         })),
    //     );

    //     if (data1.length > 0) {
    //       this.creatProduct.price = priceInCents;
    //       this.creatProduct.productName = `${data1[0].wellnessPlanName} - ${this.wellnessPlans()[0].serviceName} - ${data1[0].dropdown}`;
    //       this.creatProduct.productDescription = `${data1[0].wellnessPlanName} - ${this.wellnessPlans()[0].serviceName} - ${data1[0].dropdown}`;
    //       this.creatProduct.clinicWellnessUpdateId =
    //         wellnessUpdate.wellnessUpdateId;
    //       // this.stripeService.createProduct(this.creatProduct).subscribe({
    //       //   next: (response: any) => {
    //       //     console.log('Product created successfully:', response);
    //       //     this.updateClinicWellnessDataResuable(wellnessUpdate);
    //       //   },
    //       //   error: (error: HttpErrorResponse) => {
    //       //     console.log('Error creating product:', error);
    //       //   },
    //       // });
    //     } else {
    //       console.log(
    //         'No matching data found for the specified wellnessUpdate.',
    //       );
    //     }
    //   } else {
    //     console.log(
    //       'Invalid clinicPrice value. Please provide a valid number.',
    //     );
    //   }

    //   console.log('Status is not true, update is not performed.');
    // }
  }

  /**
   * Method to update wellness plans.
   * Here this method used to update field.
   * @param wellnessUpdate
   */
  updateField(wellnessUpdate: WellnessUpdate) {
    if (this.currentSelectedWellnessPlan) {
      this.updateClinicWellnessData(wellnessUpdate);
    }
  }

  cancelEdit() {
    this.currentSelectedWellnessPlan = null;
    this.editingField = null;
  }
  exportAsExcel(): void {
    const printableWellnessPlan: PrintableWellnessPlan[] =
      this.transformToPrintableWellnessPlan(this.wellnessPlans());
    this.sharedService.exportAsExcelFile(
      printableWellnessPlan,
      'wellness-plan',
    );
  }

  private transformToPrintableWellnessPlan(
    clinicWellnessPlans: ClinicWellnessPlan[],
  ): PrintableWellnessPlan[] {
    return clinicWellnessPlans.reduce((acc: PrintableWellnessPlan[], p) => {
      const transformedPlans = p.clinicDropDowns.map((cd) => ({
        'Pet Type': p.petType,
        'Age Group': p.ageGroup,
        'Wellness Plan Name': p.wellnessPlanName,
        'Service Name': p.serviceName,
        'Service Drop Down': cd.dropdown || '',
        'Price Based': cd.priceBased || '',
        'Price For Small': cd.priceForSmall || '',
        'Price For Medium': cd.priceForMedium || '',
        'Price For Large': cd.priceForLarge || '',
        'Price For X-Large': cd.priceForXLarge || '',
        'Price For Quantity': cd.priceForQuantity || '',
        'Industry Standard Price': cd.industryStandardPrice || '',
        Recommendation: cd.recommendation || '',
        'Clinic Recommendation': cd.wellnessUpdate.updateRecommendation || '',
        'Discount Percentage': cd.wellnessUpdate.discountPercentage || '',
        'Doctor Percentage': cd.wellnessUpdate.doctorPercentage || '',
        'Updated Price Based': cd.wellnessUpdate.priceBased || '',
        'Updated Quantity Price':
          cd.wellnessUpdate.updatedPriceForQuantity || '',
        'Updated Small': cd.wellnessUpdate.updatedPriceForSmall || '',
        'Updated Medium': cd.wellnessUpdate.updatedPriceForMedium || '',
        'Updated Large': cd.wellnessUpdate.updatedPriceForLarge || '',
        'Updated X-Large': cd.wellnessUpdate.updatedPriceForXLarge || '',
        'Clinic Discount Price': cd.wellnessUpdate.clinicPrice || '',
        'Discount Price For Quantity':
          cd.wellnessUpdate.discountPriceForQuantity || '',
        'Discount Price For Small':
          cd.wellnessUpdate.discountPriceForSmall || '',
        'Discount Price For Medium':
          cd.wellnessUpdate.discountPriceForMedium || '',
        'Discount Price For Large':
          cd.wellnessUpdate.discountPriceForLarge || '',
        'Discount Price For X-Large':
          cd.wellnessUpdate.discountPriceForXLarge || '',
        Status: cd.wellnessUpdate.status ? 'true' : 'false',
      }));
      return acc.concat(transformedPlans);
    }, []);
  }

  validateNumberInput(event: KeyboardEvent): void {
    const inputChar = event.key;
    const currentValue = (event.target as HTMLInputElement).value;

    const isNumberOrDot = /^[0-9.]$/.test(inputChar);

    const allowedSpecialKeys = [
      'Backspace',
      'Tab',
      'ArrowLeft',
      'ArrowRight',
      'Delete',
    ];
    if (!isNumberOrDot && !allowedSpecialKeys.includes(inputChar)) {
      event.preventDefault();
      return;
    }

    if (inputChar === '.' && currentValue.includes('.')) {
      event.preventDefault();
    }
  }

  /**
   * Method will check wellnessPlan is eliable or not
   * @param wellnessUpdate
   * @returns
   */
  checkValidPlanForEnable(clinicDropDown: ClinicDropDown): boolean {
    const { priceBased, wellnessUpdate } = clinicDropDown;
    if (priceBased === 'QTY') {
      return !!wellnessUpdate.updatedPriceForQuantity;
    }
    if (priceBased === 'WGT') {
      return (
        !!wellnessUpdate.updatedPriceForSmall &&
        !!wellnessUpdate.updatedPriceForMedium &&
        !!wellnessUpdate.updatedPriceForLarge &&
        !!wellnessUpdate.updatedPriceForXLarge
      );
    }
    return false;
  }

  /**
   * confirmation for status change
   * @param wellnessUpdate
   */
  confirmStatusChange(wellnessUpdate: WellnessUpdate) {
    this.confirmationService.confirm({
      message: `Are you sure that you want to ${
        wellnessUpdate.status ? 'enable' : 'disable'
      } wellness plan?`,
      header: `${wellnessUpdate.status ? 'Enable' : 'Disable'} Confirmation`,
      icon: 'pi pi-exclamation-triangle',
      acceptIcon: 'pi pi-check mr-2',
      rejectIcon: 'pi pi-times mr-2',
      acceptButtonStyleClass:
        'px-4 py-2 text-sm rounded-md text-white bg-[#007CDA] ms-6',
      rejectButtonStyleClass:
        'px-4 py-2 text-sm rounded-md text-white bg-red-500',
      accept: () => {
        this.updateClinicWellnessData(wellnessUpdate);
        // this.updateClinicWellnessDataResuable(wellnessUpdate)
      },
      reject: () => {
        wellnessUpdate.status = !wellnessUpdate.status;
      },
    });
  }

  clearFilter() {
    this.petTypeFilter.set(null);
    this.wellnessPlanNameFilter.set(null);
    this.serviceNameFilter.set(null);
  }

  editWellnessPlan(
    clinicDropDown: ClinicDropDown,
    wellnessPlan: ClinicWellnessPlan,
  ) {
    this.ref = this.dialogService.open(WellnessPlanUpdateformComponent, {
      header: 'Update Wellness Plan',
      width: '75vw',
      contentStyle: { overflow: 'auto' },
      breakpoints: {
        '1024px': '80vw',
        '640px': '90vw',
      },
      // closable: false,
      data: {
        clinicDropDown,
        serviceName: wellnessPlan.serviceName,
        wellnessPlanName: wellnessPlan.wellnessPlanName,
      },
    });

    this.ref.onClose.subscribe((wellnessUpdate: any) => {
      if (wellnessUpdate.state === false) {
        this.loader = true;
        // this.updateClinicWellnessData(wellnessUpdate);
        this.updateClinicWellnessDataResuable(wellnessUpdate);
      } else {
        this.updateClinicWellnessDataResuable(wellnessUpdate);
      }
    });
  }

  viewWellnessPlan(wellnessPlan: ClinicWellnessPlan, index: number) {
    console.log('wellnessplan', wellnessPlan, '\n index', index);
    this.router.navigate(['clinic/wellnessplan/view']);
    sessionStorage.setItem('WI', JSON.stringify({ wellnessPlan, index }));
  }

  isClinicAdminHasAccess(): boolean {
    const adminAccess = this.clinicAmdminAccess();
    return (
      adminAccess.updateClinicPrice &&
      adminAccess.updateDiscountPercentage &&
      adminAccess.updateDiscountPrice &&
      adminAccess.updateDoctorPercentage &&
      adminAccess.updateRecommendation
    );
  }
}

const aese: PrintableWellnessPlan = {
  'Pet Type': '',
  'Age Group': '',
  'Wellness Plan Name': '',
  'Service Name': '',
  'Service Drop Down': '',
  'Price Based': '',
  'Price For Small': '',
  'Price For Medium': '',
  'Price For Large': '',
  'Price For X-Large': '',
  'Price For Quantity': '',
  'Industry Standard Price': '',
  Recommendation: '',
  'Clinic Recommendation': '',
  'Discount Percentage': '',
  'Doctor Percentage': '',
  'Updated Price Based': '',
  'Updated Quantity Price': '',
  'Updated Small': '',
  'Updated Medium': '',
  'Updated Large': '',
  'Updated X-Large': '',
  'Clinic Discount Price': '',
  'Discount Price For Quantity': '',
  'Discount Price For Small': '',
  'Discount Price For Medium': '',
  'Discount Price For Large': '',
  'Discount Price For X-Large': '',
  Status: '',
};
interface PrintableWellnessPlan {
  'Pet Type': string;
  'Age Group': string;
  'Wellness Plan Name': string;
  'Service Name': string;
  'Service Drop Down': string;
  'Price Based': string;
  'Price For Small': string;
  'Price For Medium': string;
  'Price For Large': string;
  'Price For X-Large': string;
  'Price For Quantity': string;
  Recommendation: string;
  'Industry Standard Price': string;
  'Clinic Recommendation': string;
  'Discount Percentage': string;
  'Doctor Percentage': string;
  'Updated Price Based': string;
  'Updated Quantity Price': string;
  'Updated Small': string;
  'Updated Medium': string;
  'Updated Large': string;
  'Updated X-Large': string;
  'Clinic Discount Price': string;
  'Discount Price For Quantity': string;
  'Discount Price For Small': string;
  'Discount Price For Medium': string;
  'Discount Price For Large': string;
  'Discount Price For X-Large': string;
  Status: string;
}
