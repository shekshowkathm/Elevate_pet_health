import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { NumberInputDirective } from '../../../../shared/directives/number-input.directive';
import {
  ClinicDropDown,
  WellnessUpdate,
} from '../../../models/wellness-plan-response';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-wellness-plan-updateform',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, NumberInputDirective],
  templateUrl: './wellness-plan-updateform.component.html',
  styleUrl: './wellness-plan-updateform.component.scss',
})
export class WellnessPlanUpdateformComponent implements OnInit {
  wellnessUpdateForm!: FormGroup;
  priceBased: string = '';
  serviceName: string = '';
  wellnessPlanName: string = '';
  clinicDropDown: ClinicDropDown = {
    dropdown: '',
    priceBased: '',
    industryStandardPrice: '',
    recommendation: '',
    wellnessUpdate: {} as WellnessUpdate,
  };

  constructor(
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
  ) {}
  priceFields = [
    {
      id: 'updatedPriceForSmall',
      label: 'Price for Small',
      formControlName: 'updatedPriceForSmall',
    },
    {
      id: 'updatedPriceForMedium',
      label: 'Price for Medium',
      formControlName: 'updatedPriceForMedium',
    },
    {
      id: 'updatedPriceForLarge',
      label: 'Price for Large',
      formControlName: 'updatedPriceForLarge',
    },
    {
      id: 'updatedPriceForXLarge',
      label: 'Price for XLarge',
      formControlName: 'updatedPriceForXLarge',
    },
  ];

  ngOnInit(): void {
    this.initializeForm();
  }

  initializeForm(): void {
    this.clinicDropDown = this.config.data.clinicDropDown;
    this.serviceName = this.config.data.serviceName;
    this.wellnessPlanName = this.config.data.wellnessPlanName;
    console.log(
      this.clinicDropDown,
      this.serviceName,
      this.wellnessPlanName,
      'uuuu',
    );
    this.wellnessUpdateForm = new FormGroup({
      wellnessUpdateId: new FormControl(
        this.clinicDropDown.wellnessUpdate.wellnessUpdateId,
      ),
      updateRecommendation: new FormControl(
        this.clinicDropDown.wellnessUpdate.updateRecommendation ||
          this.clinicDropDown.recommendation ||
          null,
        [Validators.required],
      ),
      // clinicPrice: new FormControl(
      //   clinicDropDown.wellnessUpdate.clinicPrice ||
      //     clinicDropDown.industryStandardPrice.split('$')[1] ||
      //     null,
      //   [Validators.required, Validators.pattern(/^\d+(\.\d{1,2})?$/)],
      // ),
      discountPercentage: new FormControl(
        this.clinicDropDown.wellnessUpdate.discountPercentage || null,
        [Validators.required, Validators.min(0), Validators.max(100)],
      ),
      // discountPrice: new FormControl(
      //   clinicDropDown.wellnessUpdate.discountPrice || null,
      // ),
      doctorPercentage: new FormControl(
        this.clinicDropDown.wellnessUpdate.doctorPercentage || null,
        [Validators.required, Validators.min(0), Validators.max(100)],
      ),
      status: new FormControl(this.clinicDropDown.wellnessUpdate.status),
      stipeAccountId: new FormControl(
        this.clinicDropDown.wellnessUpdate.stipeAccountId,
      ),
      stripePriceId: new FormControl(
        this.clinicDropDown.wellnessUpdate.stripePriceId,
      ),
      stripeProductId: new FormControl(
        this.clinicDropDown.wellnessUpdate.stripeProductId,
      ),
      stripeProductIdSmall: new FormControl(
        this.clinicDropDown.wellnessUpdate.stripeProductIdSmall,
      ),
      stripeProductIdMedium: new FormControl(
        this.clinicDropDown.wellnessUpdate.stripeProductIdMedium,
      ),
      stripeProductIdLarge: new FormControl(
        this.clinicDropDown.wellnessUpdate.stripeProductIdLarge,
      ),
      stripeProductIdXLarge: new FormControl(
        this.clinicDropDown.wellnessUpdate.stripeProductIdXLarge,
      ),
      stripePriceIdSmall: new FormControl(
        this.clinicDropDown.wellnessUpdate.stripePriceIdSmall,
      ),
      stripePriceIdMedium: new FormControl(
        this.clinicDropDown.wellnessUpdate.stripePriceIdMedium,
      ),
      stripePriceIdLarge: new FormControl(
        this.clinicDropDown.wellnessUpdate.stripePriceIdLarge,
      ),
      stripePriceIdXLarge: new FormControl(
        this.clinicDropDown.wellnessUpdate.stripePriceIdXLarge,
      ),
      updatedPriceForSmall: new FormControl(
        this.clinicDropDown.wellnessUpdate.updatedPriceForSmall ||
          this.clinicDropDown.priceForSmall ||
          null,
        [Validators.pattern(/^\d+(\.\d{1,2})?$/)],
      ),
      updatedPriceForMedium: new FormControl(
        this.clinicDropDown.wellnessUpdate.updatedPriceForMedium ||
          this.clinicDropDown.priceForMedium ||
          null,
        [Validators.pattern(/^\d+(\.\d{1,2})?$/)],
      ),
      updatedPriceForLarge: new FormControl(
        this.clinicDropDown.wellnessUpdate.updatedPriceForLarge ||
          this.clinicDropDown.priceForLarge ||
          null,
        [Validators.pattern(/^\d+(\.\d{1,2})?$/)],
      ),
      updatedPriceForXLarge: new FormControl(
        this.clinicDropDown.wellnessUpdate.updatedPriceForXLarge ||
          this.clinicDropDown.priceForXLarge,
        [Validators.pattern(/^\d+(\.\d{1,2})?$/)],
      ),
      updatedPriceForQuantity: new FormControl(
        this.clinicDropDown.wellnessUpdate.updatedPriceForQuantity ||
          this.clinicDropDown.priceForQuantity,
        [Validators.pattern(/^\d+(\.\d{1,2})?$/)],
      ),
    });
    this.updateFieldStates(this.clinicDropDown);
  }

  onSubmit(): void {
    if (this.wellnessUpdateForm.valid) {
      const formValue: WellnessUpdate = this.wellnessUpdateForm.getRawValue();
      this.ref.close(formValue);
    } else {
      this.wellnessUpdateForm.markAllAsTouched();
    }
  }

  onReset(): void {
    this.wellnessUpdateForm.reset();
  }

  get control() {
    return this.wellnessUpdateForm.controls;
  }

  updateFieldStates(clinicDropDown: ClinicDropDown): void {
    const priceBased = clinicDropDown.priceBased;
    this.priceBased = priceBased;
    if (priceBased === 'QTY') {
      this.priceFields.forEach((field) => {
        this.disableField(field.formControlName);
      });
      this.enableField('priceForQuantity');
    } else if (priceBased === 'WGT') {
      this.priceFields.forEach((field) => {
        this.enableField(field.formControlName);
      });
      this.disableField('priceForQuantity');
    }
  }

  disableField(fieldName: string): void {
    const control = this.wellnessUpdateForm.get(fieldName);
    if (control) {
      control.disable();
      control.clearValidators();
      control.updateValueAndValidity();
    }
  }

  enableField(fieldName: string): void {
    const control = this.wellnessUpdateForm.get(fieldName);
    if (control) {
      control.enable();
      control.setValidators([Validators.pattern(/^\d+(\.\d{1,2})?$/)]);
      control.updateValueAndValidity();
    }
  }
  close() {
    this.ref.close();
  }
}
