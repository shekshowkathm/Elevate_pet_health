import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WellnessPlanUpdateformComponent } from './wellness-plan-updateform.component';

describe('WellnessPlanUpdateformComponent', () => {
  let component: WellnessPlanUpdateformComponent;
  let fixture: ComponentFixture<WellnessPlanUpdateformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WellnessPlanUpdateformComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WellnessPlanUpdateformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
