import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicUserProfileComponent } from './clinic-user-profile.component';

describe('ClinicUserProfileComponent', () => {
  let component: ClinicUserProfileComponent;
  let fixture: ComponentFixture<ClinicUserProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClinicUserProfileComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClinicUserProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
