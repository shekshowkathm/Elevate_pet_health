import { Component, Inject, inject, OnInit, PLATFORM_ID } from '@angular/core';
import { ClinicService } from '../../services/clinic.service';
import { isPlatformBrowser, NgIf } from '@angular/common';
import { ClinicAuthService } from '../../services/clinic-auth.service';
import { Router } from '@angular/router';
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { ClinicUser } from '../../models/clinic-user';
import { ToastModule } from 'primeng/toast';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { MessageService } from 'primeng/api';
import { HttpErrorResponse } from '@angular/common/http';
import {
  DialogService,
  DynamicDialogModule,
  DynamicDialogRef,
} from 'primeng/dynamicdialog';
import { ImageUploadComponent } from '../../../shared/component/image-upload/image-upload.component';
import { US_STATES } from '../../../shared/constants/usa-states';
import { CustomDropdownComponent } from '../custom-dropdown/custom-dropdown.component';
import { PhoneNumberDirective } from '../../../shared/directives/phone-number.directive';
import { NumberInputDirective } from '../../../shared/directives/number-input.directive';
import { TIME_ZONES } from '../../../shared/constants/timeZone';

@Component({
  selector: 'app-clinic-user-profile',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    NgIf,
    ToastModule,
    ProgressSpinnerModule,
    DynamicDialogModule,
    CustomDropdownComponent,
    PhoneNumberDirective,
    NumberInputDirective,
  ],
  templateUrl: './clinic-user-profile.component.html',
  styleUrl: './clinic-user-profile.component.scss',
  providers: [MessageService, DialogService],
})
export class ClinicUserProfileComponent implements OnInit {
  private clinicService = inject(ClinicService);
  private clinicAuthService = inject(ClinicAuthService);
  private router = inject(Router);
  ref: DynamicDialogRef | undefined;

  userDetail = this.clinicService.userDataSignal;
  loader: boolean = false;
  userEmail = this.clinicAuthService.getEmail();
  matchedUrl: boolean = false;
  selectedImageUrl: string = '';

  clinicUserProfileForm: FormGroup;
  states = US_STATES;
  timeZones: { label: string; value: string }[] = TIME_ZONES.map((t) => ({
    label: `${t.fullName} (${t.abbreviation})`,
    value: t.abbreviation,
  }));

  constructor(
    private messageService: MessageService,
    @Inject(PLATFORM_ID) private platformId: Object,
    public dialogService: DialogService
  ) {
    this.clinicUserProfileForm = this.createFormGroup();
  }
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.checkAndCallUserDetailMethod();
    }
  }

  /**
   *  Checks if the current page is update profile page.
   * If the current page is update profile page, the userDetail method will be called
   * upon page refresh with form initialzation.
   * Otherwise, the userDetail method will be called with initialize the userProfileForm.
   */
  private checkAndCallUserDetailMethod() {
    const matchedUrl = /update-profile/.test(this.router.url);
    if (matchedUrl) {
      this.matchedUrl = true;
      if (!this.userDetail()) {
        this.fetchUserDetailForUpdatePage();
      } else {
        this.initializeUserProfileForm();
      }
    } else {
      this.matchedUrl = false;
      if (!this.userDetail()) {
        this.fetchUserDetail();
      }
    }
  }

  private fetchUserDetail() {
    this.loader = true;
    this.clinicService.getCurrentClinicLoggedInUser().subscribe({
      next: (val: any) => {
        this.userDetail.set(val as ClinicUser);
        this.loader = false;
      },
      error: (err: HttpErrorResponse) => {
        console.error('Error fetching user details:', err);
        this.loader = false;
      },
    });
  }

  private fetchUserDetailForUpdatePage() {
    this.loader = true;
    this.clinicService.getCurrentClinicLoggedInUser().subscribe({
      next: (val: any) => {
        this.userDetail.set(val as ClinicUser);
        this.loader = false;
        this.initializeUserProfileForm();
      },
      error: (err: HttpErrorResponse) => {
        console.error('Error fetching user details for update page:', err);
        this.loader = false;
      },
    });
  }

  private initializeUserProfileForm(): void {
    const user = this.userDetail();
    if (user) {
      this.clinicUserProfileForm.patchValue({
        firstName: user.firstName,
        lastName: user.lastName,
        contactNumber: user.contactNumber,
        address: user.address,
        city: user.city,
        state: user.state,
        zipcode: user.zipcode,
        timezone: this.clinicAuthService.getUserTimeZone(),
      });
    }
  }

  navigateToUpdateProfile() {
    if (!this.matchedUrl) {
      this.router.navigateByUrl('/clinic/update-profile');
    }
  }

  navigateToDashboard() {
    this.router.navigateByUrl('/clinic/dashboard');
  }

  updateClinicProfileform() {
    this.loader = true;
    const {
      firstName,
      lastName,
      contactNumber,
      state,
      city,
      zipcode,
      address,
      timezone,
    } = this.clinicUserProfileForm.value;

    const payload: ClinicUser = {
      id: this.userDetail()?.id,
      profile: this.selectedImageUrl
        ? this.selectedImageUrl
        : this.userDetail()?.profile,
      designation: this.userDetail()?.designation,
      contactNumber: contactNumber!,
      doctor: this.userDetail()?.doctor,
      state: state!,
      city: city!,
      zipcode: zipcode!,
      address: address!,
      firstName: firstName,
      lastName: lastName,
      timezone: timezone,
    };
    this.clinicService.UpadateClinicUser(payload).subscribe({
      next: (res: any) => {
        console.log(res);
        this.loader = false;
        this.clinicUserProfileForm.reset();
        this.fetchUserDetail();
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Profile Details updated sucessfully',
        });
        setTimeout(() => {
          this.router.navigateByUrl('/clinic/profile');
        }, 1000);
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        console.log(err);
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Cannot Update Profile, Try again!',
        });
      },
    });
  }

  private createFormGroup(): FormGroup {
    return new FormGroup({
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', [Validators.required]),
      timezone: new FormControl('', [Validators.required]),
      contactNumber: new FormControl('', [
        Validators.required,
        Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/),
      ]),
      address: new FormControl('', [Validators.required]),
      city: new FormControl('', [Validators.required]),
      state: new FormControl('', [Validators.required]),
      zipcode: new FormControl('', [
        Validators.required,
        Validators.pattern('^\\d{5}(-\\d{4})?$'),
      ]),
    });
  }

  uploadOrSelectImage() {
    this.ref = this.dialogService.open(ImageUploadComponent, {
      header: 'Upload Image',
      width: '500px',
      modal: true,
      breakpoints: {
        '640px': '90vw',
      },
    });
    this.ref.onClose.subscribe((url: any) => {
      if (url) {
        this.selectedImageUrl = url;
      }
      console.log('url', url);
    });
  }

  getStateNameWithCode(stateCode: string): string {
    if (!stateCode) return '';
    const state = this.states.find((s) => s.code === stateCode);
    return `${state?.name} (${state?.code})`;
  }
}
