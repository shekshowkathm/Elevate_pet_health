import {
  AfterViewInit,
  Component,
  computed,
  ElementRef,
  Inject,
  inject,
  input,
  OnDestroy,
  OnInit,
  PLATFORM_ID,
  Renderer2,
  signal,
  ViewChild,
} from '@angular/core';
import { ClinicAuthService } from '../../services/clinic-auth.service';
import { ClinicService } from '../../services/clinic.service';
import { DialogModule } from 'primeng/dialog';
import { FormsModule, NgForm, NgModel } from '@angular/forms';
import { isPlatformBrowser, NgIf } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastModule } from 'primeng/toast';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Router, RouterLink } from '@angular/router';
import { NotVerifiedPerOwner } from '../../models/pet-owner-response';
import { ClinicUser } from '../../models/clinic-user';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { TermsAndConditionsComponent } from '../../../shared/component/terms-and-conditions/terms-and-conditions.component';

@Component({
  selector: 'app-top-nav',
  standalone: true,
  imports: [
    DialogModule,
    FormsModule,
    NgIf,
    ToastModule,
    ConfirmDialogModule,
    RouterLink,
  ],
  templateUrl: './top-nav.component.html',
  styleUrl: './top-nav.component.scss',
  providers: [MessageService, ConfirmationService, DialogService],
})
export class TopNavComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('popup') popup: ElementRef | undefined;
  isLeftSidebarCollapsed = input.required<boolean>();
  private clinicAuthService = inject(ClinicAuthService);
  private router = inject(Router);
  role = this.clinicAuthService.getRole();
  email = this.clinicAuthService.getEmail();
  selectedClinic = this.clinicAuthService.getSelectedClinic();
  isVisibleProfileOptions: boolean = false;
  showUpdateForm: boolean = false;
  passwordsMatching = false;
  userDetail = signal<ClinicUser | null>(null);
  notVerifiedPerOwners = signal<NotVerifiedPerOwner[] | null>(null);
  ref: DynamicDialogRef | undefined;

  notificationCount = computed(() => this.notVerifiedPerOwners()?.length || 0);

  constructor(
    private messageService: MessageService,
    private clinicService: ClinicService,
    private renderer: Renderer2,
    private confirmationService: ConfirmationService,
    @Inject(PLATFORM_ID) private platformId: Object,
    public dialogService: DialogService,
  ) {}

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.checkProfileOrUpdateProfile();
      this.userDetail = this.clinicService.userDataSignal;
      this.notVerifiedPerOwners = this.clinicService.notVerifiedPerOwnersSignal;
    }
  }

  ngAfterViewInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      const terms = this.clinicAuthService.getTerms();
      if (!terms) {
        this.showTermsAndServices();
      }
    }
  }

  /**
   * Checks if the current page is either the profile or update profile page.
   * If the current page is one of these, the userDetail method will not be called upon page refresh.
   * Otherwise, the userDetail method will be called on other pages.
   */
  checkProfileOrUpdateProfile() {
    const matchedUrl = /update-profile|profile/.test(this.router.url);
    if (!matchedUrl) {
      this.getUserDetails();
    }
  }

  showProfileOptions() {
    if (this.isVisibleProfileOptions) {
      this.isVisibleProfileOptions = false;
    } else {
      this.isVisibleProfileOptions = true;
      this.renderer.listen('window', 'click', (e: Event) =>
        this.onClickOutside(e),
      );
    }
  }
  onClickOutside(e: Event): boolean | void {
    if (this.popup && !this.popup.nativeElement.contains(e.target)) {
      this.isVisibleProfileOptions = false;
    }
  }

  showPasswordUpdateForm() {
    this.showUpdateForm = !this.showUpdateForm;
    if (this.isLeftSidebarCollapsed()) {
      this.isVisibleProfileOptions = false;
    }
  }

  cancelPasswordUpdate(form: NgForm) {
    this.showUpdateForm = false;
    form.reset();
    if (this.isLeftSidebarCollapsed()) {
      this.isVisibleProfileOptions = false;
    }
    if (localStorage.getItem('profilePage') === 'open') {
      this.isVisibleProfileOptions = false;
      this.router.navigateByUrl('clinic/update-profile');
      localStorage.removeItem('profilePage');
    }
  }

  submitForm(form: NgForm) {
    this.clinicService.UpdatePassword(form.value.password).subscribe({
      next: (res) => {
        form.reset();
        this.showUpdateForm = false;
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Password updated successfully!',
        });
        if (localStorage.getItem('profilePage') === 'open') {
          this.isVisibleProfileOptions = false;
          this.router.navigateByUrl('clinic/update-profile');
          localStorage.removeItem('profilePage');
        }
      },
      error: (err: HttpErrorResponse) => {
        console.log(err);
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Somthing went wrong. Try again!',
        });
      },
    });
  }

  checkPasswordMatch(
    passwordControl: NgModel,
    confirmPasswordControl: NgModel,
  ) {
    const password = passwordControl.control.value;
    const confirmPassword = confirmPasswordControl.control.value;
    if (password === confirmPassword) {
      this.passwordsMatching = true;
    } else {
      this.passwordsMatching = false;
    }
  }

  logout() {
    this.confirmationService.confirm({
      message: 'Are you sure you want to log out?',
      header: 'Logout Confirmation',
      icon: 'pi pi-info-circle',
      accept: () => {
        this.clinicAuthService.logout();
        this.router.navigateByUrl('');
        this.isVisibleProfileOptions = false;
        this.showUpdateForm = false;
        this.clinicService.userDataSignal.set(null);
        this.clinicAuthService.clearSelectedClinic();
      },
      reject: () => {},
    });
  }

  gotoProfile() {
    this.isVisibleProfileOptions = false;
    this.router.navigateByUrl('clinic/profile');
  }

  clinicNotification() {
    this.router.navigateByUrl('clinic/clinicNotification');
    this.clinicService.callNotVerifiedOwnersMethod();
  }

  getUserDetails() {
    this.clinicService.getCurrentClinicLoggedInUser().subscribe({
      next: (val: any) => {
        this.userDetail.set(val as ClinicUser);
      },
    });
  }

  showTermsAndServices() {
    this.ref = this.dialogService.open(TermsAndConditionsComponent, {
      header: 'Welcome to Your Work Place !',
      width: '70%',
      breakpoints: {
        '960px': '75vw',
        '640px': '90vw',
      },
      style: {
        'box-shadow': '#007cda 0px 0px 10px 3px',
      },
      duplicate: false,
    });
    this.ref.onClose.subscribe((res: boolean) => {
      if (res) {
        console.log('first', res);
        this.clinicService.updateTermsAndConditions().subscribe({
          next: (res: any) => {
            console.log(res);
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Terms and Conditions updated',
            });
            this.clinicAuthService.setTermsAndConditions(true);
            this.showUpdateForm = true;
            localStorage.setItem('profilePage', 'open');
          },
          error: (err: HttpErrorResponse) => {
            console.log(err);
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'somthing wrong',
            });
          },
        });
      } else {
        console.log('second', res);
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'somithing wrong',
        });
        this.router.navigateByUrl('');
        this.clinicAuthService.logout();
      }
    });
  }

  ngOnDestroy() {
    if (this.ref) {
      this.ref.close();
    }
  }
}
