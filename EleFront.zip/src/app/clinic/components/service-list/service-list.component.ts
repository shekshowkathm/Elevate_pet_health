import {
  Component,
  inject,
  Inject,
  PLATFORM_ID,
  signal,
  effect,
  computed,
} from '@angular/core';
import { CurrencyPipe, isPlatformBrowser } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TableModule } from 'primeng/table';
import { WellnessService } from '../../services/wellness.service';
import { SharedService } from '../../../shared/service/shared.service';
import { ServiceList } from '../../models/service-list-response';
import { InputTextModule } from 'primeng/inputtext';
import { FormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';

@Component({
  selector: 'app-service-list',
  standalone: true,
  imports: [
    TableModule,
    ProgressSpinnerModule,
    InputTextModule,
    FormsModule,
    DropdownModule,
    CurrencyPipe,
  ],
  templateUrl: './service-list.component.html',
  styleUrl: './service-list.component.scss',
})
export class ServiceListComponent {
  private sharedService = inject(SharedService);
  private wellnessService = inject(WellnessService);
  serviceList = signal<ServiceList[]>([]);
  loader: boolean = false;
  petTypes: { name: string; value: string }[] = [
    {
      name: 'Dog',
      value: 'Dog',
    },
    {
      name: 'Cat',
      value: 'Cat',
    },
  ];
  petTypeFilter = signal<string | null>(null);
  serviceFilter = signal<string | null>(null);
  filteredServices = computed(() => {
    const petType = this.petTypeFilter()?.toLowerCase();
    const service = this.serviceFilter()?.toLowerCase();

    const res = this.serviceList().filter(
      (item) =>
        (petType ? item.petType.toLowerCase() === petType : true) &&
        (service ? item.service.toLowerCase().includes(service) : true),
    );
    return res;
  });

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.fetchServiceList();
    }
  }

  fetchServiceList() {
    this.loader = true;
    this.wellnessService.fetchServiceList().subscribe({
      next: (res: any) => {
        this.serviceList.set(res as ServiceList[]);
        this.loader = false;
      },
      error: (err: HttpErrorResponse) => {
        console.error('Error fetching weight range', err);
        this.loader = false;
      },
    });
  }
  exportAsExcel() {
    const printableServiceTableArray: PrintServiceList[] =
      this.transformToPrintServiceList(this.serviceList());
    this.sharedService.exportAsExcelFile(
      printableServiceTableArray,
      'service-list',
    );
  }

  private transformToPrintServiceList(
    serviceList: ServiceList[],
  ): PrintServiceList[] {
    return serviceList.reduce((acc: PrintServiceList[], service) => {
      const transformedDropdowns = service.dropdowns.map((dropdown) => ({
        'Pet type': service.petType,
        'Service Name': service.service,
        'Service Drop Down': dropdown.dropdown,
        'Based on QTY & Weight': dropdown.priceBased,
        'Small Weight Price': dropdown.priceForSmall,
        'Medium Weight Price': dropdown.priceForMedium,
        'Large Weight Price': dropdown.priceForLarge,
        'X-Large Weight Price': dropdown.priceForXLarge,
        'Quantity Based Price': dropdown.priceForQuantity,
        'Industry Standard Price': dropdown.industryStandardPrice,
      }));
      return acc.concat(transformedDropdowns);
    }, []);
  }

  clearFilter() {
    this.petTypeFilter.set(null);
    this.serviceFilter.set(null);
  }
}

interface PrintServiceList {
  'Pet type': string;
  'Service Name': string;
  'Service Drop Down': string;
  'Based on QTY & Weight': string;
  'Small Weight Price': string;
  'Medium Weight Price': string;
  'Large Weight Price': string;
  'X-Large Weight Price': string;
  'Quantity Based Price': string;
  'Industry Standard Price': string;
}
