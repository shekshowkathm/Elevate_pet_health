import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WeightRangeComponent } from './weight-range.component';

describe('WeightRangeComponent', () => {
  let component: WeightRangeComponent;
  let fixture: ComponentFixture<WeightRangeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WeightRangeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WeightRangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
