import { isPlatformBrowser } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
  Component,
  inject,
  Inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TableModule } from 'primeng/table';
import { weightRangeResponse } from '../../models/weight-range-response';
import { WellnessService } from '../../services/wellness.service';
import { FormsModule } from '@angular/forms';
import { ClinicAuthService } from '../../services/clinic-auth.service';
import { ClinicAdminService } from '../../services/clinic-admin.service';
import { AdminAccess } from '../../models/admin-access';
import { SharedService } from '../../../shared/service/shared.service';

@Component({
  selector: 'app-weight-range',
  standalone: true,
  imports: [TableModule, ProgressSpinnerModule, FormsModule],
  templateUrl: './weight-range.component.html',
  styleUrl: './weight-range.component.scss',
})
export class WeightRangeComponent implements OnInit {
  private wellnessService = inject(WellnessService);
  private clinicAuthService = inject(ClinicAuthService);
  private clinicAdminService = inject(ClinicAdminService);
  private sharedService = inject(SharedService);
  weightRangeList = signal<weightRangeResponse[]>([]);
  loader: boolean = false;
  currentUser = '';
  selectedUpdatedWeight: string = '';
  disableOtherEditBtn: boolean = false;
  clinicAmdminAccess = signal<AdminAccess>({
    clinicAdminId: 0,
    updateWeightRange: false,
    updateClinicPrice: false,
    updateRecommendation: false,
    updateDiscountPercentage: false,
    updateDiscountPrice: false,
    updateDoctorPercentage: false,
    viewPayment: false,
  });
  currentSelectedpetWetRange = signal<weightRangeResponse | null>(null);

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.fetchWeightRange();
      this.currentUser = this.clinicAuthService.getRole();
      if (this.currentUser === 'CLINIC_ADMIN') {
        this.fetchClinicAdminAccess();
      }
    }
  }

  fetchClinicAdminAccess() {
    const clinicAdminId = Number(this.clinicAuthService.getUserId());
    if (!clinicAdminId) return;
    this.clinicAdminService.fetchClinicAdminAccess(clinicAdminId).subscribe({
      next: (val: any) => {
        this.clinicAmdminAccess.set(val as AdminAccess);
      },
      error: (err: HttpErrorResponse) => {
        console.log(
          'Error fetching clinic admin access in wellness plan coponent',
          err,
        );
      },
    });
  }

  fetchWeightRange() {
    this.loader = true;
    this.wellnessService.fetchWeightRange().subscribe({
      next: (res: any) => {
        this.weightRangeList.set(res as weightRangeResponse[]);
        this.loader = false;
      },
      error: (err: HttpErrorResponse) => {
        console.error('Error fetching weight range', err);
        this.loader = false;
      },
    });
  }
  editUpdatedWeight(pet: weightRangeResponse) {
    if (pet.updatedWeight) {
      this.selectedUpdatedWeight = pet.updatedWeight;
    } else {
      this.selectedUpdatedWeight = pet.weight;
    }
    this.currentSelectedpetWetRange.set(pet);
    this.disableOtherEditBtn = true;
  }

  updateUpdatedWeight(pet: weightRangeResponse) {
    if (
      this.currentSelectedpetWetRange()?.clinicWeightRangeId ===
      pet.clinicWeightRangeId
    ) {
      this.wellnessService
        .updateWeightRange(pet.clinicWeightRangeId, this.selectedUpdatedWeight)
        .subscribe({
          next: (res: any) => {
            this.fetchWeightRange();
            this.cancelOrRestUpdatedWeight();
          },
          error: (err: HttpErrorResponse) => {
            console.log('Error updating weight range', err);
          },
        });
    }
  }

  cancelOrRestUpdatedWeight() {
    this.selectedUpdatedWeight = '';
    this.disableOtherEditBtn = false;
    this.currentSelectedpetWetRange.set(null);
  }

  exportAsExcel() {
    const pritableWeightRange: PrintableWeightRange[] =
      this.weightRangeList().map((w) => ({
        'Pet Type': w.petType,
        Weight: w.weight,
        'Size of Pet': w.size,
        'Updated Weight': w.updatedWeight,
      }));
    this.weightRangeList().map((w) => ({}));
    this.sharedService.exportAsExcelFile(pritableWeightRange, 'weight-range');
  }
}

interface PrintableWeightRange {
  'Pet Type': string;
  Weight: string;
  'Size of Pet': string;
  'Updated Weight': string;
}
