import { isPlatformBrowser, NgClass } from '@angular/common';
import {
  Component,
  Inject,
  inject,
  input,
  OnInit,
  output,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { NavItemComponent } from './nav-item/nav-item.component';
import { NavigationItem, NavigationItemsService } from './navigation';
import { NavCollapseComponent } from './nav-collapse/nav-collapse.component';
import { Router } from '@angular/router';
import { ClinicAuthService } from '../../services/clinic-auth.service';
import { ClinicAdminService } from '../../services/clinic-admin.service';
import { HttpErrorResponse } from '@angular/common/http';
import { AdminAccess } from '../../models/admin-access';
import { Roles } from '../../../shared/enum/roles';

@Component({
  selector: 'app-left-sidebar',
  standalone: true,
  imports: [NgClass, NavItemComponent, NavCollapseComponent],
  templateUrl: './left-sidebar.component.html',
  styleUrl: './left-sidebar.component.scss',
})
export class LeftSidebarComponent implements OnInit {
  isLeftSidebarCollapsed = input.required<boolean>();
  changeIsLeftSidebarCollapsed = output<boolean>();
  navItems = signal<NavigationItem[]>([]);
  navService = inject(NavigationItemsService);
  clinicAuthService = inject(ClinicAuthService);
  private clinicAdminService = inject(ClinicAdminService);
  router = inject(Router);
  role = this.clinicAuthService.getRole();
  roles = Roles;
  clinicAmdminAccess = signal<AdminAccess>({
    clinicAdminId: 0,
    updateWeightRange: false,
    updateClinicPrice: false,
    updateRecommendation: false,
    updateDiscountPercentage: false,
    updateDiscountPrice: false,
    updateDoctorPercentage: false,
    viewPayment: false,
  });
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.displayNavigationBasedOnUser();
    }
  }

  /**
   * Method will check the current logged in user (CLINIC_OWNER, CLINIC_ADMIN, CLINIC_ASSOCIATE)
   */
  displayNavigationBasedOnUser() {
    if (this.role === Roles.CLINIC_OWNER) {
      this.navItems.set(this.navService.getClinicOwnerRoutes());
    } else if (this.role === Roles.CLINIC_ADMIN) {
      this.navItems.set(this.navService.getClinicAdminRoutes());
      this.fetchClinicAdminAccess();
    } else if (this.role === Roles.CLINIC_ASSOCIATE) {
      this.navItems.set(this.navService.getClinicAssociateRoutes());
    } else {
      this.clinicAuthService.logout();
      this.router.navigateByUrl('');
    }
  }

  toggleCollapse(): void {
    this.changeIsLeftSidebarCollapsed.emit(!this.isLeftSidebarCollapsed());
  }

  closeSidenav(): void {
    this.changeIsLeftSidebarCollapsed.emit(true);
  }

  changeDropDown(navItem: NavigationItem) {
    navItem.isOpen = !navItem.isOpen;
  }

  private fetchClinicAdminAccess() {
    const clinicAdminId = Number(this.clinicAuthService.getUserId());
    if (!clinicAdminId) return;
    this.clinicAdminService.fetchClinicAdminAccess(clinicAdminId).subscribe({
      next: (val: any) => {
        this.clinicAmdminAccess.set(val as AdminAccess);
      },
      error: (err: HttpErrorResponse) => {
        console.log(
          'Error fetching clinic admin access in wellness plan coponent',
          err,
        );
      },
    });
  }
}
