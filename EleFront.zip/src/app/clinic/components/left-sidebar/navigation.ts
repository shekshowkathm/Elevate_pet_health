import { Injectable } from '@angular/core';

export interface NavigationItem {
  label: string;
  icon?: string;
  route?: string;
  color?: string;
  children?: NavigationItem[];
  isOpen?: boolean;
  type: 'collapse' | 'item';
}

export const CLINIC_OWNER_NAVIGATION: NavigationItem[] = [
  {
    label: 'Dashboard',
    icon: 'pi-th-large',
    route: 'dashboard',
    type: 'item',
  },
  {
    label: 'Clinic Details',
    icon: 'pi-envelope',
    type: 'collapse',
    route: 'clinic-detail',
    children: [
      {
        label: 'Clinic Admin',
        route: 'clinic-admin',
        color: '#ffb946',
        type: 'item',
      },
      {
        label: 'Associates',
        route: 'clinic-associate',
        color: '#885af8',
        type: 'item',
      },
      {
        label: 'Pet Owners',
        route: 'pet-owners',
        color: '#2ed47a',
        type: 'item',
      },
    ],
  },
  {
    label: 'Service List',
    icon: 'pi-briefcase',
    route: 'service-list',
    type: 'item',
  },
  {
    label: 'Setup Data',
    icon: 'pi-heart-fill',
    route: 'wellness-plan-details',
    type: 'item',
  },
  {
    label: 'Scheduled Appointments',
    icon: 'pi-calendar-plus',
    route: 'scheduled-appointments',
    type: 'item',
  },
  {
    label: 'Transaction details',
    icon: 'pi-money-bill',
    route: 'transactions',
    type: 'item',
  },
  {
    label: 'Alerts',
    icon: 'pi-bell',
    route: 'all-alerts',
    type: 'item',
  },
  {
    label: 'Support',
    icon: 'pi-users',
    route: 'support',
    type: 'item',
  },
];

export const CLINIC_ADMIN_NAVIGATION: NavigationItem[] = [
  {
    label: 'Dashboard',
    icon: 'pi-th-large',
    route: 'dashboard',
    type: 'item',
  },
  {
    label: 'Clinic Details',
    icon: 'pi-envelope',
    type: 'collapse',
    route: 'clinic-detail',
    children: [
      {
        label: 'Associates',
        route: 'clinic-associate',
        color: '#885af8',
        type: 'item',
      },
      {
        label: 'Pet Owners',
        route: 'pet-owners',
        color: '#2ed47a',
        type: 'item',
      },
    ],
  },
  {
    label: 'Service List',
    icon: 'pi-briefcase',
    route: 'service-list',
    type: 'item',
  },
  {
    label: 'Setup Data',
    icon: 'pi-heart-fill',
    route: 'wellness-plan-details',
    type: 'item',
  },
  {
    label: 'Scheduled Appointments',
    icon: 'pi-calendar-plus',
    route: 'scheduled-appointments',
    type: 'item',
  },
  {
    label: 'Transaction details',
    icon: 'pi-money-bill',
    route: 'transactions',
    type: 'item',
  },
  {
    label: 'Alerts',
    icon: 'pi-bell',
    route: 'all-alerts',
    type: 'item',
  },
  {
    label: 'Support',
    icon: 'pi-users',
    route: 'support',
    type: 'item',
  },
];

export const CLINIC_ASSOCIATE_NAVIGATION: NavigationItem[] = [
  {
    label: 'Dashboard',
    icon: 'pi-th-large',
    route: 'dashboard',
    type: 'item',
  },
  {
    label: 'Pet Owners',
    route: 'pet-owners',
    icon: 'pi-user',
    type: 'item',
  },
  {
    label: 'Service List',
    icon: 'pi-briefcase',
    route: 'service-list',
    type: 'item',
  },
  {
    label: 'Setup Data',
    icon: 'pi-heart-fill',
    route: 'wellness-plan-details',
    type: 'item',
  },
  {
    label: 'Scheduled Appointments',
    icon: 'pi-calendar-plus',
    route: 'scheduled-appointments',
    type: 'item',
  },
  {
    label: 'Alerts',
    icon: 'pi-bell',
    route: 'all-alerts',
    type: 'item',
  },
  {
    label: 'Support',
    icon: 'pi-users',
    route: 'support',
    type: 'item',
  },
];

@Injectable({
  providedIn: 'root',
})
export class NavigationItemsService {
  getClinicOwnerRoutes() {
    return CLINIC_OWNER_NAVIGATION;
  }

  getClinicAdminRoutes() {
    return CLINIC_ADMIN_NAVIGATION;
  }
  getClinicAssociateRoutes() {
    return CLINIC_ASSOCIATE_NAVIGATION;
  }
}
