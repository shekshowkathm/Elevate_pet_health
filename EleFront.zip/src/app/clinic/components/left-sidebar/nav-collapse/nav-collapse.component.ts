import { NgClass } from '@angular/common';
import { Component, input, signal } from '@angular/core';
import { NavigationItem } from '../navigation';
import { NavItemComponent } from '../nav-item/nav-item.component';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { TooltipModule } from 'primeng/tooltip';

@Component({
  selector: 'app-nav-collapse',
  standalone: true,
  imports: [
    NgClass,
    NavItemComponent,
    RouterLink,
    RouterLinkActive,
    TooltipModule,
  ],
  templateUrl: './nav-collapse.component.html',
  styleUrl: './nav-collapse.component.scss',
})
export class NavCollapseComponent {
  isLeftSidebarCollapsed = input.required<boolean>();
  navItem = input.required<NavigationItem>();
  isOpened = signal<boolean>(false);

  toggleIsOpened() {
    this.isOpened.update((value) => !value);
  }
}
