import { Component, input } from '@angular/core';
import { NavigationItem } from '../navigation';
import { RouterModule } from '@angular/router';
import { NgClass } from '@angular/common';
import { TooltipModule } from 'primeng/tooltip';

@Component({
  selector: 'app-nav-item',
  standalone: true,
  imports: [RouterModule, NgClass, TooltipModule],
  templateUrl: './nav-item.component.html',
  styleUrl: './nav-item.component.scss',
})
export class NavItemComponent {
  item = input.required<NavigationItem>();
  isLeftSidebarCollapsed = input.required<boolean>();
}
