import { NgIf } from '@angular/common';
import { Component, inject } from '@angular/core';
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ToastModule } from 'primeng/toast';
import { RequestClinic } from '../../models/request-clinic';
import { ClinicService } from '../../services/clinic.service';
import { US_STATES } from '../../../shared/constants/usa-states';
import { CustomDropdownComponent } from '../custom-dropdown/custom-dropdown.component';
import { PhoneNumberDirective } from '../../../shared/directives/phone-number.directive';
import { NumberInputDirective } from '../../../shared/directives/number-input.directive';
import { HttpErrorResponse, HttpStatusCode } from '@angular/common/http';

@Component({
  selector: 'app-request-new-clinic',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    NgIf,
    ProgressSpinnerModule,
    ToastModule,
    CustomDropdownComponent,
    PhoneNumberDirective,
    NumberInputDirective,
  ],
  templateUrl: './request-new-clinic.component.html',
  styleUrl: './request-new-clinic.component.scss',
  providers: [MessageService],
})
export class RequestNewClinicComponent {
  private router = inject(Router);
  private clinicService = inject(ClinicService);
  loader: boolean = false;
  states = US_STATES;
  clinicRequestForm = new FormGroup({
    clinicName: new FormControl('', [Validators.required]),
    contactNumber: new FormControl('', [
      Validators.required,
      Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/),
    ]),
    email: new FormControl('', [Validators.required, Validators.email]),
    address: new FormControl('', [Validators.required]),
    city: new FormControl('', [Validators.required]),
    state: new FormControl('', [Validators.required]),
    zipCode: new FormControl('', [
      Validators.required,
      Validators.pattern('^\\d{5}(-\\d{4})?$'),
    ]),
  });

  constructor(private messageService: MessageService) {}

  submitRequestForm() {
    this.loader = true;
    const payload: RequestClinic = {
      clinicName: this.clinicRequestForm.value.clinicName!,
      address: this.clinicRequestForm.value.address!,
      zipCode: this.clinicRequestForm.value.zipCode!,
      city: this.clinicRequestForm.value.city!,
      contactNumber: this.clinicRequestForm.value.contactNumber!,
      email: this.clinicRequestForm.value.email!,
      state: this.clinicRequestForm.value.state!,
    };
    this.clinicService.RequestForNewClinic(payload).subscribe({
      next: (res: string) => {
        this.loader = false;
        this.clinicRequestForm.reset();
        this.messageService.add({
          severity: 'success',
          summary: 'Thank you for your submission!',
          detail:
            'Your request for a new clinic has been received. Our team will review and verify the information provided. You will be notified once your request has been approved',
        });
        setTimeout(() => {
          this.router.navigateByUrl('/clinic/dashboard');
        }, 5000);
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        if (err.status === HttpStatusCode.Conflict) {
          this.messageService.add({
            severity: 'error',
            summary: 'Email Already Exists',
            detail: err.error,
          });
          return;
        }
        this.messageService.add({
          severity: 'error',
          summary: 'Submission Failed',
          detail:
            'There was an error processing your request. Please try again later or contact support if the issue persists.',
        });
      },
    });
  }
}
