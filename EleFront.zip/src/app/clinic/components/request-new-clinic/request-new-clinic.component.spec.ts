import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestNewClinicComponent } from './request-new-clinic.component';

describe('RequestNewClinicComponent', () => {
  let component: RequestNewClinicComponent;
  let fixture: ComponentFixture<RequestNewClinicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RequestNewClinicComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RequestNewClinicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
