import {
  Component,
  computed,
  Inject,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TableModule } from 'primeng/table';
import { Appointment } from '../../models/appointment';
import { AppointmentService } from '../../services/appointment.service';
import { CommonModule, DatePipe, isPlatformBrowser, NgIf } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';

@Component({
  selector: 'app-scheduled-appointments',
  standalone: true,
  imports: [TableModule, ProgressSpinnerModule, DatePipe, FormsModule,CommonModule,ButtonModule],
  templateUrl: './scheduled-appointments.component.html',
  styleUrl: './scheduled-appointments.component.scss',
})
export class ScheduledAppointmentsComponent implements OnInit {
  private appointmentService = inject(AppointmentService);
  private router = inject(Router);
  selectedStatus = signal('');
  loader: boolean = false;
  applyShadow: boolean = true;
  scheduledAppointments = signal<Appointment[]>([]);
  searchTerm = signal<string | null>(null);
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.fetchScheduledAppointments();
    }
  }

  filteredScheduledAppointments = computed(() => {
    const searchTerm = this.searchTerm()?.toLowerCase();
    const selectedStatus = this.selectedStatus()?.toLowerCase();
    return this.scheduledAppointments().filter((appointment) => {
      const matchesSearchTerm = searchTerm
        ? appointment.petName.toLowerCase().includes(searchTerm) ||
          appointment.petOwnerName.toLowerCase().includes(searchTerm) ||
          appointment.email.toLowerCase().includes(searchTerm) ||
          appointment.phoneNumber.toLowerCase().includes(searchTerm) ||
          appointment.dateOfAppoinment.toLowerCase().includes(searchTerm) ||
          appointment.petType.toLowerCase().includes(searchTerm)
        : true;

      const matchesStatus = selectedStatus
        ? appointment.status.toLowerCase() === selectedStatus
        : true;

      return matchesSearchTerm && matchesStatus;
    });
  });
   // Compute counts for each status
   notScheduledCount = computed(() =>
    this.scheduledAppointments().filter((a) => a.status.toLowerCase() === 'not scheduled').length
  );

  scheduledCount = computed(() =>
    this.scheduledAppointments().filter((a) => a.status.toLowerCase() === 'scheduled').length
  );

  missedCount = computed(() =>
    this.scheduledAppointments().filter((a) => a.status.toLowerCase() === 'missed scheduled').length
  );
  setStatus(status: string) {
    this.selectedStatus.set(status);
  }
  isFilterApplied() {
    return this.selectedStatus() !== '';
  }

  fetchScheduledAppointments() {
    this.loader = true;
    this.appointmentService.fetchScheduledAppointments().subscribe({
      next: (res: Appointment[]) => {
        this.loader = false;
        this.scheduledAppointments.set(res);
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        console.log('Error fetch the scheduled appointments', err);
      },
    });
  }

  navigateToCalendar() {
    this.router.navigateByUrl('/clinic/calendar');
  }
  clearFilter() {
    this.searchTerm.set(null);
  }
}
