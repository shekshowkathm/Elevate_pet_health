import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateClinicDetailsComponent } from './update-clinic-details.component';

describe('UpdateClinicDetailsComponent', () => {
  let component: UpdateClinicDetailsComponent;
  let fixture: ComponentFixture<UpdateClinicDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpdateClinicDetailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateClinicDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
