import { Component, Inject, inject, OnInit, PLATFORM_ID } from '@angular/core';
import { ClinicService } from '../../services/clinic.service';
import { ClinicDetailResponse } from '../../models/clinic-details-response';
import { HttpErrorResponse } from '@angular/common/http';
import {
  FormGroup,
  FormControl,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';
import { isPlatformBrowser, NgClass, NgIf } from '@angular/common';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { Router } from '@angular/router';
import { DynamicDialogRef, DialogService } from 'primeng/dynamicdialog';
import { ImageUploadComponent } from '../../../shared/component/image-upload/image-upload.component';
import { CustomDropdownComponent } from '../custom-dropdown/custom-dropdown.component';
import { US_STATES } from '../../../shared/constants/usa-states';
import { PhoneNumberDirective } from '../../../shared/directives/phone-number.directive';
import { NumberInputDirective } from '../../../shared/directives/number-input.directive';
import { ImageUploadService } from '../../../shared/service/image-upload.service';

@Component({
  selector: 'app-update-clinic-details',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    NgIf,
    ToastModule,
    ProgressSpinnerModule,
    CustomDropdownComponent,
    PhoneNumberDirective,
    NumberInputDirective,
    NgClass,
  ],
  templateUrl: './update-clinic-details.component.html',
  styleUrl: './update-clinic-details.component.scss',
  providers: [MessageService, DialogService],
})
export class UpdateClinicDetailsComponent implements OnInit {
  private clinicService = inject(ClinicService);
  private imageUploadService = inject(ImageUploadService);
  private router = inject(Router);
  currentClinic: ClinicDetailResponse | null = null;
  loader: boolean = false;
  states = US_STATES;
  currentClinicLogo: File | null = null;
  clinicForm = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    clinicName: new FormControl('', Validators.required),
    contactNumber: new FormControl('', [
      Validators.required,
      Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/),
    ]),
    address: new FormControl('', Validators.required),
    city: new FormControl('', Validators.required),
    state: new FormControl('', Validators.required),
    zipCode: new FormControl('', [
      Validators.required,
      Validators.pattern('^\\d{5}(-\\d{4})?$'),
    ]),
    clinicLogo: new FormControl(''),
    socialLinkOne: new FormControl(''),
    socialLinkTwo: new FormControl(''),
    socialLinkThree: new FormControl(''),
    socialLinkFour: new FormControl(''),
  });
  selectedImageUrl: string = '';
  ref: DynamicDialogRef | undefined;

  constructor(
    private messageService: MessageService,
    @Inject(PLATFORM_ID) private platformId: Object,
    public dialogService: DialogService,
  ) {}
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.getClinicDetails();
    }
  }

  getClinicDetails() {
    this.loader = true;
    this.clinicService.getCurrentClinicalDetails().subscribe({
      next: (res: any) => {
        this.currentClinic = res as ClinicDetailResponse;
        this.initializeForm();
        this.loader = false;
      },
      error: (err: HttpErrorResponse) => {
        console.log(err.error, err.message, err.status);
        this.loader = false;
      },
    });
  }

  initializeForm() {
    if (this.currentClinic) {
      const initialValues = {
        email: this.currentClinic.email || '',
        clinicName: this.currentClinic.clinicName || '',
        contactNumber: this.currentClinic.contactNumber || '',
        address: this.currentClinic.address || '',
        city: this.currentClinic.city || '',
        state: this.currentClinic.state || '',
        zipCode: this.currentClinic.zipCode || '',
        clinicLogo: this.currentClinic.clinicLogo || '',
        socialLinkOne: this.currentClinic.socialLinkOne || '',
        socialLinkTwo: this.currentClinic.socialLinkTwo || '',
        socialLinkThree: this.currentClinic.socialLinkThree || '',
        socialLinkFour: this.currentClinic.socialLinkFour || '',
      };
      this.clinicForm.patchValue(initialValues);
    }
  }

  async updateClinicDetails() {
    this.loader = true;
    let clinicLogoUrl = '';
    const clinicLogoFile = this.currentClinicLogo;
    if (clinicLogoFile) {
      try {
        clinicLogoUrl = await this.imageUploadService.uploadFile(
          clinicLogoFile,
          clinicLogoFile.name,
        );
      } catch (error) {
        console.log('Error uploading Clinic Logo', error);
        this.messageService.add({
          severity: 'error',
          summary: 'Error uploading logo',
          detail: 'Failed to update Clinic Logo',
        });
        this.loader = false;
        return;
      }
    } else {
      clinicLogoUrl = this.currentClinic?.clinicLogo || '';
    }
    const cliObj: ClinicDetailResponse = {
      clinicName: this.clinicForm.value.clinicName!,
      address: this.clinicForm.value.address!,
      zipCode: this.clinicForm.value.zipCode!,
      city: this.clinicForm.value.city!,
      state: this.clinicForm.value.state!,
      email: this.clinicForm.value.email!,
      id: this.currentClinic?.id,
      clinicOwnerId: this.currentClinic?.clinicOwnerId,
      clinicImage: this.selectedImageUrl
        ? this.selectedImageUrl
        : this.currentClinic?.clinicImage,
      contactNumber: this.clinicForm.value.contactNumber!,
      clinicLogo: clinicLogoUrl || '',
      socialLinkOne: this.clinicForm.value.socialLinkOne || '',
      socialLinkTwo: this.clinicForm.value.socialLinkTwo || '',
      socialLinkThree: this.clinicForm.value.socialLinkThree || '',
      socialLinkFour: this.clinicForm.value.socialLinkFour || '',
    };
    this.clinicService.UpdateCurrentClinicDetails(cliObj).subscribe({
      next: (res: string) => {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: res,
        });
        this.loader = false;
        setTimeout(() => {
          this.router.navigateByUrl('/clinic/clinic-detail');
        }, 1500);
      },
      error: (err: HttpErrorResponse) => {
        console.log(err);
        this.loader = false;
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to update clinic detail',
        });
      },
    });
  }

  uploadLogoAndSetUrl(tagetfile: any) {
    this.currentClinicLogo = tagetfile.files[0];
  }

  showImageFromUrl(url: string): string {
    return url.split('/media/')[1];
  }

  uploadOrSelectImage() {
    this.ref = this.dialogService.open(ImageUploadComponent, {
      header: 'Upload Image',
      width: '500px',
      modal: true,
      breakpoints: {
        '640px': '90vw',
      },
    });
    this.ref.onClose.subscribe((url: any) => {
      if (url) {
        this.selectedImageUrl = url;
      }
      console.log('url', url);
    });
  }
}
