import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicNotificationComponent } from './clinic-notification.component';

describe('ClinicNotificationComponent', () => {
  let component: ClinicNotificationComponent;
  let fixture: ComponentFixture<ClinicNotificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClinicNotificationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClinicNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
