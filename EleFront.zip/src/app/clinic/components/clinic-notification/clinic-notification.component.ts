import { isPlatformBrowser, NgFor } from '@angular/common';
import { Component, Inject, PLATFORM_ID, signal } from '@angular/core';
import { CardModule } from 'primeng/card';
import { ClinicService } from '../../services/clinic.service';
import { NotVerifiedPerOwner } from '../../models/pet-owner-response';
import { MessageService } from 'primeng/api';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ToastModule } from 'primeng/toast';
import { HttpErrorResponse } from '@angular/common/http';
import { StripeService } from '../../services/stripe.service';

@Component({
  selector: 'app-clinic-notification',
  standalone: true,
  imports: [CardModule, NgFor, ProgressSpinnerModule, ToastModule],
  templateUrl: './clinic-notification.component.html',
  styleUrl: './clinic-notification.component.scss',
  providers: [MessageService],
})
export class ClinicNotificationComponent {
  notVerifiedPerOwners = signal<NotVerifiedPerOwner[] | null>(null);
  loader: boolean = false;

  constructor(
    private ClinicService: ClinicService,private stripeService :StripeService,
    private messageService: MessageService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit() {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.notVerifiedPerOwners = this.ClinicService.notVerifiedPerOwnersSignal;
      if (
        !this.notVerifiedPerOwners() ||
        this.notVerifiedPerOwners()?.length === 0
      ) {
        this.fetchNotVerifiedPetOwners();
      }
    }
  }

  fetchNotVerifiedPetOwners() {
    console.log('mehod called for not verifed pet owners');
    this.ClinicService.notVerifiedPetOwner().subscribe({
      next: (response: NotVerifiedPerOwner[]) => {
        console.log('response is for not verified pet owners :', response);
        this.notVerifiedPerOwners.set(response);
      },
    });
  }

  updatePetOwnerStatus(id: number, petId: number) {
    this.loader = true;
    let data = { id:id ,stripeAccountId:localStorage.getItem('1')}
    this.stripeService.UpdateStripe(data).subscribe((doc:any)=>{
    this.ClinicService.verifiedPetOwner(data).subscribe({
      next: (response: string) => {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: response,
        });
        this.updatePetStatus(petId);
      },
      error: (err: HttpErrorResponse) => {
        console.log('Error in updatePetOwnerStatus', err);
        this.loader = false;
      },
    });
  })
  }

  updatePetStatus(petOwnerID: number) {
    this.ClinicService.updatePetStatus(petOwnerID).subscribe({
      next: (response: string) => {
        this.fetchNotVerifiedPetOwners();
        this.loader = false;
      },
      error: (err: HttpErrorResponse) => {
        this.fetchNotVerifiedPetOwners();
        this.loader = false;
      },
    });
  }
}
