import { ClinicAuthService } from './../../services/clinic-auth.service';
import { RouterOutlet } from '@angular/router';
import {
  Component,
  HostListener,
  Inject,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { LeftSidebarComponent } from '../left-sidebar/left-sidebar.component';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { TopNavComponent } from '../top-nav/top-nav.component';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [LeftSidebarComponent, RouterOutlet, TopNavComponent, ToastModule],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.scss',
  providers: [DialogService, MessageService],
})
export class LayoutComponent implements OnInit {
  isLeftSidebarCollapsed = signal<boolean>(false);
  screenWidth = signal<number>(0);
  ref: DynamicDialogRef | undefined;
  private clinicAuthService = inject(ClinicAuthService);
  isClinicSelected = this.clinicAuthService.getSelectedClinic();
  userRole: string = '';
  constructor(
    public dialogService: DialogService,
    public messageService: MessageService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    if (typeof window !== 'undefined') {
      this.screenWidth.set(window.innerWidth);
    }
  }
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.userRole = this.clinicAuthService.getRole();
    }
    this.isLeftSidebarCollapsed.set(this.screenWidth() < 768);
  }

  @HostListener('window:resize')
  onResize() {
    this.screenWidth.set(window.innerWidth);
    if (this.screenWidth() < 768) {
      this.isLeftSidebarCollapsed.set(true);
    }
  }

  changeIsLeftSidebarCollapsed(isLeftSidebarCollapsed: boolean): void {
    this.isLeftSidebarCollapsed.set(isLeftSidebarCollapsed);
  }
}
