import { Component, Inject, inject, PLATFORM_ID, signal } from '@angular/core';
import { ClinicService } from '../../services/clinic.service';
import { ClinicAuthService } from '../../services/clinic-auth.service';
import { Alerts } from '../../models/alerts';
import { CardModule } from 'primeng/card';
import {
  CommonModule,
  DatePipe,
  isPlatformBrowser,
  NgClass,
  NgFor,
  NgIf,
} from '@angular/common';
import { ButtonModule } from 'primeng/button';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { StripeService } from '../../services/stripe.service';
import { TrancationService } from '../../../pet-owner/service/trancation.service';
import { TransactionDetail } from '../../models/transaction-detail';
import { TableModule } from 'primeng/table';

interface Tabs {
  label: string;
  value: string;
}

@Component({
  selector: 'app-alerts',
  standalone: true,
  imports: [
    NgClass,
    DropdownModule,
    FormsModule,
    ProgressSpinnerModule,
    CommonModule,
    DatePipe,
    TableModule,
  ],
  templateUrl: './alerts.component.html',
  styleUrl: './alerts.component.scss',
})
export class AlertsComponent {
  private router = inject(Router);
  alertResponse = signal<Alerts[]>([]);
  transactionDetail: TransactionDetail[] = [];
  activeSection: string = 'plans';
  isApiLoaded: boolean = false;
  loader: boolean = false;
  public CardList: any[] = [];

  tabs: Tabs[] = [
    {
      label: 'Plans',
      value: 'plans',
    },
    {
      label: 'Payments',
      value: 'payments',
    },
    {
      label: 'Card',
      value: 'card',
    },
    {
      label: 'Today Appointments',
      value: 'TODAYS_APPOINTMENTS',
    },
    {
      label: 'Missed Appointments',
      value: 'MISSED_APPOINTMENTS',
    },
    {
      label: 'Expiring Plans',
      value: 'expiringPlans',
    },
  ];

  isLoading: boolean = false;
  constructor(
    private clinicService: ClinicService,
    private stripeService: StripeService,
    @Inject(PLATFORM_ID) private platformId: Object,
    private trancationService: TrancationService,
  ) {}

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.fetchPlansToConfirmAlerts();
    }
  }

  fetchPlansToConfirmAlerts() {
    this.isLoading = true;
    this.clinicService.fetchPlansToConfirmAlerts().subscribe({
      next: (response: Alerts[]) => {
        this.alertResponse.set(response);
        this.isLoading = false;
        this.isApiLoaded = true;
      },
      error: (error) => {
        this.isLoading = false;
        this.isApiLoaded = true;
        console.error('Error retrieving object:', error);
      },
    });
  }

  fetchAppointmentAlerts() {
    this.isLoading = true;
    this.clinicService.fetchAppointmentAlerts().subscribe({
      next: (response: Alerts[]) => {
        this.alertResponse.set(
          response.filter((a) => a.status === this.activeSection),
        );
        this.isLoading = false;
        this.isApiLoaded = true;
      },
      error: (error) => {
        this.isLoading = false;
        this.isApiLoaded = true;
        console.error('Error retrieving object:', error);
      },
    });
  }

  fetchExpiringPlansAlerts() {
    this.isLoading = true;
    this.clinicService.fetchExpiringPlansAlerts().subscribe({
      next: (response: Alerts[]) => {
        this.alertResponse.set(response);
        this.isLoading = false;
        this.isApiLoaded = true;
      },
      error: (error) => {
        this.isLoading = false;
        this.isApiLoaded = true;
        console.error('Error retrieving object:', error);
      },
    });
  }

  selectTab(tab: string): void {
    this.activeSection = tab;
    this.apiCallBasedOnTab();
  }

  apiCallBasedOnTab() {
    this.isApiLoaded = false;
    switch (this.activeSection) {
      case 'plans':
        this.fetchPlansToConfirmAlerts();
        break;
      case 'TODAYS_APPOINTMENTS':
      case 'MISSED_APPOINTMENTS':
        this.fetchAppointmentAlerts();
        break;
      case 'expiringPlans':
        this.fetchExpiringPlansAlerts();
        break;
      case 'payments':
        this.fetchpaymentDetails();
        break;
      case 'card':
        this.expiredCardDetails();
        break;
      default:
        this.isApiLoaded = true;
        this.alertResponse.set([]);
        break;
    }
  }

  navidateToPages(alert: Alerts) {
    switch (this.activeSection) {
      case 'plans':
        this.viewPetOwner(alert.petId, alert.petOwnerId);
        break;
      case 'TODAYS_APPOINTMENTS':
      case 'MISSED_APPOINTMENTS':
        this.navigateToSheduledAppointments();
        break;
      case 'expiringPlans':
        this.viewPetOwner(alert.petId, alert.petOwnerId);
        break;
      case 'payments':
      case 'card':
      default:
        break;
    }
  }
  expiredCardDetails() {
    const stripeAccountId = localStorage.getItem('1') || '';
    if (!stripeAccountId) {
      console.warn('Stripe account ID is not available in localStorage.');
      return;
    }

    this.loader = true;
    this.stripeService.getExpiryDetailsByClinic(stripeAccountId).subscribe({
      next: (doc: any) => {
        console.log(doc,"dhdghds")
        if(doc) {
          this.CardList = doc.expiringCards
        }
        this.isApiLoaded = true;
        this.loader = false;
      },
      error: (error) => {
        console.error('Error fetching card details:', error);
        this.CardList = [];
        this.isApiLoaded = true;
        this.loader = false;
      },
    });
  }

  viewPetOwner(petid: number, petOwnerId: number) {
    this.router.navigate(['/clinic/pet-owner', petOwnerId, 'pet', petid]);
  }

  navigateToSheduledAppointments() {
    this.router.navigate(['/clinic/scheduled-appointments']);
  }
  trackByIndex(index: number, item: any): number {
    return index;
  }
  fetchpaymentDetails() {
    const stripeAccountId = localStorage.getItem('1') || '';
    if (!stripeAccountId) {
      console.warn('Stripe account ID is not available in localStorage.');
    }
    let data = { stripeAccountId: stripeAccountId, paymentStatus: 'open' };
    this.loader = true;
    this.trancationService.getByAccountId(data).subscribe((doc: any) => {
      const dataArray = JSON.parse(doc);
      this.transactionDetail = dataArray;
      this.isApiLoaded = true;
      this.loader = false;
    });
  }
}
