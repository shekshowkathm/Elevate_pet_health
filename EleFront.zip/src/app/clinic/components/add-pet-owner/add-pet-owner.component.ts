import { NgIf } from '@angular/common';
import { Component, inject } from '@angular/core';
import {
  ReactiveFormsModule,
  FormGroup,
  FormControl,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ToastModule } from 'primeng/toast';
import { ClinicService } from '../../services/clinic.service';
import { HttpErrorResponse, HttpStatusCode } from '@angular/common/http';
import { AddPetOwnerByClinic } from '../../models/add-pet-owner-by-clinic';
import { PhoneNumberDirective } from '../../../shared/directives/phone-number.directive';
import { TIME_ZONES } from '../../../shared/constants/timeZone';
import { CustomDropdownComponent } from '../custom-dropdown/custom-dropdown.component';
import { ClinicAuthService } from '../../services/clinic-auth.service';
import { Roles } from '../../../shared/enum/roles';

@Component({
  selector: 'app-add-pet-owner',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    NgIf,
    ProgressSpinnerModule,
    ToastModule,
    PhoneNumberDirective,
    CustomDropdownComponent,
  ],
  templateUrl: './add-pet-owner.component.html',
  styleUrl: './add-pet-owner.component.scss',
  providers: [MessageService],
})
export class AddPetOwnerComponent {
  private router = inject(Router);
  loader: boolean = false;
  private clinicService = inject(ClinicService);
  private clinicAuthService = inject(ClinicAuthService);
  addNewPetOwnerForm = new FormGroup({
    firstName: new FormControl('', [Validators.required]),
    lastName: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    role: new FormControl('PET_OWNER'),
    contact: new FormControl('', [
      Validators.required,
      Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/),
    ]),
    petName: new FormControl('', [Validators.required]),
    timezone: new FormControl('', [Validators.required]),
  });
  timeZones: { label: string; value: string }[] = TIME_ZONES.map((t) => ({
    label: `${t.fullName} (${t.abbreviation})`,
    value: t.abbreviation,
  }));
  constructor(private messageService: MessageService) {}

  submitNewPetOwner() {
    this.loader = true;
    this.clinicService
      .addPetOwnerByClinic(this.addNewPetOwnerForm.value as AddPetOwnerByClinic)
      .subscribe({
        next: (val: any) => {
          this.loader = false;
          this.addNewPetOwnerForm.reset();
          this.messageService.add({
            severity: 'success',
            summary: 'Pet Owner Added',
            detail: 'Pet Owner Added sucessfully',
          });
          if (this.clinicAuthService.getRole() !== Roles.CLINIC_ASSOCIATE) {
            this.clinicService.callNotVerifiedOwnersMethod();
          }
          setTimeout(() => {
            this.router.navigateByUrl('/clinic/pet-owners');
          }, 1000);
        },
        error: (err: HttpErrorResponse) => {
          console.log('Error Adding new pet owner by clinic', err);
          this.loader = false;
          if (err.status === HttpStatusCode.Conflict) {
            this.messageService.add({
              severity: 'error',
              summary: 'Email Already Exists',
              detail: 'Please use different Email address',
            });
            return;
          }
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Cannot add Pet Owner',
          });
        },
      });
  }
}
