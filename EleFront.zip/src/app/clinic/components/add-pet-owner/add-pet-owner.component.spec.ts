import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPetOwnerComponent } from './add-pet-owner.component';

describe('AddPetOwnerComponent', () => {
  let component: AddPetOwnerComponent;
  let fixture: ComponentFixture<AddPetOwnerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddPetOwnerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddPetOwnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
