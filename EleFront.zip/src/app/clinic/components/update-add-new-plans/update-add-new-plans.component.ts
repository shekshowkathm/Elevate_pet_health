import { ClinicAuthService } from './../../services/clinic-auth.service';
import { Component, computed, inject, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { WellnessService } from '../../services/wellness.service';
import { TableModule } from 'primeng/table';
import { CurrencyPipe, NgClass } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  ClinicWellnessPlan,
  ClinicWellnessPlanWithPromotions,
  PromotionWithAvailabityStatus,
} from '../../models/wellness-plan-response';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { combineLatest } from 'rxjs';
import { SingleDigitDirective } from '../../../shared/directives/single-digit.directive';
import { SendToPetOwnerWithPromotions } from '../../models/send-to-pet-owner';
import { HttpErrorResponse } from '@angular/common/http';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { PromotionEligibilityPipe } from '../../../shared/pipes/promotion-eligibility.pipe';
@Component({
  selector: 'app-update-add-new-plans',
  standalone: true,
  imports: [
    TableModule,
    FormsModule,
    ToastModule,
    CurrencyPipe,
    NgClass,
    SingleDigitDirective,
    ProgressSpinnerModule,
    PromotionEligibilityPipe,
  ],
  templateUrl: './update-add-new-plans.component.html',
  styleUrl: './update-add-new-plans.component.scss',
  providers: [MessageService, CurrencyPipe],
})
export class UpdateAddNewPlansComponent {
  private clinicAuthService = inject(ClinicAuthService);
  private router = inject(Router);
  private currencyPipe = inject(CurrencyPipe);
  /** General Fields */
  isApiLoaded: boolean = false;
  loader: boolean = true;
  clinicId: number = this.clinicAuthService.getSelectedClinic()() || 0;
  petId: number = 0;
  action: string = '';
  wellnessPlanName: string = '';
  petSize: string = '';
  selectedPlans = signal<ClinicWellnessPlan[]>([]);
  wellnessPlans: ClinicWellnessPlan[] = []; // will recive data from server for both Adding New Plans and Updating Existing Plans.
  promotions = signal<PromotionWithAvailabityStatus[]>([]);
  /** Fields for Updating Existing Plans */
  managePetWellnessPlanId: number = 0;
  startDate: string = '';
  endDate: string = '';
  monthlyAmount: string = '';
  totalAmount: string = '';

  constructor(
    private route: ActivatedRoute,
    private wellnessService: WellnessService,
    private messageService: MessageService,
  ) {}

  ngOnInit() {
    combineLatest([this.route.params, this.route.queryParams]).subscribe(
      ([params, queryParams]) => {
        this.action = queryParams['action'];
        this.petSize = queryParams['size'];
        this.petId = params['petId'];
        this.wellnessPlanName = params['wellnessPlanName'];
        if (this.action === 'add') {
          this.getPlansForAdd();
        } else if (this.action === 'update') {
          this.managePetWellnessPlanId = +params['managePetWellnessPlanId'];
          this.getPlansToUpdate();
        } else {
          console.log('Unknown action', this.action);
        }
      },
    );
  }

  getPlansToUpdate() {
    this.loader = true;
    this.wellnessService
      .fetchUpdatePlans(
        this.clinicId,
        this.wellnessPlanName,
        this.managePetWellnessPlanId,
      )
      .subscribe({
        next: (res: any) => {
          const data = res as {
            endDate: string;
            startDate: string;
            plans: ClinicWellnessPlan[];
            totalAmount: string;
            monthlyAmount: string;
          };
          this.wellnessPlans = data.plans.sort((a, b) =>
            b.planStatus === a.planStatus
              ? 0
              : b.planStatus === 'ACTIVE'
                ? 1
                : -1,
          );
          this.loader = false;
          this.isApiLoaded = true;
          this.startDate = data.startDate;
          this.endDate = data.endDate;
          this.totalAmount = data.totalAmount;
          this.monthlyAmount = data.monthlyAmount;
        },
        error: (error) => {
          console.error('Error fetching update plans:', error);
          this.loader = false;
          this.isApiLoaded = true;
        },
      });
  }

  getPlansForAdd() {
    if (this.petSize) {
      this.loader = true;
      this.wellnessService
        .fetchAddPlans(
          this.clinicId,
          this.wellnessPlanName,
          this.petSize,
          this.petId,
        )
        .subscribe({
          next: (response: ClinicWellnessPlanWithPromotions) => {
            this.wellnessPlans = response.wellnessPlans.map(
              (plan: ClinicWellnessPlan) => ({
                ...plan,
                serviceFrequency: 1,
              }),
            );
                        this.promotions.set(response.promotions.filter((p) => p.status));
            this.loader = false;
            this.isApiLoaded = true;
          },
          error: (err: HttpErrorResponse) => {
            this.isApiLoaded = true;
            this.loader = false;
            console.log('Error fetch plans for add new plans', err);
          },
        });
    }
  }

  parsePrice(price: string | undefined): number {
    return price ? parseFloat(price.replace('$', '').trim()) || 0 : 0;
  }
  getPriceByPetSize(
    plan: ClinicWellnessPlan,
    index: number,
  ): {
    price: number;
    discountPrice: number;
  } {
    const sizePriceMap: Record<
      string,
      { price: string | undefined; discountPrice: string | undefined }
    > = {
      Small: {
        price: plan.clinicDropDowns[index].wellnessUpdate.updatedPriceForSmall,
        discountPrice:
          this.action === 'update'
            ? plan.clinicDropDowns[index].wellnessUpdate.discountPriceForSmall
            : plan.clinicDropDowns[0].wellnessUpdate.price,
      },
      Medium: {
        price: plan.clinicDropDowns[index].wellnessUpdate.updatedPriceForMedium,
        discountPrice:
          this.action === 'update'
            ? plan.clinicDropDowns[index].wellnessUpdate.discountPriceForMedium
            : plan.clinicDropDowns[0].wellnessUpdate.price,
      },
      Large: {
        price: plan.clinicDropDowns[index].wellnessUpdate.updatedPriceForLarge,
        discountPrice:
          this.action === 'update'
            ? plan.clinicDropDowns[index].wellnessUpdate.discountPriceForLarge
            : plan.clinicDropDowns[0].wellnessUpdate.price,
      },
      'X-Large': {
        price: plan.clinicDropDowns[index].wellnessUpdate.updatedPriceForXLarge,
        discountPrice:
          this.action === 'update'
            ? plan.clinicDropDowns[index].wellnessUpdate.discountPriceForXLarge
            : plan.clinicDropDowns[0].wellnessUpdate.price,
      },
    };

    const prices = sizePriceMap[this.petSize] || {
      price: undefined,
      discountPrice: undefined,
    };
    return {
      price: this.parsePrice(prices.price),
      discountPrice: this.parsePrice(prices.discountPrice),
    };
  }

  onCheckboxChange(plan: ClinicWellnessPlan) {
    this.selectedPlans.update((currentPlans) => {
      const planExists = currentPlans.some(
        (p) =>
          p.clinicWellnessPlanId === plan.clinicWellnessPlanId &&
          p.clinicDropDowns[0].wellnessUpdate.wellnessUpdateId ===
            plan.clinicDropDowns[0].wellnessUpdate.wellnessUpdateId,
      );

      if (planExists) {
        return currentPlans.filter(
          (p) =>
            !(
              p.clinicWellnessPlanId === plan.clinicWellnessPlanId &&
              p.clinicDropDowns[0].wellnessUpdate.wellnessUpdateId ===
                plan.clinicDropDowns[0].wellnessUpdate.wellnessUpdateId
            ),
        );
      } else {
        return [...currentPlans, plan];
      }
    });
  }

  checkChangeOnSelectedWellnessPlan(
    wellnessPlan: ClinicWellnessPlan,
    newServiceCount: number,
  ): void {
    this.selectedPlans.update((plans) => {
      return plans.map((plan) =>
        plan.clinicWellnessPlanId === wellnessPlan.clinicWellnessPlanId &&
        plan.clinicDropDowns[0].wellnessUpdate.wellnessUpdateId ===
          wellnessPlan.clinicDropDowns[0].wellnessUpdate.wellnessUpdateId
          ? { ...plan, serviceFrequency: newServiceCount }
          : plan,
      );
    });
  }

  sendConfirmationForAddandUpdateWellnesPlans() {
    this.loader = true;
    let plans: SendToPetOwnerWithPromotions = {
      choosePlans: [],
      promotionDiscounts: [],
    };
    if (this.action === 'add') {
      plans.choosePlans = this.selectedPlans().map((plan) => ({
        petId: this.petId,
        clinicWellnessPlan: plan.clinicWellnessPlanId!,
        clinicWellnessUpdate:
          plan.clinicDropDowns[0].wellnessUpdate.wellnessUpdateId,
        sentBy: this.clinicAuthService.getUserId()!,
        serviceFrequency: plan.serviceFrequency,
      }));
    } else if (this.action === 'update') {
      plans.choosePlans = this.selectedPlans().map((plan) => ({
        petId: this.petId,
        clinicWellnessPlan: plan.clinicWellnessPlanId!,
        clinicWellnessUpdate:
          plan.clinicDropDowns[0].wellnessUpdate.wellnessUpdateId,
        sentBy: this.clinicAuthService.getUserId()!,
        serviceFrequency: plan.serviceFrequency,
        managePetWellnessPlanId: this.managePetWellnessPlanId,
      }));
    }
    plans.promotionDiscounts = this.promotions().map((p) => {
      return { id: p.id };
    });
    console.log(`paylod in ${this.action} plans`, plans);
    this.wellnessService
      .sendWellnessPlansToPetOwnerWithAction(plans, this.action)
      .subscribe({
        next: (res: any) => {
          console.log('response', res);
          this.loader = false;
          if (this.action === 'add') {
            this.messageService.add({
              severity: 'success',
              summary: 'Plan send',
              detail: 'Wellness plan send sucessfully',
            });
          } else if (this.action === 'update') {
            this.messageService.add({
              severity: 'success',
              summary: 'Plan update',
              detail: 'Wellness plan send sucessfully',
            });
          }
          setTimeout(() => {
            this.router.navigateByUrl('/clinic/pet-owners');
          }, 2000);
        },
        error: (err: HttpErrorResponse) => {
          this.loader = false;
          console.log('Error sending plans to petowner', err);
          this.messageService.add({
            severity: 'error',
            summary: 'Failed',
            detail: 'Failed to send Wellness plan',
          });
        },
      });
  }

  computedSelectedWellnessPlanSignal =
    computed(() => {
      const total = this.selectedPlans().reduce(
        (acc, plan) => {
          const serviceCount = plan.serviceFrequency ?? 1;
          const priceCalculations = {
            QTY: () => ({
              price: this.parsePrice(
                plan.clinicDropDowns[0].wellnessUpdate.updatedPriceForQuantity,
              ),
              discountPrice: this.parsePrice(
                this.action === 'update'
                  ? plan.clinicDropDowns[0].wellnessUpdate
                      .discountPriceForQuantity
                  : plan.clinicDropDowns[0].wellnessUpdate.price,
              ),
            }),
            WGT: () => this.getPriceByPetSize(plan, 0),
          };

          const priceBased = plan.clinicDropDowns[0].wellnessUpdate
            .priceBased as keyof typeof priceCalculations;
          const { price, discountPrice } = priceCalculations[priceBased]() || {
            price: 0,
            discountPrice: 0,
          };

          if (price) acc.totalPriceSum += price * serviceCount;
          if (discountPrice)
            acc.totalDiscountedPriceSum += discountPrice * serviceCount;

          return acc;
        },
        { totalPriceSum: 0, totalDiscountedPriceSum: 0 },
      );

      let promotionCount = 0;
      let firstMonthPrice = 0;
      let remainingMonthPrice = 0;
      let totalPriceWithInstallments = 0;
      if (this.action === 'add') {
        const promotions = this.promotions();
        if (promotions && promotions !== null) {
          promotionCount = promotions.length;
        }
        if (promotionCount > 0) {
          firstMonthPrice = total.totalDiscountedPriceSum / 12 + 7;
        } else {
          firstMonthPrice = total.totalDiscountedPriceSum / 12 + 49 + 7;
        }
        remainingMonthPrice = total.totalDiscountedPriceSum / 12 + 7;
        totalPriceWithInstallments = firstMonthPrice + remainingMonthPrice * 11;
      } else if (this.action === 'update') {
        const { remainingMonths } = this.calculateMonths(
          this.startDate,
          this.endDate,
        );
        remainingMonthPrice =
          Number(this.monthlyAmount) +
          total.totalDiscountedPriceSum / remainingMonths +
          7;
        totalPriceWithInstallments =
          total.totalDiscountedPriceSum + Number(this.totalAmount);
      }

      return {
        totalPrice: this.currencyPipe.transform(total.totalPriceSum),
        totalDiscountedPrice: this.currencyPipe.transform(
          total.totalDiscountedPriceSum,
        ),
        firstMonthPrice: this.currencyPipe.transform(this.monthlyAmount),
        remainingMonthPrice: this.currencyPipe.transform(remainingMonthPrice),
        totalPriceWithInstallments: this.currencyPipe.transform(
          totalPriceWithInstallments,
        ),
      };
    });

  getPromotionsCount(): number {
    return this.promotions().length;
  }

  private calculateMonths(
    startDateStr: string,
    endDateStr: string,
  ): { monthsPassed: number; remainingMonths: number } {
    const startDate = new Date(startDateStr);
    const endDate = new Date(endDateStr);
    const currentDate = new Date();

    const totalMonths = 12;
    // const totalMonths = (endDate.getFullYear() - startDate.getFullYear()) * 12 + (endDate.getMonth() - startDate.getMonth());
    const monthsPassed =
      (currentDate.getFullYear() - startDate.getFullYear()) * 12 +
      (currentDate.getMonth() - startDate.getMonth());
    const adjustedMonthsPassed = Math.max(
      0,
      Math.min(monthsPassed, totalMonths),
    );
    const remainingMonths = totalMonths - adjustedMonthsPassed;

    return {
      monthsPassed: adjustedMonthsPassed,
      remainingMonths: remainingMonths,
    };
  }
}
