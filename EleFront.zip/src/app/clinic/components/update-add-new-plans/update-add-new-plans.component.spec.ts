import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateAddNewPlansComponent } from './update-add-new-plans.component';

describe('UpdateAddNewPlansComponent', () => {
  let component: UpdateAddNewPlansComponent;
  let fixture: ComponentFixture<UpdateAddNewPlansComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpdateAddNewPlansComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateAddNewPlansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
