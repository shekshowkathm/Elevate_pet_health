import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WellnessplanViewComponent } from './wellnessplan-view.component';

describe('WellnessplanViewComponent', () => {
  let component: WellnessplanViewComponent;
  let fixture: ComponentFixture<WellnessplanViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WellnessplanViewComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WellnessplanViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
