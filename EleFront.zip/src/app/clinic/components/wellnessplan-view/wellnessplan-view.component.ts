import { CurrencyPipe, isPlatformBrowser, NgClass } from '@angular/common';
import { Component, Inject, PLATFORM_ID } from '@angular/core';
import {
  ClinicDropDown,
  ClinicWellnessPlan,
} from '../../models/wellness-plan-response';

@Component({
  selector: 'app-wellnessplan-view',
  standalone: true,
  imports: [NgClass, CurrencyPipe],
  templateUrl: './wellnessplan-view.component.html',
  styleUrl: './wellnessplan-view.component.scss',
})
export class WellnessplanViewComponent {
  wellnessPlan: ClinicWellnessPlan | null = null;
  selectedDropdown: ClinicDropDown | null = null;

  weightFieldAndText: { text: string; field: string }[] = [
    {
      text: 'Updated Small:',
      field: 'selectedDropdown.wellnessUpdate.updatedPriceForSmall',
    },
    {
      text: 'Updated Medium:',
      field: 'selectedDropdown.wellnessUpdate.updatedPriceForMedium',
    },
    {
      text: 'Updated Large:',
      field: 'selectedDropdown.wellnessUpdate.updatedPriceForLarge',
    },
    {
      text: 'Updated XLarge:',
      field: 'selectedDropdown.wellnessUpdate.updatedPriceForXLarge',
    },
    {
      text: 'Discounted Price for small:',
      field: 'selectedDropdown.wellnessUpdate.discountPriceForSmall',
    },
    {
      text: 'Discount Price For Medium:',
      field: 'selectedDropdown.wellnessUpdate.discountPriceForMedium',
    },
    {
      text: 'Discount Price For Large:',
      field: 'selectedDropdown.wellnessUpdate.discountPriceForLarge',
    },
    {
      text: 'Discount Price For XLarge:',
      field: 'selectedDropdown.wellnessUpdate.discountPriceForXLarge',
    },
  ];

  constructor(@Inject(PLATFORM_ID) private platformId: object) {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      const storedData = sessionStorage.getItem('WI');
      if (storedData) {
        const { wellnessPlan, index } = JSON.parse(storedData);
        this.wellnessPlan = wellnessPlan as ClinicWellnessPlan;
        this.selectedDropdown =
          this.wellnessPlan?.clinicDropDowns[index] || null;
      }
    }
  }

  selectDropdown(index: number) {
    if (this.wellnessPlan) {
      this.selectedDropdown = this.wellnessPlan.clinicDropDowns[index] || null;
    }
  }
}
