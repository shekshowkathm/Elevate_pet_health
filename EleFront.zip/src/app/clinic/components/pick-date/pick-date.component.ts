import { Component, input, output } from '@angular/core';
import { CalendarModule } from 'primeng/calendar';
import { PetWellnessPlan } from '../../models/pet';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-pick-date',
  standalone: true,
  imports: [CalendarModule, FormsModule, DatePipe],
  templateUrl: './pick-date.component.html',
  styleUrl: './pick-date.component.scss',
})
export class PickDateComponent {
  selectedWellnessPaln = input.required<PetWellnessPlan>();
  updateDate = output<string>();

  calendarVisible = false;
  selectedDate: string = '';

  minDate = new Date().toISOString().split('T')[0];

  openCalender() {
    this.calendarVisible = true;
    if (
      this.selectedWellnessPaln() &&
      this.selectedWellnessPaln().scheduledDateAndTime
    ) {
      this.selectedDate =
        this.selectedWellnessPaln().scheduledDateAndTime || '';
    }
  }

  resetOrClear(): void {
    this.selectedDate = '';
    this.calendarVisible = false;
  }
  updateScheduledAppointment() {
    this.updateDate.emit(this.selectedDate);
    this.calendarVisible = false;
  }
}
