import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BreedWithAgeComponent } from './breed-with-age.component';

describe('BreedWithAgeComponent', () => {
  let component: BreedWithAgeComponent;
  let fixture: ComponentFixture<BreedWithAgeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BreedWithAgeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BreedWithAgeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
