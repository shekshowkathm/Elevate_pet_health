import {
  Component,
  Inject,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { TableModule } from 'primeng/table';
import { PetWithAgeResponse } from '../../models/pet-with-age-response';
import { WellnessService } from '../../services/wellness.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { isPlatformBrowser } from '@angular/common';
import { SharedService } from '../../../shared/service/shared.service';

@Component({
  selector: 'app-breed-with-age',
  standalone: true,
  imports: [TableModule, ProgressSpinnerModule],
  templateUrl: './breed-with-age.component.html',
  styleUrl: './breed-with-age.component.scss',
})
export class BreedWithAgeComponent implements OnInit {
  private wellnessService = inject(WellnessService);
  private sharedService = inject(SharedService);
  petWithAge = signal<PetWithAgeResponse[]>([]);
  loader: boolean = false;

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.fetchPetwithBreed();
    }
  }

  fetchPetwithBreed() {
    this.loader = true;
    this.wellnessService.fetchPetwithBreed().subscribe({
      next: (res: any) => {
        this.petWithAge.set(res as PetWithAgeResponse[]);
        this.loader = false;
      },
      error: (err: HttpErrorResponse) => {
        console.error('Error fetching pet with age', err);
        this.loader = false;
      },
    });
  }

  exportAsExcel() {
    const printableBreedWithAge: PrintableBreedWithAge[] =
      this.petWithAge().map((p) => ({
        'Pet Type': p.petType,
        'Dog Breed': p.breed,
        'Breed Type': p.breedType,
        'Age for Puppy': p.ageForPuppy,
        'Age for Kitten': p.ageForKitten,
        'Age for Adult': p.ageForAdult,
        'Age for Senior': p.ageForSenior,
      }));
    this.sharedService.exportAsExcelFile(
      printableBreedWithAge,
      'breed-with-age'
    );
  }
}
interface PrintableBreedWithAge {
  'Pet Type': string;
  'Dog Breed': string;
  'Breed Type': string;
  'Age for Puppy': string;
  'Age for Kitten': string;
  'Age for Adult': string;
  'Age for Senior': string;
}
