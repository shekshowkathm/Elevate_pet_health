import { DatePipe, NgClass } from '@angular/common';
import { Component, inject, OnInit, signal } from '@angular/core';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TableModule } from 'primeng/table';
import { FileSizePipe } from '../../../shared/pipes/file-size.pipe';
import { DocumentResponse } from '../../models/document-response';
import {
  DynamicDialogRef,
  DynamicDialogConfig,
  DialogService,
} from 'primeng/dynamicdialog';
import { FilesUploadComponent } from '../../../shared/component/files-upload/files-upload.component';
import { UploadedFileDetail } from '../../../shared/model/upload-file-detail';
import { ClinicAuthService } from '../../services/clinic-auth.service';
import { HttpErrorResponse } from '@angular/common/http';
import { from, concatMap, finalize } from 'rxjs';
import { DocumentService } from '../../services/document.service';

@Component({
  selector: 'app-document-view',
  standalone: true,
  imports: [
    TableModule,
    ProgressSpinnerModule,
    DatePipe,
    FileSizePipe,
    NgClass,
  ],
  templateUrl: './document-view.component.html',
  styleUrl: './document-view.component.scss',
  providers: [DialogService],
})
export class DocumentViewComponent implements OnInit {
  private clinicAuthService = inject(ClinicAuthService);
  private documentService = inject(DocumentService);
  documents = signal<DocumentResponse[]>([]);
  ApiLoaded: boolean = false;
  loader: boolean = false;
  petOwnerLoader: boolean = false;
  petOwnerDocuments = signal<DocumentResponse[]>([]);
  petOwnerApiLoaded: boolean = false;
  type: string = '';
  petOwnerId = 0;
  petId = 0;

  constructor(
    public ref: DynamicDialogRef,
    public config: DynamicDialogConfig,
    public dialogService: DialogService,
  ) {}

  viewDocument(doc: DocumentResponse) {
    window.open(doc.documentUrl, '_blank');
  }

  ngOnInit(): void {
    console.log(this.config.data);
    this.type = this.config.data.view;
    this.petOwnerId = this.config.data.petOwnerId;
    this.petId = this.config.data.petId;

    if (this.type === 'ALL') {
      this.fetchDocumentUploadedByClinicToAllPetOwners();
    } else if (this.type === 'INDIVIDUAL') {
      this.fetchDocumentsUploadedByClinicToIndividualPetOwners();
      this.fetchDocumentsUploadedByIndividualPetOwnerToClinic();
    }
  }

  fetchDocumentUploadedByClinicToAllPetOwners() {
    this.loader = true;
    this.documentService
      .fetchDocumentUploadedByClinicToAllPetOwners()
      .subscribe({
        next: (val: DocumentResponse[]) => {
          this.loader = false;
          this.ApiLoaded = true;
          this.documents.set(val);
        },
        error: (err: HttpErrorResponse) => {
          this.loader = false;
          this.ApiLoaded = true;
          console.log(
            'Error fetch data for fetchDocumentUploadedByClinicToAllPetOwners',
            err,
          );
        },
      });
  }

  fetchDocumentsUploadedByClinicToIndividualPetOwners() {
    this.loader = true;
    this.documentService
      .fetchDocumentsUploadedByClinicToIndividualPetOwners(this.petId)
      .subscribe({
        next: (val: DocumentResponse[]) => {
          this.loader = false;
          this.ApiLoaded = true;
          this.documents.set(val);
        },
        error: (err: HttpErrorResponse) => {
          this.loader = false;
          this.ApiLoaded = true;
          console.log(
            'Error fetch data for fetchDocumentsUploadedByClinicToIndividualPetOwners',
            err,
          );
        },
      });
  }

  fetchDocumentsUploadedByIndividualPetOwnerToClinic() {
    this.petOwnerLoader = true;
    this.documentService
      .fetchDocumentsUploadedByIndividualPetOwnerToClinic(this.petOwnerId)
      .subscribe({
        next: (val: DocumentResponse[]) => {
          this.petOwnerLoader = false;
          this.petOwnerApiLoaded = true;
          this.petOwnerDocuments.set(val);
        },
        error: (err: HttpErrorResponse) => {
          this.petOwnerLoader = false;
          this.petOwnerApiLoaded = true;
          console.log('Error fetch data for fetchDocumentForAllUsers', err);
        },
      });
  }

  uploadDocuments(): void {
    this.openUploadDialog().onClose.subscribe(
      (files: UploadedFileDetail[] | undefined | null) => {
        if (files && files.length > 0) {
          this.loader = true;
          const documents = this.mapFilesToDocuments(files);
          this.uploadDocumentsToServer(documents);
        }
      },
    );
  }

  private openUploadDialog(): DynamicDialogRef {
    return this.dialogService.open(FilesUploadComponent, {
      header: 'Upload Files',
      width: '50vw',
      closable: false,
      contentStyle: { overflow: 'auto' },
      breakpoints: {
        '960px': '75vw',
        '640px': '90vw',
      },
    });
  }

  private mapFilesToDocuments(files: UploadedFileDetail[]): DocumentResponse[] {
    const role = this.clinicAuthService.getRole();
    const userId = this.clinicAuthService.getUserId()!;
    const clinicId = this.clinicAuthService.getSelectedClinic()()!;
    return files.map((file) => ({
      documentUrl: file.url,
      uploadedByRole: role,
      uploadedById: userId,
      targetType: this.type === 'ALL' ? 'AllPetOwners' : 'PetOwner',
      targetId: this.type === 'ALL' ? null : this.petId,
      clinicId: clinicId,
      uploadDate: file.uploadDate,
      description: file.name,
      fileSize: file.size.toString(),
    }));
  }

  private uploadDocumentsToServer(documents: DocumentResponse[]): void {
    from(documents)
      .pipe(
        concatMap((doc) =>
          this.documentService.uploadDocumentByClinicToSuperAdmin(doc),
        ),
        finalize(() => {
          this.loader = false;
        }),
      )
      .subscribe({
        next: (doc: any) => {
          this.documents.update((currentDocs) => [...currentDocs, doc]);
        },
        error: (err: HttpErrorResponse) => {
          console.error('Error uploading document:', err);
        },
      });
  }
}
