import {
  Component,
  computed,
  Inject,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { WellnessService } from '../../services/wellness.service';
import { ChoosenPlans } from '../../models/choosen-plans';
import { ActivatedRoute, Router } from '@angular/router';
import { TableModule } from 'primeng/table';
import { InputSwitchModule } from 'primeng/inputswitch';
import {
  NgFor,
  NgClass,
  isPlatformBrowser,
  CurrencyPipe,
} from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PaginatorModule } from 'primeng/paginator';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { TooltipModule } from 'primeng/tooltip';
import { combineLatest } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { PromotionEligibilityPipe } from '../../../shared/pipes/promotion-eligibility.pipe';

@Component({
  selector: 'app-choosen-plans',
  standalone: true,
  imports: [
    NgFor,
    TableModule,
    InputSwitchModule,
    FormsModule,
    NgClass,
    PaginatorModule,
    ToastModule,
    TooltipModule,
    CurrencyPipe,
    PromotionEligibilityPipe,
  ],
  templateUrl: './choosen-plans.component.html',
  styleUrl: './choosen-plans.component.scss',
  providers: [MessageService, CurrencyPipe],
})
export class ChoosenPlansComponent {
  choosenPlans = signal<ChoosenPlans[]>([]);
  petId!: number;
  selectedPlans = signal<ChoosenPlans[]>([]);
  promotions = signal<string[]>([]);
  startDate = signal<string>('');
  minDate = new Date().toISOString().split('T')[0];
  endDate = computed(() => {
    if (this.startDate()) {
      const start = new Date(this.startDate());
      start.setFullYear(start.getFullYear() + 1);
      return start.toISOString().split('T')[0];
    }
    return '';
  });
  action: string = '';
  managePetWellnessPlanId: number = 0;
  loader: boolean = false;
  constructor(
    private wellnessPlanService: WellnessService,
    private route: ActivatedRoute,
    private messageService: MessageService,
    @Inject(PLATFORM_ID) private platformId: Object,
    private router: Router,
    private currencyPipe: CurrencyPipe,
  ) {}

  ngOnInit() {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      combineLatest([this.route.params, this.route.queryParams]).subscribe(
        ([params, queryParams]) => {
          this.action = queryParams['action'];
          this.petId = params['petId'];
          this.managePetWellnessPlanId = queryParams['planId'] as number;
          if (this.action === 'update-plans') {
            this.getPlansForUpdateCoinfirmation();
          } else if (this.action === 'confirm-new-plans') {
            this.fetchNewSetPlansByPetId();
          } else {
            this.getChoosenPlans();
          }
        },
      );
    }
  }

  getPlansForUpdateCoinfirmation() {
    if (this.action === 'update-plans' && this.managePetWellnessPlanId) {
      this.loader = true;
      this.wellnessPlanService
        .fetchPlansPendingConfirmationByPetId(this.petId)
        .subscribe({
          next: (res: ChoosenPlans[]) => {
            this.loader = false;
            const plansWithDuplicats: ChoosenPlans[] = res;
            this.choosenPlans.set(
              this.getChoosenPlansWithServiceCount(plansWithDuplicats),
            );
            const promotions = this.choosenPlans()[0].promotions;
            if (promotions && promotions !== null) {
              this.promotions.set(promotions);
            }
          },
          error: (err: HttpErrorResponse) => {
            this.loader = false;
            console.log(err);
          },
        });
    }
  }

  formatDateToYMD(dateString: string): string {
    const date = new Date(dateString);
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${year}-${month}-${day}`;
  }

  getChoosenPlans() {
    this.loader = true;
    this.wellnessPlanService.getChoosenPlansByPetOwner(this.petId).subscribe({
      next: (response) => {
        this.loader = false;
        const plansWithDuplicats: ChoosenPlans[] = response;
        this.choosenPlans.set(
          this.getChoosenPlansWithServiceCount(plansWithDuplicats),
        );
        this.selectedPlans.set(
          this.choosenPlans().filter((plan) => plan.confirmed === true),
        );
        this.managePetWellnessPlanId =
          this.choosenPlans()[0].managePetWellnessPlanId || 0;
        const promotions = this.choosenPlans()[0].promotions;
        if (promotions && promotions !== null) {
          this.promotions.set(promotions);
        }
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
      },
    });
  }

  private getChoosenPlansWithServiceCount(
    plans: ChoosenPlans[],
  ): ChoosenPlans[] {
    const aggregatePlans = new Map<string, ChoosenPlans>();

    plans.forEach((plan) => {
      const wellnessplanId = plan.clinicWellnessPlan.clinicWellnessPlanId;
      const wellnessUpdateId = plan.wellnessPlanUpdate.wellnessUpdateId;
      const uniqueName = `${wellnessplanId}-${wellnessUpdateId}`;

      if (aggregatePlans.get(uniqueName)) {
        const existingPlan = aggregatePlans.get(uniqueName)!;
        existingPlan.serviceCount += plan.serviceCount ?? 1;
        existingPlan.choosePlanIds.push(plan.choosePlanId);
      } else {
        aggregatePlans.set(uniqueName, {
          ...plan,
          serviceCount: plan.serviceCount ?? 1,
          choosePlanIds: [plan.choosePlanId],
        });
      }
    });
    return Array.from(aggregatePlans.values());
  }

  updateConfirmPlans() {
    this.loader = true;
    const selectedId: number[] = this.selectedPlans().reduce<number[]>(
      (acc, plan) => {
        return acc.concat(plan.choosePlanIds);
      },
      [],
    );

    let payload: {
      petWellnessPlanIds: number[];
      startDate: string;
      endDate: string;
      managePetWellnessPlanId?: number;
      totalAmount?: string;
      updatedAmount?: string;
    } = {
      petWellnessPlanIds: [],
      startDate: '',
      endDate: '',
    };

    const totalDiscountedPrice =
      this.computedChoosenPlanSignal().totalDiscountedPrice;
    if (this.action === 'update-plans') {
      payload = {
        petWellnessPlanIds: selectedId,
        startDate: this.choosenPlans()[0].startDate!,
        endDate: this.choosenPlans()[0].endDate!,
        managePetWellnessPlanId: this.managePetWellnessPlanId,
        updatedAmount: totalDiscountedPrice
          ? totalDiscountedPrice.replace('$', '')
          : '0',
      };
    } else {
      payload = {
        petWellnessPlanIds: selectedId,
        startDate: this.startDate(),
        endDate: this.endDate(),
        managePetWellnessPlanId: this.managePetWellnessPlanId,
        totalAmount: totalDiscountedPrice
          ? totalDiscountedPrice.replace('$', '')
          : '0',
      };
    }
    this.wellnessPlanService.updateConfirmPlans(payload).subscribe({
      next: (response) => {
        this.loader = false;
        let successMessage = '';
        if (this.action === 'update-plans') {
          successMessage = 'Updated Successfully';
        } else if (this.action === 'confirm-new-plans') {
          successMessage = 'New Plans Added Successfully';
        } else {
          successMessage = 'Updated Successfully';
        }
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: successMessage,
        });

        setTimeout(() => {
          const petOwnerId = this.choosenPlans()[0].petOwnerId;
          this.router.navigate([
            '/clinic/pet-owner',
            petOwnerId,
            'pet',
            this.petId,
          ]);
        }, 2000);
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to update plans',
        });
      },
    });
  }

  fetchNewSetPlansByPetId() {
    this.loader = true;
    this.wellnessPlanService.fetchNewSetPlansByPetId(this.petId).subscribe({
      next: (res: ChoosenPlans[]) => {
        this.loader = false;
        const plansWithDuplicats: ChoosenPlans[] = res;
        this.choosenPlans.set(
          this.getChoosenPlansWithServiceCount(plansWithDuplicats),
        );
        this.managePetWellnessPlanId =
          this.choosenPlans()[0].managePetWellnessPlanId || 0;
        const promotions = this.choosenPlans()[0].promotions;
        if (promotions && promotions !== null) {
          this.promotions.set(promotions);
        }
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        console.log(err);
      },
    });
  }

  parsePrice(price: string | undefined): number {
    return price ? parseFloat(price.replace('$', '').trim()) || 0 : 0;
  }
  getPriceByPetSize(plan: ChoosenPlans): {
    price: number;
    discountPrice: number;
  } {
    const sizePriceMap: Record<
      string,
      { price: string | undefined; discountPrice: string | undefined }
    > = {
      Small: {
        price: plan.wellnessPlanUpdate.updatedPriceForSmall,
        discountPrice: plan.wellnessPlanUpdate.discountPriceForSmall,
      },
      Medium: {
        price: plan.wellnessPlanUpdate.updatedPriceForMedium,
        discountPrice: plan.wellnessPlanUpdate.discountPriceForMedium,
      },
      Large: {
        price: plan.wellnessPlanUpdate.updatedPriceForLarge,
        discountPrice: plan.wellnessPlanUpdate.discountPriceForLarge,
      },
      'X-Large': {
        price: plan.wellnessPlanUpdate.updatedPriceForXLarge,
        discountPrice: plan.wellnessPlanUpdate.discountPriceForXLarge,
      },
    };

    const prices = sizePriceMap[plan.petSize] || {
      price: undefined,
      discountPrice: undefined,
    };
    return {
      price: this.parsePrice(prices.price),
      discountPrice: this.parsePrice(prices.discountPrice),
    };
  }

  computedChoosenPlanSignal = computed(() => {
    const total = this.selectedPlans().reduce(
      (acc, plan) => {
        const serviceCount = plan.serviceCount ?? 1;
        const priceCalculations = {
          QTY: () => ({
            price: this.parsePrice(
              plan.wellnessPlanUpdate.updatedPriceForQuantity,
            ),
            discountPrice: this.parsePrice(
              plan.wellnessPlanUpdate.discountPriceForQuantity,
            ),
          }),
          WGT: () => this.getPriceByPetSize(plan),
        };

        const priceBased = plan.wellnessPlanUpdate
          .priceBased as keyof typeof priceCalculations;
        const { price, discountPrice } = priceCalculations[priceBased]() || {
          price: 0,
          discountPrice: 0,
        };

        if (price) acc.totalPriceSum += price * serviceCount;
        if (discountPrice)
          acc.totalDiscountedPriceSum += discountPrice * serviceCount;

        return acc;
      },
      { totalPriceSum: 0, totalDiscountedPriceSum: 0 },
    );
    let promotionCount = 0;
    const promotions = this.promotions();
    if (promotions && promotions !== null) {
      promotionCount = promotions.length;
    }
    let firstMonthPrice = 0;
    if (promotionCount > 0) {
      firstMonthPrice = total.totalDiscountedPriceSum / 12 + 7;
    } else {
      firstMonthPrice = total.totalDiscountedPriceSum / 12 + 49 + 7;
    }
    const remainingMonthPrice = total.totalDiscountedPriceSum / 12 + 7;
    const totalPrice = firstMonthPrice + remainingMonthPrice * 11;

    return {
      totalPrice: this.currencyPipe.transform(total.totalPriceSum),
      totalDiscountedPrice: this.currencyPipe.transform(
        total.totalDiscountedPriceSum,
      ),
      firstMonthPrice: this.currencyPipe.transform(firstMonthPrice),
      remainingMonthPrice: this.currencyPipe.transform(remainingMonthPrice),
      totalPriceWithInstallments: this.currencyPipe.transform(totalPrice),
    };
  });

  getPromotionsCount(): number {
    const promotions = this.promotions();
    if (promotions && promotions !== null) {
      return promotions.length;
    }
    return 0;
  }
}
