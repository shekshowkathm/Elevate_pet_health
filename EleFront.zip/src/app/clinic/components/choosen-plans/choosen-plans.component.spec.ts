import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChoosenPlansComponent } from './choosen-plans.component';

describe('ChoosenPlansComponent', () => {
  let component: ChoosenPlansComponent;
  let fixture: ComponentFixture<ChoosenPlansComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ChoosenPlansComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChoosenPlansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
