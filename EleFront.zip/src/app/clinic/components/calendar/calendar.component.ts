import { isPlatformBrowser, NgClass } from '@angular/common';
import {
  Component,
  Inject,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import {
  CalendarEvent,
  CalendarEventAction,
  CalendarModule,
  CalendarView,
} from 'angular-calendar';
import { isSameDay, isSameMonth } from 'date-fns';
import { AppointmentService } from '../../services/appointment.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Appointment, CalendarAppointment } from '../../models/appointment';

@Component({
  selector: 'app-calendar',
  standalone: true,
  imports: [CalendarModule, NgClass],
  templateUrl: './calendar.component.html',
  styleUrl: './calendar.component.scss',
})
export class CalendarComponent implements OnInit {
  private appointmentService = inject(AppointmentService);

  view: CalendarView = CalendarView.Month;
  CalendarView = CalendarView;
  viewDate: Date = new Date();
  activeDayIsOpen: boolean = false;
  events: CalendarEvent[] = [];

  loader: boolean = false;
  scheduledAppointments = signal<CalendarAppointment[]>([]);
  actions: CalendarEventAction[] = [
    // {
    //   label: '<i class="pi pi-eye me-2 text-[#007cda]"></i>',
    //   onClick: function ({
    //     event,
    //     sourceEvent,
    //   }: {
    //     event: CalendarEvent;
    //     sourceEvent: MouseEvent | KeyboardEvent;
    //   }) {
    //     // console.log('view\n', 'event', event, '\nsourceEvent', sourceEvent);
    //   },
    // },
  ];

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.fetchAppointments();
    }
  }

  fetchAppointments() {
    this.appointmentService.fetchAppointToShowInCalender().subscribe({
      next: (res: any) => {
        this.loader = false;
        this.scheduledAppointments.set(res);
        this.events = this.scheduledAppointments().map((a) => {
          return {
            title: `${a.dropDown}, ${a.serviceName} - ${a.petName}`,
            start: new Date(`${a.scheduledDateAndTime}`),
            clinicName: a.clinicName,
            petName: a.petName,
            status: 'Scheduled',
            actions: this.actions,
          };
        });
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        console.log('Error fetch the scheduled appointments', err);
      },
    });
  }

  handleEvent(action: string, event: CalendarEvent): void {
    // console.log(`first ${action} event: `, event, '\n\n\n');
    if (action === 'Reschedule') {
      // console.log(`Action: ${action}, \n event: ${event}`);
    } else if (action === 'Cancel') {
      // console.log(`Action: ${action}, \n event: ${event}`);
    }
  }

  closeOpenMonthViewDay() {
    this.activeDayIsOpen = false;
  }

  dayClicked(event: any) {
    // console.log(event, 'jkadbcjh');
    const { day, sourceEvent } = event;
    if (day.events.length === 0) {
      // TODO: Shedule new Event
    } else {
      // TODO: Show mentioned events
      if (isSameMonth(day.date, this.viewDate)) {
        if (
          (isSameDay(this.viewDate, day.date) &&
            this.activeDayIsOpen === true) ||
          day.events.length === 0
        ) {
          this.activeDayIsOpen = false;
        } else {
          this.activeDayIsOpen = true;
          this.viewDate = day.date;
        }
      }
    }
  }

  columnHeaderClicked(event: any) {
    // console.log('columnHeaderClicked', event, '\n\n', event.isoDayNumber);
  }

  dayHeaderClicked(event: any) {
    // console.log('dayHeaderClicked', event, '\n\n', event.day.date);
  }

  hourSegmentClicked(event: any) {
    // console.log('hourSegmentClicked', event, '\n\n');
  }
}
