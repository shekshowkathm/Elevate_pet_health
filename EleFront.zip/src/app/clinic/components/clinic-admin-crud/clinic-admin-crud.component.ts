import { NgIf } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { ClinicAdminService } from '../../services/clinic-admin.service';
import { ToastModule } from 'primeng/toast';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { MessageService } from 'primeng/api';
import { CustomDropdownComponent } from '../custom-dropdown/custom-dropdown.component';
import { US_STATES } from '../../../shared/constants/usa-states';
import { PhoneNumberDirective } from '../../../shared/directives/phone-number.directive';
import { NumberInputDirective } from '../../../shared/directives/number-input.directive';
import { HttpErrorResponse, HttpStatusCode } from '@angular/common/http';
import { TIME_ZONES } from '../../../shared/constants/timeZone';

@Component({
  selector: 'app-clinic-admin-crud',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    NgIf,
    ProgressSpinnerModule,
    ToastModule,
    CustomDropdownComponent,
    PhoneNumberDirective,
    NumberInputDirective,
  ],
  templateUrl: './clinic-admin-crud.component.html',
  styleUrl: './clinic-admin-crud.component.scss',
  providers: [MessageService],
})
export class ClinicAdminCrudComponent implements OnInit {
  private router = inject(Router);
  private clinicAdminService = inject(ClinicAdminService);
  loader: boolean = false;
  states = US_STATES;
  clinicAdminForm = new FormGroup({
    firstName: new FormControl('', [Validators.required]),
    lastName: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    contactNumber: new FormControl('', [
      Validators.required,
      Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/),
    ]),
    address: new FormControl('', [Validators.required]),
    city: new FormControl('', [Validators.required]),
    state: new FormControl('', [Validators.required]),
    timezone: new FormControl('', [Validators.required]),
    zipCode: new FormControl('', [
      Validators.required,
      Validators.pattern('^\\d{5}(-\\d{4})?$'),
    ]),
    doctor: new FormControl(false),
  });
  timeZones: { label: string; value: string }[] = TIME_ZONES.map((t) => ({
    label: `${t.fullName} (${t.abbreviation})`,
    value: t.abbreviation,
  }));
  constructor(private messageService: MessageService) {}
  ngOnInit(): void {}

  submitClinicAdmin() {
    this.loader = true;
    const payloadObj = {
      email: this.clinicAdminForm.value.email,
      role: 'CLINIC_ADMIN',
      firstName: this.clinicAdminForm.value.firstName,
      lastName: this.clinicAdminForm.value.lastName,
      state: this.clinicAdminForm.value.state,
      city: this.clinicAdminForm.value.city,
      zipcode: this.clinicAdminForm.value.zipCode,
      doctor: this.clinicAdminForm.value.doctor,
      contactNumber: this.clinicAdminForm.value.contactNumber,
      timezone: this.clinicAdminForm.value.timezone,
    };
    this.clinicAdminService.AddclinicAdminAndAssociate(payloadObj).subscribe({
      next: (res: any) => {
        this.loader = false;
        this.clinicAdminForm.reset();
        this.messageService.add({
          severity: 'success',
          summary: 'Admin Added',
          detail: 'Clinic Admin Added sucessfully',
        });
        setTimeout(() => {
          this.router.navigateByUrl('/clinic/clinic-admin');
        }, 1000);
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        if (err.status === HttpStatusCode.Conflict) {
          this.messageService.add({
            severity: 'error',
            summary: 'Email Already Exists',
            detail: 'Please use different Email address',
          });
          return;
        }
        this.messageService.add({
          severity: 'error',
          summary: 'Already Admin Present',
          detail: 'Cannot add admin',
        });
      },
    });
  }
}
