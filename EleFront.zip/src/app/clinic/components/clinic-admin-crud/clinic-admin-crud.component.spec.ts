import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicAdminCrudComponent } from './clinic-admin-crud.component';

describe('ClinicAdminCrudComponent', () => {
  let component: ClinicAdminCrudComponent;
  let fixture: ComponentFixture<ClinicAdminCrudComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClinicAdminCrudComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClinicAdminCrudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
