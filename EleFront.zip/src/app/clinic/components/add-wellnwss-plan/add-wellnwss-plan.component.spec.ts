import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddWellnwssPlanComponent } from './add-wellnwss-plan.component';

describe('AddWellnwssPlanComponent', () => {
  let component: AddWellnwssPlanComponent;
  let fixture: ComponentFixture<AddWellnwssPlanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddWellnwssPlanComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddWellnwssPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
