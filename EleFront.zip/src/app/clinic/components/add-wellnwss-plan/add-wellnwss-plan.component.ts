import {
  CurrencyPipe,
  isPlatformBrowser,
  NgClass,
  NgIf,
} from '@angular/common';
import {
  Component,
  computed,
  inject,
  Inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { WellnessService } from '../../services/wellness.service';
import { HttpErrorResponse } from '@angular/common/http';
import {
  ClinicWellnessPlan,
  ClinicWellnessPlanWithPromotions,
  PromotionWithAvailabityStatus,
  TransformedClinicWellnessPlan,
} from '../../models/wellness-plan-response';
import { TableModule } from 'primeng/table';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { FormsModule } from '@angular/forms';
import { PetListWithOwnerIdDTO } from '../../models/pet-owners';
import { ClinicAuthService } from '../../services/clinic-auth.service';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { SingleDigitDirective } from '../../../shared/directives/single-digit.directive';
import {
  SendToPetOwner,
  SendToPetOwnerWithPromotions,
} from '../../models/send-to-pet-owner';
import { PromotionEligibilityPipe } from '../../../shared/pipes/promotion-eligibility.pipe';

@Component({
  selector: 'app-add-wellnwss-plan',
  standalone: true,
  imports: [
    TableModule,
    ProgressSpinnerModule,
    FormsModule,
    ToastModule,
    NgClass,
    CurrencyPipe,
    SingleDigitDirective,
    PromotionEligibilityPipe,
  ],
  templateUrl: './add-wellnwss-plan.component.html',
  styleUrl: './add-wellnwss-plan.component.scss',
  providers: [MessageService, CurrencyPipe],
})
export class AddWellnwssPlanComponent implements OnInit {
  private activatedRoute = inject(ActivatedRoute);
  private clinicAuthService = inject(ClinicAuthService);
  private wellnessService = inject(WellnessService);
  private currencyPipe = inject(CurrencyPipe);
  private router = inject(Router);
  petId = signal<number>(0);
  ageGroups = ['Puppy', 'Kitten', 'Adult', 'Senior'];
  wellnessPlans = signal<ClinicWellnessPlan[] | null>(null);
  loader = false;
  petType = '';
  ageGroup = '';
  petSize = '';
  wellnessPlanName = '';
  petDetail: PetListWithOwnerIdDTO = {
    id: 0,
    ownerFirstName: null,
    ownerLastName: null,
    email: '',
    contact: '',
    petName: '',
    petType: '',
    petBreed: '',
    weight: '',
    profile: null,
    image: '',
    dob: null,
    state: '',
    city: '',
    ownerId: 0,
  };
  transformedWellnessPlanData: TransformedClinicWellnessPlan[] = [];
  selectedPlans = signal<TransformedClinicWellnessPlan[]>([]);
  promotions = signal<PromotionWithAvailabityStatus[]>([]);
  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    private messageService: MessageService,
  ) {}
  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe((params) => {
      this.petId.set(Number(params.get('petId')));
    });
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.petDetail = JSON.parse(
        sessionStorage.getItem('selectedPet') as string,
      );
      this.petType = this.petDetail?.petType || '';
      this.ageGroup = this.petDetail?.ageGroup || '';
      this.petSize = this.petDetail.petSize || '';
      this.fetchWellnessPlan();
    }
  }

  fetchWellnessPlan() {
    if (this.petType && this.ageGroup && this.petSize) {
      this.loader = true;
      this.wellnessPlanName = `${this.petType} - ${this.ageGroup}`;

      this.wellnessService
        .fetchWellnessPlanBasedOnPetandWellnesPlanNameAndPetSize(
          this.wellnessPlanName,
          this.petSize,
          this.petId(),
        )
        .subscribe({
          next: (res: ClinicWellnessPlanWithPromotions) => {
            this.wellnessPlans.set(res.wellnessPlans);
            this.promotions.set(res.promotions.filter((p) => p.status));
            this.loader = false;
            const requiredPlans: TransformedClinicWellnessPlan[] = [];
            const nonRequiredPlans: TransformedClinicWellnessPlan[] = [];
            const transformedData = res.wellnessPlans.flatMap((plan) =>
              plan.clinicDropDowns.map((dropdown) => {
                const transformedPlan: TransformedClinicWellnessPlan = {
                  clinicWellnessPlanId: plan.clinicWellnessPlanId,
                  petType: plan.petType,
                  ageGroup: plan.ageGroup,
                  wellnessPlanName: plan.wellnessPlanName,
                  serviceName: plan.serviceName,
                  dropdown: dropdown.dropdown,
                  priceBased: dropdown.priceBased,
                  industryStandardPrice: dropdown.industryStandardPrice,
                  recommendation: dropdown.wellnessUpdate.updateRecommendation,
                  wellnessUpdate: dropdown.wellnessUpdate,
                  serviceCount: 1,
                };

                if (transformedPlan.recommendation === 'Required') {
                  requiredPlans.push(transformedPlan);
                } else {
                  nonRequiredPlans.push(transformedPlan);
                }
                return transformedPlan;
              }),
            );
            this.transformedWellnessPlanData = [
              ...requiredPlans,
              ...nonRequiredPlans,
            ];

            this.selectedPlans.set(requiredPlans);
          },
          error: (err: HttpErrorResponse) => {
            console.error('Error fetching wellness plans', err);
            this.loader = false;
          },
        });
    }
  }

  // Method not used
  confirmPlans() {
    if (this.selectedPlans().length === 0) {
      this.messageService.add({
        severity: 'warn',
        summary: 'Confirm Plan',
        detail: 'Please select plans before confirm.',
      });
      return;
    }
    const payload: {
      petId: number;
      petOwnerId: number;
      clinicWellnessPlan: number;
      wellnessPlanUpdate: number;
      assignedBy: number;
    }[] = this.selectedPlans().map((s) => {
      return {
        petId: this.petDetail.id,
        petOwnerId: this.petDetail.ownerId,
        clinicWellnessPlan: s.clinicWellnessPlanId!,
        wellnessPlanUpdate: s.wellnessUpdate.wellnessUpdateId,
        assignedBy: this.clinicAuthService.getUserId()!,
      };
    });

    this.wellnessService.confirmSelectedWellnessPlans(payload).subscribe({
      next: (res: any) => {
        console.log('res', res);
        this.messageService.add({
          severity: 'success',
          summary: 'Plan confirmed',
          detail: 'Wellness plan Added sucessfully',
        });
      },
      error: (err: HttpErrorResponse) => {
        console.log('Error confirming selected wellness plans', err);
      },
    });
  }

  saveAsPDF() {
    if (this.transformedWellnessPlanData.length === 0) {
      this.messageService.add({
        severity: 'warn',
        summary: 'Confirm Plan',
        detail: 'Please select plans before confirm.',
      });
      return;
    }
    const doc = new jsPDF();

    const columns = [
      'S.No',
      'Pet Type',
      'Wellness Plan Name',
      'Service Name',
      'Service Drop Down',
      'Price Based',
      'Recommendation',
      'Clinic Standard Price',
      'Clinic Discount Price',
    ];
    const rows = this.selectedPlans().map((plan, i) => [
      i + 1,
      plan.petType,
      plan.wellnessPlanName,
      plan.serviceName,
      plan.dropdown,
      plan.priceBased,
      plan.wellnessUpdate.updateRecommendation,
      this.getPrice(plan),
      plan.wellnessUpdate.price,
    ]);

    autoTable(doc, {
      head: [columns],
      body: rows,
    });
    doc.save('wellness plans.pdf');
  }

  private getPrice(plan: TransformedClinicWellnessPlan): string {
    if (plan.priceBased === 'QTY') {
      return plan.wellnessUpdate.updatedPriceForQuantity || '';
    }
    if (plan.priceBased === 'WGT') {
      const sizePriceMap: Record<string, string | undefined> = {
        Small: plan.wellnessUpdate.updatedPriceForSmall,
        Medium: plan.wellnessUpdate.updatedPriceForMedium,
        Large: plan.wellnessUpdate.updatedPriceForLarge,
        'X-Large': plan.wellnessUpdate.updatedPriceForXLarge,
      };

      return sizePriceMap[this.petSize] || '';
    }
    return '';
  }

  sendWellnessPlansToPetOwner() {
    if (this.selectedPlans().length === 0) {
      this.messageService.add({
        severity: 'warn',
        summary: 'Confirm Plan',
        detail: 'Please select plans before confirm.',
      });
      return;
    }
    let plans: SendToPetOwnerWithPromotions = {
      promotionDiscounts: [],
      choosePlans: [],
    };

    plans.choosePlans = this.selectedPlans().map((s) => ({
      petId: this.petDetail.id,
      petOwnerId: this.petDetail.ownerId,
      clinicWellnessPlan: s.clinicWellnessPlanId!,
      clinicWellnessUpdate: s.wellnessUpdate.wellnessUpdateId,
      sentBy: this.clinicAuthService.getUserId()!,
      serviceFrequency: s.serviceCount ?? 1,
    }));
    plans.promotionDiscounts = this.promotions().map((p) => {
      return { id: p.id };
    });

    this.loader = true;

    this.wellnessService.sendWellnessPlansToPetOwner(plans).subscribe({
      next: (res: any) => {
        console.log(res);
        this.messageService.add({
          severity: 'success',
          summary: 'Plan send',
          detail: 'Wellness plan send sucessfully',
        });
        this.loader = false;
        setTimeout(() => {
          this.router.navigateByUrl('/clinic/pet-owners');
        }, 2000);
      },
      error: (err: HttpErrorResponse) => {
        console.log('Error send wellness plans to pet owner: ', err);
        this.loader = false;
      },
    });
  }

  /**
   * Updates the `serviceCount` of a selected wellness plan based on its `wellnessPlanId` and `wellnessUpdateId`.
   * This method uses the `update` function of the `selectedPlans` signal to reactively update
   * the state of the selected wellness plans array. It ensures that both `clinicWellnessPlanId`
   * and `wellnessUpdateId` match before updating the `serviceCount`.
   *
   * @param {TransformedClinicWellnessPlan} wellnessPlan - The wellness plan object containing the `clinicWellnessPlanId`
   *                                                    and `wellnessUpdateId` that need to match for the update.
   * @param {number} newServiceCount - The new service count to set for the selected wellness plan.
   *
   * @returns {void} - This method does not return anything, it updates the signal's state.
   */
  checkChangeOnSelectedWellnessPlan(
    wellnessPlan: TransformedClinicWellnessPlan,
    newServiceCount: number,
  ): void {
    this.selectedPlans.update((plans) => {
      return plans.map((plan) =>
        plan.clinicWellnessPlanId === wellnessPlan.clinicWellnessPlanId &&
        plan.wellnessUpdate.wellnessUpdateId ===
          wellnessPlan.wellnessUpdate.wellnessUpdateId
          ? { ...plan, serviceCount: newServiceCount }
          : plan,
      );
    });
  }

  computedSelectedWellnessPlanSignal = computed(() => {
    const parsePrice = (price: string | undefined): number =>
      price ? parseFloat(price.replace('$', '').trim()) || 0 : 0;

    const getPriceByPetSize = (plan: TransformedClinicWellnessPlan): number => {
      const sizePriceMap: Record<string, string | undefined> = {
        Small: plan.wellnessUpdate.updatedPriceForSmall,
        Medium: plan.wellnessUpdate.updatedPriceForMedium,
        Large: plan.wellnessUpdate.updatedPriceForLarge,
        'X-Large': plan.wellnessUpdate.updatedPriceForXLarge,
      };
      return parsePrice(sizePriceMap[this.petSize]);
    };

    const total = this.selectedPlans().reduce(
      (acc, plan) => {
        let price = 0;

        if (plan.priceBased === 'QTY') {
          price = parsePrice(plan.wellnessUpdate.updatedPriceForQuantity);
        } else if (plan.priceBased === 'WGT') {
          price = getPriceByPetSize(plan);
        }

        if (price) acc.totalPriceSum += price * (plan.serviceCount ?? 1);

        if (plan?.wellnessUpdate?.price) {
          const discountedPrice = parsePrice(plan.wellnessUpdate.price);
          acc.totalDiscountedPriceSum +=
            discountedPrice * (plan.serviceCount ?? 1);
        }

        return acc;
      },
      { totalPriceSum: 0, totalDiscountedPriceSum: 0 },
    );
    const promotionCount = this.promotions().length;
    let firstMonthPrice = 0;
    if (promotionCount > 0) {
      firstMonthPrice = total.totalDiscountedPriceSum / 12 + 7;
    } else {
      firstMonthPrice = total.totalDiscountedPriceSum / 12 + 49 + 7;
    }
    const remainingMonthPrice = total.totalDiscountedPriceSum / 12 + 7;
    const totalPriceWithInstallments =
      firstMonthPrice + remainingMonthPrice * 11;

    return {
      totalPrice: this.currencyPipe.transform(total.totalPriceSum),
      totalDiscountedPrice: this.currencyPipe.transform(
        total.totalDiscountedPriceSum,
      ),
      firstMonthPrice: this.currencyPipe.transform(firstMonthPrice),
      remainingMonthPrice: this.currencyPipe.transform(remainingMonthPrice),
      totalPriceWithInstallments: this.currencyPipe.transform(
        totalPriceWithInstallments,
      ),
    };
  });

  getPromotionsCount(): number {
    return this.promotions().length;
  }
}
