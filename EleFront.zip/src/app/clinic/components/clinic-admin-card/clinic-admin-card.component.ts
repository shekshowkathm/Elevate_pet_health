import {
  trigger,
  state,
  style,
  transition,
  animate,
} from '@angular/animations';
import { isPlatformBrowser, NgIf } from '@angular/common';
import {
  Component,
  inject,
  Inject,
  input,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { InputSwitchModule } from 'primeng/inputswitch';
import { AdminAccess } from '../../models/admin-access';
import { ClinicUser } from '../../models/clinic-user';
import { ClinicAdminWithClinicResponse } from '../../models/clinic-admin-with-clinic-response';
import { ClinicAdminService } from '../../services/clinic-admin.service';
import { HttpErrorResponse } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-clinic-admin-card',
  standalone: true,
  imports: [InputSwitchModule, NgIf, FormsModule],
  templateUrl: './clinic-admin-card.component.html',
  styleUrl: './clinic-admin-card.component.scss',
  animations: [
    trigger('slideInOut', [
      state(
        'void',
        style({
          height: '0px',
          opacity: 0,
          overflow: 'hidden',
        }),
      ),
      state(
        '*',
        style({
          height: '*',
          opacity: 1,
          overflow: 'hidden',
        }),
      ),
      transition('void <=> *', [animate('500ms ease-in-out')]),
    ]),
  ],
})
export class ClinicAdminCardComponent implements OnInit {
  private clinicAdminService = inject(ClinicAdminService);
  showAccess: boolean = false;
  item = input.required<ClinicAdminWithClinicResponse>();
  clinicAdminAccess = signal<AdminAccess>({
    clinicAdminId: 0,
    updateWeightRange: false,
    updateClinicPrice: false,
    updateRecommendation: false,
    updateDiscountPercentage: false,
    updateDiscountPrice: false,
    updateDoctorPercentage: false,
    viewPayment: false,
  });
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.fetchClinicAdminAccess();
    }
  }

  toggleAccess() {
    this.showAccess = !this.showAccess;
  }
  fetchClinicAdminAccess() {
    this.clinicAdminService.fetchClinicAdminAccess(this.item().id).subscribe({
      next: (val: any) => {
        this.clinicAdminAccess.set(val as AdminAccess);
      },
      error: (err: HttpErrorResponse) => {
        console.log('Error fetch Admin Access:', err);
      },
    });
  }

  updateclinicAdminAccess() {
    this.clinicAdminService
      .updateClinicAdminAccess(this.clinicAdminAccess())
      .subscribe({
        next: (val: any) => {
          this.fetchClinicAdminAccess();
        },
        error: (err: HttpErrorResponse) => {
          console.log('Error updating clinic admin access :', err);
          this.fetchClinicAdminAccess();
        },
      });
  }
}
