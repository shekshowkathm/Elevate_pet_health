import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicAdminCardComponent } from './clinic-admin-card.component';

describe('ClinicAdminCardComponent', () => {
  let component: ClinicAdminCardComponent;
  let fixture: ComponentFixture<ClinicAdminCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClinicAdminCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClinicAdminCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
