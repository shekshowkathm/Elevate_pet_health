import {
  Component,
  computed,
  inject,
  Inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TableModule } from 'primeng/table';
import { SupportCardComponent } from '../support-card/support-card.component';
import { UserSupportRequest } from '../../models/user-support-requests';
import { isPlatformBrowser } from '@angular/common';
import { ClinicService } from '../../services/clinic.service';
import { HttpErrorResponse } from '@angular/common/http';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-support',
  standalone: true,
  imports: [
    TableModule,
    ProgressSpinnerModule,
    SupportCardComponent,
    DropdownModule,
    FormsModule,
  ],
  templateUrl: './support.component.html',
  styleUrl: './support.component.scss',
})
export class SupportComponent implements OnInit {
  private clinicService = inject(ClinicService);
  loader: boolean = false;
  isAPILoaded: boolean = false;
  supportRequests = signal<UserSupportRequest[]>([]);

  filterQueryOptions: { name: string; value: string }[] = [
    {
      name: 'Pending',
      value: 'Pending',
    },
    {
      name: 'Responded',
      value: 'Responded',
    },
  ];
  queryFilter = signal<string | null>(null);
  filteredSuprotQueries = computed(() => {
    const res = this.supportRequests().filter((q) =>
      this.queryFilter() ? q.status === this.queryFilter() : true,
    );
    return res;
  });

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.loader = true;
      this.fetchSupportQuires();
    }
  }
  clearFilter() {
    this.queryFilter.set(null);
  }

  fetchSupportQuires() {
    this.clinicService.fetchSupportQuries().subscribe({
      next: (response) => {
        this.supportRequests.set(response as UserSupportRequest[]);
        this.loader = false;
        this.isAPILoaded = true;
      },
      error: (err: HttpErrorResponse) => {
        console.log('error fetching support Quires', err);
        this.loader = false;
        this.isAPILoaded = true;
      },
    });
  }
}
