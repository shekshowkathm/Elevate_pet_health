import { Component, inject, input, output } from '@angular/core';
import { UserSupportRequest } from '../../models/user-support-requests';
import { NgClass, NgOptimizedImage, TitleCasePipe } from '@angular/common';
import { DialogModule } from 'primeng/dialog';
import { FormsModule, NgForm } from '@angular/forms';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ClinicService } from '../../services/clinic.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-support-card',
  standalone: true,
  imports: [
    NgOptimizedImage,
    TitleCasePipe,
    NgClass,
    DialogModule,
    FormsModule,
    ProgressSpinnerModule,
  ],
  templateUrl: './support-card.component.html',
  styleUrl: './support-card.component.scss',
})
export class SupportCardComponent {
  supportRequest = input.required<UserSupportRequest>();
  callSuportQueries = output<void>();
  private clinicService = inject(ClinicService);
  showFullMessage: boolean = false;
  maxLength: number = 150;
  loader: boolean = false;
  visible: boolean = false;
  replyMessage: string = '';
  isError: boolean = false;
  isReplyVisible: boolean = false;

  get truncatedMessage(): string {
    return this.supportRequest().message.substring(0, this.maxLength);
  }

  toggleMessage(): void {
    this.showFullMessage = !this.showFullMessage;
  }

  respondToMessage() {
    this.visible = true;
  }

  SubmitResponse() {
    this.isError = false;
    if (!this.replyMessage) {
      this.isError = true;
      return;
    }
    this.loader = true;
    const payload: { supportId: number; replyMessage: string } = {
      supportId: this.supportRequest().id,
      replyMessage: this.replyMessage,
    };
    this.clinicService.sendReplymessage(payload).subscribe({
      next: (res: any) => {
        this.cancelOrReset();
        this.callSuportQueries.emit();
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        console.log('Error sending reply message', err);
      },
    });
  }

  cancelOrReset() {
    this.visible = false;
    this.replyMessage = '';
    this.isError = false;
    this.loader = false;
  }

  toggleReplyVisibility() {
    this.isReplyVisible = !this.isReplyVisible;
  }

  lightColors: string[] = [
    '#FFFBCC',
    '#CCFFCC',
    '#CCF2FF',
    '#FFE6CC',
    '#F5CCFF',
  ];

  getBackgroundColor(): string {
    if (this.supportRequest().status === 'Responded') {
      return '#D4EDDA';
    }
    if (this.supportRequest().status === 'Pending') {
      return '#FFF3CD';
    }
    return this.lightColors[
      Math.floor(Math.random() * this.lightColors.length)
    ];
  }
}
