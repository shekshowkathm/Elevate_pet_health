import {
  Component,
  Inject,
  inject,
  OnInit,
  PLATFORM_ID,
  signal,
} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { TableModule } from 'primeng/table';
import { ClinicAdminCrudComponent } from '../clinic-admin-crud/clinic-admin-crud.component';
import { ClinicAdminService } from '../../services/clinic-admin.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ClinicAdminWithClinicResponse } from '../../models/clinic-admin-with-clinic-response';
import { ClinicAdminCardComponent } from '../clinic-admin-card/clinic-admin-card.component';

@Component({
  selector: 'app-clinic-admin',
  standalone: true,
  imports: [
    TableModule,
    ProgressSpinnerModule,
    ClinicAdminCardComponent,
  ],
  templateUrl: './clinic-admin.component.html',
  styleUrl: './clinic-admin.component.scss',
})
export class ClinicAdminComponent implements OnInit {
  clinicAdminService = inject(ClinicAdminService);
  clinicAdmin = this.clinicAdminService.clinicAdminDetail$;
  loader = signal<boolean>(false);
  private router = inject(Router);
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.getClinicAdmin();
    }
  }

  getClinicAdmin() {
    this.loader.set(true);
    this.clinicAdminService.getClinicAdminDetails().subscribe({
      next: (res: any) => {
        this.loader.set(false);
        this.clinicAdmin.set(res as ClinicAdminWithClinicResponse);
      },
      error: (err: HttpErrorResponse) => {
        console.log(err);
        this.loader.set(false);
      },
    });
  }

  gotoAddAdmin() {
    this.router.navigateByUrl('/clinic/add-clinic-admin');
  }
}
