import { Component, OnInit } from '@angular/core';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { of } from 'rxjs';
import { TransactionDetail } from '../../models/transaction-detail';
import { HttpErrorResponse } from '@angular/common/http';
import { CommonModule, CurrencyPipe, DatePipe } from '@angular/common';
import { TableModule } from 'primeng/table';
import { TrancationService } from '../../../pet-owner/service/trancation.service';
import { FormsModule } from '@angular/forms';
import { SharedService } from '../../../shared/service/shared.service';

@Component({
  selector: 'app-transaction-details',
  standalone: true,
  imports: [
    ProgressSpinnerModule,
    CurrencyPipe,
    DatePipe,
    TableModule,
    CommonModule,
    FormsModule,
  ],
  templateUrl: './transaction-details.component.html',
  styleUrl: './transaction-details.component.scss',
})
export class TransactionDetailsComponent implements OnInit {
  loader: boolean = false;
  isApiLoaded: boolean = false;
  transactionDetail: TransactionDetail[] = [];
  public filterClinicDetails: any = [];
  clinicDetailsFilter: string = '';
  public trancationList: any[] = [];
  constructor(
    private trancationService: TrancationService,
    private sharedService: SharedService,
  ) {}
  ngOnInit(): void {
    this.fetchTransactionDetails();
  }

  fetchTransactionDetails() {
    this.loader = true;
    const stripeAccountId = localStorage.getItem('1') || '';
    if (!stripeAccountId) {
      console.warn('Stripe account ID is not available in localStorage.');
    }
    let data = { stripeAccountId: stripeAccountId, paymentStatus: 'paid' };
    this.trancationService.getByAccountId(data).subscribe((res: any) => {
      const dataArray = JSON.parse(res);
      this.loader = false;
      this.isApiLoaded = true;
      this.transactionDetail = dataArray;
      this.filterClinicDetails = this.transactionDetail
    });
  }
  filterByclinicDetailsFilter() {
    if (!this.clinicDetailsFilter) {
      this.filterClinicDetails = [...this.transactionDetail];
    } else {
      const searchQuery = this.clinicDetailsFilter.toLowerCase();
      this.filterClinicDetails = this.transactionDetail.filter((item: any) => {
        const petOwnerName = item.petOwnerName?.toLowerCase() || '';
        return petOwnerName.includes(searchQuery);
      });
    }
  }
  exportToExcel() {
    this.filterClinicDetails.forEach((res: any) => {
      const date = new Date(res.customerPaidDate * 1000);
      const usDateFormat = new Intl.DateTimeFormat('en-US', {
        dateStyle: 'short',
      }).format(date);
      this.trancationList.push({
        customerPaidDate: usDateFormat,
        InvoiceNo: res.stripeInvoiceId,
        clinicName: res.clinicName,
        clincAmount: res.connectedAccountReceived,
        petOwnerName: res.petOwnerName,
        status: res.paymentStatus,
      });
    });
    this.sharedService.exportAsExcelFile(
      this.trancationList,
      'Trancation Details',
    );
  }
}
