import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddClinicAssociateComponent } from './add-clinic-associate.component';

describe('AddClinicAssociateComponent', () => {
  let component: AddClinicAssociateComponent;
  let fixture: ComponentFixture<AddClinicAssociateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddClinicAssociateComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddClinicAssociateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
