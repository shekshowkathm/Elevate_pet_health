import { Component, inject } from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';
import { MessageService } from 'primeng/api';
import { NgIf } from '@angular/common';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ToastModule } from 'primeng/toast';
import { ClinicAssociateService } from '../../services/clinic-associate.service';
import { Router } from '@angular/router';
import { AddClinicAssociate } from '../../models/clinic-associate-model';
import { CustomDropdownComponent } from '../custom-dropdown/custom-dropdown.component';
import { US_STATES } from '../../../shared/constants/usa-states';
import { PhoneNumberDirective } from '../../../shared/directives/phone-number.directive';
import { NumberInputDirective } from '../../../shared/directives/number-input.directive';
import { HttpErrorResponse, HttpStatusCode } from '@angular/common/http';
import { TIME_ZONES } from '../../../shared/constants/timeZone';

@Component({
  selector: 'app-add-clinic-associate',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    NgIf,
    ProgressSpinnerModule,
    ToastModule,
    CustomDropdownComponent,
    PhoneNumberDirective,
    NumberInputDirective,
  ],
  templateUrl: './add-clinic-associate.component.html',
  styleUrl: './add-clinic-associate.component.scss',
  providers: [MessageService],
})
export class AddClinicAssociateComponent {
  private router = inject(Router);
  private clinicAssociateService = inject(ClinicAssociateService);
  loader: boolean = false;
  clinicAssociateForm = new FormGroup({
    firstName: new FormControl('', [Validators.required]),
    lastName: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    contactNumber: new FormControl('', [
      Validators.required,
      Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/),
    ]),
    address: new FormControl('', [Validators.required]),
    city: new FormControl('', [Validators.required]),
    state: new FormControl('', [Validators.required]),
    timezone: new FormControl('', [Validators.required]),
    zipCode: new FormControl('', [
      Validators.required,
      Validators.pattern('^\\d{5}(-\\d{4})?$'),
    ]),
    designation: new FormControl('', [Validators.required]),
    doctor: new FormControl(false),
  });
  states = US_STATES;
  timeZones: { label: string; value: string }[] = TIME_ZONES.map((t) => ({
    label: `${t.fullName} (${t.abbreviation})`,
    value: t.abbreviation,
  }));
  constructor(private messageService: MessageService) {}
  ngOnInit(): void {}

  submitClinicAssociate() {
    this.loader = true;
    const payloadObj: AddClinicAssociate = {
      email: this.clinicAssociateForm.value.email!,
      role: 'CLINIC_ASSOCIATE',
      state: this.clinicAssociateForm.value.state!,
      city: this.clinicAssociateForm.value.city!,
      zipcode: this.clinicAssociateForm.value.zipCode!,
      doctor: this.clinicAssociateForm.value.doctor!,
      designation: this.clinicAssociateForm.value.designation!,
      contactNumber: this.clinicAssociateForm.value.contactNumber!,
      firstName: this.clinicAssociateForm.value.firstName!,
      lastName: this.clinicAssociateForm.value.lastName!,
      address: this.clinicAssociateForm.value.address!,
      timezone: this.clinicAssociateForm.value.timezone!,
    };
    this.clinicAssociateService.AddclinicAssociate(payloadObj).subscribe({
      next: (res) => {
        this.loader = false;
        this.clinicAssociateForm.reset();
        this.messageService.add({
          severity: 'success',
          summary: 'Clinic Associate Added',
          detail: 'Clinic Associate Added sucessfully',
        });
        setTimeout(() => {
          this.router.navigateByUrl('/clinic/clinic-associate');
        }, 1000);
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        if (err.status === HttpStatusCode.Conflict) {
          this.messageService.add({
            severity: 'error',
            summary: 'Email Already Exists',
            detail: 'Please use different Email address',
          });
          return;
        }
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Cannot add associate',
        });
      },
    });
  }
}
