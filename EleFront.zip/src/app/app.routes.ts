import { Routes } from '@angular/router';
import { ImageUploaderComponent } from './shared/component/image-uploader/image-uploader.component';
import { AccessDeniedComponent } from './shared/component/access-denied/access-denied.component';
import { NotFoundComponent } from './shared/component/not-found/not-found.component';
import { Roles } from './shared/enum/roles';
import { authGuard } from './shared/guards/auth.guard';
import { StirpeConnectComponent } from './shared/component/stirpe-connect/stirpe-connect.component';

export const routes: Routes = [
  {
    path: 'shared',
    loadChildren: () =>
      import('./shared/shared-routing.module').then(
        (m) => m.SharedRoutingModule
      ),
  },
  {
    path: '',
    loadChildren: () =>
      import('./landing-page/landing-page-routing.module').then(
        (m) => m.LandingPageRoutingModule
      ),
  },
  {
    path: 'superAdmin',
    canActivate: [authGuard],
    data: {
      roles: [Roles.SUPER_ADMIN],
    },
    loadChildren: () =>
      import('./super-admin/super-admin-routing.module').then(
        (m) => m.SuperAdminRoutingModule
      ),
  },
  {
    path: 'salesRep',
    canActivate: [authGuard],
    data: {
      roles: [Roles.SALES_REP],
    },
    loadChildren: () =>
      import('./sales-rep/sales-rep-routing.module').then(
        (m) => m.SalesRepRoutingModule
      ),
  },
  {
    path: 'clinic',
    canActivate: [authGuard],
    data: {
      roles: [Roles.CLINIC_OWNER, Roles.CLINIC_ADMIN, Roles.CLINIC_ASSOCIATE],
    },
    loadChildren: () =>
      import('./clinic/clinic-routing.module').then(
        (m) => m.ClinicRoutingModule
      ),
  },
  {
    path: 'petOwners',
    canActivate: [authGuard],
    data: {
      roles: [Roles.PET_OWNER],
    },
    loadChildren: () =>
      import('./pet-owner/pet-owner-routing.module').then(
        (m) => m.PetOwnerRoutingModule
      ),
  },
  {
    path: 'image_upload',
    component: ImageUploaderComponent,
  },
  {path:"stripe/refresh/:accountId",
    component:StirpeConnectComponent
  },
  {
    path: 'access-denied',
    component: AccessDeniedComponent,
    data: { title: 'Access Denied' },
  },
  {
    path: '**',
    component: NotFoundComponent,
    data: { title: 'Page Not Found' },
  },
];
