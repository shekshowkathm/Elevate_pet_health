import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { HomeComponent } from "./components/landing page/home/home.component";
import { AboutUsComponent } from "./components/landing page/about-us/about-us.component";
import { FaqComponent } from "./components/landing page/faq/faq.component";
import { WhyWellnessComponent } from "./components/landing page/why-wellness/why-wellness.component";
import { NavbarComponent } from "./components/navbar/navbar/navbar.component";
import { NavbarLayoutComponent } from "./components/navbar/navbar-layout/navbar-layout.component";
import { PetDetailsComponent } from "./components/petOwnerStages/pet-details/pet-details.component";
import { UpdatePasswordComponent } from "./components/petOwnerStages/update-password/update-password.component";
import { AddPetComponent } from "./components/petOwnerStages/add-pet/add-pet.component";
import { UserProfileComponent } from "./components/petOwnerStages/user-profile/user-profile.component";
import { PetProfileComponent } from "./components/petOwnerStages/pet-profile/pet-profile.component";
import { ClinicDetailsPopupComponent } from "./components/petOwnerStages/clinic-details-popup/clinic-details-popup.component";
import { ClinicDetailsComponent } from "./components/petOwnerStages/clinic-details/clinic-details.component";
import { ChooseWellnessPlanComponent } from "./components/petOwnerStages/choose-wellness-plan/choose-wellness-plan.component";
import { TrancationDetailsComponent } from "./components/petOwnerStages/trancation-details/trancation-details.component";
import { CardDetailsComponent } from "./components/petOwnerStages/card-details/card-details.component";
import { SupportPetownerComponent } from "./components/petOwnerStages/support-petowner/support-petowner.component";
import { PlanDetailsComponent } from "./components/petOwnerStages/plan-details/plan-details.component";
import { AppointmentComponent } from "./components/petOwnerStages/appointment/appointment.component";
import { UpdatePlansComponent } from "./components/petOwnerStages/update-plans/update-plans.component";
import { AddNewSetPlansComponent } from "./components/petOwnerStages/add-new-set-plans/add-new-set-plans.component";
import { NotificationsComponent } from "./components/petOwnerStages/notifications/notifications.component";
import { InvoiceComponent } from "./components/petOwnerStages/invoice/invoice.component";

const routes: Routes = [
  {
    path: "pet-owner-home",
    component: HomeComponent
  },
  {
    path: "aboutUs",
    component: AboutUsComponent
  },
  {
    path: "faq",
    component: FaqComponent
  },
  {
    path: "why-wellness",
    component: WhyWellnessComponent
  },
  {
    path: "pet-owher-navhar-layout",
    component: NavbarLayoutComponent,
    children: [
      { path: "", redirectTo: "user-profile", pathMatch: "full" },
      {
        path: "user-profile",
        component: UserProfileComponent
      },
      {
        path: "pet-details",
        component: PetDetailsComponent
      },
      {
        path: "update-password",
        component: UpdatePasswordComponent
      },
      {
        path: "pet-profile",
        component: PetProfileComponent
      },
      {
        path: "add-pet",
        component: AddPetComponent
      },
      {
        path: "notifications",
        component: NotificationsComponent
      },
      {
        path: "invoice",
        component: InvoiceComponent
      },
      {
        path: "support",
        component: SupportPetownerComponent
      },
      {
        path: "clinic-details-popup",
        component: ClinicDetailsPopupComponent
      },
      {
        path: "clinic-details",
        component: ClinicDetailsComponent
      },
      {
        path: "choose-plans/:petId",
        component: ChooseWellnessPlanComponent
      },
      {
        path: "update-plans/:petId",
        component: UpdatePlansComponent
      },
      {
        path: "add-new-set-plans/:petId",
        component: AddNewSetPlansComponent
      },
      {
        path:"plan-details",
        component:PlanDetailsComponent
      },
      { path: "cardDetails", component: CardDetailsComponent },
      { path: "trancation", component: TrancationDetailsComponent },
      {path:'appointment', component: AppointmentComponent}
    ]
  },
  { path: "", redirectTo: "/pet-owher-navhar-layout", pathMatch: "full" },
  { path: "**", redirectTo: "/pet-owher-navhar-layout" },
  {
    path: "pet-owher-navbar",
    component: NavbarComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PetOwnerRoutingModule {}
