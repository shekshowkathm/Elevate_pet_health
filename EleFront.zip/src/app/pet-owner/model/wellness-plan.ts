export class WellnessPlan {

}

export interface WellnessUpdate {
  wellnessUpdateId: number;
  updateRecommendation: string | null;
  clinicPrice: string | null;
  discountPercentage: string | null;
  discountPrice: string | null;
  doctorPercentage: string | null;
  status: boolean;
}

export interface ClinicDropDown {
  dropdown: string;
  priceBased: string;
  industryStandardPrice: string;
  recommendation: string;
  wellnessUpdate: WellnessUpdate;
}

export interface ClinicWellnessPlan {
  clinicWellnessPlanId?: number;
  petType: string;
  ageGroup: string;
  wellnessPlanName: string;
  serviceName: string;
  clinicDropDowns: ClinicDropDown[];
}

export class ChoosePlans {
  choosePlanId!: number;
  petId!: number;
  petName!: string;
  petImage!: string;
  petOwnerId!: number;
  petOwnerFirstName!: string;
  petOwnerLastName!: string;
  clinicWellnessPlan!: ClinicWellnessPlan;
  wellnessPlanUpdate!: WellnessUpdate;
  status!: string;
  pending!: boolean;

  isStatusActive?: boolean;
  managePetWellnessPlanId!: number;
  totalAmount: any;
  promotions!: any[]
  planAccpetance?: boolean;
}
