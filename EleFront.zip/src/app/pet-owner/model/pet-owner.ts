export class PetOwner { }

export interface UserProfile {
  clinicId: number;
  contact: number;
  email: string;
  id?: number;
  firstName: string;
  lastName: string;
  profile?: string;
  role?: string;
  address?: string;
  city?: string;
  state?: string;
  zipcode?: string;
}

export interface Clinic {
  clinicId: number;
  clinicName: string;
  address: string;
  zipCode: string;
  city: string;
  state: string | null;
  contactNumber: string;
  email: string;
  qrCode: string | null;
  clinicImage: string | null;
  socialLinkFour: string | null;
  socialLinkThree: string | null;
  socialLinkOne: string | null;
  socialLinkTwo: string | null;
}

export interface PetDetails {

  id: number;
  petName: string | null;
  petType: string | null;
  gender: string | null;
  petBreed: string | null;
  petAge: number | null;
  weight: number | null;
  status: boolean;
  image: string | null;
  dob: Date | null;
  startDate: Date | null;
  clinicName: string;
  ageGroup: string;
  clinic: Clinic;
  paymentStatus: string | undefined;
  stripeSubscriptionId: string | undefined;
  wellnessPlans: WellnessPlan[];
  activePromotions: any[];
  ongoingPlans?: Record<string, WellnessPlan[]>;
  futurePlans?: Record<string, WellnessPlan[]>;
}

export interface WellnessPlan {
  stripePriceIdSmall: boolean;
  priceBased: string;
  managepetWellnessPlanId: number;
  petWellnessPlanId: number;
  startDate: Date | null;
  scheduledDate: Date | null;
  clinicWellnessPlan: ClinicWellnessPlan;
  wellnessPlanUpdate: WellnessPlanUpdate;
  confirmed: boolean;
  endDate: Date | null;
  planStatus: string | null;
  paymentStatus: string | null
  stripeSubscriptionId: string | null;
  // UI calculation purpose only for display
  subtotal: number;
  next_payment_attempt: number;
  period_start: number;
  period_end: number;
  totalAmount: number
  customerPaidDate: number
  promotions:string[]
}

export interface ClinicWellnessPlan {
  clinicWellnessPlanId: number;
  petType: string;
  ageGroup: string;
  wellnessPlanName: string;
  serviceName: string;
  clinicDropDowns: any | null;
}

export interface WellnessPlanUpdate {
  stipeAccountId?: string;
  priceId: number;
  stripePriceId?: string;
  priceBased?: string;
  wellnessUpdateId: number;
  updateRecommendation: string;
  // clinicPrice: string;
  discountPercentage: string;
  // discountPrice: string;
  discountPriceForQuantity: string | null;
  discountPriceForSmall: string | null;
  discountPriceForMedium: string | null;
  discountPriceForLarge: string | null;
  discountPriceForXLarge: string | null;
  updatedPriceForQuantity: string | null;
  updatedPriceForSmall: string | null;
  updatedPriceForMedium: string | null;
  updatedPriceForLarge: string | null;
  updatedPriceForXLarge: string | null;
  doctorPercentage: string | null;
  stripePriceIdSmall: string | null;
  stripePriceIdMedium: string | null;
  stripePriceIdLarge: string | null;
  stripePriceIdXLarge: string | null;
  status: boolean;
}
