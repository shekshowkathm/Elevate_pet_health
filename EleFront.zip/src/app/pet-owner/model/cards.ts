export class Cards {
  brand?: string;
  last4?: string;
  expMonth?: string;
  expYear?: string;
  id?: string;
  isDefault?: string;
}
