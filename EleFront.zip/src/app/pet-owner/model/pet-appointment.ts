export interface PetAppointment {
  petName: string;
  serviceName: string;
  dropDown: string;
  clinicName: string;
  doctorName?: string;
  scheduledDateAndTime: string;
}
