import { HttpClient, HttpHeaders } from "@angular/common/http";
import { EventEmitter, Injectable } from "@angular/core";
import { BehaviorSubject, catchError, map, Observable, Subject } from "rxjs";
import { environment } from "../../../environments/environment.development";
import { PetDetails, UserProfile } from "../model/pet-owner";
import { SharedService } from "../../shared/service/shared.service";
import { text } from "stream/consumers";

@Injectable({
  providedIn: "root"
})
export class PetOwnerService {
  public updatePasswordApi = environment.apiUrl + "/register/updatePassword";
  public updateUserProfileApi = environment.apiUrl + "/register/update-profile";
  public getUserDataApi = environment.apiUrl + "/register/get-profile";
  public postAddPetApi = environment.apiUrl + "/pet-detials/add-pet";
  public getUserProfileAPI = environment.apiUrl + "/pet-detials/get-profile";
  public getApprovedClinicAPI = environment.apiUrl + "/pet-detials/get-clinics";
  public postClinicPetownerAPI = environment.apiUrl + "/pet-detials/add-pet";
  public clinicAdditionAPI = environment.apiUrl +
    "/pet-detials/add-new-clinic/";
  public getPetDetailsAPI = environment.apiUrl + "/pet-detials/get-my-pet";
  public petImagePetIdAPI = environment.apiUrl + "/pet-detials/get-pet-image";
  public petUpdationAPI = environment.apiUrl + "/pet-detials/update-pet/";
  public breedDataByPetAPI = environment.apiUrl + "/breed/getBreedName/";
  public getPetDetailsIdAPI = environment.apiUrl + "/pet-detials/getPetDetails";
  public getClinicMailAPI = environment.apiUrl + "/support/get-Clinic/";
  public postPetOwnerSupportAPI = environment.apiUrl + "/support/add";
  public getPetPlansAPI = environment.apiUrl + '/pet-detials/get-Pet-Plans';
  public getDocumentsAPIForPetOwners = environment.apiUrl + '/api/documents/clinic/';
  public getNotificationsAPI = environment.apiUrl + '/alert/notificationsCount/';
  public getInitialPlanAlertsAPI = environment.apiUrl + '/alert/pet-plans-choosen'
  public getExpiryAlertAPI = environment.apiUrl + '/alert/expiry-plans-for-pets'
  public getAppointmentsAlertAPI = environment.apiUrl + '/alert/pets-appointments'
  private openDialogSubject = new Subject<void>();
  private dialogClosedSubject = new Subject<boolean>();
  private openDialogClinicDetails = new Subject<void>();
  private dialogClosedClinicDetails = new Subject<boolean>();

  private hasAcceptedTerms = false;

  // Notification refresh things

  private refreshSubject = new Subject<void>();

  // Observable for other components to subscribe to
  refresh$ = this.refreshSubject.asObservable();

  constructor(private http: HttpClient, private sharedservice: SharedService) { }

  openDialog$ = this.openDialogSubject.asObservable();
  dialogClosed$ = this.dialogClosedSubject.asObservable();
  openDialogClinic$ = this.openDialogClinicDetails.asObservable();


  // Notification refresh method
  // Method to trigger the refresh event
  triggerRefresh() {
    this.refreshSubject.next();
  }

  // Variable for Profile update

  profileUpdated = new EventEmitter<void>();

  /**
   * @returns headers
   */
  // private getRequestOptions(): { headers: HttpHeaders } {
  //   const token = localStorage.getItem('token');
  //   const headers = new HttpHeaders({
  //     'Content-Type': 'application/json',
  //     Authorization: token ? 'Bearer ' + token : '',
  //   });
  //   return { headers };
  // }
  private getRequestOptions(): { headers: HttpHeaders } {
    let token = "";
    if (typeof window !== "undefined" && localStorage) {
      token = localStorage.getItem("token") || "";
    }
    const headers = new HttpHeaders({
      "Content-Type": "application/json",
      Authorization: token ? "Bearer " + token : ""
    });
    return { headers };
  }
  /**
   * P-dialog for update password
   */
  pDialogOpenUpdatePassword() {
    this.openDialogSubject.next();
  }
  pDialogCloseUpdatePassword(isCanceled: boolean) {
    this.dialogClosedSubject.next(isCanceled);
  }
  pDialogOpenClinicDetails() {
    this.openDialogClinicDetails.next();
  }
  /**
   * @param regid 
   * @param confirmPassword 
   * @returns 
   */
  updatePassword(
    regid: string | null,
    confirmPassword: string
  ): Observable<any> {
    const requestOptions = {
      ...this.getRequestOptions(),
      responseType: "text" as "json"
    };
    const passwordData = {
      regId: regid,
      password: confirmPassword
    };
    const requestBody = JSON.stringify(passwordData);
    return this.http
      .put(this.updatePasswordApi, requestBody, requestOptions)
      .pipe(map(response => response), catchError(this.handleError));
  }

  setAcceptedTerms(status: boolean): void {
    this.hasAcceptedTerms = status;
  }
  getAcceptedTerms(): boolean {
    return this.hasAcceptedTerms;
  }
  updateUserProfile(userDetails: any): Observable<any> {
    const requestOptions = {
      ...this.getRequestOptions(),
      responseType: "text" as "text"
    };
    const requestBody = JSON.stringify(userDetails);
    return this.http
      .put(this.updateUserProfileApi, requestBody, requestOptions)
      .pipe(map(response => response), catchError(this.handleError));
  }

  getUserFromProfile(registerId: any): Observable<UserProfile> {
    const requestOptions = {
      ...this.getRequestOptions(),
      responseType: "json" as "json"
    };
    const apiUrlWithId = `${this.getUserProfileAPI}/${registerId}`;
    return this.http.get<UserProfile>(apiUrlWithId, requestOptions);
  }
  getBreedNyPetType(petType: string): Observable<any> {
    const requestOptions = {
      ...this.getRequestOptions()
    };
    const apiUrlWithId = `${this.breedDataByPetAPI}${petType}`;
    return this.http.get<UserProfile>(apiUrlWithId, requestOptions);
  }

  postAddPet(passwordData: any): Observable<any> {
    const requestOptions = {
      ...this.getRequestOptions(),
      responseType: "text" as "json"
    };
    const requestBody = JSON.stringify(passwordData);
    return this.http.post(this.postAddPetApi, requestBody, requestOptions);
  }

  getApprovedClinic(regId: any): Observable<any> {
    const requestOptions = {
      ...this.getRequestOptions(),
      responseType: "json" as "json"
    };
    const apiUrlWithId = `${this.getApprovedClinicAPI}/${regId}`;
    return this.http.get<any>(apiUrlWithId, requestOptions);
  }

  ClinicAndPetOwner(clinicAndPetOwner: any): Observable<any> {
    const requestOptions = {
      ...this.getRequestOptions(),
      responseType: "text" as "json"
    };
    const requestBody = JSON.stringify(clinicAndPetOwner);
    return this.http.post(
      this.postClinicPetownerAPI,
      requestBody,
      requestOptions
    );
  }

  ClinicAndPetOwnerNewMethod(
    petOwnerID: any,
    clinicID: number
  ): Observable<any> {
    const requestOptions = {
      ...this.getRequestOptions(),
      responseType: "text" as "json"
    };
    // const requestBody = JSON.stringify(clinicAndPetOwner);
    return this.http.post(
      this.clinicAdditionAPI + petOwnerID + "/" + clinicID,
      "",
      requestOptions
    );
  }
  petDetailsGet(petId: number): Observable<PetDetails> {
    const requestOptions = {
      ...this.getRequestOptions(),
      responseType: "json" as "json"
    };
    const apiUrlWithId = `${this.getPetDetailsAPI}/${petId}`;
    return this.http.get<PetDetails>(apiUrlWithId, requestOptions);
  }
  petImagePetId(regId: any): Observable<any> {
    const requestOptions = {
      ...this.getRequestOptions(),
      responseType: "json" as "json"
    };
    const apiUrlWithId = `${this.petImagePetIdAPI}/${regId}`;
    return this.http.get<any>(apiUrlWithId, requestOptions);
  }
  getPetDetailsId(petDetailsId: number) {
    const requestOptions = {
      ...this.getRequestOptions(),
      responseType: "json" as "json"
    };
    const apiUrlWithId = `${this.getPetDetailsIdAPI}/${petDetailsId}`;
    return this.http.get<any>(apiUrlWithId, requestOptions);
  }
  getNotificationForPetOwners(petDetailsId: any) {
    const requestOptions = {
      ...this.getRequestOptions(),
    };
    return this.http.get<any>(this.getNotificationsAPI + petDetailsId, requestOptions);
  }

  petUpdate(id: number, petObject: any): Observable<any> {
    const requestOptions = {
      ...this.getRequestOptions(),
      responseType: "text" as "json"
    };

    return this.http.put(this.petUpdationAPI + id, petObject, requestOptions);
  }

  getClinicEmail(petOwnerID: string): Observable<any> {
    const requestOptions = {
      ...this.getRequestOptions()
    };
    const apiUrlWithId = `${this.getClinicMailAPI}${petOwnerID}`;
    return this.http.get(apiUrlWithId, requestOptions);
  }

  postPetOwnerSupport(supportObject: any) {
    const requestOptions = {
      ...this.getRequestOptions(),
      responseType: "text" as "json"
    };
    return this.http.post(this.postPetOwnerSupportAPI, supportObject, requestOptions);

  }

  /**
   * @param error
   */
  private handleError(error: any): Observable<never> {
    console.error("An error occurred:", error);
    throw error;
  }

  getPetPlans(petId: number): Observable<any> {
    const requestOptions = {
      ...this.getRequestOptions(),
    };
    const newPetPlanAPI = `${this.getPetPlansAPI}/${petId}`
    return this.http.get<any>(newPetPlanAPI, requestOptions)
  }
  getPetDocuments(clinicID: number, petId: string): Observable<any> {
    const requestOptions = {
      ...this.getRequestOptions(),
    };

    return this.http.get<any>(this.getDocumentsAPIForPetOwners + clinicID + '/to-petowner/' + petId, requestOptions)
  }

  getExpiryPlanNotifications(petOwnerId: number):  Observable<any>  {
    const requestOptions = {
      ...this.getRequestOptions(),
    };
    const finalUrl = `${this.getExpiryAlertAPI}/${petOwnerId}`;
    return this.http.get<any>(finalUrl, requestOptions)
  }

  getInitialPlanAlerts(petOwnerId: number):Observable<any>{
    const requestOptions = {
      ...this.getRequestOptions(),
    };
    const finalUrl = `${this.getInitialPlanAlertsAPI}/${petOwnerId}`;
    return this.http.get<any>(finalUrl , requestOptions)
  }

  getAppointmentsAlert(petOwnerId: number):  Observable<any>  {
    const requestOptions = {
      ...this.getRequestOptions(),
    };
    const appointmentsUrl = `${this.getAppointmentsAlertAPI}/${petOwnerId}`;
    return this.http.get<any>(appointmentsUrl, requestOptions)
  }
}
