import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { SharedService } from '../../shared/service/shared.service';
import { environment } from '../../../environments/environment.development';
import { Observable, of } from 'rxjs';
import { ChoosePlans } from '../model/wellness-plan';
import { ClinicAuthService } from '../../clinic/services/clinic-auth.service';
import { PetAppointment } from '../model/pet-appointment';

@Injectable({
  providedIn: 'root',
})
export class WellnessPlanService {
  private getPlansToChooseUrl =
    environment.apiUrl + '/petWellnessPlan/getPlanToChoose';
  private getUpdatedPlansUrl = environment.apiUrl + '/petWellnessPlan/getUpdatedPlans';
  private getNewSetUrl = environment.apiUrl + '/petWellnessPlan/getNewSetPlans'
  private updatePlanStatusUrl = environment.apiUrl + '/petWellnessPlan/updateStatus';
  private acceptPlanUrl = environment.apiUrl + '/petWellnessPlan/acceptPlan'
  private acceptTermsURL = environment.apiUrl + '/petWellnessPlan/acceptPlanTermsAndConditions/'

  private readonly API_END_POINT = environment.apiUrl;
  private clinicAuthService = inject(ClinicAuthService);

  constructor(private http: HttpClient) { }

  private getRequestOptions(): { headers: HttpHeaders } {
    let token = '';
    let role = '';
    if (typeof window !== 'undefined' && localStorage) {
      token = localStorage.getItem('token') || '';
    }
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: token ? 'Bearer ' + token : '',
    });
    return { headers };
  }

  getPlansToChoose(petId: number): Observable<ChoosePlans[]> {
    const requestOptions = this.getRequestOptions();
    const role = localStorage.getItem('role') || '';
    const url = `${this.getPlansToChooseUrl}/${petId}/${role}`;
    return this.http.get<ChoosePlans[]>(url, requestOptions);
  }

  getUpdatedPlans(petId: number): Observable<ChoosePlans[]> {
    const requestOptions = this.getRequestOptions();
    const role = localStorage.getItem('role') || '';
    const url = `${this.getUpdatedPlansUrl}/${petId}/${role}`;
    return this.http.get<ChoosePlans[]>(url, requestOptions);
  }

  getAddNewSetPlans(petId: number): Observable<ChoosePlans[]> {
    const requestOptions = this.getRequestOptions();
    const role = localStorage.getItem('role') || '';
    const url = `${this.getNewSetUrl}/${petId}/${role}`;
    return this.http.get<ChoosePlans[]>(url, requestOptions);
  }

  updatePetPlanStatus(
    petWellnessPlanId: number,
    status: string,
  ): Observable<string> {
    const requestOptions = this.getRequestOptions();
    const url = `${this.updatePlanStatusUrl}/${petWellnessPlanId}/${status}`;
    return this.http.put<string>(url, null, requestOptions);
  }

  acceptAllPlanStatus(petWellnessPlanIds: number[], status: string): Observable<string> {
    const requestOptions = {
      ...this.getRequestOptions(),
      responseType: "text" as "json",
    };
    const url = `${this.acceptPlanUrl}/${status}`;
    return this.http.put<string>(url, petWellnessPlanIds, requestOptions);
  }
  acceptTermsService(ManagePetWellnessPlanId: any): Observable<string> {
    const requestOptions = {
      headers: this.getRequestOptions().headers, // Ensure headers are passed
      responseType: 'text' as 'json', // Correct way to receive a text response
    };

    return this.http.put<string>(this.acceptTermsURL + ManagePetWellnessPlanId, {}, requestOptions);
  }



  fetchSheduledAppointments(): Observable<PetAppointment[]> {
    const userId: number = this.clinicAuthService.getUserId() as number;
    const url = `${this.API_END_POINT}/petWellnessPlan/pet-Owner_calender/${userId}`;
    return this.http.get<PetAppointment[]>(url, this.getRequestOptions());
  }
}
