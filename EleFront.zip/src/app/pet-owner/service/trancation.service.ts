import { HttpClient, HttpHeaders } from "@angular/common/http";
import { inject, Injectable } from "@angular/core";
import { environment } from "../../../environments/environment.development";
import { ClinicAuthService } from "../../clinic/services/clinic-auth.service";

@Injectable({
  providedIn: "root"
})
export class TrancationService {
  public baseURL = environment.apiUrl + "/transaction";
  public invoiceAPI = environment.apiUrl + "/api/documents/invoices/";
  constructor(private http: HttpClient) { }
  private clinicAuthService = inject(ClinicAuthService);
  headers = new HttpHeaders({
    "Content-Type": "application/json",
    Authorization: "Bearer " + this.clinicAuthService.getToken()
  });

  getTransactionDetails(data: any) {
    return this.http.get(`${this.baseURL}/getTransaction/${data}`, {
      headers: this.headers
    });
  }
  getInvoiceSDetails(petOwnerID: any) {
    return this.http.get(`${this.invoiceAPI}${petOwnerID}`, {
      headers: this.headers
    });
  }
  getAllTransactionDetails() {
    return this.http.get(this.baseURL + "/getByStatus", {
      headers: this.headers, responseType: "text"
    });
  }
  gettodayEaringByclinic(stripeId: string) {
    return this.http.get(`${this.baseURL}/todayEarningByClinic/${stripeId}`, {
      headers: this.headers, responseType: "text"
    });
  }
  gettodayEarningByAdmin() {
    return this.http.get(this.baseURL + '/todayEarningByAdmin', {
      headers: this.headers, responseType: "text" as 'json'
    });
  }
  getByAccountId(data: any) {
    return this.http.put(`${this.baseURL}/getByAccountId/${data.stripeAccountId}`, { paymentStatus: data.paymentStatus }, {
      headers: this.headers, responseType: "text" as "json"
    })
  }
  getAllTransactionHistoryDetails() {
    return this.http.get(this.baseURL + "/getAll", {
      headers: this.headers, responseType: "text"
    });
  }

  getcutomerTranscationDetails(cusomerId: string) {
    return this.http.get(`${this.baseURL}/getcutomerDetails/${cusomerId}`, { headers: this.headers })
  }
  getTransactionDetailsBasedOnSaleRep(salesRepId:string){
    return this.http.get(`${this.baseURL}/getclinicPaymentsDetails/${salesRepId}`,{headers:this.headers})
  }

  getPaymentStatus(id:string){
    return this.http.get(`${this.baseURL}/getPaymentStatus/${id}`)
  }
}
