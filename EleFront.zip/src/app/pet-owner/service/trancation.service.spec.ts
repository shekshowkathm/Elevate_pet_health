import { TestBed } from '@angular/core/testing';

import { TrancationService } from './trancation.service';

describe('TrancationService', () => {
  let service: TrancationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TrancationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
