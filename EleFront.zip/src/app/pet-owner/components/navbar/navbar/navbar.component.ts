import { NgClass, NgFor, NgIf } from "@angular/common";
import { Component, EventEmitter, Input, Output } from "@angular/core";
import { Router, RouterModule } from "@angular/router";
import { HeaderComponent } from "../../../../shared/component/header/header.component";
import { PetOwnerService } from "../../../../pet-owner/service/pet-owner.service";

interface NavItem {
  label: string;
  icon?: string;
  iconUrl?: string;
  route?: string;
  color?: string;
  children?: NavItem[];
  isOpen?: boolean;
  action?: () => void;
  isActive?: boolean;
}

@Component({
  selector: "app-navbar",
  standalone: true,
  imports: [NgClass, NgFor, NgIf, RouterModule],
  templateUrl: "./navbar.component.html",
  styleUrl: "./navbar.component.scss"
})
export class NavbarComponent {
  @Input() isSidebarCollapsed: boolean = false;
  @Output() changeIsSidebarCollapsed = new EventEmitter<boolean>();
  navItems: NavItem[] = [
    {
      label: "My Profile",
      icon: "pi pi-user",
      route: "/petOwners/pet-owher-navhar-layout/user-profile"
    },
    {
      label: "Update Password",
      icon: "pi pi-user-edit",
      action: () => this.openUpdatePassword()
    },
    {
      label: "Pet Profile",
      iconUrl: "../../../../assets/PerOwner/Adult.png",
      route: "/petOwners/pet-owher-navhar-layout/pet-profile"
    },
    {
      label: "Pet Plans",
      iconUrl: "../../../../assets/PerOwner/Plans Icon.png",
      route: "/petOwners/pet-owher-navhar-layout/plan-details"
    },
    {
      label: "Add Pet",
      icon: "pi pi-plus-circle ",
      action: () => this.openClinicAddPet()
    },
    // {
    //   label: "Clinic Details",
    //   icon: "pi  pi-envelope",
    //   route: "/petOwners/pet-owher-navhar-layout/clinic-details"
    // },
    {
      label: "Appointment",
      icon: "pi pi-calendar",
      route: "/petOwners/pet-owher-navhar-layout/appointment"
    },
    {
      label: "Payments",
      icon: "pi pi-cog",
      route: "/petOwners/pet-owher-navhar-layout/trancation"
    },
    {
      label: "Card Details",
      icon: "pi-credit-card",
      route: "/petOwners/pet-owher-navhar-layout/cardDetails"
    },
    {
      label: "Notifications",
      icon: "pi-bell",
      route: "/petOwners/pet-owher-navhar-layout/notifications"
    },
    {
      label: "Invoice",
      icon: "pi-file",
      route: "/petOwners/pet-owher-navhar-layout/invoice"
    },
    {
      label: "Support",
      icon: "pi pi-info-circle",
      route: "/petOwners/pet-owher-navhar-layout/support",
      // children: [
      //   {
      //     label: "Pet Clinic Owners",
      //     route: "/clinic-owners",
      //     color: "#2e68d4"
      //   },
      //   { label: "Pet Clinic Admin", route: "/clinic-admin", color: "#ffb946" }
      // ],
      // isOpen: false
    }
  ];

  constructor(
    private router: Router,
    private PetOwnerService: PetOwnerService
  ) {}

  openUpdatePassword() {
    console.log("Update Password function triggered");
    this.PetOwnerService.pDialogOpenUpdatePassword();
    this.PetOwnerService.dialogClosed$.subscribe({
      next: isCanceled => {
        if (isCanceled) {
          this.navItems.forEach(item => {
            if (item.label === "Update Password") {
              item.isActive = false;
            }
          });
        }
      }
    });
  }

  openClinicAddPet() {
    setTimeout(() => {
      this.PetOwnerService.pDialogOpenClinicDetails();
    }, 300);
    this.router.navigate([
      "/petOwners/pet-owher-navhar-layout/clinic-details-popup"
    ]);
  }

  toggleCollapse(): void {
    this.isSidebarCollapsed = !this.isSidebarCollapsed;
    this.changeIsSidebarCollapsed.emit(this.isSidebarCollapsed);
  }

  toggleDropdown(navItem: NavItem): void {
    this.navItems.forEach(item => (item.isActive = false));
    if (navItem.action) {
      navItem.action();
      navItem.isActive = true;
    } else if (navItem.children) {
      navItem.isOpen = !navItem.isOpen;
    } else if (navItem.route) {
      this.router.navigate([navItem.route]);
    }
  }

  navigateToRoute(route: any): void {
    this.router.navigate([route]);
  }

  toggleSidebar(): void {
    this.changeIsSidebarCollapsed.emit(!this.isSidebarCollapsed);
  }
}
