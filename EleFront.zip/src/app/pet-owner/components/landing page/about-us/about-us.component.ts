import { Component } from '@angular/core';
import { HeaderComponent } from '../../../../shared/component/header/header.component';
import { FooterComponent } from '../../../../shared/component/footer/footer.component';

@Component({
  selector: 'app-about-us',
  standalone: true,
  imports: [HeaderComponent,FooterComponent],
  templateUrl: './about-us.component.html',
  styleUrl: './about-us.component.scss'
})
export class AboutUsComponent {

}
