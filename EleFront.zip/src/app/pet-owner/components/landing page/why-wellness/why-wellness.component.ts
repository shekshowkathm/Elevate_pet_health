import { Component } from '@angular/core';
import { HeaderComponent } from '../../../../shared/component/header/header.component';
import { FooterComponent } from '../../../../shared/component/footer/footer.component';

@Component({
  selector: 'app-why-wellness',
  standalone: true,
  imports: [HeaderComponent,FooterComponent],
  templateUrl: './why-wellness.component.html',
  styleUrl: './why-wellness.component.scss'
})
export class WhyWellnessComponent {

}
