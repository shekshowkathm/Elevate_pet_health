import { Component } from '@angular/core';
import { HeaderComponent } from '../../../../shared/component/header/header.component';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { FooterComponent } from '../../../../shared/component/footer/footer.component';

@Component({
  selector: 'app-faq',
  standalone: true,
  imports: [HeaderComponent,NgClass,NgIf,NgFor,FooterComponent],
  templateUrl: './faq.component.html',
  styleUrl: './faq.component.scss',
  animations: [
    trigger('expandCollapse', [
      state('collapsed', style({
        height: '0',
        opacity: 0,
        overflow: 'hidden'
      })),
      state('expanded', style({
        height: '*',
        opacity: 1,
        overflow: 'hidden'
      })),
      transition('collapsed <=> expanded', [
        animate('300ms ease-out')
      ])
    ])
  ]
})
export class FaqComponent {
  email: string = 'Info@elevatepethealth.com';
  openIndex: number | null = null;

   faqs = [
    { 
      question: 'What is Elevate Pet Health?', 
      answer: `Elevate Pet Health is a pet wellness plan tailored to your individual pet's needs. Your doctor and technician will use your pet's history and current health to build a plan designed to keep your pet happy and healthy for as long as possible.` 
    },
    { 
      question: 'How is Elevate different from pet insurance?', 
      answer: `Elevate is nothing like pet insurance. The plan costs and savings will be laid out for you to see before committing to anything.<br><br>
      1. Elevate Wellness is meant to keep your pet healthy year-round, where insurance is typically beneficial during bigger issues like emergency surgery.<br><br>
      2. Wellness versus Insurance - If insurance is not needed, you don't receive anything for the money you have spent. On a wellness plan, you are reminded and encouraged to use every service you're paying for.<br><br>
      3. With Elevate, you know what to expect. We aren't insurance, so there are no claims to file and no hidden fees.<br><br>
      4. We know that not all pets are suitable for wellness plans, which is why we let your doctor or technician create the plan for you.<br><br>
      5. Once the plan is built, even if prices of vaccines, tests, or procedures go up, you'll never see an increase in cost above what you agreed to at the beginning of your plan.` 
    },
    { 
      question: 'What does an Elevate Wellness plan look like?', 
      answer: `Each plan is built uniquely for every pet that walks through the door. Some plans may include dentals, spay or neuters, or just vaccines. It's all dependent on what your pet needs and what you want.` 
    },
    { 
      question: 'Is Elevate available for all of my pets?', 
      answer: `Elevate Pet Wellness plans are available for your dog or cat on an individual basis.` 
    },
    { 
      question: 'What happens with my Elevate plan if I move away and can\'t go to the same clinic anymore?', 
      answer: `If you have to move and need to cancel your plan, it will be up to you and the practice to come to an agreement on paying back any discounted rates, etc., from the date of cancellation. One of the benefits of being on an Elevate Wellness plan is that you receive discounts on all procedures and inventory. If you need to cancel mid-plan, the clinic will look at the services you have used and the amount you have been charged to determine whether money will be owed to you or the clinic. Please note that the Elevate fees you have paid up to the point of cancellation are not refundable.` 
    },
    { 
      question: 'What happens if my pet passes away during the year?', 
      answer: `If your pet passes away, the clinic will review how much you've paid through the wellness plan and what procedures have been done. The clinic will calculate how much is owed back to you or how much you owe the clinic. It will depend on a few factors, but we believe every clinic will do what is best for you in the end.` 
    },
    { 
      question: 'Can I transfer my wellness plan from one clinic to another also offering Elevate?', 
      answer: `No. Elevate is designed differently for privately owned clinics based on many factors. Some clinics may offer different tests or surgeries and even have different prices. We want every small business to have the option to offer wellness, whether it's a small hospital in rural Pennsylvania or a large practice in California.` 
    },
    { 
      question: 'How much does Elevate cost?', 
      answer: `The great thing about Elevate is that every plan is built to your pet's needs. 
  
      Some pets may just need annual vaccines and fecal tests, while others may need a dental and x-rays. The bill is divided over 12 months, and anything not included in your wellness plan will be discounted. This way, you always know you're paying for the absolute best wellness program to keep your pet happy and healthy for as long as possible while also being able to plan for your payments each month. In summary, since every plan is unique to each pet, the cost will vary. Ask your clinic to create a sample plan for you to review with no obligation.` 
    },
    { 
      question: 'How do I pay for my pet\'s wellness plan?', 
      answer: `All plans are structured on an annual basis for automatic debit with monthly payments. Upon enrollment, you are assessed a one-time setup fee along with your first monthly payment, followed by monthly payments until the end of your wellness plan year. All major credit cards are accepted.` 
    }
  ];
  
  toggleAnswer(index: number) {
    this.openIndex = this.openIndex === index ? null : index;
  }
  copyEmail() {
    navigator.clipboard.writeText(this.email).catch(err => {
      console.error('Could not copy email address: ', err);
    });
  }
}
