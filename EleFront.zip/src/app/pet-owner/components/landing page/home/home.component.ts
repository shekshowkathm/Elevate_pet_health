import { AfterViewInit, Component, ElementRef, inject, Inject, PLATFORM_ID, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { HeaderComponent } from '../../../../shared/component/header/header.component';
import { isPlatformBrowser, NgClass, NgIf } from '@angular/common';
import { FooterComponent } from '../../../../shared/component/footer/footer.component';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { MessageService } from 'primeng/api';
import { TermsAndConditionsComponent } from '../../../../shared/component/terms-and-conditions/terms-and-conditions.component';
import { HttpErrorResponse } from '@angular/common/http';
import { ClinicService } from '../../../../clinic/services/clinic.service';
import { ClinicAuthService } from '../../../../clinic/services/clinic-auth.service';
import { Router } from '@angular/router';
import { PetOwnerService } from '../../../../pet-owner/service/pet-owner.service'


@Component({
  selector: 'app-home',
  standalone: true,
  imports: [HeaderComponent,NgClass,NgIf,FooterComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
  providers: [DialogService, MessageService],
})
export class HomeComponent implements AfterViewInit {
  showDivs: boolean[] = [false, false, false];
  @ViewChild('firstText') firstText!: ElementRef;
  @ViewChild('secondText') secondText!: ElementRef;
  @ViewChild('div1') div1!: ElementRef;
  @ViewChild('div2') div2!: ElementRef;
  @ViewChild('div3') div3!: ElementRef;
  @ViewChild('imgDiv') imgDiv!: ElementRef;
  @ViewChild('subDiv1') subDiv1!: ElementRef;
  @ViewChild('subDiv2') subDiv2!: ElementRef;
  @ViewChild('imageDiv') imageDiv!: ElementRef;
  @ViewChildren('card') cards!: QueryList<ElementRef>;
  @ViewChild('imageContainer') imageContainer!: ElementRef;
  @ViewChild('heroImage') heroImage!: ElementRef;
  @ViewChild('headlineText') headlineText!: ElementRef;
  @ViewChild('subscriptionForm') subscriptionForm!: ElementRef;
  @ViewChild('textSection') textSection!: ElementRef;
  @ViewChild('imageSection') imageSection!: ElementRef;
  ref: DynamicDialogRef | undefined;
  private clinicService = inject(ClinicService);

  constructor(@Inject(PLATFORM_ID) private platformId: Object ,  public dialogService: DialogService, private clinicAuthService : ClinicAuthService ,
  public messageService: MessageService , private router : Router, private PetOwnerService : PetOwnerService) {}

  ngAfterViewInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.initObservers();
    }
    const terms = JSON.parse(localStorage.getItem('terms') as string);
    if (!terms) {
      this.show();
    }
  }

  private initObservers() {
    const elements = {
      text: [this.firstText.nativeElement, this.secondText.nativeElement],
      divs: [this.div1.nativeElement, this.div2.nativeElement, this.div3.nativeElement],
      imgDiv: this.imgDiv.nativeElement
    };
    const options = { threshold: 0.1 };
    this.createObserver(elements.text, 'text', options);
    this.createObserver(elements.divs, 'divs', options);
    this.createObserver([elements.imgDiv], 'imageDiv', options);
    const imageDivElement = this.imageDiv.nativeElement;
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          this.triggerAnimation();
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });
    if (imageDivElement) {
      observer.observe(imageDivElement);
    }
    const options1 = { threshold: 0.1 };
    const heroImageElement = this.heroImage.nativeElement;
    const headlineTextElement = this.headlineText.nativeElement;
    const subscriptionFormElement = this.subscriptionForm.nativeElement;
    const observer1 = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {         
          heroImageElement.classList.add('image-animation');
          setTimeout(() => {
            headlineTextElement.classList.add('text-animation');
          }, 500); 
          setTimeout(() => {
            subscriptionFormElement.classList.add('input-button-animation');
          }, 1000); 
          observer1.unobserve(entry.target); 
        }
      });
    }, options1);
    if (heroImageElement) {
      observer1.observe(heroImageElement);
    }
    const options2 = { threshold: 0.1 };
    const textElement = this.textSection.nativeElement;
    const imageElement = this.imageSection.nativeElement;
    const observer2 = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          textElement.classList.add('text-animation');
          setTimeout(() => {
            imageElement.classList.add('image-animation');
          }, 500); 
          observer2.unobserve(entry.target); 
        }
      });
    }, options2);
    if (textElement) {
      observer2.observe(textElement);
    }
    if (imageElement) {
      observer2.observe(imageElement);
    }
  }
  private createObserver(elements: Element[], type: string, options: IntersectionObserverInit) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          this.handleAnimation(entry, type);
          observer.unobserve(entry.target);
        }
      });
    }, options);
    elements.forEach(el => observer.observe(el));
  }
  private handleAnimation(entry: IntersectionObserverEntry, type: string) {
    switch (type) {
      case 'text':
        this.animateText();
        break;
      case 'divs':
        this.animateDivs();
        break;
      case 'imageDiv':
        this.animateImageDiv();
        break;
    }
  }
  private animateText() {
    const firstText = this.firstText.nativeElement;
    const secondText = this.secondText.nativeElement;
    firstText.classList.add('opacity-0');
    secondText.classList.remove('opacity-0');
    secondText.classList.add('animate-slide-down');
    setTimeout(() => {
      secondText.classList.add('animate-zoom');
      firstText.classList.remove('opacity-0');
      firstText.classList.add('animate-slide-down');
    }, 1000);
  }
  private animateDivs() {
    this.showDivs = [true, false, false];
    setTimeout(() => this.showDivs = [true, true, false], 1000);
    setTimeout(() => this.showDivs = [true, true, true], 2000);
  }
  private animateImageDiv() {
    const imgDiv = this.imgDiv.nativeElement;
    const subDiv1 = this.subDiv1.nativeElement;
    const subDiv2 = this.subDiv2.nativeElement;
    imgDiv.classList.add('animate-zoom-in');
    setTimeout(() => {
      subDiv1.classList.remove('hidden');
      subDiv1.classList.add('show');
      setTimeout(() => {
        subDiv2.classList.remove('hidden');
        subDiv2.classList.add('show');
      }, 700); 
    }, 700); 
  }
  private triggerAnimation() {
    this.cards.forEach((card, index) => {
      const delay = `${0.5 * index + 0.5}s`;
      setTimeout(() => {
        card.nativeElement.classList.add('animate');
      }, 900 * index); 
    });
  }

  show() {
    this.ref = this.dialogService.open(TermsAndConditionsComponent, {
      header: 'Welcome to Your Work Place !',
      width: '70%',
      breakpoints: {
        '960px': '75vw',
        '640px': '90vw',
      },
      style: {
        'box-shadow': '#007cda 0px 0px 10px 3px',
      },
      duplicate: false,
    });
    this.ref.onClose.subscribe((res: boolean) => {
      if (res) {
        console.log('first', res);
        this.clinicService.updateTermsAndConditions().subscribe({
          next: (res: any) => {
            console.log(res);
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Terms and Conditions updated',
            });
            this.clinicAuthService.setTermsAndConditions(true);
            this.PetOwnerService.setAcceptedTerms(true);
            const isFirstTimeFlow = this.PetOwnerService.getAcceptedTerms(); 
            console.log(isFirstTimeFlow,"kkkkkkkkkk");
             
            if(res && isFirstTimeFlow){
              this.PetOwnerService.pDialogOpenUpdatePassword();
            }
          },
          error: (err: HttpErrorResponse) => {
            console.log(err);
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'somthing wrong',
            });
          },
        });
      } else {
        console.log('second', res);
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'somithing wrong',
        });
        this.router.navigateByUrl('');
        this.clinicAuthService.logout();
      }
    });
  }
}
