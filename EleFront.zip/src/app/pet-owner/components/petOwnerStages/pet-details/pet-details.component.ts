import { AfterViewInit, Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { loadStripe, Stripe, StripeCardElement } from '@stripe/stripe-js';
import { StripeService } from '../../../../clinic/services/stripe.service';
import { environment } from '../../../../../environments/environment.development';
import {MatCheckboxModule} from '@angular/material/checkbox'
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-pet-details',
  standalone: true,
  imports:[MatCheckboxModule,CommonModule,FormsModule ],
  templateUrl: './pet-details.component.html',
  styleUrls: ['./pet-details.component.scss'],
})
export class PetDetailsComponent implements AfterViewInit {
  stripe: Stripe | null = null;
  cardElement: StripeCardElement | null = null;
  isDefaultPayment: boolean = false;
  elements: any;
  customerId: string = '';

  constructor(
    public dialogRef: MatDialogRef<PetDetailsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private stripeService: StripeService
  ) {
    // dialogRef.disableClose = true;
  }

  ngOnInit(): void {
    this.customerId = sessionStorage.getItem('stripeCustomerId') || '';
  }

  ngAfterViewInit(): void {
    this.initializeStripe();
  }

  async initializeStripe() {
    try {
      this.stripe = await loadStripe(environment.key);
      if (!this.stripe) {
        console.error('Stripe.js failed to load');
        return;
      }
      this.elements = this.stripe.elements();
      this.initializeCardElement();
    } catch (error) {
      console.error('Error initializing Stripe:', error);
    }
  }

  initializeCardElement(): void {
    if (this.elements) {
      this.cardElement = this.elements.create('card', {
        style: {
          base: {
            color: '#2c3e50', 
            fontFamily: '"Poppins", "Helvetica Neue", Helvetica, sans-serif', 
            fontSize: '18px', 
            fontWeight: '400', 
            backgroundColor: '#f9f9f9', 
            padding: '10px 12px', 
            border: '1px solid #ced4da', 
            borderRadius: '6px', 
            '::placeholder': {
              color: '#adb5bd', 
              fontStyle: 'italic', 
            },
          },
          invalid: {
            color: '#e63946', 
            iconColor: '#e63946',
            border: '1px solid #e63946', 
          },
          complete: {
            color: '#2ecc71', 
            iconColor: '#2ecc71', 
          },
        },
      });
      const cardElementContainer = document.getElementById('card-element');
      if (cardElementContainer) {
        this.cardElement?.mount('#card-element');
      } else {
        console.error('Card element container not found');
      }
    } else {
      console.error('Stripe Elements not initialized');
    }
  }
  
  onSubmit() {
    if (!this.stripe || !this.cardElement) {
      console.error('Stripe or CardElement not initialized');
      return;
    }
    this.stripe
      .createPaymentMethod({
        type: 'card',
        card: this.cardElement,
      })
      .then(({ paymentMethod, error }) => {
        if (error) {
          console.error('Error creating payment method:', error);
          return;
        }
  
        if (paymentMethod) {
          this.stripeService
            .attachCardDetails(this.customerId, paymentMethod.id,this.isDefaultPayment)
            .subscribe({
              next: (response) => {
                console.log('Card saved successfully:', response);
                alert('Card saved successfully');
                this.dialogRef.close(1);
              },
              error: (err) => {
                console.error('Error attaching card:', err);
                alert('Error attaching card');
              },
            });
        }
      })
      .catch((err) => {
        console.error('Error processing payment:', err);
      });
  }
  
  closeCardPopup(): void {
    this.dialogRef.close(2);
  }
}
