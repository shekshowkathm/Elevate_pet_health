import { Component } from '@angular/core';
import { ChoosePlans } from '../../../model/wellness-plan';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { WellnessPlanService } from '../../../service/wellness-plan.service';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ToastModule } from 'primeng/toast';
import { PetOwnerService } from '../../../service/pet-owner.service';

@Component({
  selector: 'app-update-plans',
  standalone: true,
  imports: [InputSwitchModule, FormsModule, NgFor, ToastModule, NgIf],
  templateUrl: './update-plans.component.html',
  styleUrl: './update-plans.component.scss',
  providers: [MessageService]
})
export class UpdatePlansComponent {
  choosePlans: ChoosePlans[] = [];
  petId!: number
  setKeyToBind!: number
  petName: any = ''
  checked: boolean = false;
  managePetWellnessPlanId!: number
  chossedPlansForManipulations: any[] = []
  realPrice: number = 0;
  totalDiscountedPrice: number = 0;
  firstMonthPayment: number = 0;

  constructor(private route: ActivatedRoute, private wellnessPlanSrvice: WellnessPlanService, private messageService: MessageService, private router: Router, private petOwnerSerive: PetOwnerService
  ) { }

  ngOnInit() {
    this.route.queryParamMap.subscribe(params => {
      this.managePetWellnessPlanId = +params.get('managePetWellnessPlanId')!;
      this.setKeyToBind = +params.get('setKey')!;
      this.route.paramMap.subscribe(param => {
        this.petId = +param.get('petId')!;
        this.getPlansToUpdate();
      });
    });
  }

  getPlansToUpdate() {
    const reqManagePetWellnessPlanId = this.managePetWellnessPlanId;
    this.wellnessPlanSrvice.getUpdatedPlans(this.petId).subscribe(
      response => {
        console.log("Size is : ", response.length);
        this.choosePlans = response
          .filter(plan => plan.managePetWellnessPlanId === reqManagePetWellnessPlanId) // Filter by managePetWellnessPlanId
          .map(plan => {
            plan.isStatusActive = plan.status === 'ACTIVE'; // Set isStatusActive based on the status
            return plan;
          });

        // Log the filtered and mapped plans
        console.log("Filtered and mapped plans: ", this.choosePlans);
        this.chossedPlansForManipulations = this.choosePlans
        this.petName = this.chossedPlansForManipulations[0]?.petName || null;


        if (this.chossedPlansForManipulations) {
          this.calculatePriceDetails()
        }
      }
    )
  }
  getPlansToUpdateForAccept() {
    this.wellnessPlanSrvice.getUpdatedPlans(this.petId).subscribe(
      response => {
        console.log("Size is : ", response.length);
        this.choosePlans = response.map(plan => {
          plan.isStatusActive = plan.status === 'ACTIVE';
          return plan;
        });
        console.log(this.choosePlans);

        this.chossedPlansForManipulations = this.choosePlans
        console.log(this.choosePlans);
      }
    )
  }

  calculatePriceDetails() {
    this.totalDiscountedPrice = this.chossedPlansForManipulations.reduce((sum, plan) => {
      const discountKeys = Object.keys(plan.wellnessPlanUpdate).filter(key =>
        key.startsWith('discountPriceFor') && !isNaN(parseFloat(plan.wellnessPlanUpdate[key]))
      );

      const totalPlanDiscount = discountKeys.reduce((acc, key) => {
        return acc + parseFloat(plan.wellnessPlanUpdate[key]);
      }, 0);

      return sum + totalPlanDiscount;
    }, 0);

    const totalPriceOfSet1 = parseFloat(this.choosePlans[0]?.totalAmount || 0);
    this.realPrice = totalPriceOfSet1 + this.totalDiscountedPrice;

    this.firstMonthPayment = this.realPrice / 12;
    this.firstMonthPayment = this.firstMonthPayment + 49 + 7;
  }

  rejectPlan(petWellnessPlanId: number): void {
    this.wellnessPlanSrvice.updatePetPlanStatus(petWellnessPlanId, 'PET_OWNER_REJECTED').subscribe({
      next: (response) => {
        console.log('Plan rejected successfully:', response);
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Plan rejected successfully!',
        });

        this.getPlansToUpdate();
      },
      error: (err) => {
        console.error('Error rejecting plan:', err);
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to reject the plan. Please try again.',
        });
      },
    });
  }

  acceptAllPlans() {
    const ids = this.choosePlans.map((plan) => plan.choosePlanId);

    this.wellnessPlanSrvice.acceptAllPlanStatus(ids, 'UPDATED_PLANS_TO_CLINIC').subscribe({
      next: (response) => {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'All eligible plans accepted successfully!',
        });
        this.refresh();
        this.getPlansToUpdate();
        this.router.navigate([
          '/petOwners/pet-owher-navhar-layout/pet-profile',
        ]);
      },
    });
  }

  getDynamicPrice(plan: any, type: 'discountPrice' | 'updatedPrice'): string {
    const priceBased = plan.wellnessPlanUpdate?.priceBased?.toUpperCase();

    if (priceBased === 'QTY') {
      return plan.wellnessPlanUpdate[`${type}ForQuantity`] || 'N/A';
    } else if (priceBased === 'WGT') {
      const size = plan.petSize
        ?.toLowerCase()
        ?.split('-')
        .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1))
        .join('');
      const priceField = `${type}For${size}`;
      return plan.wellnessPlanUpdate[priceField] || 'N/A';
    }
    return 'N/A';
  }

  refresh() {
    // console.log('is it refreshed ??');
    this.petOwnerSerive.triggerRefresh();
  }

}
