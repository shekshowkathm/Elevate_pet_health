import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatePlansComponent } from './update-plans.component';

describe('UpdatePlansComponent', () => {
  let component: UpdatePlansComponent;
  let fixture: ComponentFixture<UpdatePlansComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpdatePlansComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdatePlansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
