import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { isPlatformBrowser, NgClass, NgFor, NgIf } from '@angular/common';
import { PetOwnerService } from '../../../../pet-owner/service/pet-owner.service'
import { SharedService } from '../../../../shared/service/shared.service';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { UserProfile } from '../../../model/pet-owner';
import { Router } from '@angular/router';
import { S3Client, PutObjectCommand, ObjectCannedACL } from '@aws-sdk/client-s3';
import { environment } from '../../../../../environments/environment.development';
import { US_STATES } from '../../../../shared/constants/usa-states';
import { ImageResizeService } from '../../../../shared/service/image-resize.service';
import { ImageUploadService } from '../../../../shared/service/image-upload.service';




@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [ReactiveFormsModule, NgIf, NgClass, ToastModule, NgFor],
  providers: [MessageService],
  templateUrl: './user-profile.component.html',
  styleUrl: './user-profile.component.scss'
})
export class UserProfileComponent {
  myForm: FormGroup;
  selectedImage: string | ArrayBuffer | null = null;
  regId: string | null = null;
  userProfile!: UserProfile;
  profilePicture: string | null = null;

  US_STATES = US_STATES;
  selectedFileName: string = '';
  selectedFileUrl: string | ArrayBuffer | null = '';

  s3Client = new S3Client({
    region: environment.AWS_REGION,
    credentials: {
      accessKeyId: environment.AWS_ACCESS_KEY,
      secretAccessKey: environment.AWS_SECRET_KEY
    }
  });

  constructor(private PetOwnerService: PetOwnerService, private sharedservice: SharedService, private messageService: MessageService, private router: Router, @Inject(PLATFORM_ID) private platformId: Object, private imageResizeService: ImageResizeService, private imageUploadService: ImageUploadService) {
    this.myForm = new FormGroup({
      firstName: new FormControl('', [Validators.required, Validators.minLength(3)]),
      lastName: new FormControl('', [Validators.required, Validators.minLength(1)]),
      emailAddress: new FormControl('', [Validators.email, Validators.required]),
      contactNumber: new FormControl('', [
        Validators.required,
        Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/)
      ]),
      address: new FormControl('', [Validators.required]),
      city: new FormControl('', [Validators.required]),
      state: new FormControl('', [Validators.required]),
      zipcode: new FormControl('', [
        Validators.required,
        Validators.pattern(/^\d{5}$/),
      ]),
      profile: new FormControl('')
    });
  }

  ngOnInit(): void {

    this.getUserProfile();
  }

  getUserProfile() {

    if (isPlatformBrowser(this.platformId)) {
      const registerId = this.sharedservice.getId('id');
      this.regId = registerId ? registerId.trim() : null;

      if (this.regId) {
        this.PetOwnerService.getUserFromProfile(this.regId).subscribe({
          next: (response: UserProfile) => {
            this.userProfile = response;

            this.myForm.patchValue({
              firstName: this.userProfile.firstName,
              lastName: this.userProfile.lastName,
              emailAddress: this.userProfile.email,
              contactNumber: this.userProfile.contact,
              profile: this.userProfile.profile,
              address: this.userProfile.address,
              city: this.userProfile.city,
              state: this.userProfile.state,
              zipcode: this.userProfile.zipcode,
            });
            this.profilePicture = this.userProfile?.profile || null;

          },
          error: (error) => {
            console.error('Error fetching user profile:', error);
          }
        });
      }
    }
  }

  async onImageSelected(event: Event) {

    this.profilePicture = ''
    // const input = event.target as HTMLInputElement;
    // const file = input.files?.[0];
    // if (file) {
    //   this.selectedFileName = file.name;
    //   if (input.files && input.files[0]) {
    //     const file = input.files[0];
    //     const reader = new FileReader();
    //     reader.onload = () => {
    //       this.selectedImage = reader.result;
    //     };
    //     reader.readAsDataURL(file);
    //     this.myForm.patchValue({ profile: file });


    //     try {
    //       const resized400x400 = await this.imageResizeService.resizeImage(
    //         file,
    //         400,
    //         400
    //       ); // Blob --> size , type
    //       // const fileName400x400 = `${originalFileName}-${timestamp}.jpg`;
    //       const url = await this.imageUploadService.uploadFile(
    //         resized400x400,
    //         this.selectedFileName
    //       );
    //       this.myForm.patchValue({ profile: url });
    //       this.profilePicture = url;


    //     } catch (error) {
    //       // this.loader = false;
    //       console.error('Error resizing image:', error);
    //     }

    //     // this.uploadFiles(file);
    //   }
    // }


    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];

    if (file) {
      this.selectedFileName = file.name;

      const reader = new FileReader();
      reader.onload = () => this.selectedFileUrl = reader.result;
      reader.readAsDataURL(file);

      

      try {
        const resized400x400 = await this.imageResizeService.resizeImage(
          file,
          400,
          400
        ); // Blob --> size , type
        // const fileName400x400 = `${originalFileName}-${timestamp}.jpg`;
        const url = await this.imageUploadService.uploadFile(
          resized400x400,
          this.selectedFileName
        );
        this.myForm.patchValue({ profile: url });
        this.profilePicture = url;


      } catch (error) {
        // this.loader = false;
        console.error('Error resizing image:', error);
      }
      // this.uploadFiles(file);
    } else {
      this.selectedFileName = '';
      // this.selectedFileUrl = '';
      this.myForm.patchValue({ profile: '' });

    }



  }

  onSubmit() {
    this.myForm.markAllAsTouched();
    if (this.myForm.valid) {
      const userDetails = {
        ...this.myForm.value,
        id: this.regId
      };
      this.PetOwnerService.updateUserProfile(userDetails).subscribe({
        next: (response) => {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: "Updated",
          });
          // this.myForm.reset();
          this.PetOwnerService.profileUpdated.emit();
        },
      });
      const isFirstTimeFlow = this.PetOwnerService.getAcceptedTerms();
      if (this.myForm.valid && isFirstTimeFlow) {
        setTimeout(() => {
          window.location.reload();
        }, 2000);
        setTimeout(() => {
          this.router.navigate(['/petOwners/add-pet']);
        }, 2000);
      }

    } else {
      console.log('Form is invalid');
    }
  }


  onCancel() {
    this.myForm.reset();
  }

  async uploadFiles(files: File) {
    if (files) {
      const contentType = files.type; // Get the file's content type
      const mediaFolder = 'media/'; // Replace with your desired folder name
      const params = {
        Bucket: 'elevatepethealth-imagestorage', // Replace with your bucket name
        Key: `${mediaFolder}${files.name}`, // Include folder path in the Key
        Body: files,
        ContentType: contentType,
        ContentDisposition: "inline",
        ACL: 'public-read' as ObjectCannedACL // Set public access for the uploaded file
      };

      try {
        const command = new PutObjectCommand(params);
        const data = await this.s3Client.send(command);
        const uploadUrl = `https://${params.Bucket}.s3.${environment.AWS_REGION}.amazonaws.com/${params.Key}`;
        this.profilePicture = uploadUrl || null;

        this.myForm.patchValue({ profile: uploadUrl });
      } catch (err) {
        console.error('Upload error:', err);
      }
    }
  }




  formatPhoneNumber(): void {
    const inputControl = this.myForm.get('contactNumber');
    if (!inputControl) return;

    // Get the raw input and remove non-numeric characters
    const input = inputControl.value?.replace(/\D/g, '') || '';
    let formattedInput = '';

    // Format the phone number based on the length of the input
    if (input.length > 0) {
      formattedInput = `(${input.substring(0, 3)}`;
    }
    if (input.length > 3) {
      formattedInput += `) ${input.substring(3, 6)}`;
    }
    if (input.length > 6) {
      formattedInput += `-${input.substring(6, 10)}`;
    }

    // Set the formatted value back to the form control
    inputControl.setValue(formattedInput, { emitEvent: false });

    // Dynamically set validators
    inputControl.setValidators([
      Validators.required,
      Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/), // Ensure formatted pattern
      Validators.minLength(14), // Ensure the length matches the formatted input
    ]);

    // Update the form control's validation state
    inputControl.updateValueAndValidity({ emitEvent: false });
  }



}
