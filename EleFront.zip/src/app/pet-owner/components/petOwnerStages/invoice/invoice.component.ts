import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { SharedService } from '../../../../shared/service/shared.service';
import { isPlatformBrowser, NgFor, NgIf } from '@angular/common';
import { TrancationService } from '../../../service/trancation.service';
import {MatTooltipModule} from '@angular/material/tooltip';

@Component({
  selector: 'app-invoice',
  standalone: true,
  imports: [NgIf, NgFor,MatTooltipModule],
  templateUrl: './invoice.component.html',
  styleUrl: './invoice.component.scss'
})
export class InvoiceComponent {

  invoiceResponse: any[] = []
  regId!: number | null;

  groupedInvoices: any[] = [];

  constructor(@Inject(PLATFORM_ID) private platformId: Object, private sharedservice: SharedService, private transactionService: TrancationService) {

  }

  ngOnInit() {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      const registerId = this.sharedservice.getId('id');
      this.regId = registerId ? Number(registerId) : null;
      this.getInvoices();
    }
  }


  openPdfInNewTab(url: string): void {
    if (url) {
      window.open(url, '_blank');
    } else {
      console.error('PDF URL is not available.');
    }
  }

  getInvoices() {
    if (this.regId) {
      this.transactionService.getInvoiceSDetails(this.regId).subscribe({
        next: (response: any) => {
          console.log(response);
          this.invoiceResponse = response
          this.groupInvoicesById();

        }, error: (err) => {
          console.log(err);

        }
      })
    }
  }

  groupInvoicesById() {
    const grouped = this.invoiceResponse.reduce((acc, curr) => {
      if (!acc[curr.managePlanId]) {
        acc[curr.managePlanId] = { id: curr.managePlanId, items: [] };
      }
      acc[curr.managePlanId].items.push(curr);
      return acc;
    }, {});
    this.groupedInvoices = Object.values(grouped);
  }

  getFileName(url: string): string {
    if (!url) return 'Unknown File';
    return url.substring(url.lastIndexOf('/') + 1); // Extracts the file name after the last '/'
  }


}
