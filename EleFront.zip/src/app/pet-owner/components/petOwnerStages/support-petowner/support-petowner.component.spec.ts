import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupportPetownerComponent } from './support-petowner.component';

describe('SupportPetownerComponent', () => {
  let component: SupportPetownerComponent;
  let fixture: ComponentFixture<SupportPetownerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SupportPetownerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SupportPetownerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
