import { isPlatformBrowser, NgFor, NgIf } from '@angular/common';
import { ChangeDetectorRef, Component, Inject, PLATFORM_ID } from '@angular/core';
import { FormsModule, NgForm, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { PetOwnerService } from '../../../service/pet-owner.service';
import { SharedService } from '../../../../shared/service/shared.service';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';

@Component({
  selector: 'app-support-petowner',
  standalone: true,
  imports: [MatButtonModule, MatIconModule, NgIf, NgFor, FormsModule, ToastModule, ReactiveFormsModule],
  templateUrl: './support-petowner.component.html',
  styleUrl: './support-petowner.component.scss',
  providers: [MessageService],
})
export class SupportPetownerComponent {
  formData = {
    fromEmail: '',
    toEmail: '',
    message: '',
    issue: ''
  };
  fromEmail: string = '';
  toEmails: any[] = []
  selectedReceiver: string = '';

  constructor(private petOwnerService: PetOwnerService, private messageService: MessageService, @Inject(PLATFORM_ID) private platformId: Object, private sharedservice: SharedService, private cdr: ChangeDetectorRef) {

  }

  ngOnInit(): void {
    this.getClinicEmails();
  }


  onReceiverChange(e: any) {
    console.log(e.target.value);
    this.selectedReceiver = e.target.value

  }

  openEmail() {
    if (!this.selectedReceiver) {
      // Show an alert if no receiver is selected
      this.messageService.add({
        severity: 'error', // Use 'error' for danger indications
        summary: 'No Recipient Selected',
        detail: 'Please select a recipient email before proceeding.',
      });
      return;
    }

    // If a receiver is selected, proceed to open email
    const recipient = this.selectedReceiver; // Use the selected receiver
    const subject = 'Subject here'; // Replace with the email subject
    const body = 'Body content here'; // Replace with the email body
    const mailtoLink = `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

    window.location.href = mailtoLink;
  }


  getClinicEmails() {
    if (isPlatformBrowser(this.platformId)) {
      const registerId = this.sharedservice.getId('id');
      console.log(registerId);
      const storedEmail = localStorage.getItem('email');
      if (storedEmail) {
        this.fromEmail = storedEmail; // Assign to the input model
      }
      if (registerId) {
        this.petOwnerService.getClinicEmail(registerId).subscribe({
          next: (response: any) => {
            if (response && Array.isArray(response)) {
              this.toEmails = response; // Ensure response is an array
              this.cdr.detectChanges();
            } else {
              console.error('Unexpected response format:', response);
            }
            console.log(this.toEmails);

          }, error: (err) => {
            console.log(err);

          }
        })
      }
    }

  }
  onSubmit(form: NgForm) {
    if (form.valid) {
      console.log('Form Submitted!', form.value);
      this.petOwnerService.postPetOwnerSupport(form.value).subscribe({
        next: (response) => {
          console.log(response);
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Feedback sent to clinic',
          });

          // Reset the form
          form.reset();

        },
        error: (err) => {
          console.log(err);

        }
      })
    }
  }
}
