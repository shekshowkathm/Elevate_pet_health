import {
  Component,
  ElementRef,
  Inject,
  PLATFORM_ID,
  signal,
  ViewChild,
} from '@angular/core';
import { Router } from '@angular/router';
import {
  CommonModule,
  isPlatformBrowser,
  NgClass,
  NgFor,
  NgIf,
} from '@angular/common';
import { PetOwnerService } from '../../../../pet-owner/service/pet-owner.service';
import { SharedService } from '../../../../shared/service/shared.service';
import { PetDetails, WellnessPlanUpdate } from '../../../model/pet-owner';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { MatButtonModule } from '@angular/material/button';
import {
  ObjectCannedACL,
  PutObjectCommand,
  S3Client,
} from '@aws-sdk/client-s3';
import { environment } from '../../../../../environments/environment.development';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { MatIconModule } from '@angular/material/icon';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
import html2canvas from 'html2canvas';
import { CurrencyPipe } from '@angular/common';
import { StripeService } from '../../../../clinic/services/stripe.service';
import { loadStripe, Stripe } from '@stripe/stripe-js';
import { AfterViewInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PetDetailsComponent } from '../pet-details/pet-details.component';
import { StatusToggleComponent } from '../../../../shared/component/status-toggle/status-toggle.component';
import { WellnessPlanService } from '../../../service/wellness-plan.service';
import { response } from 'express';
import { ChoosePlans } from '../../../model/wellness-plan';
// Set the VFS using the imported pdfFonts
(pdfMake as any).vfs = pdfFonts.pdfMake.vfs;
import { MatTooltipModule } from '@angular/material/tooltip';
import { log } from 'node:console';
import { DialogModule } from 'primeng/dialog';
import { TooltipModule } from 'primeng/tooltip';
import { ReActivePlamComponent } from '../re-active-plam/re-active-plam.component';
import { ImageResizeService } from '../../../../shared/service/image-resize.service';
import { ImageUploadService } from '../../../../shared/service/image-upload.service';

interface DynamicImage {
  clinicName: string;
  petName: string;
  petBreed: string;
  dob: string;
  petAge: string;
  weight: string;
  gender: string;
}
interface PetProfileImage {
  petImage: string;
  petId?: number;
  navigateTo?: string;
}

interface StaticImage {
  src: string;
  navigateTo: string;
}

interface Clinic {
  clinicId: number;
  clinicName: string;
  address: string;
  zipCode: string;
  city: string;
  state: string | null;
  contactNumber: string;
  email: string;
  qrCode: string | null;
  clinicImage: string | null;

  socialLinkFour: string | null;
  socialLinkThree: string | null;
  socialLinkOne: string | null;
  socialLinkTwo: string | null;
}

@Component({
  selector: 'app-pet-profile',
  standalone: true,
  imports: [
    NgFor,
    NgIf,
    FormsModule,
    CommonModule,
    ReactiveFormsModule,
    NgFor,
    MatButtonModule,
    ToastModule,
    MatButtonModule,
    MatIconModule,
    CurrencyPipe,
    MatTooltipModule,
    DialogModule,
    TooltipModule,
  ],
  templateUrl: './pet-profile.component.html',
  styleUrl: './pet-profile.component.scss',
  providers: [MessageService],
})
export class PetProfileComponent {
  [x: string]: any;
  isMoving: boolean = false;
  selectedImage: number = 1;
  selectedPet: DynamicImage | null = null;
  regId: string | null = null;
  petProfileDetails?: PetDetails;

  documentsResponse: any[] = [];
  specificPetOwnerDocs: any[] = [];
  allPetOwnerDocs: any[] = [];
  private hasRun: boolean = false;

  stripeSubscription?: any = {};
  stripeschedSubscription?: any = {};
  subscriptionSubtotal: number | undefined;
  isSubscriptionResponseLoaded = false;
  isSchedSubscriptionResponseLoaded = false;
  petProfileImage: PetProfileImage[] = [];
  petId: number = 0;
  breedType: string[] = [];
  clinicDetails!: Clinic;
  activePromotions: any[] = [];
  PetDetails = signal<PetDetails[]>([]);
  showInputArea: boolean = true;
  couponCode: string = '';
  discountedTotal: number | null = null;
  public aggregatedData: any[] = [];
  message: string | null = null;
  isSuccess: boolean = false;
  stripeCouponId: string = '';
  // totalDiscountedPrice: number = 100;
  @ViewChild('contentToDownload') htmlContent!: ElementRef;
  s3Client = new S3Client({
    region: environment.AWS_REGION,
    credentials: {
      accessKeyId: environment.AWS_ACCESS_KEY,
      secretAccessKey: environment.AWS_SECRET_KEY,
    },
  });
  totalDiscountedPrice: number = 0;
  monthlyPayment: number = 0;
  firstmonthlyPayment: number = 0;
  public setupFee: string | undefined;
  public oneTimeFee: string | null | undefined;
  stripe: Stripe | null = null;
  cardElement: any;
  elements: any;
  customerId: string = '';
  public data: any;
  public cardExpirationData: any;
  displayCardPopup: boolean = false;
  allConfirmedAndPaid: boolean = false;
  hasPendingPlans: boolean = false;
  public paymentMethods: any;
  updatePlans: ChoosePlans[] = [];
  hasUpdatedPlans: boolean = false;
  hasAddNewSetPlans: boolean = false;
  addNewSetPlans: ChoosePlans[] = [];
  public mappedPlans: any[] = [];
  allPaidStatuses: { group: number; allPaid: boolean }[] = [];
  totalDiscountedPrices: Record<number, number> = {};
  monthlyPayments: Record<any, number> = {};
  firstMonthlyPayments: Record<any, number> = {};
  groupedWellnessPlans: { [key: string]: any[] } = {};

  displaySocialMediaDialog: boolean = false;
  socialLinkOne: any;
  socialLinkTwo: any;
  socialLinkThree: any;
  socialLinkFour: any;

  promotionSentence: any;
  isPromotionActive: boolean = false;
  isAllisPromotionActive: boolean = false;
  hasElevate: boolean = false;
  hasOtherPromotion: boolean = false;
  BillingCycle: Number = 0;
  BillingCycleStartDate: String | null | undefined;

  constructor(
    private router: Router,
    private petOwnerService: PetOwnerService,
    private stripeService: StripeService,
    private sharedservice: SharedService,
    private messageService: MessageService,
    private dialog: MatDialog,
    private wellnessPlanService: WellnessPlanService,
    @Inject(PLATFORM_ID) private platformId: Object,
    private imageResizeService: ImageResizeService,
    private imageUploadService: ImageUploadService,
  ) {}

  ngOnInit() {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      const registerId = this.sharedservice.getId('id');
      this.regId = registerId ? registerId.trim() : null;
      this.cardExpiration();
      this.getPetImagePetId();
      this.getAllStripeProduct();
      this.getCardDetails();
      this.getUpdatedPlans(this.petId);
      this.getNewPlans(this.petId);
    }
  }
  // ngAfterViewInit(): void {
  //   this.initializeStripe();
  // }
  getCardDetails() {
    const value = sessionStorage.getItem('stripeCustomerId');
    this.stripeService.getCardDetails(value).subscribe((data) => {
      this.data = data;
    });
  }
  cardExpiration() {
    const value = sessionStorage.getItem('stripeCustomerId');
    this.stripeService.cardExpiration(value).subscribe((data) => {
      this.cardExpirationData = data;
      console.log(this.cardExpirationData, 'cardExpirationData');
    });
  }

  applyCoupon() {
    if (!this.couponCode.trim()) {
      this.message = 'Please enter a valid coupon code.';
      this.isSuccess = false;
      return;
    }
    let data = {
      clinicId: this.petProfileDetails?.clinic.clinicId,
      promotionType: this.couponCode,
    };
    this.stripeService.validateCoupon(data).subscribe({
      next: (response: any) => {
        if (response) {
          this.message = 'Coupon successfully applied!';
          this.isSuccess = true;
          this.stripeCouponId = response;
        } else {
          this.message = 'Invalid or expired coupon.';
          this.isSuccess = false;
        }
      },
      error: (err: any) => {
        console.error('Error validating coupon:', err);
        this.message = 'Invalid or expired coupon.';
        this.isSuccess = false;
      },
    });
  }
  getAllStripeProduct() {
    // this.stripeService.getAllStripeProduct().subscribe((doc:any)=>{
    //   console.log(doc,"ooooooo  ");
    this.setupFee = 'price_1QSZ9SDb6WVg8hg0SCxPKTWk';
    this.oneTimeFee = 'price_1Q9dePDb6WVg8hg06IcbFJtz';

    // })
  }

  editPetProfile() {
    this.showInputArea = !this.showInputArea;
  }

  showMediaLinks(clinicDetails: any) {
    this.displaySocialMediaDialog = true;
  }

  openLink(url: any) {
    window.open(url, '_blank');
  }

  calculateTotalDiscountedPrice(plans: any[], setKey: number): void {
    if (Array.isArray(plans)) {
      const total = plans.reduce((total, plan) => {
        const update = plan.wellnessPlanUpdate;
        const discountPrice =
          parseFloat(update.discountPriceForQuantity) ||
          parseFloat(update.discountPriceForSmall) ||
          parseFloat(update.discountPriceForMedium) ||
          parseFloat(update.discountPriceForLarge) ||
          parseFloat(update.discountPriceForXLarge) ||
          0;

        return total + (isNaN(discountPrice) ? 0 : discountPrice);
      }, 0);
      console.log(`Total Discounted Price for Set ${setKey}:`, total);
      this.totalDiscountedPrices[setKey] = total;
      this.calculateMonthlyPayment(total, setKey);
    } else {
      console.log(`No plans available for Set ${setKey}`);
    }
  }
  totalDiscountedPriceForSet(setKey: any): number {
    return this.totalDiscountedPrices[setKey] || 0;
  }

  calculateMonthlyPayment(total: number, setKey: number): void {
    const monthlyPayment = total / 12 + 7;
    // if (this.promotionSentence) {
    //   var firstmonthlyPayment = monthlyPayment + 0;
    // } else {
    //   var firstmonthlyPayment = monthlyPayment + 49;
    // }
    if (this.hasOtherPromotion === false) {
      console.log('true');
      var firstmonthlyPayment = monthlyPayment + 49;
    } else {
      console.log('false');
      var firstmonthlyPayment = monthlyPayment + 0;
    }

    this.monthlyPayments[setKey] = monthlyPayment;
    this.firstMonthlyPayments[setKey] = firstmonthlyPayment;

    console.log(`Monthly Payment for Set ${setKey}:`, monthlyPayment);
    console.log(
      `First Monthly Payment for Set ${setKey}:`,
      firstmonthlyPayment,
    );
  }

  downloadPDF() {
    const content = this.htmlContent.nativeElement;
    html2canvas(content)
      .then((canvas) => {
        const imageData = canvas.toDataURL('image/png');

        const documentDefinition = {
          content: [
            {
              image: imageData,
              width: 500, // Adjust the width as needed
            },
          ],
        };

        // Create and download the PDF
        pdfMake.createPdf(documentDefinition).download('Home_Page.pdf');
      })
      .catch((error) => {
        console.error('Error generating PDF: ', error);
      });
  }

  selectImage(index: number) {
    this.selectedImage = index;
    const petId = this.petProfileImage[index]?.petId;
    this.petId = petId !== undefined ? petId : 0;
    this.getPetDetails(petId);
    this.getUpdatedPlans(petId);
    this.getNewPlans(petId);
  }

  getPetImagePetId() {
    if (isPlatformBrowser(this.platformId)) {
      const petownerId = this.regId;
      if (petownerId) {
        this.petOwnerService.petImagePetId(petownerId).subscribe({
          next: (response) => {
            this.petProfileImage = response;
            

            if (this.petProfileImage.length > 0) {
              this.selectImage(0);
            }
          },
        });
      }
    }
  }

  openPdfInNewTab(url: string): void {
    if (url) {
      window.open(url, '_blank');
    } else {
      console.error('PDF URL is not available.');
    }
  }

  getFileName(url: string): string {
    if (!url) return 'Unknown File';
    return url.substring(url.lastIndexOf('/') + 1); // Extracts the file name after the last '/'
  }

  generatePromotionSentence(promotions: any): string {
    if (promotions.length > 0) {
      let sentence = '';
      const promotionsCopy = [...promotions];
      if (promotionsCopy.length === 1) {
        sentence = `The '${promotionsCopy[0]}' promotion has been activated for this plan.`;
      } else if (promotionsCopy.length > 1) {
        const lastPromotion = promotionsCopy.pop();
        const promotionList = promotionsCopy.join("', '");
        sentence = `The '${promotionList}' and '${lastPromotion}' promotions have been activated for this plan.`;
      }
      this.promotionSentence = sentence;
      this.isPromotionActive = true;

      return sentence;
    } else {
      this.promotionSentence = null;
      this.isPromotionActive = false;
      return '';
    }
  }

  getPetDetails(petId: any) {
    if (isPlatformBrowser(this.platformId)) {
      if (petId) {
        this.petOwnerService.petDetailsGet(petId).subscribe({
          next: (response: PetDetails) => {
            this.petProfileDetails = response;
            console.log(this.petProfileDetails, 'petProfileDetails');
            // this.checkPaymentStatus(this.petProfileDetails)
            if (this.petProfileDetails?.ongoingPlans) {
              Object.keys(this.petProfileDetails?.ongoingPlans).forEach(
                (key) => {
                  const setKey = Number(key);
                  if (
                    this.petProfileDetails &&
                    this.petProfileDetails.ongoingPlans
                  ) {
                    let plans;
                    plans = this.petProfileDetails.ongoingPlans[setKey];

                    const arr = plans?.[0]?.promotions;
                    this.hasElevate = arr.some((value) =>
                      value.startsWith('Elevate'),
                    );
                    this.hasOtherPromotion = arr.some(
                      (value) => !value.startsWith('Elevate'),
                    );
                    console.log(this.hasElevate, 'hasElevate');
                    console.log(this.hasOtherPromotion, 'hasOtherPromotion');

                    if (this.hasElevate && this.hasOtherPromotion) {
                      console.log('Both promotions exist');
                    } else if (this.hasElevate) {
                      console.log('Elevate promotion exists');
                    } else if (this.hasOtherPromotion) {
                      console.log('Another kind of promotion exists');
                    } else {
                      console.log('No promotions found');
                    }
                  }
                },
              );
              Object.keys(this.petProfileDetails?.ongoingPlans).forEach(
                (key) => {
                  let setKey = Number(key);
                  this.isPlanStatusDynamic(setKey);
                },
              );
              Object.keys(this.petProfileDetails?.ongoingPlans).forEach(
                (key) => {
                  const setKey = Number(key);
                  if (
                    this.petProfileDetails &&
                    this.petProfileDetails.ongoingPlans
                  ) {
                    let plans;
                    plans = this.petProfileDetails.ongoingPlans[setKey];
                    this.calculateTotalDiscountedPrice(plans, setKey);
                  }
                },
              );
            
            }
            if (this.petProfileDetails?.futurePlans) {
              Object.keys(this.petProfileDetails?.futurePlans).forEach(
                (key) => {
                  let setKey = Number(key);
                  this.isPlanStatusDynamic(setKey);
                },
              );
              Object.keys(this.petProfileDetails?.futurePlans).forEach(
                (key) => {
                  const setKey = Number(key);
                  if (
                    this.petProfileDetails &&
                    this.petProfileDetails?.futurePlans
                  ) {
                    let plans;
                    plans = this.petProfileDetails.futurePlans[setKey];
                    this.calculateTotalDiscountedPrice(plans, setKey);
                  }
                },
              );
            }
            // if (this.petProfileDetails.paymentStatus === 'paid') {
            if (this.petProfileDetails?.ongoingPlans) {
              Object.keys(this.petProfileDetails?.ongoingPlans).forEach(
                (key) => {
                  let setKey = Number(key);
                  // this.ispaymentDynamic(setKey);
                  const isSubscriptionIdAvailable =
                    this.isSubscriptionIdAvailable(setKey);
                  if (isSubscriptionIdAvailable) {
                    if (this.petProfileDetails?.ongoingPlans) {
                      let plan =
                        this.petProfileDetails?.ongoingPlans[setKey][0];
                      let arr: string | null = plan.stripeSubscriptionId;

                      if (arr !== null) {
                        let data1 = this.checkSubscriptionId(arr);
                        console.log(data1, 'data1data1');
                        if (!data1) {
                          try {
                            this.stripeService
                              .stripeSubscriptionId(plan.stripeSubscriptionId)
                              .subscribe({
                                next: (doc: any) => {
                                  plan.period_start = doc.period_start;
                                  plan.subtotal = doc.subtotal;
                                  plan.period_end = doc.period_end;
                                  plan.next_payment_attempt =
                                    doc.next_payment_attempt;
                                },
                                error: (err) => {
                                  console.error(
                                    'Error fetching subscription details:',
                                    err,
                                  );
                                },
                              });
                          } catch (error) {
                            console.error('Unexpected error occurred:', error);
                          }
                        } else {
                          console.log(arr);
                          this.stripeService
                            .stripeSchedSubscriptionId(arr)
                            .subscribe((doc: any) => {
                              plan.subtotal = doc.totalAmount * 100;
                              plan.period_start = doc.customerPaidDate;
                            });
                        }
                      } else {
                        console.warn('stripeSubscriptionId is null');
                      }
                    }
                  } else {
                    console.log('NO sun avilable');
                  }
                },
              );
              // }else{
              //   this.isSubscriptionResponseLoaded = false
              // }
            }
            // if (this.petProfileDetails.paymentStatus === 'pending') {
            if (this.petProfileDetails?.futurePlans) {
              Object.keys(this.petProfileDetails?.futurePlans).forEach(
                (key) => {
                  let setKey = Number(key);
                  // this.ispaymentDynamic(setKey);
                  const isSubscriptionIdFutureAvailable =
                    this.isSubscriptionIdFutureAvailable(setKey);
                  if (isSubscriptionIdFutureAvailable) {
                    if (this.petProfileDetails?.futurePlans) {
                      let plan = this.petProfileDetails?.futurePlans[setKey][0];
                      this.stripeService
                        .stripeSchedSubscriptionId(plan.stripeSubscriptionId)
                        .subscribe((doc: any) => {
                          plan.totalAmount = doc.totalAmount;
                          plan.customerPaidDate = doc.customerPaidDate;
                        });
                    }
                  } else {
                    console.log('NO sun avilable');
                  }
                },
              );
            } else {
              this.isSchedSubscriptionResponseLoaded = false;
            }
            // }

            this.clinicDetails = response.clinic;
            this.socialLinkOne = this.clinicDetails.socialLinkOne;
            this.socialLinkTwo = this.clinicDetails.socialLinkTwo;
            this.socialLinkThree = this.clinicDetails.socialLinkThree;
            this.socialLinkFour = this.clinicDetails.socialLinkFour;
            this.activePromotions = response.activePromotions;
            this.getBreedType(this.petProfileDetails.petType);
            const petOwnerID = localStorage.getItem('id') || '';
            this.getPDFForPetOwners(this.clinicDetails.clinicId, petId);
          },
        });
      }
    }
  }
  getKeys(obj: object | undefined): string[] {
    return obj ? Object.keys(obj) : [];
  }
  isSubscriptionIdFutureAvailable(setKey: any): boolean {
    if (this.petProfileDetails?.futurePlans) {
      const setPlns = this.petProfileDetails!.futurePlans[setKey];
      if (!setPlns) {
        return false;
      }
      const stripeSubscriptionId = setPlns[0].stripeSubscriptionId;
      if (stripeSubscriptionId) {
        return true;
      } else {
        return false;
      }
    }

    return false;
  }
  isSubscriptionIdAvailable(setKey: any): boolean {
    if (this.petProfileDetails?.ongoingPlans) {
      const setPlns = this.petProfileDetails!.ongoingPlans[setKey];
      if (!setPlns) {
        return false;
      }
      const stripeSubscriptionId = setPlns[0].stripeSubscriptionId;
      if (stripeSubscriptionId) {
        return true;
      } else {
        return false;
      }
    }

    return false;
  }

  isPlanStatusDynamic(setKey: any): {
    anyPaid: boolean;
    allPaid: boolean;
    updatePlanDetails: boolean;
    updatePlanDetailsfuturePlans: boolean;
    confirmed: boolean;
    confirmedfuturePlans: boolean;
    anyPaidfuturePlans: boolean;
    cancelled: boolean;
    scheduled: boolean;completed:boolean
  } {
    let anyPaid = false;
    let allPaid = true;
    let updatePlanDetails = false;
    let confirmed = false;
    let confirmedfuturePlans = false;
    let anyPaidfuturePlans = false;
    let cancelled = false;
    let scheduled = false;
    let completed = false
    let updatePlanDetailsfuturePlans = false;
    if (this.petProfileDetails?.ongoingPlans) {
      const plans = this.petProfileDetails?.ongoingPlans[setKey];
      if (plans) {
        for (let plan of plans) {
          if (plan.planStatus === 'paid') {
            anyPaid = true;
          } else if (plan.planStatus === 'updated') {
            updatePlanDetails = true;
          } else if (plan.planStatus === 'confirmed') {
            confirmed = true;
          } else if (plan.planStatus === 'canceled') {
            cancelled = true;
          } else if (plan.planStatus === 'scheduled') {
            scheduled = true;
          }else if(plan.planStatus === "completed"){
            completed = true
          }
        }
        // console.log(anyPaid, allPaid, updatePlanDetails,confirmed,scheduled);
      }
    }
    if (this.petProfileDetails?.futurePlans) {
      const plans = this.petProfileDetails?.futurePlans[setKey];
      // console.log(plans);

      if (plans) {
        for (let plan of plans) {
          if (plan.planStatus === 'paid') {
            anyPaidfuturePlans = true;
          } else if (
            plan.planStatus === 'confirmed' &&
            plan.paymentStatus === 'not_started'
          ) {
            anyPaidfuturePlans = true;
          } else if (plan.planStatus === 'updated') {
            updatePlanDetailsfuturePlans = true;
          } else if (plan.planStatus === 'confirmed') {
            confirmedfuturePlans = true;
          } else if (plan.planStatus === 'scheduled') {
            scheduled = true;
          }
        }
      }
      //  console.log(confirmedfuturePlans,anyPaidfuturePlans,updatePlanDetailsfuturePlans,"futire",completed);
    }

    return {
      anyPaid,
      allPaid,
      updatePlanDetails,
      confirmed,
      confirmedfuturePlans,
      anyPaidfuturePlans,
      updatePlanDetailsfuturePlans,
      cancelled,
      scheduled,completed
    };
  }

  getPDFForPetOwners(clinicID: number, petId: string) {
    this.petOwnerService.getPetDocuments(clinicID, petId).subscribe({
      next: (response: any) => {
        this.documentsResponse = response;

        this.specificPetOwnerDocs = this.documentsResponse.filter((x) => {
          return x.targetType === 'PetOwner';
        });
        this.allPetOwnerDocs = this.documentsResponse.filter((x) => {
          return x.targetType !== 'PetOwner';
        });
      },
      error(err) {
        console.log(err);
      },
    });
  }

  checkSubscriptionId(subscriptionId: string): boolean {
    return subscriptionId.startsWith('sub_sched_');
  }

  scrollLeft(): void {
    const imageArea = document.querySelector('.image-area');
    if (imageArea) {
      imageArea.scrollBy({
        left: -150,
        behavior: 'smooth',
      });
    }
  }

  scrollRight(): void {
    const imageArea = document.querySelector('.image-area');
    if (imageArea) {
      imageArea.scrollBy({
        left: 150,
        behavior: 'smooth',
      });
    }
  }

  petProfileUpdate(form: any) {
    if (form.valid) {
      const petUpdateObject = {
        petType: this.petProfileDetails!.petType,
        petName: this.petProfileDetails!.petName,
        gender: this.petProfileDetails!.gender,
        petBreed: this.petProfileDetails!.petBreed,
        petAge: this.petProfileDetails!.petAge,
        weight: this.petProfileDetails!.weight,
        status: this.petProfileDetails!.status,
        image: this.petProfileDetails!.image,
        dob: this.petProfileDetails!.dob,
        startDate: this.petProfileDetails!.startDate,
      };
      this.petOwnerService
        .petUpdate(this.petProfileDetails!.id, petUpdateObject)
        .subscribe({
          next: (response) => {
            this.showInputArea = !this.showInputArea;
            this.messageService.add({
              severity: 'success',
              summary: response,
              detail: 'Pet Updated Successfully',
            });
            this.getPetDetails(this.petId);
            this.forImageUpdationAfterPetUpdates();
          },
          error: (err) => {
            console.log(err);
          },
        });
    } else {
      console.log('Form is invalid');
    }
  }

  async onImageSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e: any) => {};
      reader.readAsDataURL(file);
      const selectedFileName = file.name;
      try {
        const resized400x400 = await this.imageResizeService.resizeImage(
          file,
          400,
          400,
        ); // Blob --> size , type
        // const fileName400x400 = `${originalFileName}-${timestamp}.jpg`;
        const url = await this.imageUploadService.uploadFile(
          resized400x400,
          selectedFileName,
        );
        this.petProfileDetails!.image = url || null;
        // this.uploadImageError = ''
      } catch (error) {
        // this.loader = false;
        console.error('Error resizing image:', error);
      }
      // this.uploadFiles(file);
    }
  }

  async uploadFiles(files: File) {
    if (files) {
      const contentType = files.type;
      const mediaFolder = 'media/';
      const params = {
        Bucket: 'elevatepethealth-imagestorage',
        Key: `${mediaFolder}${files.name}`,
        Body: files,
        ContentType: contentType,
        ContentDisposition: 'inline',
        ACL: 'public-read' as ObjectCannedACL,
      };

      try {
        const command = new PutObjectCommand(params);
        const data = await this.s3Client.send(command);
        const uploadUrl = `https://${params.Bucket}.s3.${environment.AWS_REGION}.amazonaws.com/${params.Key}`;
        this.petProfileDetails!.image = uploadUrl || null;
      } catch (err) {
        console.error('Upload error:', err);
      }
    }
  }

  forImageUpdationAfterPetUpdates() {
    const petownerId = this.regId;
    this.petOwnerService.petImagePetId(petownerId).subscribe({
      next: (response) => {
        this.petProfileImage = response;
      },
    });
  }
  retryPayment(list: any) {
    const dialogRef = this.dialog.open(ReActivePlamComponent, {
      width: '1400px',
      height: '550px',
      data: list[0].stripeSubscriptionId,
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
      console.log(this.cardExpirationData, 'cardd');
      if (result) {
        this.BillingCycle = result.BillingCycle;
        this.BillingCycleStartDate = result.startDate;

        if (this.petProfileDetails) {
          const value = sessionStorage.getItem('stripeCustomerId');
          const choosenWellnessPlans: WellnessPlanUpdate[] = list.map(
            (item: any) => item.wellnessPlanUpdate,
          );
          const petWellnessPlanIds = list.map(
            (item: any) => item.petWellnessPlanId,
          );
          const stripeAccount = choosenWellnessPlans[0].stipeAccountId;
          const resultArray: any[] = [];
          const wellnessPlanUpdates = list.map(
            (plan: any) => plan.wellnessPlanUpdate,
          );
          wellnessPlanUpdates.forEach((item: any) => {
            if (item.priceBased === 'WGT' && item.stripePriceIdSmall) {
              resultArray.push(item);
            } else if (item.priceBased === 'WGT' && item.stripePriceIdMedium) {
              resultArray.push(item);
            } else if (item.priceBased === 'WGT' && item.stripePriceIdLarge) {
              resultArray.push(item);
            } else if (item.priceBased === 'WGT' && item.stripePriceIdXLarge) {
              resultArray.push(item);
            } else {
              resultArray.push(item);
            }
            const aggregateByStripePriceIdSmall = (
              data: any[],
              setupFee?: string,
            ) => {
              const aggregation = data.reduce((acc, item) => {
                console.log(item);
                if (item.priceBased === 'WGT' && item.stripePriceIdSmall) {
                  const key = item.stripePriceIdSmall;
                  if (!acc[key]) {
                    acc[key] = { priceId: key, quantity: 0 };
                  }
                  acc[key].quantity += 1;
                } else if (
                  item.priceBased === 'WGT' &&
                  item.stripePriceIdMedium
                ) {
                  const key = item.stripePriceIdMedium;
                  if (!acc[key]) {
                    acc[key] = { priceId: key, quantity: 0 };
                  }
                  acc[key].quantity += 1;
                } else if (
                  item.priceBased === 'WGT' &&
                  item.stripePriceIdLarge
                ) {
                  const key = item.stripePriceIdLarge;
                  if (!acc[key]) {
                    acc[key] = { priceId: key, quantity: 0 };
                  }
                  acc[key].quantity += 1;
                } else if (
                  item.priceBased === 'WGT' &&
                  item.stripePriceIdXLarge
                ) {
                  const key = item.stripePriceIdXLarge;
                  if (!acc[key]) {
                    acc[key] = { priceId: key, quantity: 0 };
                  }
                  acc[key].quantity += 1;
                } else {
                  const key = item.stripePriceId;
                  if (!acc[key]) {
                    acc[key] = { priceId: key, quantity: 0 };
                  }
                  acc[key].quantity += 1;
                }
                return acc;
              }, {});
              if (setupFee && !aggregation[setupFee]) {
                aggregation[setupFee] = { priceId: setupFee, quantity: 1 };
              }
              return Object.values(aggregation);
            };

            this.aggregatedData = aggregateByStripePriceIdSmall(
              resultArray,
              this.setupFee,
            );
          });
          if (this.cardExpirationData === true) {
            let data1 = {
              priceIds: this.aggregatedData,
              accountId: stripeAccount,
              customerId: value,
              petDetailsId: this.petProfileDetails.id,
              petWellnessPlanId: petWellnessPlanIds,
              startDate: this.BillingCycleStartDate,
              billingCycle: this.BillingCycle,
            };
            console.log(data1);
            this.stripeService
              .reActiveSubscription(data1)
              .subscribe((doc: any) => {
                if (doc) {
                  this.messageService.add({
                    severity: 'success',
                    summary: doc,
                    detail: 'Wellness Plan Schedule Successfully',
                  });
                  setTimeout(() => {
                    this.checkPaymentStatus(this.petProfileDetails);
                  }, 1500);
                } else {
                  console.error(
                    'No invoice URL received from subscription creation.',
                  );
                }
              });
          } else {
            const dialogRef = this.dialog.open(PetDetailsComponent, {
              width: '1400px',
              height: '550px',
            });

            dialogRef.afterClosed().subscribe((result) => {
              if (result === 1) {
                let data1 = {
                  priceIds: this.aggregatedData,
                  accountId: stripeAccount,
                  customerId: value,
                  petDetailsId: this.petProfileDetails?.id,
                  petWellnessPlanId: petWellnessPlanIds,
                  startDate: this.BillingCycleStartDate,
                  billingCycle: this.BillingCycle,
                };
                console.log(data1);
                this.stripeService
                  .reActiveSubscription(data1)
                  .subscribe((doc: any) => {
                    if (doc) {
                      this.messageService.add({
                        severity: 'success',
                        summary: doc,
                        detail: 'Wellness Plan Schedule Successfully',
                      });
                      setTimeout(() => {
                        this.checkPaymentStatus(this.petProfileDetails);
                      }, 1500);
                    } else {
                      console.error(
                        'No invoice URL received from subscription creation.',
                      );
                    }
                  });
              } else {
                this.messageService.add({
                  severity: 'error',
                  summary: 'error',
                  detail: 'Wellness Plan Not Scheduled ',
                });
              }
            });
          }
        }
      } else {
        this.messageService.add({
          severity: 'error',
          summary: 'Warning',
          detail: 'Dialog closed without any action.',
        });
      }
    });
  }
  CreatePayment(list: any) {
    if (this.petProfileDetails) {
      const value = sessionStorage.getItem('stripeCustomerId');
      const startDate = list[0].startDate;
      const choosenWellnessPlans: WellnessPlanUpdate[] = list.map(
        (item: any) => item.wellnessPlanUpdate,
      );
      const petWellnessPlanIds = list.map(
        (item: any) => item.petWellnessPlanId,
      );

      console.log(petWellnessPlanIds);
      const stripeAccount = choosenWellnessPlans[0].stipeAccountId;
      const resultArray: any[] = [];
      const wellnessPlanUpdates = list.map(
        (plan: any) => plan.wellnessPlanUpdate,
      );

      wellnessPlanUpdates.forEach((item: any) => {
        if (item.priceBased === 'WGT' && item.stripePriceIdSmall) {
          resultArray.push(item);
        } else if (item.priceBased === 'WGT' && item.stripePriceIdMedium) {
          resultArray.push(item);
        } else if (item.priceBased === 'WGT' && item.stripePriceIdLarge) {
          resultArray.push(item);
        } else if (item.priceBased === 'WGT' && item.stripePriceIdXLarge) {
          resultArray.push(item);
        } else {
          resultArray.push(item);
        }
        const aggregateByStripePriceIdSmall = (
          data: any[],
          setupFee?: string,
        ) => {
          const aggregation = data.reduce((acc, item) => {
            console.log(item);
            if (item.priceBased === 'WGT' && item.stripePriceIdSmall) {
              const key = item.stripePriceIdSmall;
              if (!acc[key]) {
                acc[key] = { priceId: key, quantity: 0 };
              }
              acc[key].quantity += 1;
            } else if (item.priceBased === 'WGT' && item.stripePriceIdMedium) {
              const key = item.stripePriceIdMedium;
              if (!acc[key]) {
                acc[key] = { priceId: key, quantity: 0 };
              }
              acc[key].quantity += 1;
            } else if (item.priceBased === 'WGT' && item.stripePriceIdLarge) {
              const key = item.stripePriceIdLarge;
              if (!acc[key]) {
                acc[key] = { priceId: key, quantity: 0 };
              }
              acc[key].quantity += 1;
            } else if (item.priceBased === 'WGT' && item.stripePriceIdXLarge) {
              const key = item.stripePriceIdXLarge;
              if (!acc[key]) {
                acc[key] = { priceId: key, quantity: 0 };
              }
              acc[key].quantity += 1;
            } else {
              const key = item.stripePriceId;
              if (!acc[key]) {
                acc[key] = { priceId: key, quantity: 0 };
              }
              acc[key].quantity += 1;
            }
            return acc;
          }, {});
          if (setupFee && !aggregation[setupFee]) {
            aggregation[setupFee] = { priceId: setupFee, quantity: 1 };
          }
          return Object.values(aggregation);
        };

        this.aggregatedData = aggregateByStripePriceIdSmall(
          resultArray,
          this.setupFee,
        );
      });

      if (startDate) {
        const currentDate = new Date();
        const formattedDate =
          currentDate.getFullYear() +
          '-' +
          (currentDate.getMonth() + 1).toString().padStart(2, '0') +
          '-' +
          currentDate.getDate().toString().padStart(2, '0');
        const startDateObj = new Date(startDate);

        if (startDateObj >= currentDate) {
          if (this.data === true) {
            // if (this.hasOtherPromotion) {
            //   this.oneTimeFee = null;
            // }
            let data1 = {
              priceIds: this.aggregatedData,
              accountId: stripeAccount,
              customerId: value,
              oneTimePriceId: this.oneTimeFee,
              petDetailsId: this.petProfileDetails.id,
              startDate: startDate,
              stripeCouponId: this.stripeCouponId || null,
              petWellnessPlanId: petWellnessPlanIds,
            };
            console.log(data1);
            this.stripeService
              .createSubscription(data1)
              .subscribe((doc: any) => {
                if (doc) {
                  this.messageService.add({
                    severity: 'success',
                    summary: doc,
                    detail: 'Wellness Plan Schedule Successfully',
                  });
                  setTimeout(() => {
                    this.checkPaymentStatus(this.petProfileDetails);
                  }, 1500);
                } else {
                  console.error(
                    'No invoice URL received from subscription creation.',
                  );
                }
              });
          } else {
            const dialogRef = this.dialog.open(PetDetailsComponent, {
              width: '1400px',
              height: '550px',
            });

            dialogRef.afterClosed().subscribe((result) => {
              console.log(result);
              if (result === 1) {
                if (this.hasOtherPromotion) {
                  this.oneTimeFee = null;
                }
                let data1 = {
                  priceIds: this.aggregatedData,
                  accountId: stripeAccount,
                  customerId: value,
                  oneTimePriceId: this.oneTimeFee,
                  petDetailsId: this.petProfileDetails?.id,
                  startDate: startDate,
                  petWellnessPlanId: petWellnessPlanIds,
                  stripeCouponId: this.stripeCouponId || null,
                };
                console.log(data1);

                this.stripeService
                  .createSubscription(data1)
                  .subscribe((doc: any) => {
                    if (doc) {
                      this.messageService.add({
                        severity: 'success',
                        summary: doc,
                        detail: 'Wellness Plan Schedule Successfully',
                      });
                      setTimeout(() => {
                        this.checkPaymentStatus(this.petProfileDetails);
                      }, 1500);
                    } else {
                      console.error(
                        'No invoice URL received from subscription creation.',
                      );
                    }
                  });
              } else {
                this.messageService.add({
                  severity: 'warning',
                  summary: 'Warning',
                  detail: 'Add your card',
                });
              }
            });
          }
        } else if (startDateObj <= currentDate) {
          if (this.hasOtherPromotion) {
            this.oneTimeFee = null;
          }
          console.log('dddd', currentDate);
          let data1 = {
            priceIds: this.aggregatedData,
            accountId: stripeAccount,
            customerId: value,
            oneTimePriceId: this.oneTimeFee,
            petDetailsId: this.petProfileDetails.id,
            startDate: currentDate,
            petWellnessPlanId: petWellnessPlanIds,
            stripeCouponId: this.stripeCouponId || null,
          };
          console.log(data1);

          this.stripeService.createSubscription(data1).subscribe((doc: any) => {
            if (doc) {
              const newWindow = window.open(doc, '_blank');
              setTimeout(() => {
                this.checkPaymentStatus(this.petProfileDetails);
              }, 1500);
            } else {
              console.error(
                'No invoice URL received from subscription creation.',
              );
            }
          });
        } else {
          if (this.hasOtherPromotion) {
            this.oneTimeFee = null;
          }
          let data1 = {
            priceIds: this.aggregatedData,
            accountId: stripeAccount,
            customerId: value,
            oneTimePriceId: this.oneTimeFee,
            petDetailsId: this.petProfileDetails.id,
            startDate: formattedDate,
            petWellnessPlanId: petWellnessPlanIds,
            stripeCouponId: this.stripeCouponId || null,
          };
          console.log(data1);

          this.stripeService.createSubscription(data1).subscribe((doc: any) => {
            if (doc) {
              const newWindow = window.open(doc, '_blank');
              setTimeout(() => {
                this.checkPaymentStatus(this.petProfileDetails);
              }, 1500);
            } else {
              console.error(
                'No invoice URL received from subscription creation.',
              );
            }
          });
        }
      }
    }
  }

  // CreatePayment(list:any) {
  //   console.log(list);

  // if (this.petProfileDetails) {
  //   const choosenWellnessPlans: WellnessPlanUpdate[] = this.mappedPlans.map(
  //     (item) => item.wellnessPlanUpdate,
  //   );
  //   console.log(this.mappedPlans);

  //   const value = sessionStorage.getItem('stripeCustomerId');
  //   const startDate = this.mappedPlans[0].startDate;
  //   const stripeAccout = choosenWellnessPlans[0].stipeAccountId;
  //   // const priceIds = [this.setupFee, ...choosenWellnessPlans.map(item => item.stripePriceId)]
  //   const wellnessPlanUpdates = this.mappedPlans.map(
  //     (plan) => plan.wellnessPlanUpdate,
  //   );
  //   const resultArray: any[] = [];
  //   wellnessPlanUpdates.forEach((item) => {
  //     if (item.priceBased === 'WGT' && item.stripePriceIdSmall) {
  //       resultArray.push(item);
  //     } else if (item.priceBased === 'WGT' && item.stripePriceIdMedium) {
  //       resultArray.push(item);
  //     } else if (item.priceBased === 'WGT' && item.stripePriceIdLarge) {
  //       resultArray.push(item);
  //     } else if (item.priceBased === 'WGT' && item.stripePriceIdXLarge) {
  //       resultArray.push(item);
  //     } else {
  //       resultArray.push(item);
  //     }
  //     const aggregateByStripePriceIdSmall = (
  //       data: any[],
  //       setupFee?: string,
  //     ) => {
  //       const aggregation = data.reduce((acc, item) => {
  //         console.log(item);
  //         if (item.priceBased === 'WGT' && item.stripePriceIdSmall) {
  //           const key = item.stripePriceIdSmall;
  //           if (!acc[key]) {
  //             acc[key] = { priceId: key, quantity: 0 };
  //           }
  //           acc[key].quantity += 1;
  //         } else if (item.priceBased === 'WGT' && item.stripePriceIdMedium) {
  //           const key = item.stripePriceIdMedium;
  //           if (!acc[key]) {
  //             acc[key] = { priceId: key, quantity: 0 };
  //           }
  //           acc[key].quantity += 1;
  //         } else if (item.priceBased === 'WGT' && item.stripePriceIdLarge) {
  //           const key = item.stripePriceIdLarge;
  //           if (!acc[key]) {
  //             acc[key] = { priceId: key, quantity: 0 };
  //           }
  //           acc[key].quantity += 1;
  //         } else if (item.priceBased === 'WGT' && item.stripePriceIdXLarge) {
  //           const key = item.stripePriceIdXLarge;
  //           if (!acc[key]) {
  //             acc[key] = { priceId: key, quantity: 0 };
  //           }
  //           acc[key].quantity += 1;
  //         } else {
  //           const key = item.stripePriceId;
  //           if (!acc[key]) {
  //             acc[key] = { priceId: key, quantity: 0 };
  //           }
  //           acc[key].quantity += 1;
  //         }
  //         return acc;
  //       }, {});
  //       if (setupFee && !aggregation[setupFee]) {
  //         aggregation[setupFee] = { priceId: setupFee, quantity: 1 };
  //       }
  //       return Object.values(aggregation);
  //     };

  //     this.aggregatedData = aggregateByStripePriceIdSmall(
  //       resultArray,
  //       this.setupFee,
  //     );
  //   });
  //   if (startDate) {
  //     const currentDate = new Date();
  //     const formattedDate =
  //       currentDate.getFullYear() +
  //       '-' +
  //       (currentDate.getMonth() + 1).toString().padStart(2, '0') +
  //       '-' +
  //       currentDate.getDate().toString().padStart(2, '0');
  //     const startDateObj = new Date(startDate);

  //     if (startDateObj >= currentDate) {
  //       if (this.data === true) {
  //         let data1 = {
  //           priceIds: this.aggregatedData,
  //           accountId: stripeAccout,
  //           customerId: value,
  //           oneTimePriceId: 'price_1QKbcxDb6WVg8hg0qaPhU85t',
  //           petDetailsId: this.petProfileDetails.id,
  //           startDate: startDate,
  //           stripeCouponId: this.stripeCouponId || null,
  //         };

  //         this.stripeService
  //           .createSubscription(data1)
  //           .subscribe((doc: any) => {
  //             if (doc) {
  //               this.messageService.add({
  //                 severity: 'success',
  //                 summary: doc,
  //                 detail: 'Wellness Plan Schedule Successfully',
  //               });
  //               setTimeout(() => {
  //                 this.checkPaymentStatus(this.petProfileDetails);
  //               }, 1500);
  //             } else {
  //               console.error(
  //                 'No invoice URL received from subscription creation.',
  //               );
  //             }
  //           });
  //       } else {
  //         // this.openCardPopup();
  //         const dialogRef = this.dialog.open(PetDetailsComponent, {
  //           width: '1400px',
  //           height: '550px',
  //         });
  //         dialogRef.afterClosed().subscribe((result) => {
  //           console.log(result);
  //           if (result === 1) {
  //             // this.CreatePayment()
  //             let data1 = {
  //               priceIds: this.aggregatedData,
  //               accountId: stripeAccout,
  //               customerId: value,
  //               oneTimePriceId: 'price_1QKbcxDb6WVg8hg0qaPhU85t',
  //               petDetailsId: this.petProfileDetails?.id,
  //               startDate: startDate,
  //               stripeCouponId: this.stripeCouponId || null,
  //             };
  //             this.stripeService
  //               .createSubscription(data1)
  //               .subscribe((doc: any) => {
  //                 if (doc) {
  //                   this.messageService.add({
  //                     severity: 'success',
  //                     summary: doc,
  //                     detail: 'Wellness Plan Schedule Successfully',
  //                   });
  //                   setTimeout(() => {
  //                     this.checkPaymentStatus(this.petProfileDetails);
  //                   }, 1500);
  //                 } else {
  //                   console.error(
  //                     'No invoice URL received from subscription creation.',
  //                   );
  //                 }
  //               });
  //           } else {
  //             this.messageService.add({
  //               severity: 'warning',
  //               summary: 'Warning',
  //               detail: 'Add yout card ',
  //             });
  //           }
  //         });
  //       }
  //     } else if (startDateObj <= currentDate) {
  //       console.log('dddd', currentDate);
  //       let data1 = {
  //         priceIds: this.aggregatedData,
  //         accountId: stripeAccout,
  //         customerId: value,
  //         oneTimePriceId: 'price_1QKbcxDb6WVg8hg0qaPhU85t',
  //         petDetailsId: this.petProfileDetails.id,
  //         startDate: currentDate,
  //         stripeCouponId: this.stripeCouponId || null,
  //       };
  //       console.log(data1);

  //       this.stripeService.createSubscription(data1).subscribe((doc: any) => {
  //         if (doc) {
  //           const newWindow = window.open(doc, '_blank');
  //           setTimeout(() => {
  //             this.checkPaymentStatus(this.petProfileDetails);
  //           }, 1500);
  //         } else {
  //           console.error(
  //             'No invoice URL received from subscription creation.',
  //           );
  //         }
  //       });
  //     } else {
  //       let data1 = {
  //         priceIds: this.aggregatedData,
  //         accountId: stripeAccout,
  //         customerId: value,
  //         oneTimePriceId: 'price_1QKbcxDb6WVg8hg0qaPhU85t',
  //         petDetailsId: this.petProfileDetails.id,
  //         startDate: formattedDate,
  //         stripeCouponId: this.stripeCouponId || null,
  //       };
  //       console.log(data1);

  //       this.stripeService.createSubscription(data1).subscribe((doc: any) => {
  //         if (doc) {
  //           const newWindow = window.open(doc, '_blank');
  //           setTimeout(() => {
  //             this.checkPaymentStatus(this.petProfileDetails);
  //           }, 1500);
  //         } else {
  //           console.error(
  //             'No invoice URL received from subscription creation.',
  //           );
  //         }
  //       });
  //     }
  //   } else {
  //     console.log('startDate is null');
  //   }
  // }
  // }
  updatePlan(list: any) {
    console.log(list[0].stripeSubscriptionId);

    const dialogRef = this.dialog.open(StatusToggleComponent, {
      data: 1,
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log(result);
      if (result === 1) {
        const value = sessionStorage.getItem('stripeCustomerId');
        const anyNotPaid = list.filter(
          (item: any) => item.planStatus !== 'paid',
        );
        const petWellnessPlanIds = anyNotPaid.map(
          (item: any) => item.petWellnessPlanId,
        );

        const wellnessPlanUpdates =
          anyNotPaid?.map((item: any) => item.wellnessPlanUpdate) ?? [];
        const resultArray: any[] = [];
        wellnessPlanUpdates.forEach((item: any) => {
          if (item.priceBased === 'WGT' && item.stripePriceIdSmall) {
            resultArray.push(item);
          } else if (item.priceBased === 'WGT' && item.stripePriceIdMedium) {
            resultArray.push(item);
          } else if (item.priceBased === 'WGT' && item.stripePriceIdLarge) {
            resultArray.push(item);
          } else if (item.priceBased === 'WGT' && item.stripePriceIdXLarge) {
            resultArray.push(item);
          } else {
            resultArray.push(item);
          }
          const aggregateByStripePriceIdSmall = (data: any[]) => {
            const aggregation = data.reduce((acc, item) => {
              console.log(item);
              if (item.priceBased === 'WGT' && item.stripePriceIdSmall) {
                const key = item.stripePriceIdSmall;
                if (!acc[key]) {
                  acc[key] = { priceId: key, quantity: 0 };
                }
                acc[key].quantity += 1;
              } else if (
                item.priceBased === 'WGT' &&
                item.stripePriceIdMedium
              ) {
                const key = item.stripePriceIdMedium;
                if (!acc[key]) {
                  acc[key] = { priceId: key, quantity: 0 };
                }
                acc[key].quantity += 1;
              } else if (item.priceBased === 'WGT' && item.stripePriceIdLarge) {
                const key = item.stripePriceIdLarge;
                if (!acc[key]) {
                  acc[key] = { priceId: key, quantity: 0 };
                }
                acc[key].quantity += 1;
              } else if (
                item.priceBased === 'WGT' &&
                item.stripePriceIdXLarge
              ) {
                const key = item.stripePriceIdXLarge;
                if (!acc[key]) {
                  acc[key] = { priceId: key, quantity: 0 };
                }
                acc[key].quantity += 1;
              } else {
                const key = item.stripePriceId;
                if (!acc[key]) {
                  acc[key] = { priceId: key, quantity: 0 };
                }
                acc[key].quantity += 1;
              }
              return acc;
            }, {});

            return Object.values(aggregation);
          };

          this.aggregatedData = aggregateByStripePriceIdSmall(resultArray);
          console.log(this.aggregatedData);
        });
        let data1 = {
          priceIds: this.aggregatedData,
          customerId: value,
          petDetailsId: this.petProfileDetails?.id,
          subscriptionId: list[0].stripeSubscriptionId,
          petWellnessPlanId: petWellnessPlanIds,
        };
        console.log(data1);

        this.stripeService.updateSubscription(data1).subscribe((doc: any) => {
          console.log(doc);
          this.messageService.add({
            severity: 'success',
            summary: doc,
            detail: 'Wellness Plan Added Successfully',
          });
          setTimeout(() => {
            this.checkPaymentStatus(this.petProfileDetails);
          }, 1500);
        });
      } else {
        console.log('ddddddd');
        setTimeout(() => {
          this.checkPaymentStatus(this.petProfileDetails);
        }, 1500);
      }
    });
  }
  getPetDetailsStatus(petDetailsId: any) {
    console.log(petDetailsId);
    const petownerId = petDetailsId.id;
    this.stripeService.getPetDetails(petownerId).subscribe((doc: any) => {
      console.log(doc);
      if (
        doc[0].paymentStatus === 'paid' ||
        doc[0].paymentStatus === 'not_started'
      ) {
        // window.location.href = '/petOwners/pet-owher-navhar-layout/pet-profilel';
        window.location.reload();
      } else {
        // setTimeout(() => this.checkPaymentStatus(petDetailsId), 1500);
      }
    });
  }
  checkPaymentStatus(petDetailsId: any) {
    const petownerId = petDetailsId.id;
    this.petOwnerService.getPetDetailsId(petownerId).subscribe(
      (status: any) => {
        console.log(status, 'wwwww');

        if (!status || !status.length) {
          console.warn('No status data found');
          return;
        }

        const paymentStatus = status[0]?.paymentStatus;
        const ongoingPlanStatus =
          status[0]?.ongoingPlans?.[1]?.[0]?.paymentStatus;
        const ongoingPaymentStatus =
          status[0]?.ongoingPlans?.[1]?.[0]?.planStatus;
        const futurePlanStatus =
          status[0]?.futurePlans?.[1]?.[0]?.paymentStatus;

        if (paymentStatus === 'paid') {
          if (ongoingPlanStatus === 'paid') {
            window.location.reload();
          } else if (ongoingPaymentStatus === 'scheduled') {
            window.location.reload();
          }
        } else if (paymentStatus === 'pending') {
          if (futurePlanStatus === 'not_started') {
            window.location.reload();
          } else {
            setTimeout(() => this.checkPaymentStatus(petDetailsId), 1500);
          }
        } else {
          setTimeout(() => this.checkPaymentStatus(petDetailsId), 1500);
        }
      },
      (error) => {
        console.error('Error fetching payment status:', error);
      },
    );
  }

  getBreedType(petType: any) {
    this.petOwnerService.getBreedNyPetType(petType).subscribe({
      next: (response) => {
        this.breedType = response;
      },
      error: (err) => {
        console.log(err);
      },
    });
  }
  onPetTypeChange(event: Event) {
    const target = event.target as HTMLSelectElement;
    const selectedPetType = target?.value || '';
    if (selectedPetType) {
      this.petProfileDetails!.petBreed = '';
      this.getBreedType(selectedPetType);
    }
  }

  navigateToChoosePlan(petId: number) {
    this.router.navigate([
      '/petOwners/pet-owher-navhar-layout/choose-plans',
      petId,
    ]);
  }

  navigateToUpdatePlans(petId: number, plan: any, setKey: any) {
    const wellnessplan = plan;
    const setKeyNumber = setKey;
    const managePetWellnessPlanId = wellnessplan.find(
      (item: any) => item.managepetWellnessPlanId,
    )?.managepetWellnessPlanId;

    if (managePetWellnessPlanId) {
      // Navigate with both petId and managePetWellnessPlanId
      this.router.navigate(
        ['/petOwners/pet-owher-navhar-layout/update-plans', petId],
        {
          queryParams: {
            managePetWellnessPlanId: managePetWellnessPlanId,
            setKey: setKeyNumber,
          },
        },
      );
    } else {
      // Handle the case when managePetWellnessPlanId is not found
      console.log('managePetWellnessPlanId is missing or not found');
      // Optionally, show an alert or take any other action
    }
  }

  navigateToAddNewSetPlans(petId: number) {
    this.router.navigate([
      '/petOwners/pet-owher-navhar-layout/add-new-set-plans',
      petId,
    ]);
  }

  getPrice(
    wellnessPlan: any,
    priceType: 'updatedPrice' | 'discountPrice',
  ): number | null {
    const planUpdate = wellnessPlan?.wellnessPlanUpdate;
    if (!planUpdate) return null;

    if (priceType === 'updatedPrice') {
      return (
        planUpdate.updatedPriceForQuantity ??
        planUpdate.updatedPriceForSmall ??
        null
      );
    }
    if (priceType === 'discountPrice') {
      return (
        planUpdate.discountPriceForQuantity ??
        planUpdate.discountPriceForSmall ??
        null
      );
    }
    return null;
  }

  getUpdatedPlans(petId: any) {
    if (petId) {
      this.wellnessPlanService.getUpdatedPlans(petId).subscribe({
        next: (response) => {
          this.updatePlans = response;
          this.hasUpdatedPlans = this.updatePlans.length === 1;
          if (this.updatePlans.length >= 1) {
            this.hasUpdatedPlans = true;
            // this.hasAddNewSetPlans = false
          } else {
            this.hasUpdatedPlans = false;
          }
        },
      });
    }
  }

  getNewPlans(petId: any) {
    if (petId) {
      this.wellnessPlanService.getAddNewSetPlans(petId).subscribe({
        next: (response) => {
          this.addNewSetPlans = response || [];
          this.hasAddNewSetPlans = this.addNewSetPlans.length === 1;
          if (this.addNewSetPlans.length > 1) {
            this.hasAddNewSetPlans = true;
          } else {
            this.hasAddNewSetPlans = false;
          }
        },
      });
    }
  }
}
