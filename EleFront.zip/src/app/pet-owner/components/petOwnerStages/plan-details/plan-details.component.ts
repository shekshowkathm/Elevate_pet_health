import { Stripe } from '@stripe/stripe-js';
import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { PetOwnerService } from '../../../service/pet-owner.service';
import { isPlatformBrowser, NgClass, NgFor, NgIf } from '@angular/common';
import { SharedService } from '../../../../shared/service/shared.service';
import { CommonModule } from '@angular/common';
interface PetProfileImage {
  petImage: string;
  petId?: number;
  navigateTo?: string;
}
@Component({
  selector: 'app-plan-details',
  standalone: true,
  imports: [NgFor, NgIf, NgClass, CommonModule],
  templateUrl: './plan-details.component.html',
  styleUrl: './plan-details.component.scss'
})
export class PlanDetailsComponent {
  regId: string | null = null;
  petProfileImage: PetProfileImage[] = [];
  selectedImage: number = 1;
  petId: number = 0;
  showHistoryPlans = false;
  showFuturePlans = false;
  petPlans: any = null;

  promotionSentence: string = ''

  constructor(private petOwnerService: PetOwnerService, @Inject(PLATFORM_ID) private platformId: Object, private sharedservice: SharedService) { }

  ngOnInit() {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      const registerId = this.sharedservice.getId('id');
      this.regId = registerId ? registerId.trim() : null;
      this.getPetImagePetId();
    }
  }

  selectImage(index: number) {
    this.selectedImage = index;
    const petId = this.petProfileImage[index]?.petId;
    this.petId = petId !== undefined ? petId : 0;
    this.getPetPlans(this.petId);
  }


  getPetImagePetId() {
    if (isPlatformBrowser(this.platformId)) {
      const petownerId = this.regId;
      if (petownerId) {
        this.petOwnerService.petImagePetId(petownerId).subscribe({
          next: (response) => {
            this.petProfileImage = response;
            if (this.petProfileImage.length > 0) {
              this.selectImage(0);
            }
          },
        });
      }
    }
  }

  scrollLeft() {
    const scrollContainer = document.querySelector('.overflow-x-auto');
    if (scrollContainer) {
      scrollContainer.scrollBy({
        left: -100,
        behavior: 'smooth'
      });
    }
  }

  scrollRight() {
    const scrollContainer = document.querySelector('.overflow-x-auto');
    if (scrollContainer) {
      scrollContainer.scrollBy({
        left: 100,
        behavior: 'smooth'
      });
    }
  }

  getPetPlans(petId: number) {
    this.petOwnerService.getPetPlans(petId).subscribe({
      next: (response) => {
        this.petPlans = {
          petSummary: response.petSummary || null,
          ongoingPlans: Object.values(response.ongoingPlans || {}),
          historyPlans: Object.values(response.historyPlans || {}),
          futurePlans: Object.values(response.futurePlans || {}),
        };
        console.log(this.petPlans.ongoingPlans);

        
      },
      error: (err) => {
        console.error("Error fetching pet plans", err);
      },
    });
  }

  toggleHistoryPlans() {
    this.showHistoryPlans = !this.showHistoryPlans;
  }

  toggleFuturePlans() {
    this.showFuturePlans = !this.showFuturePlans;
  }


  generatePromotionSentence(promotions: any): string {
    if (promotions.length > 0) {
      let sentence = '';
      const promotionsCopy = [...promotions]; // Create a copy of the promotions array
  
      if (promotionsCopy.length === 1) {
        sentence = `The '${promotionsCopy[0]}' promotion has been activated for this plan.`;
      } else if (promotionsCopy.length > 1) {
        const lastPromotion = promotionsCopy.pop(); // Remove last promotion from the copy
        const promotionList = promotionsCopy.join("', '"); // Join the rest with commas
        sentence = `The '${promotionList}' and '${lastPromotion}' promotions have been activated for this plan.`;
      }
  
      return sentence;
    } else {
      return '';
    }
  }
  
}
