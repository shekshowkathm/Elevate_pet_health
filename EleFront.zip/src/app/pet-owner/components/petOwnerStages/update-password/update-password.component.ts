import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AvatarModule } from 'primeng/avatar';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { PetOwnerService } from '../../../../pet-owner/service/pet-owner.service'
import { isPlatformBrowser, NgClass, NgIf } from '@angular/common';
import { SharedService } from '../../../../shared/service/shared.service';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';

@Component({
  selector: 'app-update-password',
  standalone: true,
  imports: [FormsModule, DialogModule, CardModule, ButtonModule, InputTextModule, AvatarModule, NgIf, NgClass, ToastModule],
  providers: [MessageService],
  templateUrl: './update-password.component.html',
  styleUrl: './update-password.component.scss'
})
export class UpdatePasswordComponent {
  visible: boolean = false;
  newPassword: string = '';
  confirmPassword: string = '';
  errorMessage: string = '';
  newPasswordVisible: boolean = false;
  confirmPasswordVisible: boolean = false;
  responseMessage: string = '';
  regId: string | null = null;

  constructor(@Inject(PLATFORM_ID) private platformId: Object, private messageService: MessageService, private PetOwnerService: PetOwnerService, private sharedservice: SharedService, private router: Router) {
  }

  ngOnInit(): void {

    this.PetOwnerService.openDialog$.subscribe(() => {
      this.visible = true;
    });
  }

  toggleNewPasswordVisibility() {
    this.newPasswordVisible = !this.newPasswordVisible;
  }
  toggleConfirmPasswordVisibility() {
    this.confirmPasswordVisible = !this.confirmPasswordVisible;
  }
  validatePasswords() {
    if (this.newPassword.length < 8) {
      this.errorMessage = 'Password must be at least 8 characters long.';
    } else if (this.newPassword !== this.confirmPassword) {
      this.errorMessage = 'Passwords do not match.';
    } else {
      this.errorMessage = '';
    }
  }
  onPasswordChange() {
    this.validatePasswords();
  }
  resetForm() {
    this.newPassword = '';
    this.confirmPassword = '';
    this.errorMessage = '';
    this.PetOwnerService.pDialogCloseUpdatePassword(true);
  }
  savePassword() {
    this.validatePasswords();
    if (!this.errorMessage) {
      if (isPlatformBrowser(this.platformId)) {
        const storedId = localStorage.getItem('id') || "";
        this.regId = storedId;
      }


      this.PetOwnerService.updatePassword(this.regId || null, this.confirmPassword).subscribe({
        next: (response) => {
          this.responseMessage = response.message || 'Password updated successfully';

          this.visible = false;
          this.resetForm();
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: response,
          });
          const isFirstTimeFlow = this.PetOwnerService.getAcceptedTerms();

          if (response && isFirstTimeFlow) {
            const isExisting: boolean = true;
            this.router.navigate(['/petOwners/pet-owher-navhar-layout/clinic-details'], { queryParams: { existing: isExisting } });
          }
        },
      });
    } else {
      this.resetForm();
    }
  }
}
