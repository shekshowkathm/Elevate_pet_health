import {
  NgFor,
  NgIf,
  CommonModule,
  CurrencyPipe,
  isPlatformBrowser,
} from '@angular/common';
import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { PetOwnerService } from '../../../service/pet-owner.service';
import { StripeService } from '../../../../clinic/services/stripe.service';
import { SharedService } from '../../../../shared/service/shared.service';
import { MatDialog } from '@angular/material/dialog';
import { WellnessPlanService } from '../../../service/wellness-plan.service';
import { TrancationService } from '../../../service/trancation.service';

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [
    NgFor,
    NgIf,
    FormsModule,
    CommonModule,
    ReactiveFormsModule,
    NgFor,
    MatButtonModule,
    ToastModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
  ],
  templateUrl: './notifications.component.html',
  styleUrl: './notifications.component.scss',
  providers: [MessageService],
})
export class NotificationsComponent {
  regId!: number | null;
  notificationArray: any[] = [];
  showFullMessage: boolean[] = [];
  customerId: string = '';
  public CardList: any[] = [];
  public trancation: any[] = [];
  activeSection: string = 'planConfirmation';

  constructor(
    private router: Router,
    private petOwnerService: PetOwnerService,
    private stripeService: StripeService,
    private sharedservice: SharedService,
    private trancationService: TrancationService,
    @Inject(PLATFORM_ID) private platformId: Object,
  ) {}

  ngOnInit() {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      const registerId = this.sharedservice.getId('id');
      this.regId = registerId ? Number(registerId) : null;
      this.getGetNotificationsForPlans();
    }
  }

  onFilterChange(event: any): void {
    const selectedValue = event.target.value;
    switch (selectedValue) {
      case 'planConfirmation':
        this.getGetNotificationsForPlans();
        break;
      case 'planExpired':
        this.fetchPlanExpiredNotifications();
        break;
      case 'missedAppointment':
        this.fetchAppointmentNotifications('MISSED_APPOINTMENTS');
        break;
      case 'todaysAppointments':
        this.fetchAppointmentNotifications('TODAYS_APPOINTMENTS');
        break;
      case 'paymentIssues':
        this.fetchPaymentNotifications();
        break;
      case 'cardIssues':
        this.fetchCardIssuesNotifications();
        break;

      default:
        console.error('Unknown filter selected');
    }
  }

  navigateToPlanPage(status: string, petId: number) {
    if (status === 'NEW_SET_TO_PET_OWNER') {
      this.router.navigate([
        '/petOwners/pet-owher-navhar-layout/add-new-set-plans',
        petId,
      ]);
    } else if (status === 'UPDATED_PLANS_TO_OWNER') {
      // console.log('update da');
      this.router.navigate(['/petOwners/pet-owher-navhar-layout/pet-profile']);
    } else if (status === 'SENT_TO_PET_OWNER') {
      this.router.navigate([
        '/petOwners/pet-owher-navhar-layout/choose-plans',
        petId,
      ]);
    }
  }

  toggleMessageVisibility(index: number) {
    this.showFullMessage[index] = !this.showFullMessage[index];
  }

  getGetNotificationsForPlans() {
    if(this.regId){
      this.petOwnerService.getInitialPlanAlerts(this.regId).subscribe({
        next: (value) => {
          this.notificationArray = value;
          this.showFullMessage = Array(this.notificationArray.length).fill(false);
        },
        error: (err) => {
          console.log(err);
        },
      });
    }
  }

  fetchPlanExpiredNotifications() {
    if (this.regId) {
      this.petOwnerService.getExpiryPlanNotifications(this.regId).subscribe({
        next: (value) => {
          this.notificationArray = value;
          this.showFullMessage = Array(this.notificationArray.length).fill(
            false,
          );
        },
        error: (err) => {
          console.log(err);
        },
      });
    }
  }

  fetchAppointmentNotifications(statusFilter: string) {
    if (this.regId) {
      this.petOwnerService.getAppointmentsAlert(this.regId).subscribe({
        next: (value) => {
          this.notificationArray = value;
          this.notificationArray = value.filter(
            (notification: any) => notification.status === statusFilter,
          );
          this.showFullMessage = Array(this.notificationArray.length).fill(
            false,
          );
        },
        error: (err) => {
          console.log(err);
        },
      });
    }
  }
  fetchCardIssuesNotifications() {
    this.customerId = sessionStorage.getItem('stripeCustomerId') || '';
    this.stripeService.getExpiryDetailscustomer(this.customerId).subscribe(
      (doc: any) => {
        if (doc && doc.cardLast4) {
          this.CardList = [doc];
        } else {
          this.CardList = []; 
        }
      },
      (error) => {
        console.error('Error fetching card details', error);
        this.CardList = [];
      }
    );
  }
  

  fetchPaymentNotifications() {
    this.customerId = sessionStorage.getItem('stripeCustomerId') || '';
    this.trancationService
      .getcutomerTranscationDetails(this.customerId)
      .subscribe((doc: any) => {
        this.trancation = doc;
      });
  }
  onPayNow(list: any) {
    const newWindow = window.open(list, '_blank');
  }
  viewCardDetails(row: any) {
    this.router.navigate(['petOwners/pet-owher-navhar-layout/cardDetails']);
  }
}
