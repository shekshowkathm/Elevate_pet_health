import { NgClass, isPlatformBrowser } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, inject, Inject, PLATFORM_ID, signal } from '@angular/core';
import {
  CalendarModule,
  CalendarView,
  CalendarEvent,
  CalendarEventAction,
} from 'angular-calendar';
import { isSameMonth, isSameDay } from 'date-fns';
import { WellnessPlanService } from '../../../service/wellness-plan.service';
import { PetAppointment } from '../../../model/pet-appointment';
import { MessageService } from 'primeng/api';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ToastModule } from 'primeng/toast';

@Component({
  selector: 'app-appointment',
  standalone: true,
  imports: [CalendarModule, NgClass, ProgressSpinnerModule, ToastModule],
  templateUrl: './appointment.component.html',
  styleUrl: './appointment.component.scss',
  providers: [MessageService],
})
export class AppointmentComponent {
  private wellnessPlanservice = inject(WellnessPlanService);

  view: CalendarView = CalendarView.Month;
  CalendarView = CalendarView;
  viewDate: Date = new Date();
  activeDayIsOpen: boolean = false;
  events: CalendarEvent[] = [];

  loader: boolean = false;
  scheduledAppointments = signal<PetAppointment[]>([]);
  actions: CalendarEventAction[] = [
    {
      label: '<i class="pi pi-eye me-2 text-[#007cda]"></i>',
      onClick: function ({
        event,
        sourceEvent,
      }: {
        event: CalendarEvent;
        sourceEvent: MouseEvent | KeyboardEvent;
      }) {
        // console.log('view\n', 'event', event, '\nsourceEvent', sourceEvent);
      },
    },
  ];

  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    private messageService: MessageService,
  ) {}
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      this.fetchAppointments();
    }
  }

  fetchAppointments() {
    this.wellnessPlanservice.fetchSheduledAppointments().subscribe({
      next: (res: any) => {
        this.loader = false;
        this.scheduledAppointments.set(res);
        this.events = this.scheduledAppointments().map((a) => {
          return {
            title: `${a.serviceName}, ${a.dropDown} - ${a.petName}`,
            start: new Date(a.scheduledDateAndTime),
            clinicName: a.clinicName,
            petName: a.petName,
            status: 'Scheduled',
            // actions: this.actions,
            meta: a,
          };
        });
      },
      error: (err: HttpErrorResponse) => {
        this.loader = false;
        if (err.status === 401) {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail:
              'We encountered an error while fetching your appointments. Please try again later.',
          });
        }
        console.log('Error fetch the scheduled appointments', err);
      },
    });
  }

  handleEvent(action: string, event: CalendarEvent): void {
    console.log(`first ${action} event: `, event, '\n\n\n');
    if (action === 'Reschedule') {
      // console.log(`Action: ${action}, \n event: ${event}`);
    } else if (action === 'Cancel') {
      // console.log(`Action: ${action}, \n event: ${event}`);
    }
  }

  closeOpenMonthViewDay() {
    this.activeDayIsOpen = false;
  }

  dayClicked(event: any) {
    // console.log(event, 'jkadbcjh');
    const { day, sourceEvent } = event;
    if (day.events.length === 0) {
      // TODO: Shedule new Event
    } else {
      // TODO: Show mentioned events
      if (isSameMonth(day.date, this.viewDate)) {
        if (
          (isSameDay(this.viewDate, day.date) &&
            this.activeDayIsOpen === true) ||
          day.events.length === 0
        ) {
          this.activeDayIsOpen = false;
        } else {
          this.activeDayIsOpen = true;
          this.viewDate = day.date;
        }
      }
    }
  }

  columnHeaderClicked(event: any) {
    // console.log('columnHeaderClicked', event, '\n\n', event.isoDayNumber);
  }

  dayHeaderClicked(event: any) {
    // console.log('dayHeaderClicked', event, '\n\n', event.day.date);
  }

  hourSegmentClicked(event: any) {
    // console.log('hourSegmentClicked', event, '\n\n');
  }
}
