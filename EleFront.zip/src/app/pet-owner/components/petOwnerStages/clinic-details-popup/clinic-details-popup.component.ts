import { Component } from '@angular/core';
import { PetOwnerService } from '../../../../pet-owner/service/pet-owner.service'
import { CardModule } from 'primeng/card';
import { DialogModule } from 'primeng/dialog';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
 
@Component({
  selector: 'app-clinic-details-popup',
  standalone: true,
  imports: [CardModule,DialogModule,FormsModule],
  templateUrl: './clinic-details-popup.component.html',
  styleUrl: './clinic-details-popup.component.scss'
})
export class ClinicDetailsPopupComponent {
  visible: boolean = false;
  constructor(private PetOwnerService : PetOwnerService,private router: Router) {}

  ngOnInit(): void {
    this.PetOwnerService.openDialogClinic$.subscribe(() => {
      this.visible = true;
    });
  }

  routeToAddPet(isExisting: boolean){
    this.router.navigate(['/petOwners/pet-owher-navhar-layout/clinic-details'], { queryParams: { existing: isExisting } });
  }
  routeToAddClinic(isNew: boolean){
    this.router.navigate(['/petOwners/pet-owher-navhar-layout/clinic-details'], { queryParams: { new: isNew } });
  }
  resetForm() {
    this.router.navigate(['/petOwners/pet-owher-navhar-layout/user-profile']);
  }
}
