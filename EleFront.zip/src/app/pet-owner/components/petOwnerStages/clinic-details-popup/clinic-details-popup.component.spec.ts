import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicDetailsPopupComponent } from './clinic-details-popup.component';

describe('ClinicDetailsPopupComponent', () => {
  let component: ClinicDetailsPopupComponent;
  let fixture: ComponentFixture<ClinicDetailsPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClinicDetailsPopupComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClinicDetailsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
