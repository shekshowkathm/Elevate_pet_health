import { ImageResizeService } from './../../../../shared/service/image-resize.service';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PetOwnerService } from '../../../../pet-owner/service/pet-owner.service'
import { SharedService } from '../../../../shared/service/shared.service';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { ObjectCannedACL, PutObjectCommand, S3Client } from '@aws-sdk/client-s3';
import { environment } from '../../../../../environments/environment.development';
import { response } from 'express';
import { ImageUploadService } from '../../../../shared/service/image-upload.service';

@Component({
  selector: 'app-add-pet',
  standalone: true,
  imports: [NgClass, NgIf, ReactiveFormsModule, ToastModule, NgFor],
  providers: [MessageService],
  templateUrl: './add-pet.component.html',
  styleUrl: './add-pet.component.scss'
})
export class AddPetComponent {
  @ViewChild('fileInput') fileInput!: ElementRef<HTMLInputElement>;
  form: FormGroup;
  selectedFileName: string = '';
  selectedGender: string = '';
  selectedPetType: string = '';
  regId: string | null = null;
  selectedFileUrl: string | ArrayBuffer | null = '';
  isClinicId: number = 0;
  breedType: string[] = []

  uploadImageError: string = ''

  s3Client = new S3Client({
    region: environment.AWS_REGION,
    credentials: {
      accessKeyId: environment.AWS_ACCESS_KEY,
      secretAccessKey: environment.AWS_SECRET_KEY
    }
  });

  maxDate: string | undefined;

  constructor(private fb: FormBuilder, private router: Router, private PetOwnerService: PetOwnerService, private sharedservice: SharedService, private messageService: MessageService, private route: ActivatedRoute, private imageResizeService: ImageResizeService, private imageUploadService: ImageUploadService) {
    this.form = this.fb.group({
      petName: ['', Validators.required],
      petBreed: ['', Validators.required],
      weight: ['', [Validators.required, Validators.pattern(/^[0-9]+(\.[0-9]+)?$/)]],
      // petAge: ['', [Validators.required, Validators.pattern(/^[0-9]+$/)]],
      dob: ['', Validators.required],
      gender: ['', Validators.required],
      image: [''],
      petType: ['', Validators.required]
    });
  }
  ngOnInit(): void {
    const registerId = this.sharedservice.getId('id');
    this.regId = registerId ? registerId.trim() : null;
    this.route.queryParams.subscribe(params => {
      if ('clinicId' in params) {
        this.isClinicId = +params['clinicId'];
      }
    });
    this.setMaxDate();
  }

  setMaxDate() {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    this.maxDate = `${year}-${month}-${day}`;
  }
  triggerFileInput() {
    this.fileInput.nativeElement.click();
  }
  async onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];

    if (file) {
      this.selectedFileName = file.name;

      const reader = new FileReader();
      reader.onload = () => this.selectedFileUrl = reader.result;
      reader.readAsDataURL(file);

      this.form.patchValue({ image: this.selectedFileName });

      try {
        const resized400x400 = await this.imageResizeService.resizeImage(
          file,
          400,
          400
        ); // Blob --> size , type
        // const fileName400x400 = `${originalFileName}-${timestamp}.jpg`;
        const url = await this.imageUploadService.uploadFile(
          resized400x400,
          this.selectedFileName
        );
        this.form.patchValue({ image: url });
        this.uploadImageError = ''

      } catch (error) {
        // this.loader = false;
        console.error('Error resizing image:', error);
      }
      // this.uploadFiles(file);
    } else {
      this.selectedFileName = '';
      this.selectedFileUrl = '';
      this.form.patchValue({ image: '' });
    }
  }

  selectGender(gender: string) {
    this.selectedGender = gender;
    this.form.patchValue({
      gender: gender
    });
  }
  selectPetType(petType: string) {
    this.selectedPetType = petType;
    this.form.patchValue({
      petType: petType
    });
    this.PetOwnerService.getBreedNyPetType(petType).subscribe({
      next: (response) => {
        this.breedType = response
      }, error: (err) => {
        console.log(err);

      }
    })

  }

  addPetSubmit() {
    if (this.form.valid) {
      // this.form.value.weight = `${this.form.value.weight} lbs`
      const formValue = { ...this.form.value };

      if (formValue.image) {
        formValue.dateOfBirth = this.convertDateFormat(formValue.dateOfBirth);
        const registerId = this.sharedservice.getId('id');
        const data = {
          petOwner: {
            id: registerId
          },
          clinic: {
            id: this.isClinicId
          }
        };
        const updatedFormValue = { ...formValue, ...data };
        this.PetOwnerService.postAddPet(updatedFormValue).subscribe({
          next: (response) => {
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: response,
            });
            this.form.reset();
            setTimeout(() => {
              this.router.navigate(['/petOwners/pet-owher-navhar-layout/pet-profile']);
            }, 700);
          },
        });
        const isFirstTimeFlow = this.PetOwnerService.getAcceptedTerms();
        if (this.form.valid && isFirstTimeFlow) {
          setTimeout(() => {
            this.router.navigate(['/petOwners/pet-owher-navhar-layout/pet-profile']);
          }, 600);
          setTimeout(() => {
            window.location.reload();
          }, 700);
        }
      } else {
        this.uploadImageError = 'Please upload image'
      }

    } else {
      this.form.markAllAsTouched();
    }
  }
  convertDateFormat(date: string): string {
    if (!date) return '';
    const [year, month, day] = date.split('-');
    // return `${day}-${month}-${year}`;
    return `${year}-${month}-${day}`;
  }
  get formControls() {
    return this.form.controls;
  }


  async uploadFiles(files: File) {
    if (files) {
      const contentType = files.type; // Get the file's content type
      const mediaFolder = 'media/'; // Replace with your desired folder name
      const params = {
        Bucket: 'elevatepethealth-imagestorage', // Replace with your bucket name
        Key: `${mediaFolder}${files.name}`, // Include folder path in the Key
        Body: files,
        ContentType: contentType,
        ContentDisposition: "inline",
        ACL: 'public-read' as ObjectCannedACL // Set public access for the uploaded file
      };

      try {
        const command = new PutObjectCommand(params);
        const data = await this.s3Client.send(command);
        const uploadUrl = `https://${params.Bucket}.s3.${environment.AWS_REGION}.amazonaws.com/${params.Key}`;
        const imageURL = uploadUrl || null;

        this.form.patchValue({ image: imageURL });
      } catch (err) {
        console.error('Upload error:', err);
      }
    }
  }
}
