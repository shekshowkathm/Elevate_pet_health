import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNewSetPlansComponent } from './add-new-set-plans.component';

describe('AddNewSetPlansComponent', () => {
  let component: AddNewSetPlansComponent;
  let fixture: ComponentFixture<AddNewSetPlansComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddNewSetPlansComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddNewSetPlansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
