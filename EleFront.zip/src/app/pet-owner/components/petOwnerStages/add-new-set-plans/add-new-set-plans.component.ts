import { NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ToastModule } from 'primeng/toast';
import { ChoosePlans } from '../../../model/wellness-plan';
import { WellnessPlanService } from '../../../service/wellness-plan.service';
import { PetOwnerService } from '../../../service/pet-owner.service';
import { MatButtonModule } from '@angular/material/button';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';

@Component({
  selector: 'app-add-new-set-plans',
  standalone: true,
  imports: [InputSwitchModule, FormsModule, NgFor, ToastModule, NgIf, DialogModule, ButtonModule, MatButtonModule],
  templateUrl: './add-new-set-plans.component.html',
  styleUrl: './add-new-set-plans.component.scss',
  providers: [MessageService]
})
export class AddNewSetPlansComponent {
  choosePlans: ChoosePlans[] = [];
  petId!: number
  checked: boolean = false;

  chossedPlansForManipulations: any[] = []


  totalDiscountedPrice: number = 0;
  firstMonthPayment: number = 0;

  promotionSentence: string = ''

  showTermsDialog: boolean = false;


  constructor(private route: ActivatedRoute, private wellnessPlanSrvice: WellnessPlanService, private messageService: MessageService, private router: Router, private petOwnerSerive: PetOwnerService
  ) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.petId = +params.get('petId')!;
    });
    this.getPlansToAdd();
  }

  getPlansToAdd() {
    this.wellnessPlanSrvice.getAddNewSetPlans(this.petId).subscribe(
      response => {
        console.log("Size is : ", response.length);
        this.choosePlans = response.map(plan => {
          plan.isStatusActive = plan.status === 'ACTIVE';
          return plan;
        });
        this.chossedPlansForManipulations = this.choosePlans
        this.promotionSentence = this.generatePromotionSentence(this.choosePlans[0].promotions);
        console.log(this.choosePlans);
        if (this.chossedPlansForManipulations) {
          this.calculatePriceDetails()
        }

      }
    )
  }
  getPlansToAddForAccept() {
    this.wellnessPlanSrvice.getAddNewSetPlans(this.petId).subscribe(
      response => {
        console.log("Size is : ", response.length);
        this.choosePlans = response.map(plan => {
          plan.isStatusActive = plan.status === 'ACTIVE';
          return plan;
        });
        this.chossedPlansForManipulations = this.choosePlans
        // console.log(this.choosePlans);
        // if (this.chossedPlansForManipulations) {
        //   this.calculatePriceDetails()
        // }

      }
    )
  }


  viewTermsAndConditions() {

    this.showTermsDialog = true;
  }


  agreeTerms(choosePlans: ChoosePlans) {

    this.showTermsDialog = false;
    this.wellnessPlanSrvice.acceptTermsService(choosePlans.managePetWellnessPlanId).subscribe({
      next: (response: string) => {
        console.log(response);
        this.getPlansToAdd();
      }, error: (err) => {
        console.log(err);

      }
    })
    // Perform further actions like API call, updating state, etc.
  }

  disagreeTerms() {

    this.showTermsDialog = false;
    // Handle disagreement logic if needed
  }





  calculatePriceDetails() {
    this.totalDiscountedPrice = this.chossedPlansForManipulations.reduce((sum, plan) => {
      // Get all keys from the wellnessPlanUpdate object
      const discountKeys = Object.keys(plan.wellnessPlanUpdate).filter(key =>
        key.startsWith('discountPriceFor') && !isNaN(parseFloat(plan.wellnessPlanUpdate[key]))
      );

      // Sum up all the matching discountPriceFor* fields
      const totalPlanDiscount = discountKeys.reduce((acc, key) => {
        return acc + parseFloat(plan.wellnessPlanUpdate[key]);
      }, 0);

      return sum + totalPlanDiscount;
    }, 0);

    // Calculate First Month Payment
    this.firstMonthPayment = this.totalDiscountedPrice / 12;
    if (this.promotionSentence) {
      this.firstMonthPayment = this.firstMonthPayment + 0 + 7;
    } else {
      this.firstMonthPayment = this.firstMonthPayment + 49 + 7;
    }


    console.log(this.totalDiscountedPrice);
    console.log(this.firstMonthPayment);
  }

  rejectPlan(petWellnessPlanId: number): void {
    this.wellnessPlanSrvice.updatePetPlanStatus(petWellnessPlanId, 'PET_OWNER_REJECTED').subscribe({
      next: (response) => {
        console.log('Plan rejected successfully:', response);
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Plan rejected successfully!',
        });

        this.getPlansToAdd();
      },
      error: (err) => {
        console.error('Error rejecting plan:', err);
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to reject the plan. Please try again.',
        });
      },
    });
  }

  acceptAllPlans() {
    const ids = this.choosePlans.map((plan) => plan.choosePlanId);

    this.wellnessPlanSrvice.acceptAllPlanStatus(ids, 'NEW_SET_TO_CLINIC').subscribe({
      next: (response) => {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Statuses updated successfully for the provided plans.!',
        });
        this.refresh();
        this.getPlansToAdd();
        this.router.navigate([
          '/petOwners/pet-owher-navhar-layout/pet-profile',
        ]);
      },
    });
  }

  getDynamicPrice(plan: any, type: 'discountPrice' | 'updatedPrice'): string {
    const priceBased = plan.wellnessPlanUpdate?.priceBased?.toUpperCase();

    if (priceBased === 'QTY') {
      return plan.wellnessPlanUpdate[`${type}ForQuantity`] || 'N/A';
    } else if (priceBased === 'WGT') {
      const size = plan.petSize
        ?.toLowerCase()
        ?.split('-')
        .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1))
        .join('');
      const priceField = `${type}For${size}`;
      return plan.wellnessPlanUpdate[priceField] || 'N/A';
    }
    return 'N/A';
  }

  generatePromotionSentence(promotions: string[]): string {
    let sentence = '';

    if (promotions.length === 1) {
      sentence = `The '${promotions[0]}' promotion has been activated for this plan.`;
    } else if (promotions.length > 1) {
      const lastPromotion = promotions.pop(); // Remove last promotion
      const promotionList = promotions.join("', '"); // Join the rest with commas
      sentence = `The '${promotionList}' and '${lastPromotion}' promotions have been activated for this plan.`;
    }
    console.log(sentence);

    return sentence;
  }

  refresh() {
    // console.log('is it refreshed ??');
    this.petOwnerSerive.triggerRefresh();
  }

}
