import { Component, OnInit } from '@angular/core';
import { StripeService } from '../../../../clinic/services/stripe.service';
import { CommonModule } from '@angular/common';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { Cards } from '../../../model/cards';
import { DialogModule } from 'primeng/dialog';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { MatDialog } from '@angular/material/dialog';
import { PetDetailsComponent } from '../pet-details/pet-details.component';

@Component({
  selector: 'app-card-details',
  standalone: true,
  imports: [
    CommonModule,
    ButtonModule,
    DialogModule,
    InputTextModule,
    ToastModule,
  ],
  templateUrl: './card-details.component.html',
  styleUrl: './card-details.component.scss',
  providers: [MessageService],
})
export class CardDetailsComponent implements OnInit {
  cards: Cards[] = [];
  header: string | undefined;
  display: boolean = false;
  selectedCardId!: string;
  cuatomerId = sessionStorage.getItem('stripeCustomerId') || '';

  constructor(
    private stripeService: StripeService,
    private messageService: MessageService,
    private dialog: MatDialog,
  ) {}
  ngOnInit(): void {
    this.loadCards();
  }
  loadCards() {
    this.stripeService.getCards(this.cuatomerId).subscribe((data: any) => {
      this.cards = data;
    });
  }
  openConfirmationDialog(cardId: any): void {
    this.selectedCardId = cardId;
    this.display = true;
  }
  closeDialog(): void {
    this.display = false;
    this.loadCards();
  }

  removeCard() {
    if (this.selectedCardId) {
      const selectedCard = this.cards.find(
        (card) => card.id === this.selectedCardId,
      );
      if (selectedCard?.isDefault === 'true') {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Cannot delete the default payment method.',
        });
        return;
      }
      if (this.cards.length <= 1) {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Cannot delete the last card.',
        });
        return;
      }
      let data = {
        customerId: this.cuatomerId,
        paymentMethodId: this.selectedCardId,
      };
      this.stripeService.removeCard(data).subscribe(
        (doc: any) => {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Card Removed Successfully',
          });
          this.loadCards();
        },
        (error: any) => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Failed to remove card',
          });
        },
      );
      this.closeDialog();
    }
  }
  addNewCard() {
    const dialogRef = this.dialog.open(PetDetailsComponent, {
      width: '1400px',
      height: '550px',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 2) {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to Save card',
        });
      } else {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Card Saved Successfully',
        });
        this.loadCards();
      }
    });
    this.closeDialog();
  }
}
