import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChooseWellnessPlanComponent } from './choose-wellness-plan.component';

describe('ChooseWellnessPlanComponent', () => {
  let component: ChooseWellnessPlanComponent;
  let fixture: ComponentFixture<ChooseWellnessPlanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ChooseWellnessPlanComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChooseWellnessPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
