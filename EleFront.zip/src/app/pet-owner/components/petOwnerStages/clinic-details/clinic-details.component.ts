import { NgFor, NgIf } from "@angular/common";
import { Component } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { PetOwnerService } from "../../../../pet-owner/service/pet-owner.service";
import { LoginService } from "../../../../landing-page/service/login.service";
import {
  ActiveClinic,
  ApprovedClinic
} from "../../../../landing-page/model/clinic-owner-register";
import { SharedService } from "../../../../shared/service/shared.service";
import { FormsModule } from "@angular/forms";
import { MessageService } from "primeng/api";
import { ToastModule } from "primeng/toast";
import { PetDetails } from "../../../model/pet-owner";
import { MatButtonModule } from '@angular/material/button';

interface DynamicImage {
  clinicName: string;
  petName: string;
  petBreed: string;
  dob: string;
  petAge: string;
  weight: string;
  gender: string;
}

interface PetProfileImage {
  petImage: string;
  petId: number;
  navigateTo?: string;
}

interface Clinic {
  clinicId: number;
  clinicName: string;
  address: string;
  zipCode: string;
  city: string;
  state: string | null;
  contactNumber: string;
  email: string;
  qrCode: string | null;
}

@Component({
  selector: "app-clinic-details",
  standalone: true,
  imports: [NgFor, NgIf, FormsModule, ToastModule, MatButtonModule],
  providers: [MessageService],
  templateUrl: "./clinic-details.component.html",
  styleUrl: "./clinic-details.component.scss"
})
export class ClinicDetailsComponent {
  // isExisting:boolean = false;
  // isNew:boolean = false;
  // activeClinics : ActiveClinic[] = [];
  // approvedClinic : ApprovedClinic[] = [];
  // nonApprovedClinic : ApprovedClinic[] = [];
  // regId: string | null = null;
  // selectedClinic?: number;
  // searchTerm: string = '';
  // filteredClinics: any[] = [];
  // clinics: string[] = [
  //   'Clinic A Pet For Cat',
  //   'Clinic B Pet for Dog',
  //   'Clinic C Pet for Cat and Dog',
  //   'Clinic D ',
  // ];
  // constructor(private PetOwnerService : PetOwnerService,private router: Router,private route: ActivatedRoute,private loginService : LoginService,private sharedservice : SharedService,private messageService: MessageService,) {}

  // ngOnInit() {
  //   const registerId = this.sharedservice.getId('id');
  //   this.regId = registerId ? registerId.trim() : null;
  //   this.route.queryParams.subscribe(params => {
  //     this.isExisting = params['existing'] === 'true';
  //     this.isNew = params['new'] === 'true';
  //       console.log('Is Existing:', this.isExisting);
  //   });
  //   this.getClinicDetails();
  //   this.getClinicApproved();
  //   this.searchTerm = '';
  // }
  // routeToAddPet(isClinicId: number){
  //   this.router.navigate(['/petOwners/pet-owher-navhar-layout/add-pet'], { queryParams: { clinicId: isClinicId } });
  // }

  // getClinicApproved(){
  //   const regId = this.regId
  //   this.PetOwnerService.getApprovedClinic(regId).subscribe(
  //     response => {
  //       this.approvedClinic = response.filter((clinic: any) => clinic.status === true);
  //       this.nonApprovedClinic = response.filter((clinic: any) => clinic.status === false);
  //     }
  //    )
  // }
  // getClinicDetails(){
  //   this.loginService.getActiveClinics().subscribe(
  //     response => {
  //        this.activeClinics = response;
  //        this.filteredClinics = response;
  //     }
  //    )
  // }
  // filterClinics() {
  //   const searchTermLower = this.searchTerm.toLowerCase();
  //   this.filteredClinics = this.activeClinics.filter(clinic =>
  //     clinic.clinicName.toLowerCase().includes(searchTermLower) ||
  //     clinic.address.toLowerCase().includes(searchTermLower) ||
  //     clinic.zipCode.toLowerCase().includes(searchTermLower)
  //   );
  //   if (this.filteredClinics.length === 1) {
  //     this.selectedClinic = this.filteredClinics[0].id;
  //   } else if (this.filteredClinics.length === 0) {
  //     this.selectedClinic = undefined;
  //   }
  // }

  // addPetPage(){
  //   const isExisting: boolean = true;
  //   this.router.navigate(['/petOwners/pet-owher-navhar-layout/clinic-details'], { queryParams: { existing: isExisting } });
  // }

  // submitClinic() {
  //   if (this.selectedClinic) {
  //     const clinicPetOwner ={
  //        clinic : {
  //         id: this.selectedClinic
  //       },
  //        petOwner : {
  //         id: this.regId
  //       },
  //     }
  //     this.PetOwnerService.ClinicAndPetOwner(clinicPetOwner).subscribe({
  //       next: (response) => {
  //         this.selectedClinic = undefined;
  //         this.searchTerm = '';
  //         this.filteredClinics = [...this.activeClinics];
  //         this.messageService.add({
  //           severity: 'success',
  //           summary: 'Success',
  //           detail: response,
  //         });
  //       },
  //     });
  //   } else {
  //     console.log('No clinic selected');
  //   }
  // }

  isExisting: boolean = false;
  isNew: boolean = false;
  activeClinics: ActiveClinic[] = [];
  approvedClinic: ApprovedClinic[] = [];
  nonApprovedClinic: ApprovedClinic[] = [];
  // regId: string | null = null;
  selectedClinic?: number;
  searchTerm: string = "";
  filteredClinics: any[] = [];
  clinics: string[] = [
    "Clinic A Pet For Cat",
    "Clinic B Pet for Dog",
    "Clinic C Pet for Cat and Dog",
    "Clinic D "
  ];

  /*
  Clinic Details variables
  **/

  isMoving: boolean = false;
  selectedImage: number = 1;
  selectedPet: DynamicImage | null = null;
  regId: string | null = null;
  petProfileDetails?: PetDetails;
  petProfileImage: PetProfileImage[] = [];
  clinicDetails: Clinic = {
    clinicId: 0,
    clinicName: "",
    address: "",
    zipCode: "",
    city: "",
    state: null,
    contactNumber: "",
    email: "",
    qrCode: null
  };
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private PetOwnerService: PetOwnerService,
    private sharedservice: SharedService,
    private loginService: LoginService,
    private messageService: MessageService
  ) { }

  ngOnInit() {
    //   const registerId = this.sharedservice.getId('id');
    //   this.regId = registerId ? registerId.trim() : null;

    const registerId = this.sharedservice.getId("id");
    this.regId = registerId ? registerId.trim() : null;
    this.getPetImagePetId();
    // this.selectImage(0);

    this.route.queryParams.subscribe(params => {
      this.isExisting = params["existing"] === "true";
      this.isNew = params["new"] === "true";
    });
    this.getClinicDetails();
    this.getClinicApproved();
    this.searchTerm = "";
  }

  navigateToNewClinic() {
    this.router.navigate(['/petOwners/pet-owher-navhar-layout/clinic-details'], { queryParams: { new: true } })
  }

  routeToAddPet(isClinicId: number) {
    this.router.navigate(["/petOwners/pet-owher-navhar-layout/add-pet"], {
      queryParams: { clinicId: isClinicId }
    });
  }

  getPetImagePetId() {
    const petownerId = this.regId;
    this.PetOwnerService.petImagePetId(petownerId).subscribe({
      next: response => {
        this.petProfileImage = response;
        this.getPetDetails(this.petProfileImage[0].petId);

        // this.petProfileImage.push(this.transformedStaticImage);
        if (this.petProfileImage.length > 0) {
          // this.selectImage(0);
        }
      }
    });
  }

  getPetDetails(petId: number) {
    this.PetOwnerService.petDetailsGet(petId).subscribe({
      next: (response: any) => {
        this.clinicDetails = response.clinic;
      },
      error: (err: any) => {
        console.log(err);
      }
    });
  }

  scrollLeft(): void {
    const imageArea = document.querySelector(".image-area");
    if (imageArea) {
      imageArea.scrollBy({
        left: -150, // Adjust the scroll distance as needed
        behavior: "smooth"
      });
    }
  }

  scrollRight(): void {
    const imageArea = document.querySelector(".image-area");
    if (imageArea) {
      imageArea.scrollBy({
        left: 150, // Adjust the scroll distance as needed
        behavior: "smooth"
      });
    }
  }

  /*******
   * 
   * Clinic additions
   * 
   * 
   * 
   * *****/

  getClinicApproved() {
    const regId = this.regId;
    this.PetOwnerService.getApprovedClinic(regId).subscribe(response => {
      this.approvedClinic = response.filter(
        (clinic: any) => clinic.status === true
      );
      this.nonApprovedClinic = response.filter(
        (clinic: any) => clinic.status === false
      );
    });
  }
  getClinicDetails() {
    this.loginService.getActiveClinics().subscribe(response => {
      this.activeClinics = response;
      this.filteredClinics = response;
    });
  }
  filterClinics() {
    const searchTermLower = this.searchTerm.toLowerCase();
    this.filteredClinics = this.activeClinics.filter(
      clinic =>
        clinic.clinicName.toLowerCase().includes(searchTermLower) ||
        clinic.address.toLowerCase().includes(searchTermLower) ||
        clinic.zipCode.toLowerCase().includes(searchTermLower)
    );
    if (this.filteredClinics.length === 1) {
      this.selectedClinic = this.filteredClinics[0].id;
    } else if (this.filteredClinics.length === 0) {
      this.selectedClinic = undefined;
    }
  }

  addPetPage() {
    const isExisting: boolean = true;
    this.router.navigate(
      ["/petOwners/pet-owher-navhar-layout/clinic-details"],
      { queryParams: { existing: isExisting } }
    );
  }

  submitClinic() {
    if (this.selectedClinic) {
      const clinicPetOwner = {
        clinic: {
          id: this.selectedClinic
        },
        petOwner: {
          id: this.regId
        }
      };
      this.PetOwnerService
        .ClinicAndPetOwnerNewMethod(this.regId, this.selectedClinic)
        .subscribe({
          next: response => {
            this.selectedClinic = undefined;
            this.searchTerm = "";
            this.filteredClinics = [...this.activeClinics];
            this.messageService.add({
              severity: "success",
              summary: response,
              detail: response
            });
            this.router.navigate(
              ["/petOwners/pet-owher-navhar-layout/clinic-details"],
              { queryParams: { existing: true } }
            );
          }
        });
    } else {
      console.log("No clinic selected");
    }
  }
}
