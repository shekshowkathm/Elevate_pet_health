import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReActivePlamComponent } from './re-active-plam.component';

describe('ReActivePlamComponent', () => {
  let component: ReActivePlamComponent;
  let fixture: ComponentFixture<ReActivePlamComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReActivePlamComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReActivePlamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
