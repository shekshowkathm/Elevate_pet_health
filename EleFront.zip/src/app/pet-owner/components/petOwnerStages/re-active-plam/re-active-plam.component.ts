import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { StripeService } from '../../../../clinic/services/stripe.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-re-active-plam',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './re-active-plam.component.html',
  styleUrl: './re-active-plam.component.scss',
})
export class ReActivePlamComponent implements OnInit {
  noOfMonthsPaid: Number = 0;
  selectedDate: string | null = null;
  maxDate: string = '';
  minDate: string = '';
  constructor(
    public dialogRef: MatDialogRef<ReActivePlamComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private stripeService: StripeService,
  ) {}
  ngOnInit(): void {
    console.log(this.data);
    const today = new Date();
    this.minDate = today.toISOString().split('T')[0];
    this.stripeService
      .getPaidMonthsForSubscription(this.data)
      .subscribe((doc: any) => {
        this.noOfMonthsPaid = doc;
      });
  }
  onReactivatePlan() {
    let result = {
      startDate: this.selectedDate,
      BillingCycle: 12 - (Number(this.noOfMonthsPaid) || 0),
    };
    this.dialogRef.close(result);
  }
  onClose(){
    this.dialogRef.close(); 
  }
}
