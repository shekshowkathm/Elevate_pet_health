import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrancationDetailsComponent } from './trancation-details.component';

describe('TrancationDetailsComponent', () => {
  let component: TrancationDetailsComponent;
  let fixture: ComponentFixture<TrancationDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TrancationDetailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrancationDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
