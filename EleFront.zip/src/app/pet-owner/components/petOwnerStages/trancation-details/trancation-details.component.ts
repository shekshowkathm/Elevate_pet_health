import { Component, OnInit } from '@angular/core';
import { TrancationService } from '../../../service/trancation.service';
import { TableModule } from 'primeng/table';
import { CommonModule } from '@angular/common';
import { TagModule } from 'primeng/tag';
import { ButtonModule } from 'primeng/button';

@Component({
  selector: 'app-trancation-details',
  standalone: true,
  imports: [TableModule, TagModule, CommonModule, ButtonModule],
  templateUrl: './trancation-details.component.html',
  styleUrl: './trancation-details.component.scss',
})
export class TrancationDetailsComponent implements OnInit {
  public trancation = [];
  constructor(private trancationService: TrancationService) {}
  ngOnInit(): void {
    // const value = sessionStorage.getItem('stripeCustomerId');
    this.getTransactionDetails();
  }
  getTransactionDetails() {
    const value = sessionStorage.getItem('stripeCustomerId');
    this.trancationService
      .getTransactionDetails(value)
      .subscribe((doc: any) => {
        this.trancation = doc.filter((res: { paymentStatus: string; })=>res.paymentStatus!== "active")
      });
  }
  getSeverity(status: string) {
    switch (status) {
      case 'succeeded':
      case 'paid':
        return 'success';
      case 'requires_action':
      case 'incomplete':
      case 'open':
        return 'danger';
      case 'failed':
      case 'unpaid':
      case 'canceled':
        return 'warning';
      default:
        return 'info';
    }
  }
  payNow(list: any) {
    const newWindow = window.open(list.url, '_blank');
    this.paymentStatus(list.id)
  }
  paymentStatus(id:string){
    this.trancationService.getPaymentStatus(id).subscribe((doc:any)=>{
      console.log(doc);
      const paymentStatus = doc[0]?.paymentStatus;
      if (paymentStatus === "paid") {
        window.location.reload();
      }else{
        setTimeout(() => this.paymentStatus(id), 1500);
      }

      
    })
  }
}
