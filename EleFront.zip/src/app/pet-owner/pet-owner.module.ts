import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PetOwnerRoutingModule } from './pet-owner-routing.module';
import { NavbarLayoutComponent } from './components/navbar/navbar-layout/navbar-layout.component';
import { BrowserModule } from '@angular/platform-browser';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';

@NgModule({
  declarations: [

  ],
  imports: [
    CommonModule,
    PetOwnerRoutingModule,
    BrowserModule,
    ToastModule,
    NavbarLayoutComponent

  ],
  providers: [MessageService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class PetOwnerModule { }
