export class SetupData {
    
}

export class WeightRange{
    id?:number;
    petType! : string;
    weight! : string;
    size! : string;
}

export class Breed{
    id? : number;
    petType!: string;
    breed! : string;
    breedType! : string;
    ageForPuppy! : string;
    ageForKitten! : string
    ageForAdult! : string;
    ageForSenior! : string;
}
