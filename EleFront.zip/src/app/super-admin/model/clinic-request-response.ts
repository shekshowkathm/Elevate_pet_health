export interface ClinicRequestResponse {
  registerId?: number;
  clinicId?: number;
  email: string;
  clinicName: string;
  clinicAddress: string;
  contact: string;
  zipcode: string;
  doctor: boolean;
  registerStatus: boolean;
  startDate: string;
}

export interface ElevateSalesRep {
  id?: number;
  Salesrepname: string;
  emailAddress: string;
  contact: string;
  StateCity: string;
  Action: string;
}

export interface ClinicDetails {
  address : string;
  city : string ;
  clinicAdminEmail : string ;
  clinicImage : string ;
  clinicName : string ;
  clinicOwnerEmail : string ;
  contactNumber : string ;
  email : string ;
  id? : number ;
  petOwnerCount : number ;
  noOfWellnessPlans? : number ;
  zipcode : string ;
  discount?: string;
}
export interface ClinicOwnersandClinicAdmins {
  id?: number;
  name: string;
  email: string;
  clinicName: string;
  contactNumber:string;
  city: string;
  profile: string;
  state: string;
  zipcode: string;
  doctor:boolean;
}
export interface showClinicProfile {
  id?: number,
  clinicName: string,
  address: string,
  zipcode: string,
  city: string,
  state: string,
  contactNumber: string,
  email: string,
  clinicImage: string,
  clinicAdminId: number,
  startDate: string,
  endDate: string,
  clinicStatus: boolean,
  qrCode: string,
  salesRepFirstName:string,
  salesRepLastName:string,
  salesRepID: number;
  doctor:boolean;
}
export interface ProfilebyId {
    id?: number,
    firstName?:string
    lastName?:string
    email?: string,
    doctor?: boolean,
    profile?: string,
    designation?: string,
    contactNumber?: string,
    state?: string,
    city?: string,
    zipcode?: string,
    address?:string,
    endDate?: string,
    startDate?: string
    doctorsHistory:DoctorHistory[];
}
export interface DoctorHistory {
  regId: number;
  serviceName: string;
  dropdownName: string;
  fulfilledStatus: string;
  paidAmount: number | null;
  doctorPercentage: string;
  fulfilledOn: string;
  clinicName: string;
  petName: string;
}
export interface ClinicAssociates {
   id?:number
	 name : string
	email : string
	designation : string
	contact :string
  profile : string
	city : string
	state : string
	zipcode : string
	clinicName : string
  clinicEmail : string
}
export interface PetOwners {
   id?:number
	 ownerFirstName : string
   ownerLastName : string
	 email : string
   contact : string
   petName : string
	 petType : string
	petWeight : string
	profile : string
 clinicName : string
	clinicEmail : string
}

export interface Salesrepresponse {
  id?: number;
  salesRepFirstName:string
  salesRepLastName:string
  address: string;
  city: string;
  state: string;
  email:string;
  contactNumber:string;
  registerStatus:boolean;


}
export interface AddClinicDetails {
  firstName: string | null;
  lastName: string | null;
  clinicName: string | null;
  contactNumber: string | null;
  state: string | null;
  stateCode: string | null;
  zipcode: string | null;
  email: string | null;
  address: string | null;
  city: string | null;
  superAdminId: string | null;
  salesRep: string | null;
  salesRepId: string | null;
}
export interface GetDocsResponse {
  documentUrl: string;
  uploadedById: number;
  uploadedByRole: string;
  targetType: string;
  fileSize:string;
  targetId: number ;
  clinicId?: number;
  description: string;
  uploadDate: string;
  id?: number ;
}
export interface PetOwner {
  petOwnerId: number;
  petOwnerFirstName: string;
  petOwnerLastName: string;
  petOwnerEmail: string;
  petOwnerContact: string;
  petOwnerAddress?: string | null;
  petOwnerState?: string | null;
  petOwnerCity?: string | null;
  petOwnerImage: string;
  petOwnerZipcode?: string | null;
  petId: number;
  petName: string;
  petGender: string;
  petType: string;
  petBreed: string;
  petAge: string;
  petDOB: string;
  petWeight: string;
  petProfile: string;
  endDate?: string,
  startDate?: string
  ageGroup: string;
  historyPlans?: PlanSets;
  ongoingPlans?: PlanSets;
  futurePlans?: PlanSets;

}
export interface PlanSets {
  [key: string]: PetPlan[];
}

export interface PetPlan {
  petId: number;
  petWellnessPlanId: number;
  petType: string;
  ageGroup?: string | null;
  wellnessPlanName: string;
  serviceName: string;
  dropdownName: string;
  clinicPrice: string;
  discountPrice: string;
  clinicWellnessUpdate: number;
  clinicWellnessPlan: number;
  scheduledDateAndTime?: string | null;
  fulfilledBy?: string | null;
  fulfilled: boolean;
  startDate?: string | null;
  endDate?: string | null;
  managePetWellnessPlan: number;
  updatedPrice: string;
}
export interface ImageUpload {
  id: number;
  image: string;
  scheduledAt: string;
  uploadedOn: string;
}