export class Promotion {
    promotionId!: number;
    clinicId!: number;
    clinicEmail!: string;
    clinicContact!: string;
    clinicName!: string;
    generateCode!: string;
    generateCodeExpiryCode!: string;
    thirtySixtyNinetyPromotion!: boolean;
    thirtySixtyNinetyStartDate!: Date | null;
    thirtySixtyNinetyEndDate!: Date | null;
    multiPetPromotion!: boolean;
    multiYearPromotion!: boolean;
}
