export class WellnessPlan {
}

export interface ServiceListDTO {
   petType: string;
   service: string;
   dropdown: DropdownDTO[];
 }

export interface DropdownDTO {
   dropdown: string;
   priceBased: string;
   priceForSmall:string;
   priceForMedium:string;
   priceForLarge:string;
   priceForXLarge:string;
   priceForQuantity:string;
   industryStandardPrice: string;
 }

//  for get method
 export class ServiceList {
   id?: number | null;
   petType!: string;
   service!: string;
   dropdowns!: DropdownList[];
   status!: boolean;
 }
// for get method
 export class DropdownList {
   id?: number;
   dropdown! : string;
   priceBased!: string;
   priceForSmall?:string;
   priceForMedium?:string;
   priceForLarge?:string;
   priceForXLarge?:string;
   priceForQuantity?:string;
   industryStandardPrice!: string;
 }

//  for get wellnessplan
export class WellnessPlanResponse {
  id! : number | null;
  petType! : string;
  ageGroup!: string;
  wellnessPlanName! : string;
  service! : ServiceListResponse[];
  status!: boolean
}

export class ServiceListResponse{
   id? : number;
   petType! : string;
   service ! : string;
   dropdown!: DropdownListResponseDTO[]; 
}
export class DropdownListResponseDTO{
    id? : number;
    dropdown! : string;
    priceBased!: string;
    industryStandardPrice!: string;
    recommendation!: string;
}

export class WellnessPlanRequest{
  petType!:string;
  ageGroup! : string;
  wellnessPlanName !: string;
  serviceId ! : number;
  recommendation!: Recommendation[];
}

export class Recommendation{
  dropdownId!:number;
  recommendation!: string
}
