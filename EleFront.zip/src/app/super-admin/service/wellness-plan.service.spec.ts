import { TestBed } from '@angular/core/testing';

import { WellnessPlanService } from './wellness-plan.service';

describe('WellnessPlanService', () => {
  let service: WellnessPlanService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WellnessPlanService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
