import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment.development';
import { Promotion } from '../model/promotion';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PromotionService {

  private getPromotions = environment.apiUrl + '/promotion/getPromotions'
  private getPromotionsAPI = environment.apiUrl + '/promotion/get-clinic-promotion'
  private getPromotionsByClinicAPI = environment.apiUrl + '/promotion/getPromotions/'
  private addPromotionToClinicAPI = environment.apiUrl + '/promotion/add-promotion'
  private generateCodeAPI = environment.apiUrl + '/promotion/generateCode'
  private statusUpdateAPI = environment.apiUrl + '/promotion/updatePromotion'

  constructor(private http: HttpClient) { }

  private getRequestOptions(): { headers: HttpHeaders } {
    let token = '';
    if (typeof window !== 'undefined' && localStorage) {
      token = localStorage.getItem('token') || '';
    }

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: token ? 'Bearer ' + token : '',
    });

    return { headers };
  }

  getAllPromotion(): Observable<Promotion[]> {
    const requestOptions = this.getRequestOptions();

    return this.http.get<Promotion[]>(this.getPromotions, requestOptions)
  }

  getAllNewPromotion(role:string) {
    const requestOptions = this.getRequestOptions();
    const params = new HttpParams()
    .set('role', role)
    return this.http.get(this.getPromotionsAPI, {...requestOptions,params,responseType: 'json'});
  }
  getPromotionByClinicByID(clinicid: string) {
    const requestOptions = this.getRequestOptions();
    return this.http.get(this.getPromotionsByClinicAPI + clinicid, requestOptions);
  }

  addPromotionToClinic(clinic: any) {
    const requestOptions = this.getRequestOptions();
    return this.http.post(this.addPromotionToClinicAPI, clinic, {
      ...requestOptions,
      responseType: 'text', // Specify that the response is of type 'text'
    });
  }
  generateCodeMethod(dateBody: any) {
    const requestOptions = this.getRequestOptions();
    return this.http.post(this.generateCodeAPI, dateBody, {
      ...requestOptions,
      responseType: 'text', // Specify that the response is of type 'text'
    });
  }

  updateStatusAndExpirayDate(statusObject: any) {
    const requestOptions = this.getRequestOptions();
    return this.http.put(this.statusUpdateAPI, statusObject, {
      ...requestOptions,
      responseType: 'text', // Specify that the response is of type 'text'
    })
  }


}
