import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment.development';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, map, Observable, of, Subject } from 'rxjs';
import { ClinicAssociates, ClinicDetails, ClinicOwnersandClinicAdmins, ClinicRequestResponse, GetDocsResponse, ImageUpload, PetOwner, PetOwners, ProfilebyId, Salesrepresponse, showClinicProfile, } from '../model/clinic-request-response';

@Injectable({
  providedIn: 'root'
})
export class SuperAdminService {

  public getClinicRequest = environment.apiUrl + '/register/not-verified-clinic-owners'
  public acceptClinicRegister = environment.apiUrl + '/register/updateRegisterStatus/'
  public clinicStatus = environment.apiUrl + '/clinic-details/updateClinicStatus/'
  public UpdateRep = environment.apiUrl + '/clinic-details/update-salesRep/'
  public addSalesRepApi = environment.apiUrl + '/register/add'
  public getSalesRep = environment.apiUrl + '/register/get-sales-rep'
  public getAllSalesRep = environment.apiUrl + '/register/get-all-rep-list'
  public getAllClinicOwners = environment.apiUrl + '/clinic-details/getAllClinicMembers/CLINIC_OWNER'
  public getClinicsByOwnerId = environment.apiUrl + '/clinic-details/clinic-list-owner'
  public getAllClinicAdmins = environment.apiUrl + '/clinic-details/getAllClinicMembers/CLINIC_ADMIN'
  public getAllClinicAssociates = environment.apiUrl + '/clinic-details/getAllClinicMembers/CLINIC_ASSOCIATE'
  // public getAllClinicAssociates = environment.apiUrl + '/clinic-details/getAllAssociates'
  public getAllPetOwner = environment.apiUrl + '/pet-detials/getAllPetOwners'
  public petProfilewithWellnessPlan = environment.apiUrl + '/clinic-details/getPetById'
  public getAllClinics = environment.apiUrl + '/clinic-details/clinic-list-details'
  public addClinicSAapi = environment.apiUrl + '/clinic-details/add-clinic-super-admin'
  public showClinicSAapi = environment.apiUrl + '/clinic-details/get-Clinic'
  public showById = environment.apiUrl + '/clinic-details/get-profile'
  public updateSuperAdminProfile = environment.apiUrl + '/register/update-profile'
  public getClinisOfRep = environment.apiUrl + '/clinic-details/elevate-rep-clinic-list'
  public addFilesToAllClinics = environment.apiUrl + '/api/documents/upload'
  public getAllClinicsDocsBySA = environment.apiUrl + '/api/documents/superadmin/allclinics'
  public getDocsBySAToClinic = environment.apiUrl + '/api/documents/superadmin/clinic'
  public getDocsByClinicToSA = environment.apiUrl + '/api/documents/clinic'
  public getHeadQuarterUrl = environment.apiUrl + '/clinic-details/getHeadquaters'
  public deleteRep = environment.apiUrl + '/register/status-update'
  public dashboardCountAPI = environment.apiUrl + '/counts/superAdmin'
  public uploadImageSubscriptionMailSender = environment.apiUrl + '/subscribe/addImages'
  public getSubscriptionMailSenderImages = environment.apiUrl + '/subscribe/getAllNewsLetters'

  constructor(private http: HttpClient) { }

  /**
   * @param token
   */
  private getRequestOptions(): { headers: HttpHeaders } {
    let token = '';

    if (typeof window !== 'undefined' && localStorage) {
      token = localStorage.getItem('token') || '';
    }

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': token ? `Bearer ${token}` : '',
    });

    return { headers };
  }


  /**
   * @param ClinicRegisterRequest
   */
  getAllClinicRequests(): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<ClinicRequestResponse>(this.getClinicRequest, requestOptions);
  }

  /**
     * @param refreshnotificationscount
     */
  private triggerSource = new Subject<void>();
  trigger$ = this.triggerSource.asObservable();

  triggerMethodInAnotherComponent() {
    this.triggerSource.next();
  }

  /**
   * @param getsalesrep
   */
  getAllReps(): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<Salesrepresponse>(this.getSalesRep, requestOptions);
  }
  /**
   * @param getAllsalesrep
   */
  getTotalSalesReps(): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<Salesrepresponse>(this.getAllSalesRep, requestOptions);
  }

  /**
   * @param updateRegisterStatus
   */

  updateClinicRegisterStatus(registerId: number): Observable<string> {
    const requestOptions = this.getRequestOptions();
    const acceptUrl = `${this.acceptClinicRegister}${registerId}`;
    return this.http.put(acceptUrl, null, { ...requestOptions, responseType: 'text' });
  }


  /**
   * @param updateRequestToClinic
   */
  updateClinic(clinicId: number, saleRepId: number): Observable<string> {
    const requestOptions = this.getRequestOptions();
    const clinicStatusUrl = `${this.clinicStatus}${clinicId}/${saleRepId}`;
    return this.http.put(clinicStatusUrl, null, { ...requestOptions, responseType: 'text' });
  }

  /**
   * @param updateREP
   */
  updateSalesRep(clinicId: number, saleRepId: number): Observable<string> {
    const requestOptions = this.getRequestOptions();
    const changeReps = `${this.UpdateRep}${clinicId}/${saleRepId}`;
    return this.http.put(changeReps, null, { ...requestOptions, responseType: 'text' });
  }
  /**
   *
   * @param AddSalesRep
   */
  addSaleRep(salesRep: string): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const requestBody = JSON.stringify(salesRep);
    return this.http.post(this.addSalesRepApi, requestBody, { headers: requestOptions.headers, responseType: 'text' })
  }

  /**
  *
  * @param ClinicdirectlybySA
  */
  addClinic(clinic: string): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const requestBody = JSON.stringify(clinic);
    return this.http.post(this.addClinicSAapi, requestBody, { headers: requestOptions.headers, responseType: 'text' })
  }

  // clinics
  /**
   *
   * @param GetAllClinicsdetails
   */
  clinicDetails(): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<ClinicDetails>(this.getAllClinics, requestOptions);
  }

  /**
   *
   * @param GetAllClinicsOwner
   */
  ClinicOwners(): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<ClinicOwnersandClinicAdmins>(this.getAllClinicOwners, requestOptions);

  }

  /**
   *
   * @param GetAllClinicsAdmin
   */
  ClinicAdmins(): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<ClinicOwnersandClinicAdmins>(this.getAllClinicAdmins, requestOptions);

  }
  /**
     *
     * @param GetAllClinicsAssociates
     */
  ClinicAssociates(): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<ClinicAssociates>(this.getAllClinicAssociates, requestOptions);

  }

  /**
     *
     * @param GetAllClinicsAssociates
     */
  allPetOwner(): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<PetOwners>(this.getAllPetOwner, requestOptions);
  }

  /**
     *
     * @param showClinicbyID
     */
  showProfileById(clinicId: number): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const withIdUrl = `${this.showClinicSAapi}/${clinicId}`
    return this.http.get<showClinicProfile>(withIdUrl, requestOptions);
  }


  /**
     *
     * @param showprofilegetbyID
     */
  showPersonProfileById(selectedId: any): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const withPersonalIdUrl = `${this.showById}/${selectedId}`
    return this.http.get<ProfilebyId>(withPersonalIdUrl, requestOptions);
  }
  /**
     *
     * @param GetAllClinicsofOwner
     */
  allClinicsOfOwner(ownerId: number): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const OwnerIdTogetClinics = `${this.getClinicsByOwnerId}/${ownerId}`
    return this.http.get<ClinicDetails>(OwnerIdTogetClinics, requestOptions);

  }
  /**
     *
     * @param PetofPetOwnerwithwellnessplan
     */
  petOfPetOwnerWithWellness(petId: Number, PetownerId: number): Observable<any> {
    const requestOptions = { ...this.getRequestOptions(), responseType: 'text' as 'json' };
    const petProfileWithWellnessplan = `${this.petProfilewithWellnessPlan}/${petId}/${PetownerId}`
    return this.http.get<PetOwner>(petProfileWithWellnessplan, requestOptions);

  }

  /**
     *
     * @param UpdateSAProfile
     */

  updateProfile(updatedValue: ProfilebyId) {
    const requestOptions = this.getRequestOptions();
    return this.http.put(this.updateSuperAdminProfile, updatedValue, {
      headers: requestOptions.headers,
      responseType: 'text'
    });
  }


  /**
   *
   * @param ClinicsOfRep
   */
  getAllClinicsOfRep(repId: number): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const RepsIdtoGetClinics = `${this.getClinisOfRep}/${repId}`
    return this.http.get<ClinicDetails>(RepsIdtoGetClinics, requestOptions);
  }
  /**
     *
     * @param addDoctoAllClinics
     */
  uploadfilesToAllclinics(payload: {}): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const requestBody = JSON.stringify(payload);
    return this.http.post(this.addFilesToAllClinics, requestBody, { headers: requestOptions.headers, responseType: 'text' })
  }

  /**
     *
     * @param getDocAllClinics
     */
  getAllDocsOfClinicBySA(): Observable<any> {
    const requestOptions = this.getRequestOptions();

    return this.http.get<GetDocsResponse>(this.getAllClinicsDocsBySA, requestOptions,)
  }

  /**
     *
     * @param getDocsUploadedBySuperAdminToClinic
     */
  getDocsOfSAtoClinics(clinicId: number): Observable<any> {
    if (clinicId) {
      const requestOptions = this.getRequestOptions();
      const getDocsUploadedBySAtoClinic = `${this.getDocsBySAToClinic}/${clinicId}`
      return this.http.get<GetDocsResponse>(getDocsUploadedBySAtoClinic, requestOptions);
    } else {
      // Return an empty observable or handle the case where clinicId is not present
      return of(null); // 'of' creates an observable that emits 'null'
    }

  }
  /**
     *
     * @param getDocsUploadedByClinicToSuperAdmin
     */
  getDocsOfClinicsToSA(clinicId: number): Observable<any> {
    if (clinicId) {
      const requestOptions = this.getRequestOptions();
      const getDocsUploadedBySAtoClinic = `${this.getDocsByClinicToSA}/${clinicId}/superadmin`
      return this.http.get<GetDocsResponse>(getDocsUploadedBySAtoClinic, requestOptions);
    } else {
      // Return an empty observable or handle the case where clinicId is not present
      return of(null); // 'of' creates an observable that emits 'null'
    }
  }

  getAllHeadQuarters(): Observable<any[]> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any[]>(this.getHeadQuarterUrl, requestOptions);
  }

  deleteSalesRep(repId: number): Observable<string> {
    const requestOptions = { ...this.getRequestOptions(), responseType: 'text' as 'json' };
    const selectedRep = `${this.deleteRep}/${repId}`
    return this.http.put<string>(selectedRep, null, requestOptions);


  }


  /**
   * @param getsalesrep
   */
  getAllCountOfSuperAdmin(): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(this.dashboardCountAPI, requestOptions);
  }

  /**
   *
   * @param AddImageSubscriptionMailSender
   */
  UploadPictureSubscriptionMailSender(payload: string): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const requestBody = JSON.stringify(payload);
    return this.http.post(this.uploadImageSubscriptionMailSender, requestBody, { headers: requestOptions.headers, responseType: 'text' })
  }
  
   /**
   *
   * @param GetSubscriptionMailSenderImages
   */
   fetchImagesSubscriptionMailSender(): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<ImageUpload>(this.getSubscriptionMailSenderImages, requestOptions);

  }

}
