import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Breed, WeightRange } from '../model/setup-data';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment.development';
import { ServiceList, ServiceListDTO, WellnessPlanRequest, WellnessPlanResponse } from '../model/wellness-plan';

@Injectable({
  providedIn: 'root'
})
export class WellnessPlanService {

  private addWeightRangeUrl = environment.apiUrl + '/weightRange/add'
  private getWeightRangeUrl = environment.apiUrl + '/weightRange/getAll'
  private updateWeightRangeUrl = environment.apiUrl + '/weightRange/update'
  private deleteWeightRangeUrl = environment.apiUrl + '/weightRange/delete'
  private addBreedUrl = environment.apiUrl + '/breed/add'
  private getBreedUrl = environment.apiUrl + '/breed/getAll'
  private updateBreedUrl = environment.apiUrl +'/breed/update'
  private deleteBreedUrl = environment.apiUrl + '/breed/delete'
  private addServiceUrl = environment.apiUrl + '/service/add'
  private getServiceUrl = environment.apiUrl + '/service/getAllServices'
  private updateServiceUrl = environment.apiUrl + '/service/update'
  private deleteServiceUrl = environment.apiUrl + '/service/deleteService'
  private addWellnessPlanUrl = environment.apiUrl + '/wellnessPlan/add'
  private getWellnessPlanUrl = environment.apiUrl + '/wellnessPlan/getAll'
  private updateWellnessPlanUrl = environment.apiUrl + '/wellnessPlan/updateWellnessPlan'
  private deleteWellnessPlanUrl = environment.apiUrl + '/wellnessPlan/delete'
  private getAvailableServicesUrl = environment.apiUrl + '/wellnessPlan/availableServices'
  constructor(private http : HttpClient) { }

  private getRequestOptions(): { headers: HttpHeaders } {
    let token = '';
    if (typeof window !== 'undefined' && localStorage) {
      token = localStorage.getItem('token') || '';
    }

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: token ? 'Bearer ' + token : '',
    });

    return { headers };
  }

  addWeightRange(weightRange : WeightRange) : Observable<string>{
    const requestOptions = this.getRequestOptions();
    return this.http.post<string>(this.addWeightRangeUrl , weightRange , {...requestOptions,responseType: 'text' as 'json'});
  }

  getAllWeightRange() : Observable<WeightRange[]>{
     const requestOptions = this.getRequestOptions();
     return this.http.get<WeightRange[]>(this.getWeightRangeUrl , requestOptions)
  }

  updateWeightRanges(updateWeightRange: WeightRange) : Observable<string>{
     const requestOptions = this.getRequestOptions();
     return this.http.put<string>(this.updateWeightRangeUrl, updateWeightRange , {...requestOptions,responseType: 'text' as 'json'})
  }

  deleteWeightRange(id : number) : Observable<string> {
     const requestOptions = this.getRequestOptions();
     const deleteUrl = `${this.deleteWeightRangeUrl}/${id}`; 
     return this.http.delete<string>(deleteUrl , {...requestOptions,responseType: 'text' as 'json'})
  }

  addBreed(breed : Breed ) : Observable<string>{
    const requestOptions = this.getRequestOptions();
    return this.http.post<string>(this.addBreedUrl , breed ,{...requestOptions , responseType: 'text' as 'json'}  );
  }

  getAllBreed() : Observable<Breed[]>{
    const requestOptions = this.getRequestOptions();
    return this.http.get<Breed[]>(this.getBreedUrl , requestOptions)
 }

 updateBreed(breed: Breed) : Observable<string>{
  const requestOptions = this.getRequestOptions();
  return this.http.put<string>(this.updateBreedUrl, breed,{...requestOptions , responseType: 'text' as 'json'} )
 }

 deleteBreed(id : number) : Observable<string> {
  const requestOptions = this.getRequestOptions();
  const deleteUrl = `${this.deleteBreedUrl}/${id}`; 
  
  return this.http.delete<string>(deleteUrl , {...requestOptions,responseType: 'text' as 'json'})
 }

  addServiceList(serviceListDto: ServiceListDTO): Observable<string> {
    const requestOptions = this.getRequestOptions();
    return this.http.post<string>(this.addServiceUrl, serviceListDto, {...requestOptions,responseType: 'text' as 'json'});
  }
  
  getAllServices() : Observable<ServiceList[]>{
    const requestOptions = this.getRequestOptions();
    return this.http.get<ServiceList[]>(this.getServiceUrl , requestOptions)
  }

  updateServiceList(updateService : ServiceList) : Observable<string>{
     const requestOptions = this.getRequestOptions();
     return this.http.put<string>(this.updateServiceUrl , updateService, {...requestOptions,responseType: 'text' as 'json'} )
  }

  deleteServiceList(id : number) : Observable<string> {
    const requestOptions = this.getRequestOptions();
    const deleteUrl = `${this.deleteServiceUrl}/${id}`; 
    return this.http.delete<string>(deleteUrl , {...requestOptions,responseType: 'text' as 'json'})
 }

  addWellnessPlan(wellnessPlan : WellnessPlanRequest) : Observable<string>{
    const requestOptions = this.getRequestOptions();
    return this.http.post<string>(this.addWellnessPlanUrl, wellnessPlan, {...requestOptions,responseType: 'text' as 'json'});
  }
  getAllWellnessPlan() : Observable<WellnessPlanResponse[]>{
    const requestOptions = this.getRequestOptions();
    return this.http.get<WellnessPlanResponse[]>(this.getWellnessPlanUrl , requestOptions)
  }

  updateWellnessPlan(wellnessPlan : WellnessPlanResponse) : Observable<string>{
    const requestOptions = this.getRequestOptions();
    return this.http.put<string>(this.updateWellnessPlanUrl , wellnessPlan, {...requestOptions,responseType: 'text' as 'json'} )
 }

 deleteWellnessPlan(id : number) : Observable<string> {
  const requestOptions = this.getRequestOptions();
  const deleteUrl = `${this.deleteWellnessPlanUrl}/${id}`; 
  return this.http.delete<string>(deleteUrl , {...requestOptions,responseType: 'text' as 'json'})
}

getAvailableServices(wellnessPlanName : string) : Observable<ServiceList[]>{
   const requestOptions = this.getRequestOptions();
   const availableServiceUrl = `${this.getAvailableServicesUrl}/${wellnessPlanName}`;
   return this.http.get<ServiceList[]>(availableServiceUrl , requestOptions)
}

}
