import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { SuperAdminLayoutComponent } from "./components/super-admin-layout/super-admin-layout.component";
import { NotificationSuperAdminComponent } from "./components/notification-super-admin/notification-super-admin.component";
import { SaDashboardComponent } from "./components/sa-dashboard/sa-dashboard.component";
import { ElevateSalesRepComponent } from "./components/elevate-sales-rep/elevate-sales-rep.component";
import { SaClinicOwnersComponent } from "./components/sa-clinic-owners/sa-clinic-owners.component";
import { SaClinicAdminComponent } from "./components/sa-clinic-admin/sa-clinic-admin.component";
import { SaClinicAssociatesComponent } from "./components/sa-clinic-associates/sa-clinic-associates.component";
import { SaPetownersComponent } from "./components/sa-petowners/sa-petowners.component";
import { SaClinicdetailsComponent } from "./components/sa-clinicdetails/sa-clinicdetails.component";
import { AddSalesRepComponent } from "./components/add-sales-rep/add-sales-rep.component";
import { AddclinicbySAComponent } from "./components/addclinicby-sa/addclinicby-sa.component";
import { ShowprofileComponent } from "./components/showprofile/showprofile.component";
import { SetupDataComponent } from "./components/setup-data/setup-data.component";
import { ServicelistComponent } from "./components/servicelist/servicelist.component";
import { PromotiondiscountComponent } from "./components/promotiondiscount/promotiondiscount.component";
import { ClinicDetailsForDiscountsComponent } from "./components/clinic-details-for-discounts/clinic-details-for-discounts.component";
import { StripeComponent } from "./components/stripe/stripe.component";
import { CreditCardDetailsComponent } from "./components/credit-card-details/credit-card-details.component";
import { DashboardComponent } from "./components/dashboard/dashboard.component";
import { PaymentsHistoryComponent } from "./components/payments-history/payments-history.component";
import { sub } from "date-fns";
import { SubscriptionMailSenderComponent } from "./components/subscription-mail-sender/subscription-mail-sender.component";

const routes: Routes = [
  {
    path: "",
    component: SuperAdminLayoutComponent,

    children: [
      {
        path: "superAdminNotification",
        component: NotificationSuperAdminComponent
      },
      {
        path: "setUpData",
        component: SetupDataComponent
      },
      {
        path: "servicelist",
        component: ServicelistComponent
      },
      {
        path: "promotion-discount",
        component: PromotiondiscountComponent
      },
      {
        path: "clinic-details-for-discount/:clinicId",
        component: ClinicDetailsForDiscountsComponent
      },
      {
        path: "",
        component: SaDashboardComponent
      },
      {
        path: "elevateSalesRepComponent",
        component: ElevateSalesRepComponent
      },
      {
        path: "saclinicowners",
        component: SaClinicOwnersComponent
      },
      {
        path: "saclinicAdmins",
        component: SaClinicAdminComponent
      },
      {
        path: "saclinicAssociates",
        component: SaClinicAssociatesComponent
      },
      {
        path: "sapetOwners",
        component: SaPetownersComponent
      },
      {
        path: "saclinicdetails",
        component: SaClinicdetailsComponent
      },
      {
        path: "addSalesRep",
        component: AddSalesRepComponent
      },
      {
        path: "addClinic",
        component: AddclinicbySAComponent
      },
      {
        path: "showProfile",
        component: ShowprofileComponent
      },
      {
        path: "stripe",
        component: StripeComponent
      },
      {
        path: "cardDetails",
        component: CreditCardDetailsComponent
      },
      {
        path: "stripe-dash",
        component: DashboardComponent
      },
      {path:"history",component:PaymentsHistoryComponent},
      {
        path:"subscriptionMailSender",
        component:SubscriptionMailSenderComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SuperAdminRoutingModule {}
