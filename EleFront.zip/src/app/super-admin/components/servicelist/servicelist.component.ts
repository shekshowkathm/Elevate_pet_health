import { NgIf, NgFor, NgClass, CurrencyPipe } from '@angular/common';
import { ChangeDetectorRef, Component } from '@angular/core';
import {
  ReactiveFormsModule,
  FormsModule,
  FormGroup,
  Validators,
  FormBuilder,
  FormArray,
  FormControl,
} from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';
import { TabViewModule } from 'primeng/tabview';
import { ToastModule } from 'primeng/toast';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import {
  DropdownListResponseDTO,
  ServiceList,
  ServiceListDTO,
  ServiceListResponse,
  WellnessPlanRequest,
  WellnessPlanResponse,
} from '../../model/wellness-plan';
import { WellnessPlanService } from '../../service/wellness-plan.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { CardModule } from 'primeng/card';
import { SharedService } from '../../../shared/service/shared.service';

@Component({
  selector: 'app-servicelist',
  standalone: true,
  imports: [
    TableModule,
    TabViewModule,
    NgIf,
    NgFor,
    MatSlideToggleModule,
    ReactiveFormsModule,
    FormsModule,
    InputTextModule,
    NgClass,
    ToastModule,
    ConfirmDialogModule,
    CardModule,
    CurrencyPipe,
  ],
  templateUrl: './servicelist.component.html',
  styleUrl: './servicelist.component.scss',
  providers: [MessageService, ConfirmationService],
})
export class ServicelistComponent {
  activeTab: string = 'serviceList';
  services: ServiceList[] = [];
  filterServices: ServiceList[] = [];
  petTypeFilter: string = '';
  serviceNameFilter: string = '';
  wellnessNameFilter: string = '';
  petTypeFilterWellnessPlan: string = '';
  wellnessPlans: WellnessPlanResponse[] = [];
  filterWellnessPlan: WellnessPlanResponse[] = [];
  serviceDropdownOptions: any[] = [];
  showServiceForm: boolean = false;
  showWellnessPlanForm: boolean = false;
  serviceForm!: FormGroup;
  wellnessPlanForm!: FormGroup;
  checked = false;
  disabled = false;
  petTypes = ['Dog', 'Cat'];
  ageGroups = ['Puppy', 'Kitten', 'Adult', 'Senior'];
  selectedServiceDetails: any = { dropdowns: [] };
  selectedServiceId!: number | null;
  editMode = false;
  selectedPlan!: WellnessPlanResponse;
  selectedWellnessPlanId!: number | null;
  updateMethod: boolean = false;
  addMethod: boolean = true;
  availableServices : ServiceList[] = [];

  constructor(
    private fb: FormBuilder,
    private wellnessPlanService: WellnessPlanService,
    private messageService: MessageService,
    private cdr: ChangeDetectorRef,
    private confirmationService: ConfirmationService,
    private sharedservice: SharedService
  ) {
    this.serviceForm = this.fb.group({
      petType: ['', Validators.required],
      serviceName: ['', Validators.required],
      items: this.fb.array([]),
    });
    this.wellnessPlanForm = this.fb.group({
      petType: ['', Validators.required],
      ageGroup: ['', Validators.required],
      wellnessPlanName: [{ value: '', disabled: true }],
      serviceList: ['', Validators.required],
      items: this.fb.array([
        this.fb.group({
          id: [''],
          dropdown: [''],
          industryStandardPrice: [''],
          priceBased: [''],
          recommendation: [''],
        }),
      ]),
      // recommendations: [''],
    });
  }

  ngOnInit() {
    this.addFields();
    this.fetchServices();
    this.fetchWellnessPlan();
    this.wellnessPlanForm.get('petType')?.valueChanges.subscribe(() => {
      this.updateWellnessPlanName();
    });

    this.wellnessPlanForm.get('ageGroup')?.valueChanges.subscribe(() => {
      this.updateWellnessPlanName();
    });
  }

  openServiceForm() {
    this.resetServiceForm();
    this.showServiceForm = true;
  }

  resetServiceForm(): void {
    this.serviceForm.reset();
    const itemsArray = this.serviceForm.get('items') as FormArray;
    while (itemsArray.length) {
      itemsArray.removeAt(0);
    }
    this.addFields();
    this.editMode = false;
    this.selectedServiceId = null;
  }

  openWellnessPlanForm() {
    this.resetWellnessPlanForm();
    this.showWellnessPlanForm = true;
  }

  resetWellnessPlanForm(): void {
    this.wellnessPlanForm.reset();
    const itemsArray = this.wellnessPlanForm.get('items') as FormArray;
    while (itemsArray.length) {
      itemsArray.removeAt(0);
    }
    itemsArray.push(this.fb.group({
      id: [''],
      dropdown: [''],
      industryStandardPrice: [''],
      priceBased: [''],
      recommendation: [''],
    }));
    this.editMode = false;
    this.selectedWellnessPlanId = null;
    this.selectedServiceDetails = { dropdowns: [] };
  }

  toggleWellnessPlanForm() {
    this.showWellnessPlanForm = !this.showWellnessPlanForm;
  }

  toggleForm() {
    this.showServiceForm = !this.showServiceForm;
  }

  addFields(): void {
    const itemGroup = this.fb.group({
      dropdown: ['', Validators.required],
      priceBased: ['', Validators.required],
      industryStandardPrice: [null, [Validators.required, Validators.min(0)]],
      priceForQuantity: [''],
      priceForSmall: [''],
      priceForMedium: [''],
      priceForLarge: [''],
      priceForXLarge: [''],
    });

    itemGroup.get('priceBased')?.valueChanges.subscribe((value) => {
      this.togglePriceFields(itemGroup, value as string);
    });

    itemGroup
      .get('industryStandardPrice')
      ?.valueChanges.subscribe((industryPrice) => {
        if (itemGroup.get('priceBased')?.value === 'QTY') {
          itemGroup.get('priceForQuantity')?.setValue(industryPrice || '');
        }
      });

    (this.serviceForm.get('items') as FormArray).push(itemGroup);
  }

  togglePriceFields(itemGroup: FormGroup, value: string): void {
    this.clearQTYField(itemGroup);
    this.clearWGTFields(itemGroup);

    if (value === 'QTY') {
      itemGroup.get('priceForQuantity')?.setValidators([Validators.required]);
    } else if (value === 'WGT') {
      itemGroup.get('priceForSmall')?.setValidators([Validators.required]);
      itemGroup.get('priceForMedium')?.setValidators([Validators.required]);
      itemGroup.get('priceForLarge')?.setValidators([Validators.required]);
      itemGroup.get('priceForXLarge')?.setValidators([Validators.required]);
    }

    itemGroup.get('priceForQuantity')?.updateValueAndValidity();
    itemGroup.get('priceForSmall')?.updateValueAndValidity();
    itemGroup.get('priceForMedium')?.updateValueAndValidity();
    itemGroup.get('priceForLarge')?.updateValueAndValidity();
    itemGroup.get('priceForXLarge')?.updateValueAndValidity();
  }

  clearQTYField(itemGroup: FormGroup): void {
    itemGroup.get('priceForQuantity')?.clearValidators();
    itemGroup.get('priceForQuantity')?.updateValueAndValidity();
  }

  clearWGTFields(itemGroup: FormGroup): void {
    itemGroup.get('priceForSmall')?.clearValidators();
    itemGroup.get('priceForMedium')?.clearValidators();
    itemGroup.get('priceForLarge')?.clearValidators();
    itemGroup.get('priceForXLarge')?.clearValidators();
    itemGroup.get('priceForSmall')?.updateValueAndValidity();
    itemGroup.get('priceForMedium')?.updateValueAndValidity();
    itemGroup.get('priceForLarge')?.updateValueAndValidity();
    itemGroup.get('priceForXLarge')?.updateValueAndValidity();
  }

  isQTY(index: number): boolean {
    return this.items.at(index).get('priceBased')?.value === 'QTY';
  }

  isWGT(index: number): boolean {
    return this.items.at(index).get('priceBased')?.value === 'WGT';
  }

  onPriceBasedChange(index: number): void {
    const selectedValue = this.serviceForm.get(
      `items.${index}.priceBased`,
    )?.value;

    if (selectedValue !== undefined) {
      if (selectedValue === 'QTY') {

      } else if (selectedValue === 'WGT') {

      }
    }
  }

  removeFields(index: number): void {
    (this.serviceForm.get('items') as FormArray).removeAt(index);
  }

  get items(): FormArray {
    if (this.updateMethod) {
      return this.wellnessPlanForm.get('items') as FormArray;
    } else {
      return this.serviceForm.get('items') as FormArray;
    }
  }

  isFieldInvalid(index: number, field: string): boolean {
    const control = this.serviceForm.get(`items.${index}.${field}`);
    return control ? control.invalid && control.touched : false;
  }

  onSubmit() {
    if (this.serviceForm.valid) {
      const serviceListDto: ServiceListDTO = {
        petType: this.serviceForm.value.petType,
        service: this.serviceForm.value.serviceName,
        dropdown: this.serviceForm.value.items.map((item: any) => ({
          dropdown: item.dropdown,
          priceBased: item.priceBased,
          priceForSmall: item.priceForSmall ? `${item.priceForSmall}` : '',
          priceForMedium: item.priceForMedium ? `${item.priceForMedium}` : '',
          priceForLarge: item.priceForLarge ? `${item.priceForLarge}` : '',
          priceForXLarge: item.priceForXLarge ? `${item.priceForXLarge}` : '',
          priceForQuantity: item.priceForQuantity
            ? `${item.priceForQuantity}`
            : '',
          industryStandardPrice: `${item.industryStandardPrice}`,
        })),
      };


      this.wellnessPlanService.addServiceList(serviceListDto).subscribe({
        next: (response) => {
          this.fetchServices();
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Breed Added Successfully',
          });
          this.showServiceForm = false;
          this.serviceForm.reset();
        },
        error: (error) => {

        },
      });
    }
  }

  fetchServices() {
    this.wellnessPlanService.getAllServices().subscribe(
      (data: ServiceList[]) => {
        this.services = data;
        this.filterServices = [...data];
      },
      (error) => {

      },
    );
  }
  exportToExcelServiceList() {
    this.sharedservice.exportAsExcelFile(this.services, 'Service-List');
  }

  applyCombinedFilter() {
    if (!this.petTypeFilter && !this.serviceNameFilter) {
      this.filterServices = [...this.services];
    } else {
      this.filterServices = this.services.filter((service) => {
        const matchesPetType =
          !this.petTypeFilter ||
          service.petType
            .toLowerCase()
            .includes(this.petTypeFilter.toLowerCase());
        const matchesServiceName =
          !this.serviceNameFilter ||
          service.service
            .toLowerCase()
            .includes(this.serviceNameFilter.toLowerCase());

        return matchesPetType && matchesServiceName;
      });
    }
  }
  clearPetTypeFilterSL(){
    this.petTypeFilter = ''
    this.applyCombinedFilter();
  }
  clearServiceFilterSL(){
    this.serviceNameFilter = ''
    this.applyCombinedFilter();
  }

  isNoData(): boolean {
    return this.filterServices.length === 0;
  }

  onUpdate() {
    if (this.serviceForm.valid) {
      const updatedService: ServiceList = {
        id: this.selectedServiceId,
        petType: this.serviceForm.value.petType,
        service: this.serviceForm.value.serviceName,
        dropdowns: this.serviceForm.value.items.map((item: any) => ({
          id: item.id,
          dropdown: item.dropdown,
          priceBased: item.priceBased,
          industryStandardPrice: `${item.industryStandardPrice}`,
          priceForSmall: item?.priceForSmall ?? '',
          priceForMedium: item?.priceForMedium ?? '',
          priceForLarge: item?.priceForLarge ?? '',
          priceForXLarge: item?.priceForXLarge ?? '',
          priceForQuantity: item?.priceForQuantity ?? '',
        })),
        status: true,
      };
      const dropdownIds = updatedService.dropdowns.map(
        (dropdown) => dropdown.id,
      );
      this.wellnessPlanService.updateServiceList(updatedService).subscribe({
        next: (response) => {
          this.fetchServices();
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Service Updated Successfully',
          });
          this.showServiceForm = false;
          this.serviceForm.reset();
          this.editMode = false;
        },
        error: (error) => {

        },
      });
    }
  }

  fetchWellnessPlan() {
    this.wellnessPlanService.getAllWellnessPlan().subscribe(
      (data: WellnessPlanResponse[]) => {
        this.wellnessPlans = data;
        this.filterWellnessPlan = [...this.wellnessPlans];
      },
      (error) => {

      },
    );
  }
  exportToExcelWellness() {
    this.sharedservice.exportAsExcelFile(this.wellnessPlans, 'Wellness-Plan');
  }

  applyCombinedFilterWellnessPlan() {
    if (
      !this.petTypeFilter &&
      !this.wellnessNameFilter &&
      !this.serviceNameFilter
    ) {
      this.filterWellnessPlan = [...this.wellnessPlans];
    } else {
      this.filterWellnessPlan = this.wellnessPlans.filter((plan) => {
        const petTypeMatch =
          !this.petTypeFilter ||
          plan.petType.toLowerCase().includes(this.petTypeFilter.toLowerCase());
        const wellnessNameMatch =
          !this.wellnessNameFilter ||
          plan.wellnessPlanName
            .toLowerCase()
            .includes(this.wellnessNameFilter.toLowerCase());

        const serviceMatch =
          !this.serviceNameFilter ||
          plan.service.some((svc) =>
            svc.service
              .toLowerCase()
              .includes(this.serviceNameFilter.toLowerCase()),
          );

        return petTypeMatch && wellnessNameMatch && serviceMatch;
      });
    }
  }
  clearPetTypeFilterWP(){
    this.petTypeFilter = ''
    this.applyCombinedFilterWellnessPlan();
  }
  clearWellnessNameFilterWP(){
    this.wellnessNameFilter = ''
    this.applyCombinedFilterWellnessPlan();
  }
  clearServiceNameFilterWP(){
    this.serviceNameFilter = ''
    this.applyCombinedFilterWellnessPlan();
  }

  isNoWellnesPlan(): boolean {
    return this.filterWellnessPlan.length === 0;
  }

  onPetTypeChange() {
    this.updateWellnessPlanName();
  }

  onAgeGroupChange() {
    this.updateWellnessPlanName();
  }

  updateWellnessPlanName() {
    const petType = this.wellnessPlanForm.get('petType')?.value;
    const ageGroup = this.wellnessPlanForm.get('ageGroup')?.value;

    if (petType && ageGroup) {
      this.wellnessPlanForm.patchValue({
        wellnessPlanName: `${petType} - ${ageGroup}`,
      });
      const wellnessPlanName = this.wellnessPlanForm.get('wellnessPlanName')?.value;
      this.getAvailableServices(wellnessPlanName);
    } else {
      this.wellnessPlanForm.patchValue({
        wellnessPlanName: '',
      });
    }
  }

  onServiceChange() {
    const selectedServiceId = +this.wellnessPlanForm.get('serviceList')?.value;
    const selectedService = this.services.find(
      (service) => service.id === selectedServiceId,
    );
    if (selectedService) {
      this.selectedServiceDetails = selectedService;
      this.addDynamicDropdownControls();
    } else {
      this.selectedServiceDetails = null;
    }
  }

  addDynamicDropdownControls() {
    this.selectedServiceDetails.dropdowns.forEach((_: any, index: any) => {
      if (this.wellnessPlanForm.contains(`dropdown${index}`)) {
        this.wellnessPlanForm.removeControl(`dropdown${index}`);
        this.wellnessPlanForm.removeControl(`priceBased${index}`);
        this.wellnessPlanForm.removeControl(`industryPrice${index}`);
        this.wellnessPlanForm.removeControl(`recommendation${index}`);
      }
    });

    // Add new controls
    this.selectedServiceDetails.dropdowns.forEach(
      (
        dropdown: {
          dropdown: any;
          priceBased: any;
          industryStandardPrice: any;
        },
        index: any,
      ) => {
        this.wellnessPlanForm.addControl(
          `dropdown${index}`,
          new FormControl(dropdown.dropdown),
        );
        this.wellnessPlanForm.addControl(
          `priceBased${index}`,
          new FormControl(dropdown.priceBased),
        );
        this.wellnessPlanForm.addControl(
          `industryPrice${index}`,
          new FormControl(dropdown.industryStandardPrice),
        );
        this.wellnessPlanForm.addControl(
          `recommendation${index}`,
          new FormControl('', Validators.required),
        );
      },
    );
    this.cdr.detectChanges();
  }

  submitWellnessPlanForm() {
    if (this.wellnessPlanForm.valid) {
      const wellnessPlan = new WellnessPlanRequest();

      wellnessPlan.petType = this.wellnessPlanForm.get('petType')?.value;
      wellnessPlan.ageGroup = this.wellnessPlanForm.get('ageGroup')?.value;
      wellnessPlan.wellnessPlanName = this.wellnessPlanForm.get('wellnessPlanName')?.value;
      if (this.selectedServiceDetails) {
        wellnessPlan.serviceId = this.selectedServiceDetails.id;
      } else {

        return;
      }

      wellnessPlan.recommendation = this.selectedServiceDetails.dropdowns.map(
        (dropdown: any, index: number) => ({
          dropdownId: dropdown.id,
          recommendation: this.wellnessPlanForm.get(`recommendation${index}`)?.value,
        })
      );

      this.wellnessPlanService.addWellnessPlan(wellnessPlan).subscribe(
        (response) => {
          if (response === "Wellness Plan Added") {
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Wellness Plan Added Successfully',
            });
          } else if (response === "Wellness plan Already Exists") {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Wellness Plan Already Exists',
            });
          }
          this.wellnessPlanForm.reset();
          this.showWellnessPlanForm = false;
          this.fetchWellnessPlan();
        },
        (error) => {

        }
      );
    }
  }

  toggleServiceFormForm() {
    this.showServiceForm = !this.showServiceForm;
    if (this.showServiceForm === false) {
      this.serviceForm.reset({});
    }
  }

  cancelWellnessForm() {
    this.showWellnessPlanForm = !this.showWellnessPlanForm;
    if (this.showWellnessPlanForm === false) {
      this.wellnessPlanForm.reset({});
      this.selectedServiceDetails = { dropdowns: [] };
    }
  }

  editService(service: any) {
    this.showServiceForm = true;
    this.editMode = true;
    this.selectedServiceId = service.id;

    this.serviceForm.patchValue({
      petType: service.petType,
      serviceName: service.service,
    });



    const itemsArray = this.serviceForm.get('items') as FormArray;
    itemsArray.clear();
    service.dropdowns.forEach((dropdown: any) => {
      itemsArray.push(
        this.fb.group({
          id: [dropdown.id, Validators.required],
          dropdown: [dropdown.dropdown, Validators.required],
          priceBased: [dropdown.priceBased, Validators.required],
          industryStandardPrice: [
            dropdown.industryStandardPrice.replace('$', ''),
            Validators.required,
          ],
          priceForSmall: [
            dropdown.priceForSmall
              ? dropdown.priceForSmall.replace('$', '')
              : null,
          ],
          priceForMedium: [
            dropdown.priceForMedium
              ? dropdown.priceForMedium.replace('$', '')
              : null,
          ],
          priceForLarge: [
            dropdown.priceForLarge
              ? dropdown.priceForLarge.replace('$', '')
              : null,
          ],
          priceForXLarge: [
            dropdown.priceForXLarge
              ? dropdown.priceForXLarge.replace('$', '')
              : null,
          ],
          priceForQuantity: [
            dropdown.priceForQuantity
              ? dropdown.priceForQuantity.replace('$', '')
              : null,
          ],
        }),
      );
    });
  }

  confirmDeleteService(id: number) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete this service?',
      header: 'Delete Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.deleteService(id);
      },
      reject: () => {
        this.messageService.add({
          severity: 'info',
          summary: 'Cancelled',
          detail: 'Deletion cancelled',
        });
      },
    });
  }

  deleteService(id: number) {
    this.wellnessPlanService.deleteServiceList(id).subscribe({
      next: (response: any) => {
        if (response === 'Service deleted successfully') {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: response,
          });
          this.fetchServices();
        } else {
          this.messageService.add({
            severity: 'warn',
            summary: 'Warning',
            detail:
              'The service could not be deleted. It might be associated with a Wellness Plan or Recommendation.',
          });
        }
      },
      error: (err) => {
        const errorMessage =
          err.error || 'Failed to delete service due to a constraint violation';
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: errorMessage,
        });
      },
    });
  }

  confirmDeleteWellnessPlan(id: number) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete this wellness plan?',
      header: 'Delete Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.deleteWellnessPlan(id);
      },
      reject: () => {
        this.messageService.add({
          severity: 'info',
          summary: 'Cancelled',
          detail: 'Deletion cancelled',
        });
      },
    });
  }

  deleteWellnessPlan(id: number) {
    this.wellnessPlanService.deleteWellnessPlan(id).subscribe({
      next: () => {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Wellness Plan deleted',
        });
        this.fetchWellnessPlan();
      },
      error: () => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to delete wellnessPlan',
        });
      },
    });
  }

  editWellnessPlan(plan: WellnessPlanResponse) {
    if (plan) {
      this.updateMethod = true;
      this.addMethod = false;
    }
    this.showWellnessPlanForm = true;
    this.editMode = true;
    this.selectedWellnessPlanId = plan.id ?? null;

    this.populateWellnessPlanForm(plan);
  }

  private populateWellnessPlanForm(plan: WellnessPlanResponse) {
    this.wellnessPlanForm.patchValue({
      petType: plan.petType,
      ageGroup: plan.ageGroup,
      wellnessPlanName: plan.wellnessPlanName,
      serviceList: plan.service.map((service) => service.id),
    });
    const itemsArray = this.wellnessPlanForm.get('items') as FormArray;
    itemsArray.clear();
    plan.service.forEach((service: ServiceListResponse) => {
      service.dropdown.forEach((dropdownItem: DropdownListResponseDTO) => {
        const itemGroup = this.fb.group({
          dropdown: [dropdownItem.dropdown],
          priceBased: [dropdownItem.priceBased],
          industryStandardPrice: [dropdownItem.industryStandardPrice],
          recommendation: [dropdownItem.recommendation],
          id: [dropdownItem.id],
        });
        itemsArray.push(itemGroup);
      });
    });
  }

  updateWellnessPlan() {
    const itemsControl = this.wellnessPlanForm.get('items');
    const itemsValue = itemsControl ? itemsControl.value : [];

    const updatedWellnessPlan: WellnessPlanResponse = {
      id: this.selectedWellnessPlanId || null,
      petType: this.wellnessPlanForm.value.petType,
      ageGroup: this.wellnessPlanForm.value.ageGroup,
      wellnessPlanName: this.wellnessPlanForm.get('wellnessPlanName')?.value,
      status: true,
      service: [
        {
          id: this.wellnessPlanForm.value.serviceId,
          petType: this.wellnessPlanForm.value.petType,
          service: this.wellnessPlanForm.value.serviceName,
          dropdown: itemsValue.map((item: any) => ({
            id: item.id || null,
            dropdown: item.dropdown,
            priceBased: item.priceBased,
            industryStandardPrice: item.industryStandardPrice,
            recommendation: item.recommendation,
          })),
        },
      ],
    };

    this.wellnessPlanService.updateWellnessPlan(updatedWellnessPlan).subscribe(
      (response) => {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Wellness Plan Updated Successfully',
        });
        this.wellnessPlanForm.reset();
        this.fetchWellnessPlan();
      },
      (error) => {

      },
    );
  }

  getAvailableServices(wellnessPlanName : string) {
    this.wellnessPlanService.getAvailableServices(wellnessPlanName).subscribe(
      (response) => {
        this.availableServices = response;

      },
      (error) => {
        
      }
    );
  }

}
