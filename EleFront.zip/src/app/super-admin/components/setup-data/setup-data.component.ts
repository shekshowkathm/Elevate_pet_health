import { CommonModule, NgClass, NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import {
  ReactiveFormsModule,
  FormGroup,
  FormBuilder,
  Validators,
  FormsModule,
} from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';
import { TabViewModule } from 'primeng/tabview';
import { WellnessPlanService } from '../../service/wellness-plan.service';
import { Breed, WeightRange } from '../../model/setup-data';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { CardModule } from 'primeng/card';
import { SharedService } from '../../../shared/service/shared.service';

@Component({
  selector: 'app-setup-data',
  standalone: true,
  imports: [
    CommonModule,
    TableModule,
    TabViewModule,
    ConfirmDialogModule,
    MatSlideToggleModule,
    ReactiveFormsModule,
    FormsModule,
    InputTextModule,
    ToastModule,
    CardModule,
  ],
  templateUrl: './setup-data.component.html',
  styleUrl: './setup-data.component.scss',
  providers: [MessageService, ConfirmationService],
})
export class SetupDataComponent {
  activeTab: string = 'weightRanges';
  weightRangeForm: FormGroup;
  showForm: boolean = false;
  showBreedForm: boolean = false;
  petWithBreedForm: FormGroup;
  getWeightRanges: WeightRange[] = [];
  getBreeds: Breed[] = [];
  filterBreeds: Breed[] = [];
  petTypeFilter: string = '';
  breedNameFilter: string = '';
  breedTypeFilter: string = '';
  selectedRangeId: number | any;
  selectedBreedId: number | any;
  breedOptions: string[] = [];

  constructor(
    private fb: FormBuilder,
    private setupDataService: WellnessPlanService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private sharedservice: SharedService
  ) {
    this.weightRangeForm = this.fb.group({
      petType: ['', Validators.required],
      weight: [
        '',
        [
          Validators.required,
          Validators.pattern('^\\d+(\\.\\d+)?-\\d+(\\.\\d+)?$')
        ],
      ],
      size: ['', Validators.required],
    });

    this.petWithBreedForm = this.fb.group({
      petType: ['', Validators.required],
      breed: ['', Validators.required],
      breedType: ['', Validators.required],
      ageForPuppy: [''],
      ageForKitten: [''],
      ageForAdult: [''],
      ageForSenior: ['', [Validators.required]],
    });
    this.petWithBreedForm.get('petType')?.valueChanges.subscribe((petType) => {
      this.updateBreedOptions(petType);
    });
  }

  ngOnInit() {
    this.fetchWeightRanges();
    this.fetchBreed();
  }

  toggleForm() {
    this.showForm = !this.showForm;
    if (this.showForm) {
      this.weightRangeForm.reset();
    }
  }

  toggleBreedForm() {
    this.showBreedForm = !this.showBreedForm;
    if (this.showBreedForm) {
      this.petWithBreedForm.reset();
      this.selectedBreedId = null;
    }
  }

  fetchWeightRanges() {
    this.setupDataService.getAllWeightRange().subscribe(
      (response: WeightRange[]) => {
        this.getWeightRanges = response;
      },
      (error) => {
      
      },
    );
  }
  exportToExcelWeight() {
    this.sharedservice.exportAsExcelFile(this.getWeightRanges, 'Weight-Ranges');
  }

  editWeightRange(range: WeightRange) {
    this.showForm = true;
    const formatedWeight = range.weight.replace(/(\d+)lb-(\d+)lb/, "$1-$2")
    this.weightRangeForm.patchValue({
      petType: range.petType,
      weight: formatedWeight,
      size: range.size,
    });
    this.selectedRangeId = range.id;
  }

  onWeightRangeSubmit() {
    if (this.weightRangeForm.invalid) {
      this.weightRangeForm.markAllAsTouched();
      return;
    }
    const weightRangeRaw: string = this.weightRangeForm.value.weight;
    const weightRangeRequiredFormat = weightRangeRaw.replace(/(\d+(\.\d+)?)-(\d+(\.\d+)?)/, "$1lb-$3lb");
    const weightRangePayload: WeightRange = {
      id: this.selectedRangeId,
      petType: this.weightRangeForm.get('petType')?.value,
      weight: weightRangeRequiredFormat,
      size: this.weightRangeForm.get('size')?.value,
    };

    if (this.selectedRangeId) {
      this.setupDataService.updateWeightRanges(weightRangePayload).subscribe({
        next: (response: string) => {
          this.showSuccessToast(response);
          this.resetForm();
          this.fetchWeightRanges();
        },
        error: (err) => {
          this.showErrorToast('Failed to update weight range');
        },
      });
    } else {
      this.setupDataService.addWeightRange(weightRangePayload).subscribe({
        next: (response: string) => {
          this.showSuccessToast(response);
          this.resetForm();
          this.fetchWeightRanges();
        },
        error: (err) => {
          if (err.status === 409) {
            if (err.error === 'Weight range overlaps with an existing range') {
              this.showErrorToast(
                'Weight range overlaps with an existing range!',
              );
            } else if (
              err.error === 'Duplicate Entry: This weight range already exists.'
            ) {
              this.showErrorToast(
                'Duplicate entry: Weight range already exists!',
              );
            } else {
              this.showErrorToast('Conflict: Unable to add weight range.');
            }
          }
        },
      });
    }
  }

  confirmDelete(id: number) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete this weight range?',
      header: 'Delete Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.deleteWeightRange(id);
      },
      reject: () => {
        this.messageService.add({
          severity: 'info',
          summary: 'Cancelled',
          detail: 'Deletion cancelled',
        });
      },
    });
  }

  deleteWeightRange(id: number) {
    this.setupDataService.deleteWeightRange(id).subscribe({
      next: () => {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Weight range deleted',
        });
        this.fetchWeightRanges();
      },
      error: () => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to delete weight range',
        });
      },
    });
  }

  onBreedSubmit() {
    if (this.petWithBreedForm.valid) {
      const ageForPuppy = this.petWithBreedForm.get('ageForPuppy')?.value;
      const ageForKitten = this.petWithBreedForm.get('ageForKitten')?.value;
      const ageForAdult = this.petWithBreedForm.get('ageForAdult')?.value;
      const ageForSenior = this.petWithBreedForm.get('ageForSenior')?.value;

      let formattedAgeForPuppy = '';
      let formattedAgeForKitten = '';
      let formattedAgeForAdult = '';
      let formattedAgeForSenior = '';

      if (ageForPuppy) {
        const [minPuppy, maxPuppy] = ageForPuppy
          .split('-')
          .map((num: string) => num.trim());
        formattedAgeForPuppy = `${minPuppy} months - ${maxPuppy} months`;
      }

      if (ageForKitten) {
        const [minKitten, maxKitten] = ageForKitten
          .split('-')
          .map((num: string) => num.trim());
        formattedAgeForKitten = `${minKitten} months - ${maxKitten} months`;
      }

      if (ageForAdult) {
        const [minAdult, maxAdult] = ageForAdult
          .split('-')
          .map((num: string) => num.trim());
        formattedAgeForAdult = `${minAdult} months - ${maxAdult} months`;
      }

      if (ageForSenior) {
        const [minSenior, maxSenior] = ageForSenior
          .split('-')
          .map((num: string) => num.trim());
        formattedAgeForSenior = `${minSenior} months - ${maxSenior} months`;
      }

      const breedAge: Breed = {
        id: this.selectedBreedId,
        petType: this.petWithBreedForm.get('petType')?.value,
        breed: this.petWithBreedForm.get('breed')?.value,
        breedType: this.petWithBreedForm.get('breedType')?.value,
        ageForPuppy: formattedAgeForPuppy,
        ageForKitten: formattedAgeForKitten,
        ageForAdult: formattedAgeForAdult,
        ageForSenior: formattedAgeForSenior,
      };

      if (this.selectedBreedId) {
        this.setupDataService.updateBreed(breedAge).subscribe(
          (response) => {
            this.showSuccessToast('Breed updated successfully!');
            this.resetBreedForm();
            this.fetchBreed();
          },
          (error) => {
            if (error.status === 409) {
              this.messageService.add({
                severity: 'error',
                summary: 'Conflict Error',
                detail: 'Values are overlapping',
              });
            } else {
              this.showErrorToast('Failed to update breed');
            }
          },
        );
      } else {
        this.setupDataService.addBreed(breedAge).subscribe(
          (response) => {
            this.showBreedForm = false;
            this.fetchBreed();
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Breed Added Successfully',
            });
          },
          (error) => {
            if (error.status === 409) {
              this.messageService.add({
                severity: 'error',
                summary: 'Conflict Error',
                detail: 'Already exist with the same breed',
              });
            } else {
              this.messageService.add({
                severity: 'error',
                summary: 'Error',
                detail: 'Failed to add breed',
              });
            }
          },
        );
      }
    } else {
      this.petWithBreedForm.markAllAsTouched();
      this.messageService.add({
        severity: 'warn',
        summary: 'Form Validation',
        detail: 'Please fill in all required fields correctly.',
      });
    }
  }

  fetchBreed() {
    this.setupDataService.getAllBreed().subscribe(
      (response: Breed[]) => {
        this.getBreeds = response;
        this.filterBreeds = [...response];
      },
      (error) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to get breed',
        });
      },
    );
  }
  exportToExcelbreed() {
    this.sharedservice.exportAsExcelFile(this.getBreeds, 'Breed');
  }
  applyCombinedFilterBreed() {
    if (!this.petTypeFilter && !this.breedNameFilter && !this.breedTypeFilter) {
      this.filterBreeds = [...this.getBreeds];
    } else {
      this.filterBreeds = this.getBreeds.filter((breed) => {
        const petTypeMatch =
          !this.petTypeFilter ||
          breed.petType
            .toLowerCase()
            .includes(this.petTypeFilter.toLowerCase());
        const breedNameMatch =
          !this.breedNameFilter ||
          breed.breed
            .toLowerCase()
            .includes(this.breedNameFilter.toLowerCase());

        const breedTypeMatch =
          !this.breedTypeFilter ||
          breed.breedType
            .toLowerCase()
            .includes(this.breedTypeFilter.toLowerCase());

        return petTypeMatch && breedNameMatch && breedTypeMatch;
      });
    }
  }
  clearPettypeFilter(){
    this.petTypeFilter = ''
    this.applyCombinedFilterBreed();
  }
  clearBreedTypeFilter(){
    this.breedTypeFilter = ''
    this.applyCombinedFilterBreed();
  }
  clearBreedNameFilter(){
    this.breedNameFilter = ''
    this.applyCombinedFilterBreed();
  }
  isNoBreed() {
    return this.filterBreeds.length === 0;
  }

  editPetWithBreed(pet: any) {
    this.showBreedForm = true;
    this.petWithBreedForm.patchValue({
      petType: pet.petType,
      breed: pet.breed,
      breedType: pet.breedType,
      ageForPuppy: pet.ageForPuppy,
      ageForKitten: pet.ageForKitten,
      ageForAdult: pet.ageForAdult,
      ageForSenior: pet.ageForSenior,
    });
    this.selectedBreedId = pet.id;
  }

  confirmDeleteBreed(id: number) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete this breed?',
      header: 'Delete Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.deleteBreed(id);
      },
      reject: () => {
        this.messageService.add({
          severity: 'info',
          summary: 'Cancelled',
          detail: 'Deletion cancelled',
        });
      },
    });
  }

  deleteBreed(id: number) {
    this.setupDataService.deleteBreed(id).subscribe({
      next: () => {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Breed deleted',
        });
        this.fetchBreed();
      },
      error: () => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to delete breed',
        });
      },
    });
  }

  resetForm() {
    this.weightRangeForm.reset();
    this.showForm = false;
    this.selectedRangeId = null;
  }

  resetBreedForm() {
    this.petWithBreedForm.reset();
    this.showBreedForm = false;
    this.selectedBreedId = null;
  }

  showSuccessToast(message: string) {
    this.messageService.add({
      severity: 'success',
      summary: 'Success',
      detail: message,
    });
  }

  showErrorToast(message: string) {
    this.messageService.add({
      severity: 'error',
      summary: 'Error',
      detail: message,
    });
  }

  updateBreedOptions(petType: string): void {
    if (petType === 'Dog') {
      this.breedOptions = [
        'Giant Breed',
        'Large Breed',
        'Medium Breed',
        'Small Breed',
        'Toy Breed',
      ];
    } else if (petType === 'Cat') {
      this.breedOptions = ['Short-Haired', 'Long-Haired'];
    } else {
      this.breedOptions = [];
    }
    this.petWithBreedForm.get('breedType')?.reset();
  }
 
}
