import { NgFor, NgClass, NgIf, CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ScrollerModule } from 'primeng/scroller';
import { TableModule } from 'primeng/table';
import { SuperAdminService } from '../../service/super-admin.service';
import { Router } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedService } from '../../../shared/service/shared.service';
import { InputTextModule } from 'primeng/inputtext';

@Component({
  selector: 'app-sa-clinic-admin',
  standalone: true,
  imports: [
    TableModule,
    MatSlideToggleModule,
    ScrollerModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    InputTextModule,
  ],
  templateUrl: './sa-clinic-admin.component.html',
  styleUrl: './sa-clinic-admin.component.scss',
})
export class SaClinicAdminComponent {
  allClinicAdminsResponse: any[] = [];
  filterClinicAdminResponse: any[] = [];
  clinicAdminFilter: string = '';
  checked = false;
  disabled = false;
  isLoading: boolean = false;

  constructor(
    private superAdminService: SuperAdminService,
    private router: Router,
    private sharedService: SharedService,
  ) {}
  ngOnInit(): void {
    this.getAllClinicAdmins();
  }
  getAllClinicAdmins() {
    this.isLoading = true;
    this.superAdminService.ClinicAdmins().subscribe({
      next: (response) => {
        this.allClinicAdminsResponse = response;
        this.filterClinicAdminResponse = [...response];
        this.isLoading = false;
      },
      error: (error) => {
        if (error.status === 401) {
        } else {
        }
      },
    });
  }

  getprofileById(personalId: number) {
    this.router.navigate(['/superAdmin/showProfile'], {
      queryParams: { AdminId: personalId },
    });
  }

  exportToExcel() {
    this.sharedService.exportAsExcelFile(
      this.allClinicAdminsResponse,
      'ClinicAdmins',
    );
  }
  filterByClinicOwnersDetails() {
    if (!this.clinicAdminFilter) {
      this.filterClinicAdminResponse = [...this.allClinicAdminsResponse];
    } else {
      const searchQuery = this.clinicAdminFilter.toLowerCase();
      this.filterClinicAdminResponse = this.allClinicAdminsResponse.filter(
        (clinicAdmin) => {
          const clinicName = clinicAdmin.clinicName?.toLowerCase() || ''; // Ensure values are lowercase and handle undefined/null
          const city = clinicAdmin.city?.toLowerCase() || '';
          const state = clinicAdmin.state?.toLowerCase() || '';

          return (
            clinicName.includes(searchQuery) ||
            city.includes(searchQuery) ||
            state.includes(searchQuery)
          );
        },
      );
    }
  }
  clearFilter() {
    this.clinicAdminFilter = '';
    this.filterByClinicOwnersDetails();
  }
  isNoData(): boolean {
    return this.filterClinicAdminResponse.length === 0;
  }
}
