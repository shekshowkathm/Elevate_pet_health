import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaClinicAdminComponent } from './sa-clinic-admin.component';

describe('SaClinicAdminComponent', () => {
  let component: SaClinicAdminComponent;
  let fixture: ComponentFixture<SaClinicAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SaClinicAdminComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SaClinicAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
