import { Component, signal } from '@angular/core';

import { NgFor, NgClass, CommonModule } from '@angular/common';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ScrollerModule } from 'primeng/scroller';
import { TableModule } from 'primeng/table';
import { SuperAdminService } from '../../service/super-admin.service';
import { Router } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedService } from '../../../shared/service/shared.service';

@Component({
  selector: 'app-sa-clinic-owners',
  standalone: true,
  imports: [
    TableModule,
    MatSlideToggleModule,
    ScrollerModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
  ],
  templateUrl: './sa-clinic-owners.component.html',
  styleUrl: './sa-clinic-owners.component.scss',
})
export class SaClinicOwnersComponent {
  allClinicOwnersResponse: any[] = [];
  filterClinicOwnersReponse: any[] = [];
  checked = false;
  disabled = false;
  clinicdetailsOwnerFilter: string = '';
  isLoading: boolean = false;

  constructor(
    private superAdminService: SuperAdminService,
    private router: Router,
    private sharedService: SharedService,
  ) {}

  ngOnInit(): void {
    this.getAllClinicOwners();
  }
  getAllClinicOwners() {
    this.isLoading = true;
    this.superAdminService.ClinicOwners().subscribe({
      next: (response) => {
        this.allClinicOwnersResponse = response;
        this.filterClinicOwnersReponse = [...response];
        this.isLoading = false;
      },
      error: (error) => {
        if (error.status === 401) {
        } else {
        }
      },
    });
  }
  navigateToAddClinic() {
    this.router.navigate(['/superAdmin/addClinic']);
  }

  getprofileById(personalId: number) {
    this.router.navigate(['/superAdmin/showProfile'], {
      queryParams: { selectedId: personalId },
    });
  }

  exportToExcel() {
    this.sharedService.exportAsExcelFile(
      this.allClinicOwnersResponse,
      'ClinicOwners',
    );
  }
  filterByClinicOwnersDetails() {
    if (!this.clinicdetailsOwnerFilter) {
      this.filterClinicOwnersReponse = [...this.allClinicOwnersResponse];
    } else {
      const searchQuery = this.clinicdetailsOwnerFilter.toLowerCase();
      this.filterClinicOwnersReponse = this.allClinicOwnersResponse.filter(
        (clinic) => {
          const clinicName = clinic.clinicName?.toLowerCase() || ''; // Ensure values are lowercase and handle undefined/null
          const zipCode = clinic.zipcode?.toLowerCase() || '';
          const city = clinic.city?.toLowerCase() || '';
          const state = clinic.state?.toLowerCase() || '';
          const clinicOwnerName =
            `${clinic.firstName}${clinic.lastName}`.toLowerCase() || '';

          return (
            clinicName.includes(searchQuery) ||
            zipCode.includes(searchQuery) ||
            city.includes(searchQuery) ||
            state.includes(searchQuery) ||
            clinicOwnerName.includes(searchQuery)
          );
        },
      );
    }
  }
  clearFilter() {
    this.clinicdetailsOwnerFilter = '';
    this.filterByClinicOwnersDetails();
  }
  isNoData(): boolean {
    return this.filterClinicOwnersReponse.length === 0;
  }
}
