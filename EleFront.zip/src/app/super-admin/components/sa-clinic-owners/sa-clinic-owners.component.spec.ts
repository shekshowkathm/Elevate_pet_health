import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaClinicOwnersComponent } from './sa-clinic-owners.component';

describe('SaClinicOwnersComponent', () => {
  let component: SaClinicOwnersComponent;
  let fixture: ComponentFixture<SaClinicOwnersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SaClinicOwnersComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SaClinicOwnersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
