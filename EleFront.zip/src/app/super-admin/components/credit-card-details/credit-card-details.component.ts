import { Component, OnInit } from '@angular/core';
import { StripeService } from '../../../clinic/services/stripe.service';
import { TableModule } from 'primeng/table';
import { CommonModule } from '@angular/common';
import { TagModule } from 'primeng/tag';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { FormsModule } from '@angular/forms';
import { SharedService } from '../../../shared/service/shared.service';

@Component({
  selector: 'app-credit-card-details',
  standalone: true,
  imports: [
    TableModule,
    TagModule,
    CommonModule,
    ProgressSpinnerModule,
    FormsModule,
  ],
  templateUrl: './credit-card-details.component.html',
  styleUrls: ['./credit-card-details.component.scss'], // Corrected 'styleUrls'
})
export class CreditCardDetailsComponent implements OnInit {
  public CardList: any[] = [];
  public CardDetailsList: any[] = [];
  public filteredResponse: any[] = [];
  public loader: boolean = false;
  public clinicDetailsFilter: string = '';
  public petOwnerDetailsFilter: string = '';
  public petOwnerEmailDetailsFilter :string =''

  constructor(
    private stripeService: StripeService,
private sharedService: SharedService,
  ) {}

  ngOnInit(): void {
    this.getAllCustomerCardDetails();
  }

  getAllCustomerCardDetails(): void {
    this.loader = true;
    this.stripeService.getExpiringCard().subscribe({
      next: (data: any) => {
        this.CardList = data.details
        this.filteredResponse = data.details
        this.loader = false;
      },
      error: (err) => {
        this.loader = false;
      },
    });
  }

  filterByClinicDetails(): void {
    const query = this.clinicDetailsFilter.trim().toLowerCase();
    if (!query) {
      this.filteredResponse = this.CardList;
    } else {
      this.filteredResponse = this.CardList.filter((card) => {
        const clinicName = card.clinicName?.toLowerCase() || '';
        return clinicName.includes(query);
      });
    }
  }

  filterByPetOwnerDetails(): void {
    const query = this.petOwnerDetailsFilter.trim().toLowerCase();
    if (!query) {
      this.filteredResponse = this.CardList;
    } else {
      this.filteredResponse = this.CardList.filter((card) => {
        const customerName = card.customerName?.toLowerCase() || '';
        return customerName.includes(query);
      });
    }
  }
  filterByPetOwnerEmailDetails(): void {
    const query = this.petOwnerEmailDetailsFilter.trim().toLowerCase();
    if (!query) {
      this.filteredResponse = this.CardList;
    } else {
      this.filteredResponse = this.CardList.filter((card) => {
        const customerEmail = card.customerEmail?.toLowerCase() || '';
        return customerEmail.includes(query);
      });
    }
  }


  exportToExcel(): void {
    this.filteredResponse.forEach((res: any) => {
      this.CardDetailsList.push({
        PetOwnerName: res.customerName,
        PetOwnerEmail: res.customerEmail,
        cardType: res.cardBrand,
        cardLast4: res.cardLast4,
        expYear: `${res.expMonth}/${res.expYear}`,
        clinicName: res.clinicName,
      });
    });
    this.sharedService.exportAsExcelFile(
      this.CardDetailsList,
      'Card Exp Details',
    );
  }
}
