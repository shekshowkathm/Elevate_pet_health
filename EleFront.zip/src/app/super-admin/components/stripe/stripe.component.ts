import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { ToastModule } from 'primeng/toast';
import { TrancationService } from '../../../pet-owner/service/trancation.service';
import { TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { SharedService } from '../../../shared/service/shared.service';

@Component({
  selector: 'app-stripe',
  standalone: true,
  imports: [
    CommonModule,
    ConfirmPopupModule,
    ButtonModule,
    TableModule,
    ToastModule,
    RouterModule,
    TagModule,
    DialogModule,
    FormsModule,
    ReactiveFormsModule,
    DynamicDialogModule,
    DropdownModule,
    InputTextModule,
  ],
  templateUrl: './stripe.component.html',
  styleUrl: './stripe.component.scss',
})
export class StripeComponent implements OnInit {
  public trancation: any[] = [];
  public trancationList: any[] = [];
  public filterClinicDetails: any = [];
  clinicDetailsFilter: string = '';
  petOwnerFilter:string='';
  constructor(
    private trancationService: TrancationService,
    private sharedService: SharedService,
  ) {}
  ngOnInit(): void {
    this.getAllTransactionDetails();
  }
  getAllTransactionDetails() {
    this.trancationService.getAllTransactionDetails().subscribe({
      next: (doc: any) => {
        try {
          const dataArray = JSON.parse(doc);
          console.log(dataArray,"dataArray");
          
          this.trancation = dataArray.sort((a: any, b: any) => b.customerPaidDate - a.customerPaidDate); // Sort transactions
          this.filterClinicDetails = [...this.trancation];
          
        } catch (error) {

          this.trancation = [];
          this.filterClinicDetails = [];
        }
      },
      error: (err: any) => {
        this.trancation = [];
        this.filterClinicDetails = [];
      },
      complete: () => {
        
      }
    });

  }
  getSeverity(status: string) {
    switch (status) {
      case 'paid':
        return 'success';
      case 'LOWSTOCK':
        return 'warning';
      case 'failure':
        return 'danger';
      default:
        return 'info';
    }
  }
  // account_id: string = "acct_1QJTNIL67oK3hgzN";

  // redirectToStripeDashboard(): void {
  //   const stripeUrl = `https://connect.stripe.com/app/express#${this
  //     .account_id}/overview`;
  //   window.open(stripeUrl, "_blank");
  // }
  exportToExcel() {
    this.filterClinicDetails.forEach((res:any) => {
      const date = new Date(res.customerPaidDate * 1000);
      const usDateFormat = new Intl.DateTimeFormat('en-US', {
        dateStyle: 'short',
      }).format(date);
      this.trancationList.push({
        customerPaidDate: usDateFormat,
        InvoiceNo: res.stripeInvoiceId,
        totalAmount: res.totalAmount,
        ClincName: res.ClincName,
        elaveteAmount: res.platformReceivedAmount - res.discountAmount,
        clinicName:res.clinicName,
        clincAmount: res.connectedAccountReceived,
        petOwnerName:res.petOwnerName,
        stripeFee: res.stripeFee,
        status: res.paymentStatus,
        stripeFeeElevate:res.stripeFeeElevate,
        stripeFeeClinic:res.stripeFeeClinic,
        
      });
    });
    this.sharedService.exportAsExcelFile(
      this.trancationList,
      'Trancation Details',
    );
  }
  filterByclinicDetailsFilter() {
    if (!this.clinicDetailsFilter) {
      this.filterClinicDetails = [...this.trancation];
    } else {
      const searchQuery = this.clinicDetailsFilter.toLowerCase();
      this.filterClinicDetails = this.trancation.filter((item) => {
        const clinicName = item.clinicName?.toLowerCase() || '';
        const petOwnerName = item.petOwnerName?.toLowerCase() || '';
        return (
          clinicName.includes(searchQuery) 
        );
      });
    }
  }

  
  filterBypetOwnerFilter() {
    if (!this.petOwnerFilter) {
      this.filterClinicDetails = [...this.trancation];
    } else {
      const searchQuery = this.petOwnerFilter.toLowerCase();
      this.filterClinicDetails = this.trancation.filter((item) => {
        const clinicName = item.clinicName?.toLowerCase() || '';
        const petOwnerName = item.petOwnerName?.toLowerCase() || '';
        return (
         petOwnerName.includes(searchQuery)
        );
      });
    }
  }
}
