import { CommonModule, isPlatformBrowser } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  Inject,
  PLATFORM_ID,
} from '@angular/core';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { ButtonModule } from 'primeng/button';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { Router, RouterModule } from '@angular/router';
import { DialogModule } from 'primeng/dialog';
import { SuperAdminService } from '../../service/super-admin.service';
import { SharedService } from '../../../shared/service/shared.service';
import { ProfilebyId } from '../../model/clinic-request-response';
import {
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  FormBuilder,
  Validators,
} from '@angular/forms';
import {
  DialogService,
  DynamicDialogModule,
  DynamicDialogRef,
} from 'primeng/dynamicdialog';
import { ImageUploadComponent } from '../../../shared/component/image-upload/image-upload.component';
import { US_STATES } from '../../../shared/constants/usa-states';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextModule } from 'primeng/inputtext';
import { ConfirmDialogModule } from 'primeng/confirmdialog';

@Component({
  selector: 'app-super-admin-header',
  standalone: true,
  imports: [
    CommonModule,
    ConfirmPopupModule,
    ButtonModule,
    ToastModule,
    RouterModule,
    DialogModule,
    FormsModule,
    ReactiveFormsModule,
    DynamicDialogModule,
    DropdownModule,
    InputTextModule,
  ],
  templateUrl: './super-admin-header.component.html',
  styleUrl: './super-admin-header.component.scss',
  providers: [ConfirmationService, MessageService, DialogService],
})
export class SuperAdminHeaderComponent {
  isVisibleProfileOptions: boolean = false;
  displayDialogProfile: boolean = false;
  showAllow = true;
  clinicRequestsResponse: any[] = [];
  superAdminEmail: string | null = null; // Initialize as null
  role: string | null = null; // Initialize as null
  private isBrowser: boolean;
  superAdminId: string | null = null;
  profilebyId: any = {};
  showSaveButton: boolean = false;
  isEditable: boolean = false;
  profileForm!: FormGroup;
  selectedImageUrl: string | ArrayBuffer | null = null;
  usStates = US_STATES;
  private ref: DynamicDialogRef | undefined;
  logoutDialogVisible: boolean = false;

  constructor(
    private router: Router,
    private superAdminService: SuperAdminService,
    private sharedservice: SharedService,
    public dialogService: DialogService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private fb: FormBuilder,
    private cdRef: ChangeDetectorRef,
    @Inject(PLATFORM_ID) private platformId: Object,
  ) {
    this.isBrowser = isPlatformBrowser(this.platformId); // Check if it's the browser
  }

  ngOnInit(): void {
    // Fetch clinic requests
    this.getClinicRequests();
    this.superAdminService.trigger$.subscribe(() => {
      this.getClinicRequests();
    });
    const registerId = this.sharedservice.getId('id');
    this.superAdminId = registerId ? registerId.trim() : null;
    this.getSuperAdminProfile();
    this.initializeForm();
  }
  ngAfterViewChecked(): void {
    this.cdRef.detectChanges();
  }
  initializeForm(): void {
    this.profileForm = this.fb.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      contactNumber: [
        '',
        [Validators.required, Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/)],
      ],
      state: ['', [Validators.required]],
      profile: [this.selectedImageUrl || this.profilebyId.profile],
    });
  }

  showProfileOptions() {
    this.isVisibleProfileOptions = !this.isVisibleProfileOptions;
  }

  showFullProfile() {
    this.displayDialogProfile = !this.displayDialogProfile;
  }

  navigateToNotifications() {
    this.router.navigate(['/superAdmin/superAdminNotification']);
    this.isVisibleProfileOptions = false;
  }

  navigateToHome() {
    this.router.navigate(['/superAdmin']);
    
  }
  navigateToSubscriptionMailSender() {
    this.router.navigate(['/superAdmin/subscriptionMailSender']);
    this.isVisibleProfileOptions = false;
  }

  showLogoutDialog() {
    this.logoutDialogVisible = true;
  }
  // Ensure localStorage.clear() runs only in the browser
  confirmLogout() {
    if (this.isBrowser) {
      localStorage.clear();
    }
    this.router.navigate(['']);
    this.logoutDialogVisible = false;
  }

  getClinicRequests() {
    this.superAdminService.getAllClinicRequests().subscribe({
      next: (response) => {
        this.clinicRequestsResponse = response;
      },
      error: (error) => {
        if (error.status === 401) {
        } else {
        }
      },
    });
  }

  showDialog() {
    this.displayDialogProfile = true;
  }
  getSuperAdminProfile() {
    const id = this.superAdminId;
    this.superAdminService.showPersonProfileById(id).subscribe({
      next: (profileResponse) => {
        this.profilebyId = profileResponse;

        this.profileForm.patchValue({
          firstName: this.profilebyId.firstName,
          lastName: this.profilebyId.lastName,
          email: this.profilebyId.email,
          contactNumber: this.profilebyId.contactNumber,
          state: this.profilebyId.state,
          profile: this.profilebyId.profile,
        });
        this.formatPhoneNumber();
      },
      error: (error) => {
        if (error.status === 401) {
        } else {
        }
      },
    });
  }
  toggleButtons() {
    this.showSaveButton = true; // Show the "Save changes" button
    this.isEditable = true;
  }

  saveChanges() {
    this.showSaveButton = false;
    if (this.profileForm.valid) {
      // Update profilebyId with form values
      // this.updatedValues = this.profileForm.value;
      const convertid = Number(this.superAdminId);
      const userDetails = {
        ...this.profileForm.value,
        id: convertid,
      };

      this.superAdminService.updateProfile(userDetails).subscribe({
        next: (response) => {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Profile Updated successfully!',
          });
          this.profileForm.reset();
          this.getSuperAdminProfile();
          this.displayDialogProfile = false;
        },
        error: (error) => {
          this.displayDialogProfile = true;
        },
      });

      this.isEditable = false; // Exit edit mode
    }

    // this.isEditable = false;
  }

  uploadOrSelectImage() {
    this.ref = this.dialogService.open(ImageUploadComponent, {
      header: 'Upload Image',
      width: '500px',
      modal: true,
      breakpoints: {
        '640px': '90vw',
      },
    });
    this.ref.onClose.subscribe((url: any) => {
      if (url) {
        this.selectedImageUrl = url;
        const imageUrl = this.selectedImageUrl;
        this.profileForm.patchValue({
          profile: imageUrl,
        });
      }
    });
  }
  formatPhoneNumber(): void {
    const contactNumberControl = this.profileForm.get('contactNumber');
    const input = contactNumberControl?.value
      ? contactNumberControl.value.replace(/\D/g, '')
      : ''; // Check if value exists and remove non-numeric characters
    let formattedInput = input;

    if (input.length > 0) {
      formattedInput = `(${input.substring(0, 3)}`; // Add opening parenthesis
    }
    if (input.length >= 4) {
      formattedInput += `) ${input.substring(3, 6)}`; // Add closing parenthesis and space
    }
    if (input.length >= 7) {
      formattedInput += `-${input.substring(6, 10)}`; // Add hyphen before the last 4 digits
    }

    // Set the formatted value back to the form control
    contactNumberControl?.setValue(formattedInput, { emitEvent: false });

    // Add or remove the pattern validator based on input length
    if (input.length === 10) {
      contactNumberControl?.setValidators([
        Validators.required,
        Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/),
      ]);
    } else {
      contactNumberControl?.setValidators([Validators.required]);
    }

    contactNumberControl?.updateValueAndValidity({ emitEvent: false });
  }
}
