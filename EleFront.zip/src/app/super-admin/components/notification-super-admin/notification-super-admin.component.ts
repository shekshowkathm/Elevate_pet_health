import { Component } from '@angular/core';
import { CardModule } from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { CommonModule } from '@angular/common';
import { SuperAdminService } from '../../service/super-admin.service';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { ListboxModule } from 'primeng/listbox';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { MultiSelectModule } from 'primeng/multiselect';
import { MessageService } from 'primeng/api';
import { TooltipModule } from 'primeng/tooltip';
import { ToastModule } from 'primeng/toast';
import { ClinicService } from '../../../clinic/services/clinic.service';
import { StripeService } from '../../../clinic/services/stripe.service';

@Component({
  selector: 'app-notification-super-admin',
  standalone: true,
  imports: [
    CardModule,
    ButtonModule,
    CommonModule,
    DialogModule,
    InputTextModule,
    FormsModule,
    ListboxModule,
    MultiSelectModule,
    FormsModule,
    ReactiveFormsModule,
    TooltipModule,
    ToastModule,
  ],
  templateUrl: './notification-super-admin.component.html',
  styleUrl: './notification-super-admin.component.scss',
  providers: [MessageService],
})
export class NotificationSuperAdminComponent {
  clinicRequestsResponse: any[] = [];
  allRepsResponse: any[] = [];
  filteredReps: any[] = [];
  selectedRep: any = null;
  displayRepDialog: boolean = false;
  selectedCity!: string;
  myGroup!: FormGroup;
  notificationLoading: boolean = false;
  isSalesRepSelected: boolean = false;
  choosenRep!: string;

  constructor(
    private superAdminService: SuperAdminService,
    private fb: FormBuilder,private stripeService:StripeService,
    private messageService: MessageService
  ) {
    this.myGroup = this.fb.group({
      text: [''],
    });
  }
  ngOnInit(): void {
    this.getClinicRequests();
    this.getSalereps();

    this.myGroup.get('text')?.valueChanges.subscribe((value) => {
      this.filterReps(value); // Call the filter method when input changes
    });


  }

  // getmethod for clinic requests
  getClinicRequests() {
    this.superAdminService.getAllClinicRequests().subscribe({
      next: (response) => {
        this.clinicRequestsResponse = response;
        this.clinicRequestsResponse = response.map((clinic:any) => ({
          ...clinic,
          displayRepDialog: false,
          selectedRep: null,
          isSalesRepSelected: false,
          notificationLoading: false, // Initialize spinner flag
        }));
      },
      error: (error) => {

      },
    });
  }

  // getAllsalesrep
  getSalereps() {
    this.superAdminService.getAllReps().subscribe({
      next: (response) => {
        this.allRepsResponse = response;
        this.filteredReps = this.allRepsResponse.map((rep) => ({
          label: `${rep.firstName}${rep.lastName} - ${rep.city}, ${rep.state}`, // Combining name, city, and state
          value: rep, // Store the full rep object in value
        }));
      },
      error: (error) => {

      },
    });
  }
  // update Status of the clinic Registration
  updateClinicStatus(index: number, clinic: any) {
    this.clinicRequestsResponse[index].notificationLoading = true;
    let data = {
      registerId:clinic.registerId,
      email:clinic.clinicEmail,
      clinicId:clinic.clinicId,
      registerStatus:clinic.registerStatus,
      firstName:clinic.clinicName,
      role:clinic.role
    }
    this.stripeService.UpdateStripeStatus(data).subscribe((doc:any)=>{
      const registerId = clinic.registerId;
    this.superAdminService.updateClinicRegisterStatus(registerId).subscribe({
      next: (response) => {
        this.refreshnotifications();
        this.clinicStatus(index,clinic);
      },
      error: (error) => {


        // this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Failed to update clinic registration' });
      },
    });
  })
  }

  // update the clinic status
  clinicStatus(index:number,clinic:any) {
    this.clinicRequestsResponse[index].notificationLoading = true;
    const clinicId = clinic.clinicId;
    const salesRepId = this.selectedRep?.value?.id;


    if (!salesRepId) {



      return;
    }
    this.isSalesRepSelected = true;

    this.superAdminService.updateClinic(clinicId, salesRepId).subscribe({
      next: (response) => {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Clinic status updated',
        });

        this.clinicRequestsResponse[index].notificationLoading = false;
        this.getClinicRequests();
        this.refreshnotifications();
      },
      error: (error) => {
        
        this.clinicRequestsResponse[index].notificationLoading = false; // Stop loading spinner
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to update clinic status',
        });
      },
    });
  }
  onCityChange(event: any, index: number) {
    let clinic = this.clinicRequestsResponse[index]; // Access the clinic based on the index

    if (this.selectedRep) {
      let repSelected = this.selectedRep.value;

      clinic.choosenRep = `${repSelected.firstName} ${repSelected.lastName}`; // Set the selected rep for the specific clinic
      clinic.isSalesRepSelected = true; // Enable the button when a sales rep is selected
    } else {
      clinic.isSalesRepSelected = false; // Disable the button if no rep is selected
    }
  }
  refreshnotifications() {
    this.superAdminService.triggerMethodInAnotherComponent();
  }

  // dialogtoshoreps
  showRepDialog(index: number) {
    this.clearSelection(index);
    this.clinicRequestsResponse[index].displayRepDialog = true;
  }

  filterReps(searchText: string) {
    if (!searchText) {
      // If no search text, show all representatives
      this.filteredReps = this.allRepsResponse.map((rep) => ({
        label: `${rep.firstName} ${rep.lastName}- ${rep.city}, ${rep.state}`,
        value: rep,
      }));
    } else {
      // Convert searchText to lowercase for case-insensitive comparison
      const lowerSearchText = searchText.toLowerCase();

      // Filter by name, city, or state
      this.filteredReps = this.allRepsResponse
        .filter((rep) => {
          const nameMatch = rep.firstName
            .toLowerCase()
            .includes(lowerSearchText);
          rep.lastName.toLowerCase().includes(lowerSearchText);
          const cityMatch = rep.city.toLowerCase().includes(lowerSearchText);
          const stateMatch = rep.state.toLowerCase().includes(lowerSearchText);

          // Return true if search text matches any of the fields
          return nameMatch || cityMatch || stateMatch;
        })
        .map((rep) => ({
          label: `${rep.firstName}${rep.lastName} - ${rep.city}, ${rep.state}`,
          value: rep,
        }));
    }
  }
  clearSelection(index: number) {
    this.clinicRequestsResponse[index].selectedRep = null;
    this.myGroup.get('text')?.setValue('');
  }
}
