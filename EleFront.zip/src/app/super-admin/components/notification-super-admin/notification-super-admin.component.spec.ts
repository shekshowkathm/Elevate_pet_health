import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotificationSuperAdminComponent } from './notification-super-admin.component';

describe('NotificationSuperAdminComponent', () => {
  let component: NotificationSuperAdminComponent;
  let fixture: ComponentFixture<NotificationSuperAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NotificationSuperAdminComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NotificationSuperAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
