import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { DropdownModule } from 'primeng/dropdown';
import { SuperAdminService } from '../../service/super-admin.service';
import { TrancationService } from '../../../pet-owner/service/trancation.service';
import { StripeService } from '../../../clinic/services/stripe.service';

interface DashboardData {
  associatesCount: number;
  petOwnersCount: number;
  activePlansCount: number;
  expiringPlanCounts: number;
  creditCardIssuesCounts: number;
  todayPaymentsCount: number;
  salesRepsCount: number;
  totalClinicsCount: number;
}

@Component({
  selector: 'app-sa-dashboard',
  standalone: true,
  imports: [DropdownModule],
  templateUrl: './sa-dashboard.component.html',
  styleUrl: './sa-dashboard.component.scss',
})
export class SaDashboardComponent {
  todayPaymentsCount: number = 0;
  creditCardIssuesCounts:number =0
  dashboardData: DashboardData = {
    associatesCount: 0,
    petOwnersCount: 0,
    activePlansCount: 0,
    expiringPlanCounts: 0,
    creditCardIssuesCounts: 0,
    todayPaymentsCount: 0,
    salesRepsCount: 0,
    totalClinicsCount: 2,
  };

  constructor(
    private router: Router,
    private superAdminSerice: SuperAdminService,
    private trancationService: TrancationService,private stipeService : StripeService,
  ) {}

  ngOnInit() {
    this.getAllCounts();
    this.getTotalAmount();
    this.getcardIssue()
  }

  getAllCounts() {
    this.superAdminSerice.getAllCountOfSuperAdmin().subscribe({
      next: (response: any) => {
        this.dashboardData = response;
      },
      error: (err: any) => {},
    });
  }
  getTotalAmount() {
    this.trancationService.gettodayEarningByAdmin().subscribe({
      next: (doc: any) => {
        const rawValue = doc || 0;
        this.todayPaymentsCount = isNaN(Number(rawValue))
          ? 0
          : Number(rawValue);
      },
      error: (err: any) => {
        this.todayPaymentsCount = 0;
      },
      complete: () => {},
    });
  }
  getcardIssue(){
    this.stipeService.getExpiringCard().subscribe((doc:any)=>{
      this.creditCardIssuesCounts = doc.count
    })
  }

  routetoSalesRep() {
    this.router.navigate(['/superAdmin/elevateSalesRepComponent']);
  }
  routeToClinicDetails() {
    this.router.navigate(['/superAdmin/saclinicdetails']);
  }
  routeToPetOwners() {
    this.router.navigate(['/superAdmin/sapetOwners']);
  }
  routeToWellnessPlan() {
    this.router.navigate(['/superAdmin/servicelist']);
  }
}
