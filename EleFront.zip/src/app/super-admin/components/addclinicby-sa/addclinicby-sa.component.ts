import { CommonModule, JsonPipe } from '@angular/common';
import { Component } from '@angular/core';
import {
  FormsModule,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
  FormBuilder,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { SuperAdminService } from '../../service/super-admin.service';
import { MessageService } from 'primeng/api';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ToastModule } from 'primeng/toast';
import { SharedService } from '../../../shared/service/shared.service';
import { DropdownModule } from 'primeng/dropdown';
import { US_STATES } from '../../../shared/constants/usa-states';
import { TIME_ZONES } from '../../../shared/constants/timeZone';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addclinicby-sa',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    InputTextModule,
    FormsModule,
    ButtonModule,
    CommonModule,
    ProgressSpinnerModule,
    ToastModule,
    DropdownModule,
  ],
  templateUrl: './addclinicby-sa.component.html',
  styleUrl: './addclinicby-sa.component.scss',
  providers: [MessageService],
})
export class AddclinicbySAComponent {
  clinicDetailsGroup!: FormGroup;
  allRepsResponse: any[] = [];
  filteredReps: any[] = [];
  superAdminId: number | null = null;
  isLoading: boolean = false;
  selectedRep!: {};
  repId!: number;
  usStates = US_STATES;
  timeZone = TIME_ZONES;
  headQuarters: string[] = [];
  constructor(
    private superAdminService: SuperAdminService,
    private messageService: MessageService,
    private formGroup: FormBuilder,
    private sharedService: SharedService,
    private router: Router
  ) {}

  ngOnInit() {
    const registerId = this.sharedService.getId('id');
    const Id = registerId ? Number(registerId.trim()) : 0;

    this.clinicDetailsGroup = this.formGroup.group({
      firstName: new FormControl(null, [Validators.required]),
      lastName: new FormControl(null, [Validators.required]),
      clinicName: new FormControl(null, [Validators.required]),
      contactNumber: new FormControl(null, [Validators.required]),
      state: new FormControl(null, [Validators.required]),
      zipCode: new FormControl(null, [
        Validators.required,
        Validators.pattern(/^\d{5}$/),
      ]),
      email: new FormControl(null, [Validators.required, Validators.email]),
      address: new FormControl(null, [Validators.required]),
      city: new FormControl(null, [Validators.required]),
      timezone:new FormControl(null,[Validators.required]),
      superAdminId: Id,
      salesRepId: new FormControl(null, [Validators.required]),
      headquater: new FormControl(false),
      headquaters: new FormControl(null),
    });
    this.getHeadQuarters();
    this.getSalereps();
  }
  addClinic() {
    if (this.clinicDetailsGroup.valid) {
      this.isLoading = true;
      const payload = {
        ...this.clinicDetailsGroup.value,
      };
      this.superAdminService.addClinic(payload).subscribe({
        next: (response) => {
          this.isLoading = false;

          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Clinic added successfully!',
          });
          setTimeout(() => {
            this.router.navigate(['superAdmin/saclinicdetails']);
          }, 3000);
          this.clinicDetailsGroup.reset({
            clinicName: null,
            contactNumber: null,
            stateCode: null,
            state: null,
            zipCode: null,
            email: null,
            address: null,
            city: null,
            superAdminId: null,
            salesRepId: null,
            timeZone:null,
          });
          this.clinicDetailsGroup.get('salesRepId')?.setValue(null);
        },
        error: (error) => {
          this.isLoading = false;
          if (error?.status === 409) {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Email already exists. Please use a different email.',
            });
          } else {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Error in adding Clinic!',
            });
          }
        },
      });
    }
  }
  // phoneNumber
  formatPhoneNumber(): void {
    const input = this.clinicDetailsGroup
      .get('contactNumber')
      ?.value.replace(/\D/g, ''); // Remove non-numeric characters
    let formattedInput = input;

    if (input.length > 0) {
      formattedInput = `(${input.substring(0, 3)}`; // Add opening parenthesis
    }
    if (input.length >= 4) {
      formattedInput += `) ${input.substring(3, 6)}`; // Add closing parenthesis and space
    }
    if (input.length >= 7) {
      formattedInput += `-${input.substring(6, 10)}`; // Add hyphen before the last 4 digits
    }

    // Set the formatted value back to the form control
    this.clinicDetailsGroup
      .get('contactNumber')
      ?.setValue(formattedInput, { emitEvent: false });

    // Add the pattern validator only when the full phone number is entered
    if (input.length === 10) {
      this.clinicDetailsGroup
        .get('contactNumber')
        ?.setValidators([
          Validators.required,
          Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/),
        ]);
    } else {
      // Remove pattern validator if the input is not yet complete
      this.clinicDetailsGroup
        .get('contactNumber')
        ?.setValidators([Validators.required]);
    }

    this.clinicDetailsGroup
      .get('contactNumber')
      ?.updateValueAndValidity({ emitEvent: false });
  }

  // activeReps
  getSalereps() {
    this.superAdminService.getAllReps().subscribe({
      next: (response) => {
        this.allRepsResponse = response;
        this.filteredReps = this.allRepsResponse.map((rep) => ({
          label: `${rep.firstName}${rep.lastName} - ${rep.city}, ${rep.state}`, // Combining name, city, and state
          value: rep.id, // Store the full rep object in value
        }));
      },
      error: (error) => {
        if (error.status === 401) {

        } else {

        }
      },
    });
  }
  filterReps(searchText: string) {
    if (!searchText) {
      // Show all representatives if no search text
      this.filteredReps = this.allRepsResponse.map((rep) => ({
        label: `${rep.firstName} ${rep.lastName} - ${rep.city}, ${rep.state}`,
        value: rep.id,
      }));
    } else {
      const lowerSearchText = searchText.toLowerCase();
      // Filter by first name, last name, city, or state
      this.filteredReps = this.allRepsResponse
        .filter((rep) => {
          const nameMatch =
            rep.firstName.toLowerCase().includes(lowerSearchText) ||
            rep.lastName.toLowerCase().includes(lowerSearchText);
          const cityMatch = rep.city.toLowerCase().includes(lowerSearchText);
          const stateMatch = rep.state.toLowerCase().includes(lowerSearchText);

          return nameMatch || cityMatch || stateMatch;
        })
        .map((rep) => ({
          label: `${rep.firstName} ${rep.lastName} - ${rep.city}, ${rep.state}`,
          value: rep.id,
        }));
    }
  }

  getHeadQuarters() {
    this.superAdminService.getAllHeadQuarters().subscribe({
      next: (response) => {
        this.headQuarters = response;
      },
      error: (error) => {
        if (error.status === 401) {

        } else {
          
        }
      },
    });
  }
}
