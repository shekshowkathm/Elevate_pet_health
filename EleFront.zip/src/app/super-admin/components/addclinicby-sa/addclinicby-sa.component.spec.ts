import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddclinicbySAComponent } from './addclinicby-sa.component';

describe('AddclinicbySAComponent', () => {
  let component: AddclinicbySAComponent;
  let fixture: ComponentFixture<AddclinicbySAComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddclinicbySAComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddclinicbySAComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
