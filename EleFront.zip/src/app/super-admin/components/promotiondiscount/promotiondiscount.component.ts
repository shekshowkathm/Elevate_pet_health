import { ChangeDetectorRef, Component } from '@angular/core';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { CalendarModule } from 'primeng/calendar';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { PaginatorModule } from 'primeng/paginator';
import { Promotion } from '../../model/promotion';
import { CommonModule, DatePipe } from '@angular/common';
import { PromotionService } from '../../service/promotion.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Router } from '@angular/router';
import { nextDay } from 'date-fns';
import { error } from 'console';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ToastModule } from 'primeng/toast';

import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { StripeService } from '../../../clinic/services/stripe.service';
import { SharedService } from '../../../shared/service/shared.service';

@Component({
  selector: 'app-promotiondiscount',
  standalone: true,
  imports: [
    CommonModule,
    TableModule,
    ButtonModule,
    CalendarModule,
    ToastModule,
    PaginatorModule,
    MatSlideToggleModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    FormsModule,
    MatIconModule,
    DialogModule,
    InputTextModule,

  ],
  templateUrl: './promotiondiscount.component.html',
  styleUrl: './promotiondiscount.component.scss',
  providers: [
    MessageService,
    ConfirmationService,
    DatePipe,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    MatSlideToggleModule,
  ],
})
export class PromotiondiscountComponent {
  showCalendar: boolean = false;
  selectedDate!: string;
  clinics: any[] = [];
  filterResponse: any[] = [];
  promotions: any[] = [];
  minDate = new Date().toISOString().split('T')[0];

  displayGenerateDialog: boolean = false;
  selectedClinic: any = null;
  expiryDate: string = '';
  errorMessage: string = '';
  promotion: string = '';
  dropdownValue: string = '';
  headquarter: string = '';
  isLoading: boolean = false;

  constructor(
    private promotionService: PromotionService,
    private messageService: MessageService,
    private router: Router,
    private datePipe: DatePipe,
    private cdr: ChangeDetectorRef,
    private stripeService: StripeService,
    private sharedservice: SharedService,
  ) { }

  ngOnInit() {
    this.fetchPromotions();
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

  getTomorrow(): Date {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow;
  }

  onEndDateChange(clinic: any): void {
  }

  toggleCalendar() {
    this.showCalendar = !this.showCalendar;
  }

  fetchPromotions() {
    const Role = this.sharedservice.getItem('role');
    if (Role) {
      this.isLoading = true;
      this.promotionService.getAllNewPromotion(Role).subscribe({
        next: (response: any) => {
          this.clinics = response;
          this.filterResponse = [...response];
          this.isLoading = false;
          this.cdr.detectChanges();
        },
        error: (err) => {
          this.isLoading = false;
        },
      });
    }
  }
  
  filterPromotion() {
    if (!this.promotion && !this.dropdownValue && !this.headquarter) {
      this.filterResponse = [...this.clinics];
    } else {
      this.filterResponse = this.clinics.filter((promo) => {
        const clinicName = `${promo.clinicName}`.toLowerCase();
        const searchQuery = this.promotion.toLowerCase() || '';
        const dropdownFilter =
        !this.dropdownValue ||
        (this.dropdownValue === 'thirtySixtyNinety' && (promo.thirtySixtyNinety === "ONGOING" || promo.thirtySixtyNinety === "TAKEN" )) ||
        (this.dropdownValue === 'multiPet' && promo.multiPet) ||
        (this.dropdownValue === 'multiYear' && promo.multiYear) ||
        (this.dropdownValue === 'generateCode' && promo.generateCode) ||
        (this.dropdownValue === 'all' &&
          promo.thirtySixtyNinety &&
          promo.multiPet &&
          promo.multiYear &&
          promo.generateCode);
          const headquarterFilter = !this.headquarter || 
          (promo.headquater && promo.clinicName.toLowerCase().includes(this.headquarter.toLowerCase())) ||
          (!promo.headquater && promo.headquaters && promo.headquaters.toLowerCase().includes(this.headquarter.toLowerCase()));

      return (
        (clinicName.includes(searchQuery) || searchQuery === '') &&
        dropdownFilter &&
        headquarterFilter

      );
    });
  }
  }
  
  clearFilter() {
    this.promotion = '';
    this.dropdownValue = '';
    this.headquarter = '';
    this.filterPromotion();
    
  }
  isNoData(): boolean {
    return this.filterResponse.length === 0;
  }

  isPromotionActive(clinic: any, promotion: string): boolean {
    const isActive = clinic.activeDiscount?.includes(promotion) || false;
    return isActive;
  }

  viewClinic(clinic: any) {

    this.router.navigate([
      '/superAdmin/clinic-details-for-discount',
      clinic.clinicId,
    ]);
  }

  deleteClinic(clinic: any) {

  }
  exportToExcel() {
    this.sharedservice.exportAsExcelFile(this.clinics, 'Promotion-Discount');
  }

  onToggleDaysChange(clinic: any, promotionType: string) {
    const today = new Date();
    const formattedDate = this.datePipe.transform(today, 'MM/dd/yyyy');

    // Calculate the end date based on promotion type
    let endDate: Date | null = null;
    if (promotionType === '30-60-90 Days') {
      endDate = new Date(today); // Create a new Date instance based on today
      endDate.setDate(today.getDate() + 30); // Add 30 days to the new date instance
    }

    // Format the end date to avoid any timezone issues
    const formattedEndDate = endDate
      ? this.datePipe.transform(endDate, 'MM/dd/yyyy')
      : null;

    const promotionObject = {
      clinic: {
        id: clinic.clinicId,
      },
      promotionType: promotionType,
      // startDate: formattedDate, // Set today's date here
      endDate: formattedEndDate, // Set the calculated end date
    };




    this.promotionService.addPromotionToClinic(promotionObject).subscribe({
      next: (response: any) => {

        setTimeout(() => {
          this.fetchPromotions();
        }, 500);
      },
      error: (err: any) => {

      },
    });
  }

  openGenerateCodePopup(clinic: any): void {
    this.selectedClinic = clinic;
    this.displayGenerateDialog = true;
    this.errorMessage = ''; // Reset error message when dialog opens
  }

  submitGenerateCode(): void {
    const currentDate = new Date();
    const selectedDate = new Date(this.expiryDate);

    if (!this.expiryDate) {
      this.errorMessage = 'Please enter an expiry date.';
    } else if (selectedDate <= currentDate) {
      this.errorMessage = 'Expiry date should be a future date.';
    } else {
      // Format the expiryDate as MM/DD/YYYY
      const formattedExpiryDate = this.formatDateToMMDDYYYY(selectedDate);

      const dateBody = {
        clinicId: this.selectedClinic.clinicId,
        expiryDate: formattedExpiryDate,
      };
      this.promotionService.generateCodeMethod(dateBody).subscribe({
        next: (response) => {

          this.displayGenerateDialog = false;
          this.expiryDate = '';
          this.errorMessage = '';
          this.fetchPromotions();
        },
        error: (err) => {

        },
      });
    }
  }

  // Utility method to format date as MM/DD/YYYY
  formatDateToMMDDYYYY(date: Date): string {
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
    const day = String(date.getDate()).padStart(2, '0');
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
  }

  closeDialog(): void {
    this.displayGenerateDialog = false;
    this.expiryDate = '';
    this.errorMessage = '';
  }

  creactCoupanCode(clinic: any): void {

    if (
      clinic.monthlyPlanCounts ===
      'No wellness plans found for the specified month and year.'
    ) {
      this.messageService.add({
        severity: 'warn',
        summary: 'Warning',
        detail:
          'Cannot create a coupon code: No wellness plans found for the specified month and year.',
      });
      setTimeout(() => {
        this.fetchPromotions();
      }, 500);
      return;
    }

    this.promotionService.getPromotionByClinicByID(clinic.clinicId).subscribe({
      next: (response: any) => {
        this.promotions = response;
        const promotion = this.promotions.find(
          (x: any) => x.promotionType === clinic.generateCode,
        );
        const data = {
          clinicId: clinic.clinicId,
          couponCode: clinic.generateCode,
          couponName: clinic.generateCode,
          firstTimeOnly: true,
          couponExpiryDate: clinic.expiryDate,
          maxRedemptions: clinic.monthlyPlanCounts,
          stripeAccountId: clinic.stripeAccountId,
          discountAmount: 4900,
          durationMonths: 12,
          productId: 'prod_R1h23GJXfBEAyp',
          promotionId: promotion ? promotion.promotionId : null,
        };


        this.stripeService.creactCoupanCode(data).subscribe({
          next: (doc: any) => {
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Coupon code created successfully.',
            });
          },
          error: (err: any) => {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Failed to create coupon code. Please try again.',
            });
          },
          complete: () => {
          
          },
        });
      },
      error: (err: any) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Error fetching promotions. Please try again later.',
        });
      },
    });
  }
}
