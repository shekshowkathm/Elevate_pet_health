import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PromotiondiscountComponent } from './promotiondiscount.component';

describe('PromotiondiscountComponent', () => {
  let component: PromotiondiscountComponent;
  let fixture: ComponentFixture<PromotiondiscountComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PromotiondiscountComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PromotiondiscountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
