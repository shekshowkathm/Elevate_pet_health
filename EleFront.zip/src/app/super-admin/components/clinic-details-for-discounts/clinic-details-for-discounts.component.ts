import { CommonModule, DatePipe, NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { PromotionService } from '../../service/promotion.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ActivatedRoute, Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { StripeService } from '../../../clinic/services/stripe.service';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { DialogModule } from 'primeng/dialog';
import { ToastModule } from 'primeng/toast';
import { ButtonModule } from 'primeng/button';

@Component({
  selector: 'app-clinic-details-for-discounts',
  standalone: true,
  imports: [
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    TableModule,
    NgIf,
    MatSlideToggleModule,
    DialogModule,
    FormsModule,
    ReactiveFormsModule,
    ToastModule,
    MatDatepickerModule,
    CommonModule,
    ButtonModule,
  ],
  templateUrl: './clinic-details-for-discounts.component.html',
  styleUrl: './clinic-details-for-discounts.component.scss',
  providers: [
    MessageService,
    ConfirmationService,
    DatePipe,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    MatSlideToggleModule,
  ],
})
export class ClinicDetailsForDiscountsComponent {
  clinicId: string = '';

  promotions: any[] = [];

  selectedDate: string = ''; // Ensure it's an empty string, not null
  today: string = new Date().toISOString().split('T')[0]; // Get today's date in YYYY-MM-DD format
  isDateValid: boolean = false; // Flag to track whether the selected date is valid

  showExpDate: boolean = false;
  showDiv: boolean = true;

  code: string = '';

  expiryDate: string = '';
  errorMessage: string = '';
  minDate = new Date().toISOString().split('T')[0];
  displayGenerateDialog: boolean = false;
  selectedPromotions: any = null;

  constructor(
    private promotionService: PromotionService,
    private messageService: MessageService,
    private router: Router,
    private route: ActivatedRoute,
    private stipeService: StripeService,
    private datePipe: DatePipe,
  ) {}

  ngOnInit() {
    this.clinicId = this.route.snapshot.paramMap.get('clinicId')!;
    this.fetchClinicPromotionDetails();
  }

  fetchClinicPromotionDetails() {
    this.promotionService.getPromotionByClinicByID(this.clinicId).subscribe({
      next: (response: any) => {
        this.promotions = response;
      },
      error: (error) => {},
    });
  }

  showExpDatePart() {
    this.showExpDate = true;
  }
  cancelQuestion() {
    this.showDiv = false;
  }

  normalPosition() {
    this.showExpDate = false;
    this.showDiv = true;
  }

  onDateChange() {
    // Ensure selectedDate is not null
    if (this.selectedDate) {
      const selectedDate = new Date(this.selectedDate);
      const currentDate = new Date();

      // Validate that the selected date is today or in the future
      this.isDateValid = selectedDate >= currentDate;
    }
  }

  submitDate() {
    if (this.isDateValid) {
      const dateBody = {
        clinicId: this.promotions[0].clinicId,
        expiryDate: this.selectedDate,
      };

      this.promotionService.generateCodeMethod(dateBody).subscribe({
        next: (response) => {
          this.code = response;

          // Clear the date after submission
          this.selectedDate = ''; // Reset the date picker value
          this.isDateValid = false; // Reset validation flag
          this.code = response;
        },
        error: (err) => {},
      });
    } else {
    }
  }

  generateCode() {
    this.promotionService
      .generateCodeMethod(this.promotions[0].clinicId)
      .subscribe({
        next: (response) => {
          this.code = response;
        },
        error: (err) => {},
      });
  }

  onStatusChange(promotion: any): void {
    // Add logic to handle the status change, such as making an API call
    const statusObject = {
      id: promotion.promotionId,
      expiryDate: promotion.expiryDate,
      endDate: promotion.endDate,
      status: promotion.status,
    };
    this.promotionService.updateStatusAndExpirayDate(statusObject).subscribe({
      next: (response) => {
        this.stipeService.deleteCoupon(promotion).subscribe((doc: any) => {
          this.fetchClinicPromotionDetails();
        });
      },
      error: (err) => {},
    });
    setTimeout(() => {
      this.fetchClinicPromotionDetails();
    }, 850);
  }

  // End date methods
  submitEndDate(): void {
    const currentDate = new Date();
    const selectedDate = new Date(this.expiryDate);

    if (!this.expiryDate) {
      this.errorMessage = 'Please enter an expiry date.';
    } else if (selectedDate <= currentDate) {
      this.errorMessage = 'Expiry date should be a future date.';
    } else {
      // Format the expiryDate as MM/DD/YYYY
      const formattedExpiryDate = this.formatDateToMMDDYYYY(selectedDate);

      const dateBody = {
        id: this.selectedPromotions.promotionId,
        endDate: formattedExpiryDate,
        status: true,
      };

      this.promotionService.updateStatusAndExpirayDate(dateBody).subscribe({
        next: (response) => {
          this.displayGenerateDialog = false;
          this.expiryDate = '';
          this.errorMessage = '';
          this.fetchClinicPromotionDetails();
        },
        error: (err) => {},
      });
    }
  }

  // Utility method to format date as MM/DD/YYYY
  formatDateToMMDDYYYY(date: Date): string {
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
    const day = String(date.getDate()).padStart(2, '0');
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
  }

  openGenerateCodePopup(promotion: any): void {
    this.selectedPromotions = promotion;
    this.displayGenerateDialog = true;
    this.errorMessage = ''; // Reset error message when dialog opens
  }

  closeDialog(): void {
    this.displayGenerateDialog = false;
    this.expiryDate = '';
    this.errorMessage = '';
  }
}
