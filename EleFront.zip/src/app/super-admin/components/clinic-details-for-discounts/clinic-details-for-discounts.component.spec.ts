import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicDetailsForDiscountsComponent } from './clinic-details-for-discounts.component';

describe('ClinicDetailsForDiscountsComponent', () => {
  let component: ClinicDetailsForDiscountsComponent;
  let fixture: ComponentFixture<ClinicDetailsForDiscountsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClinicDetailsForDiscountsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClinicDetailsForDiscountsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
