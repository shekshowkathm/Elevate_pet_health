import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuperAdminleftNavbarComponent } from './super-adminleft-navbar.component';

describe('SuperAdminleftNavbarComponent', () => {
  let component: SuperAdminleftNavbarComponent;
  let fixture: ComponentFixture<SuperAdminleftNavbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SuperAdminleftNavbarComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SuperAdminleftNavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
