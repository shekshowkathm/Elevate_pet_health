import { CommonModule, NgClass } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  input,
  Output,
  output,
} from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';

interface NavItem {
  label: string;
  icon?: string;
  route?: string;
  color?: string;
  children?: NavItem[];
  isOpen?: boolean;
}

@Component({
  selector: 'app-super-adminleft-navbar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './super-adminleft-navbar.component.html',
  styleUrl: './super-adminleft-navbar.component.scss',
})
export class SuperAdminleftNavbarComponent {
  @Input() isLeftSidebarCollapsed: boolean = false;
  @Output() changeIsLeftSidebarCollapsed = new EventEmitter<boolean>();
  constructor(private router: Router) {}
  navItems: NavItem[] = [
    { label: 'Dashboard', icon: 'pi-th-large', route: '/superAdmin' },
    {
      label: 'Elevate Sales Rep',
      icon: 'pi pi-users',
      route: '/superAdmin/elevateSalesRepComponent',
    },
    {
      label: 'Clinic Details',
      icon: 'pi-envelope',
      route: '/superAdmin/saclinicdetails',
      children: [
        {
          label: 'Clinic Owners',
          icon: '',
          route: '/superAdmin/saclinicowners',
          color: '#2e68d4',
        },
        {
          label: 'Clinic Admin',
          icon: '',
          route: '/superAdmin/saclinicAdmins',
          color: '#ffb946',
        },
        {
          label: 'Associates',
          icon: '',
          route: '/superAdmin/saclinicAssociates',
          color: '#885af8',
        },
        {
          label: 'Pet Owners',
          icon: '',
          route: '/superAdmin/sapetOwners',
          color: '#2ed47a',
        },
      ],
      isOpen: false,
    },
    { label: 'Setup Data', icon: 'pi pi-list', route: '/superAdmin/setUpData' },
    {
      label: 'Service List',
      icon: 'pi-heart-fill',
      route: '/superAdmin/servicelist',
    },
    {
      label: 'Promotion Discounts',
      icon: 'pi-th-large',
      route: '/superAdmin/promotion-discount',
    },
    {
      label: 'Payment',
      icon: 'pi-calendar-clock',
      route: '/superAdmin/stripe',
    },
    {
      label: 'Card Details',
      icon: 'pi-credit-card',
      route: '/superAdmin/cardDetails',
    },
    { label: 'Stripe Dashboard',
      icon: 'pi-user',
      route: 'stripe-dash' },
    { label: 'Transaction History',
      icon: 'pi-receipt',
      route: 'history' },
  ];

  toggleCollapse(): void {
    this.changeIsLeftSidebarCollapsed.emit(!this.isLeftSidebarCollapsed);
  }

  closeSidenav(): void {
    this.changeIsLeftSidebarCollapsed.emit(true);
  }

  changeDropDown(navItem: NavItem) {
    navItem.isOpen = !navItem.isOpen;
  }

  toggleDropdown(navItem: NavItem): void {
    if (navItem.children) {
      navItem.isOpen = !navItem.isOpen;
    } else if (navItem.route) {
      this.router.navigate([navItem.route]);
    }
  }

  navigateToRoute(route: any): void {
    this.router.navigate([route]);
  }
}
