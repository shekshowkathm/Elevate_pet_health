import { Component, computed, ElementRef, ViewChild } from '@angular/core';
import { SuperAdminService } from '../../service/super-admin.service';
import { ActivatedRoute } from '@angular/router';
import { NgFor, NgClass, NgIf, CommonModule, DatePipe } from '@angular/common';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ScrollerModule } from 'primeng/scroller';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { FilesUploadComponent } from '../../../shared/component/files-upload/files-upload.component';
import { SharedService } from '../../../shared/service/shared.service';
import { CardModule } from 'primeng/card';
import { FileUploadService } from '../../../shared/service/file-upload.service';
import { PetOwner } from '../../model/clinic-request-response';
import { MessageService } from 'primeng/api';
import { DropdownModule } from 'primeng/dropdown';
import { ToastModule } from 'primeng/toast';

@Component({
  selector: 'app-showprofile',
  standalone: true,
  imports: [
    ButtonModule,
    TableModule,
    DialogModule,
    FormsModule,
    ReactiveFormsModule,
    MatSlideToggleModule,
    ScrollerModule,
    CardModule,
    DialogModule,
    DropdownModule,
    ButtonModule,
    ToastModule,
    CommonModule,
    DatePipe
  ],
  templateUrl: './showprofile.component.html',
  styleUrl: './showprofile.component.scss',
  providers: [DialogService, MessageService],
})
export class ShowprofileComponent {
  @ViewChild('fileInput') fileInput!: ElementRef;
  profileData: any = {};
  petOwnersProfile: PetOwner | null = null;
  clinidetailsId!: number;
  clinicOwnerId!: number;
  clinicAdminId!: number;
  clinicAssociateId!: number;
  petOwnerId!: number;
  salesRepId!: number;
  displayDialog: boolean = false;
  selectedFile: File | null = null;
  uploadUrl: string = '';
  filePreview: string | ArrayBuffer | null = null;
  isImage: boolean = false;
  clinicsOfClinicowner: any[] = [];
  allPetsOfPetOwnerResponse: any[] = [];
  clinicdetailsOfRep: any[] = [];
  checked = false;
  disabled = false;
  ref!: DynamicDialogRef;
  allDocsResponse: any[] = [];
  allDocsResponseClinicToSA: any[] = [];
  displayRepsDialog: boolean = false;
  allRepsResponse: any[] = [];
  filteredReps: any[] = [];
  selectedRep: any;
  clinicId!: number;
  totalUpdatedPrice!: string;
  totalDiscountPrice!: string;
  showFuturePlans: boolean = false;
  showHistoryPlans : boolean = false;
  showOnGoingPlans : boolean = true;
  totalsOngoing!: { totalUpdatedPrice: string; totalDiscountPrice: string; firstMonthAmmount: string; remainingMonthAmmount: string;totalPrice:string; }[];
  totalsFuture!: { totalUpdatedPrice: string; totalDiscountPrice: string; firstMonthAmmount: string; remainingMonthAmmount: string;totalPrice:string; }[];
  totalsHistory!: { totalUpdatedPrice: string; totalDiscountPrice: string; firstMonthAmmount: string; remainingMonthAmmount: string;totalPrice:string; }[];





  constructor(
    private superAdminService: SuperAdminService,
    private route: ActivatedRoute,
    private dialogService: DialogService,
    private sharedService: SharedService,
    private fileUploadService: FileUploadService,
    private messageService: MessageService
  ) {}
  ngOnInit(): void {
    this.getprofile();
    this.getIndvidualprofile();
    this.getclinicAdminprofile();
    this.getclinicAssociateprofile();
    this.getPetOwnerprofile();
    this.getclinicRepsprofile();
    this.getAllClinicsOfRep();
    this.getAllDocsSAToClinic();
    this.getAllDocsbyClinictoSA();

  }
  // clinic
  getprofile() {
    this.route.queryParams.subscribe((params) => {
      const clinicId = params['clinicId'];

      this.clinidetailsId = clinicId;

      if (clinicId) {
        this.superAdminService.showProfileById(clinicId).subscribe({
          next: (response) => {
            this.profileData = response;
          },
          error: (error) => {
            if (error.status === 401) {

            } else {

            }
          },
        });
      }
    });
  }
  // owner
  getIndvidualprofile() {
    this.route.queryParams.subscribe((params) => {
      const Id = params['selectedId'];

      this.clinicOwnerId = Id;

      if (Id) {
        this.superAdminService.showPersonProfileById(Id).subscribe({
          next: (response) => {
            this.profileData = response;

            this.superAdminService.allClinicsOfOwner(Id).subscribe({
              next: (clinicDeatilsoftheOwner) => {
                this.clinicsOfClinicowner = clinicDeatilsoftheOwner;
              },
            });
          },
          error: (error) => {
            if (error.status === 401) {

            } else {

            }
          },
        });
      }
    });
  }

  // admin
  getclinicAdminprofile() {
    this.route.queryParams.subscribe((params) => {
      const adminId = params['AdminId'];
      this.clinicAdminId = adminId;

      if (adminId) {
        this.superAdminService.showPersonProfileById(adminId).subscribe({
          next: (response) => {
            this.profileData = response;
          },
          error: (error) => {
            if (error.status === 401) {

            } else {

            }
          },
        });
      }
    });
  }
  // associate
  getclinicAssociateprofile() {
    this.route.queryParams.subscribe((params) => {
      const associateId = params['AssociateId'];

      this.clinicAssociateId = associateId;

      if (associateId) {
        this.superAdminService.showPersonProfileById(associateId).subscribe({
          next: (response) => {
            this.profileData = response;
          },
          error: (error) => {
            if (error.status === 401) {

            } else {

            }
          },
        });
      }
    });
  }
  // petowner
  getPetOwnerprofile() {
    this.route.queryParams.subscribe((params) => {
      const petsId = params['petId'];
      const petOwnersId = params['petownerId'];

      if (petsId && petOwnersId) {
        this.superAdminService
          .petOfPetOwnerWithWellness(petsId, petOwnersId)
          .subscribe({
            next: (response) => {
              this.petOwnersProfile = JSON.parse(response)as PetOwner;
              this.petOwnerId = petOwnersId;
              this.calculateTotals();

            },
            error: (error) => {
              if (error.status === 401) {

              } else {

              }
            },
          });
      }
    });
  }
  getOngoingPlans() {
    return Object.values(this.petOwnersProfile?.ongoingPlans || {});
  }
  getHistoryPlans(){
    return Object.values(this.petOwnersProfile?.historyPlans || {});
  }
  getFutureplans(){
    return Object.values(this.petOwnersProfile?.futurePlans || {});

  }
  calculateTotals() {
    const totalsongoing: Array<{ totalUpdatedPrice: string; totalDiscountPrice: string; firstMonthAmmount: string; remainingMonthAmmount: string; totalPrice:string; }> = [];
    const totalsHistory: Array<{ totalUpdatedPrice: string; totalDiscountPrice: string; firstMonthAmmount: string; remainingMonthAmmount: string; totalPrice:string; }> = [];
    const totalsFuture: Array<{ totalUpdatedPrice: string; totalDiscountPrice: string; firstMonthAmmount: string; remainingMonthAmmount: string; totalPrice:string; }> = [];
    const ongoingPlans = this.getOngoingPlans();
    const planHistory = this.getHistoryPlans();
    const futurePlans = this.getFutureplans();
        if(ongoingPlans){
            ongoingPlans.forEach((planSet, index) => {
            let totalUpdatedPrice = 0;
            let totalDiscountPrice = 0;


            planSet.forEach((plan: any) => {
              totalUpdatedPrice += parseFloat(plan.updatedPrice || '0');
              totalDiscountPrice += parseFloat(plan.discountPrice || '0');

            });
            const firstMonth = totalDiscountPrice / 12 + 49;
            const remainingMonth = totalDiscountPrice / 12 + 7;
            const total = firstMonth + remainingMonth * 11
            totalsongoing[index] = {
              totalUpdatedPrice: totalUpdatedPrice.toFixed(2),
              totalDiscountPrice: totalDiscountPrice.toFixed(2),
              firstMonthAmmount: firstMonth.toFixed(2),
              remainingMonthAmmount: remainingMonth.toFixed(2),
              totalPrice : total.toFixed(2),
            };

          });
          this.totalsOngoing = totalsongoing;
        }
        if(planHistory){
          planHistory.forEach((planSet, index) => {
            let totalUpdatedPrice = 0;
            let totalDiscountPrice = 0;


            planSet.forEach((plan: any) => {
              totalUpdatedPrice += parseFloat(plan.updatedPrice || '0');
              totalDiscountPrice += parseFloat(plan.discountPrice || '0');

            });
            const firstMonth = totalDiscountPrice / 12 + 49;
            const remainingMonth = totalDiscountPrice / 12 + 7;
            const total = firstMonth + remainingMonth * 11
            totalsHistory[index] = {
              totalUpdatedPrice: totalUpdatedPrice.toFixed(2),
              totalDiscountPrice: totalDiscountPrice.toFixed(2),
              firstMonthAmmount: firstMonth.toFixed(2),
              remainingMonthAmmount: remainingMonth.toFixed(2),
              totalPrice : total.toFixed(2),
            };

          });
          this.totalsHistory = totalsHistory;
        }
        if(futurePlans){
          futurePlans.forEach((planSet, index) => {
            let totalUpdatedPrice = 0;
            let totalDiscountPrice = 0;


            planSet.forEach((plan: any) => {
              totalUpdatedPrice += parseFloat(plan.updatedPrice || '0');
              totalDiscountPrice += parseFloat(plan.discountPrice || '0');

            });
            const firstMonth = totalDiscountPrice / 12 + 49;
            const remainingMonth = totalDiscountPrice / 12 + 7;
            const total = firstMonth + remainingMonth * 11
            totalsFuture[index] = {
              totalUpdatedPrice: totalUpdatedPrice.toFixed(2),
              totalDiscountPrice: totalDiscountPrice.toFixed(2),
              firstMonthAmmount: firstMonth.toFixed(2),
              remainingMonthAmmount: remainingMonth.toFixed(2),
              totalPrice : total.toFixed(2),
            };

          });
          this.totalsFuture = totalsFuture;
        }
  }
  togglePlans(planType: string): void {
    if (planType === 'ongoing') {
      this.showOnGoingPlans = !this.showOnGoingPlans;
      if (this.showOnGoingPlans) {
        this.showFuturePlans = false;
        this.showHistoryPlans = false;
      }
    } else if (planType === 'future') {
      this.showFuturePlans = !this.showFuturePlans;
      if (this.showFuturePlans) {
        this.showOnGoingPlans = false;
        this.showHistoryPlans = false;
      }
    } else if (planType === 'history') {
      this.showHistoryPlans = !this.showHistoryPlans;
      if (this.showHistoryPlans) {
        this.showOnGoingPlans = false;
        this.showFuturePlans = false;
      }
    }
  }




  // SalesRep
  getclinicRepsprofile() {
    this.route.queryParams.subscribe((params) => {
      const repsId = params['RepId'];

      this.salesRepId = repsId;

      if (repsId) {
        this.superAdminService.showPersonProfileById(repsId).subscribe({
          next: (response) => {
            this.profileData = response;
          },
          error: (error) => {
            if (error.status === 401) {

            } else {

            }
          },
        });
      }
    });
  }
  // getsalesRepsClinic
  getAllClinicsOfRep() {
    this.route.queryParams.subscribe((params) => {
      const repsId = params['RepId'];

      this.salesRepId = repsId;

      if (repsId) {
        this.superAdminService.getAllClinicsOfRep(repsId).subscribe({
          next: (response) => {
            this.clinicdetailsOfRep = response;
          },
          error: (error) => {
            if (error.status === 401) {


            } else {

            }
          },
        });
      }
    });
  }
  // upload docs
  uploadDocumentsToAllClinics() {
    this.ref = this.dialogService.open(FilesUploadComponent, {
      header: 'File Upload',
      width: '400px',
      closable: false,
      data: { url: '/shared/file_upload' },
    });

    this.ref.onClose.subscribe((files: any[]) => {
      if (files && files.length > 0) {
        // this.fileUploadService.uploadFile(file);

        const uploadedByRole = this.sharedService.getItem('role');
        const uploadedById = Number(this.sharedService.getId('id'));
        const clinicId = this.clinidetailsId;
        if (uploadedByRole && uploadedById) {
          // Iterate over each file in the files array
          files.forEach((file) => {
            const documentUrl = file.url;
            const description = file.name;
            const fileSize = file.size;

            if (documentUrl && description) {
              // Construct the payload for each file
              const payload = {
                documentUrl: documentUrl,
                uploadedByRole: uploadedByRole,
                uploadedById: uploadedById,
                fileSize: fileSize,
                targetType: 'Clinic',
                clinicId: clinicId,
                uploadDate: new Date().toISOString(),
                description: description,
              };
              // Call the service to upload each file's payload
              this.superAdminService
                .uploadfilesToAllclinics(payload)
                .subscribe({
                  next: (response) => {
                    this. getAllDocsSAToClinic();
                  },
                  error: (error) => {

                  },
                });
            }
          });
        } else {

        }
      }
    });
  }

  // Close the dialog
  closeDialog() {
    this.displayDialog = false;
  }

  getAllDocsSAToClinic() {
    this.superAdminService.getDocsOfSAtoClinics(this.clinidetailsId).subscribe({
      next: (response) => {
        this.allDocsResponse = response;
      },
      error: (error) => {
        if (error.status === 401) {

        } else {

        }
      },
    });
  }

  getAllDocsbyClinictoSA() {
    this.superAdminService.getDocsOfClinicsToSA(this.clinidetailsId).subscribe({
      next: (response) => {
        this.allDocsResponseClinicToSA = response;
      },
      error: (error) => {
        if (error.status === 401) {

        } else {

        }
      },
    });
  }

  getSalereps() {
    this.superAdminService.getAllReps().subscribe({
      next: (response) => {
        this.allRepsResponse = response;

        this.filteredReps = this.allRepsResponse.map((rep) => ({
          label: `${rep.firstName}${rep.lastName} - ${rep.city}, ${rep.state}`, // Combining name, city, and state
          value: rep, // Store the full rep object in value
        }));
      },
      error: (error) => {

      },
    });
  }
  filterReps(event: { filter: string }) {
    const searchText = event.filter.toLowerCase();

    if (!searchText) {
      // If no search text, show all representatives
      this.filteredReps = this.allRepsResponse.map((rep) => ({
        label: `${rep.firstName} ${rep.lastName} - ${rep.city}, ${rep.state}`,
        value: rep,
      }));
    } else {
      // Filter by name, city, or state
      this.filteredReps = this.allRepsResponse
        .filter((rep) => {
          const nameMatch = `${rep.firstName} ${rep.lastName}`
            .toLowerCase()
            .includes(searchText);
          const cityMatch = rep.city.toLowerCase().includes(searchText);
          const stateMatch = rep.state.toLowerCase().includes(searchText);

          // Return true if search text matches any of the fields
          return nameMatch || cityMatch || stateMatch;
        })
        .map((rep) => ({
          label: `${rep.firstName} ${rep.lastName} - ${rep.city}, ${rep.state}`,
          value: rep,
        }));
    }
  }
  onAddRep(clinciId: number) {
    this.clinicId = clinciId;

    this.getSalereps(); // Fetch the sales reps when "Add" button is clicked
    this.displayRepsDialog = true; // Show the dialog
  }
  assignRep() {
    if (this.clinicId && this.selectedRep) {
      const clinicId = this.clinicId;
      const salesRepId = this.selectedRep;
      this.superAdminService.updateSalesRep(clinicId, salesRepId).subscribe({
        next: (response) => {
          this.getprofile();
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Sales Rep updated',
          });

          this.displayRepsDialog = false;
        },
        error: (error) => {
         
          this.displayRepsDialog = false;
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Failed to update clinic status',
          });
        },
      });
    }
    // Close the dialog after assignment
  }

  clearDropdown() {
    this.selectedRep = null; // Clear the selected value when the dialog is closed
  }
  viewDocument(doc: string) {
    window.open(doc, '_blank');
  }
}
