import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSalesRepComponent } from './add-sales-rep.component';

describe('AddSalesRepComponent', () => {
  let component: AddSalesRepComponent;
  let fixture: ComponentFixture<AddSalesRepComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddSalesRepComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddSalesRepComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
