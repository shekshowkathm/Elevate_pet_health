import { NgClass, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { SuperAdminService } from '../../../super-admin/service/super-admin.service';
import { SharedService } from '../../../shared/service/shared.service';
import { US_STATES } from '../../../shared/constants/usa-states';
import { DropdownModule } from 'primeng/dropdown';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TIME_ZONES } from '../../../shared/constants/timeZone';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-add-sales-rep',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    NgIf,
    DropdownModule,
    NgClass,
    ToastModule,
    ProgressSpinnerModule,
  ],
  templateUrl: './add-sales-rep.component.html',
  styleUrl: './add-sales-rep.component.scss',
  providers: [MessageService],
})
export class AddSalesRepComponent {
  form!: FormGroup;
  loading: boolean = false;
  regId: string | null = null;
  Usstatescodes = US_STATES;
  timeZone = TIME_ZONES;
  constructor(
    private fb: FormBuilder,
    private SuperAdminService: SuperAdminService,
    private sharedservice: SharedService,
    private messageService: MessageService,
    private router: Router,
    
  ) {}

  ngOnInit() {
    const registerId = this.sharedservice.getId('id');
    this.regId = registerId ? registerId.trim() : null;
    this.form = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      address:['',[Validators.required]],
      contactNumber: [
        '',
        [
          Validators.required,
          Validators.pattern(/^\d+$/),
          Validators.minLength(10),
          Validators.maxLength(10),
        ],
      ],
      zipcode: [
        '',
        [
          Validators.required,
          Validators.pattern(/^\d+$/),
          Validators.minLength(5),
          Validators.maxLength(5),
        ],
      ],
      state: ['', Validators.required],
      timezone:['',Validators.required],
      city: ['', Validators.required],
    });
    this.formatPhoneNumber();
  }

  onSubmit() {
    if (this.form.valid) {
      const role = 'SALES_REP';
      const regId = this.regId;
      const createdBy = {
        id: regId,
      };
      this.loading = true;
      const salesRepObj = {
        ...this.form.value,
        role: role,
        created_By: createdBy,
      };
      this.SuperAdminService.addSaleRep(salesRepObj).subscribe({
        next: (response) => {
          this.loading = false;
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'SalesRep Added!',
          });
          setTimeout(() => {
            this.router.navigate(['superAdmin/elevateSalesRepComponent']);
          }, 3000);
          this.form.reset();
        },
        error: (error) => {
          
          this.loading = false; // Stop the loader on error

          if (error?.error === 'Email Already Exists') {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Email already exists. Please use a different email.',
            });
          } else {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Error in adding SalesRep!',
            });
          }
        },
      });
    } else {
      this.loading = false;
      
    }
  }

  get formControls() {
    return this.form.controls;
  }

  formatPhoneNumber(): void {
    const input = this.form.get('contactNumber')?.value.replace(/\D/g, ''); // Remove non-numeric characters
    let formattedInput = input;

    if (input.length > 0) {
      formattedInput = `(${input.substring(0, 3)}`; // Add opening parenthesis
    }
    if (input.length >= 4) {
      formattedInput += `) ${input.substring(3, 6)}`; // Add closing parenthesis and space
    }
    if (input.length >= 7) {
      formattedInput += `-${input.substring(6, 10)}`; // Add hyphen before the last 4 digits
    }

    // Set the formatted value back to the form control
    this.form
      .get('contactNumber')
      ?.setValue(formattedInput, { emitEvent: false });

    // Add the pattern validator only when the full phone number is entered
    if (input.length === 10) {
      this.form
        .get('contactNumber')
        ?.setValidators([
          Validators.required,
          Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/),
        ]);
    } else {
      // Remove pattern validator if the input is not yet complete
      this.form.get('contactNumber')?.setValidators([Validators.required]);
    }

    this.form
      .get('contactNumber')
      ?.updateValueAndValidity({ emitEvent: false });
  }
}
