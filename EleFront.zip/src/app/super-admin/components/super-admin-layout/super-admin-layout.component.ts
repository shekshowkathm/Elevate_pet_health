import { Component } from '@angular/core';
import { SuperAdminHeaderComponent } from '../super-admin-header/super-admin-header.component';
import { SuperAdminleftNavbarComponent } from '../super-adminleft-navbar/super-adminleft-navbar.component';
import { RouterOutlet } from '@angular/router';
import { HostListener, OnInit, signal } from '@angular/core';
import { SaDashboardComponent } from '../sa-dashboard/sa-dashboard.component';

@Component({
  selector: 'app-super-admin-layout',
  standalone: true,
  imports: [
    SuperAdminHeaderComponent,
    SuperAdminleftNavbarComponent,
    RouterOutlet,
    
  ],
  templateUrl: './super-admin-layout.component.html',
  styleUrl: './super-admin-layout.component.scss',
})
export class SuperAdminLayoutComponent {
  isLeftSidebarCollapsed = signal<boolean>(false);
  screenWidth = signal<number>(0);

  constructor() {
    if (typeof window !== 'undefined') {
      this.screenWidth.set(window.innerWidth);
    }
  }
  @HostListener('window:resize')
  onResize() {
    this.screenWidth.set(window.innerWidth);
    if (this.screenWidth() < 768) {
      this.isLeftSidebarCollapsed.set(true);
    }
  }

  ngOnInit(): void {
    this.isLeftSidebarCollapsed.set(this.screenWidth() < 768);
  }

  changeIsLeftSidebarCollapsed(isLeftSidebarCollapsed: boolean): void {
    this.isLeftSidebarCollapsed.set(isLeftSidebarCollapsed);
  }
}
