import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubscriptionMailSenderComponent } from './subscription-mail-sender.component';

describe('SubscriptionMailSenderComponent', () => {
  let component: SubscriptionMailSenderComponent;
  let fixture: ComponentFixture<SubscriptionMailSenderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SubscriptionMailSenderComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SubscriptionMailSenderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
