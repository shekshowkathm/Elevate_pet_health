import { Component, ElementRef, ViewChild } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { FilesUploadComponent } from '../../../shared/component/files-upload/files-upload.component';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { CalendarModule } from 'primeng/calendar';

import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { DatePipe, NgIf } from '@angular/common';
import { OverlayPanel, OverlayPanelModule } from 'primeng/overlaypanel';
import { SuperAdminService } from '../../service/super-admin.service';
import { ImageUpload } from '../../model/clinic-request-response';
import { TableModule } from 'primeng/table';
import { CardModule } from 'primeng/card';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';


@Component({
  selector: 'app-subscription-mail-sender',
  standalone: true,
  imports: [ButtonModule, DialogModule, DialogModule, CalendarModule, FormsModule, ReactiveFormsModule, ToastModule, OverlayPanelModule, TableModule, NgIf, CardModule],
  templateUrl: './subscription-mail-sender.component.html',
  styleUrl: './subscription-mail-sender.component.scss',
  providers: [DialogService, DatePipe, MessageService],
})
export class SubscriptionMailSenderComponent {
  @ViewChild('op') overlayPanel!: OverlayPanel;
  ref!: DynamicDialogRef;
  imageUrl: string = '';
  imageName: string = '';
  payloadValue: any;
  responseSubscriptionMailSender: ImageUpload[] = [];
  filterScheduledImageSubscriptionMailSender: ImageUpload[] = [];
  isLoading: boolean = false;
  isLoadingPost: boolean = false;
  uploadForm!: FormGroup
  filteredName: string = '';
  filteredUploadedDate: string = '';
  filteredScheduledDate: string = '';
  constructor(
    private dialogService: DialogService,
    private superAdminService: SuperAdminService,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private messageService: MessageService
  ) {

  }
  ngOnInit(): void {

    this.getScheduledImageSubscriptionMailSender();
    this.uploadForm = this.fb.group({
      image: ['', Validators.required],
      scheduledAt: ['', Validators.required],
    });
  }




  uploadImageSubscriptionMailSender() {
    this.ref = this.dialogService.open(FilesUploadComponent, {
      header: 'File Upload',
      width: '400px',
      closable: false,
      data: { url: '/shared/file_upload' },
    });

    this.ref.onClose.subscribe((files: any[]) => {
      if (files && files.length > 0) {

        files.forEach((file) => {
          const documentUrl = file.url;
          const description = file.name;
          const fileSize = file.size;
          this.imageName = file.name;
          this.uploadForm.get('image')?.setValue(file.url);
          // console.log(fileSize,description,documentUrl);
        });



      }
    });
  }


  toggleOverlay(event: Event) {
    this.overlayPanel.toggle(event);

  }
  onImageUpload() {
    this.isLoadingPost = true;
    if (this.uploadForm.value) {
      this.payloadValue = this.uploadForm.value;
      let formData = this.uploadForm.value;
      if (formData.scheduledAt) {
        formData.scheduledAt = new Date(formData.scheduledAt).toLocaleDateString('en-US', {
          month: '2-digit',
          day: '2-digit',
          year: 'numeric'
        });
      }
      this.superAdminService.UploadPictureSubscriptionMailSender(this.payloadValue).subscribe({
        next: (response) => {
          this.isLoadingPost = false;
          this.uploadForm.reset();
          this.imageName = '';
          this.getScheduledImageSubscriptionMailSender();

          this.messageService.add({
            severity: 'success',
            summary: 'Upload Successful',
            detail: 'The image has been uploaded successfully.'
          });
          setTimeout(() => {
            this.isLoadingPost = false;
        }, 500);
          this.overlayPanel.hide();
        },

        error: (error) => {
          console.log(error);
          this.isLoadingPost = false;

          this.messageService.add({
            severity: 'error',
            summary: 'Upload Failed',
            detail: 'An error occurred while uploading the image. Please try again.'
          });


        },
      });
    }
  }
  getScheduledImageSubscriptionMailSender() {
    this.isLoading = true;
    this.superAdminService.fetchImagesSubscriptionMailSender().subscribe({
      next: (response) => {
        this.responseSubscriptionMailSender = response;
        this.filterScheduledImageSubscriptionMailSender = [...response];
        this.isLoading = false;
      },
      error: (error) => {
        if (error.status === 401) {
        } else {
        }
      },
    });

  }
  getFileName(url: string): string {
    return url.split('/').pop() || 'Unknown File';
  }

  filterScheduledImages() {
    this.filterScheduledImageSubscriptionMailSender = this.responseSubscriptionMailSender.filter((image) => {
      const nameMatch = this.filteredName
        ? image.image.toLowerCase().includes(this.filteredName.toLowerCase())
        : true;

      const uploadedDateMatch = this.filteredUploadedDate
        ? this.compareDates(image.uploadedOn, this.filteredUploadedDate)
        : true;

      const scheduledDateMatch = this.filteredScheduledDate
        ? this.compareDates(image.scheduledAt, this.filteredScheduledDate)
        : true;

      return nameMatch && uploadedDateMatch && scheduledDateMatch;
    });
  }
  compareDates(dateStr: string | null, filterDateStr: string): boolean {
    if (!dateStr) return false;

    const parsedDate = this.parseDate(dateStr);
    const filterDate = new Date(filterDateStr); // Convert filter input (YYYY-MM-DD) to Date object

    return parsedDate.toDateString() === filterDate.toDateString();
  }

  // Helper function to parse dates
  parseDate(dateStr: string): Date {
    // Handle both "YYYY-MM-DD" and "MM/DD/YYYY" formats
    if (dateStr.includes('-')) {
      return new Date(dateStr); // "YYYY-MM-DD"
    } else {
      const [month, day, year] = dateStr.split('/').map(Number);
      return new Date(year, month - 1, day); // "MM/DD/YYYY"
    }
  }

  formatDate(dateString: string | null): string {
    if (!dateString) return 'N/A'; // Handle null values
    const parsedDate = new Date(dateString.includes('/') ? this.convertToISO(dateString) : dateString);
    return this.datePipe.transform(parsedDate, 'MM/dd/yyyy') || dateString;
  }

  convertToISO(dateString: string): string {
    const [month, day, year] = dateString.split('/').map(Number);
    return `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
  }

}
