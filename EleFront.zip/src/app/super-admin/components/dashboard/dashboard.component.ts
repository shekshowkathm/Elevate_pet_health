import { Component, OnInit } from "@angular/core";
import { ChartModule } from "primeng/chart";
import { StripeService } from "../../../clinic/services/stripe.service";
import { ProgressSpinnerModule } from "primeng/progressspinner";
import { TableModule } from "primeng/table";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { SharedService } from "../../../shared/service/shared.service";

@Component({
  selector: "app-dashboard",
  standalone: true,
  imports: [ChartModule,ProgressSpinnerModule,TableModule,CommonModule,FormsModule],
  templateUrl: "./dashboard.component.html",
  styleUrl: "./dashboard.component.scss"
})
export class DashboardComponent implements OnInit {
  data: any;
  barData:any
   labels: string[] = [];
   balanceList: any[] = [];
   upcomingList:any[] =[]
   balance: number[] = []; 
   loader:boolean = false
   public petOwnerDetailsFilter: string = '';
   public filteredResponse: any[] = [];
   public trancationList: any[] = [];

  options: any;
  constructor(private stripeService:StripeService,  private sharedService: SharedService){}

  ngOnInit() {
    this.getLastsixMonthDetails()
    this.getBalance()
    this.upcomingPayments()
  }
 async getBalance(){

    this.stripeService.getBalance().subscribe((doc:any)=>{
      this.balanceList = doc
    })
  }
  async getLastsixMonthDetails(){
    this.loader = true
    this.stripeService.getLastSixMonthsPayments().subscribe((doc:any)=>{
      this.barData = doc
      this.loader = false
      if (Array.isArray(this.barData)) {
        this.barData.forEach((item: any) => {
          this.labels.push(item.month); 
          this.balance.push(item.total);   
        });
      }
      const documentStyle = getComputedStyle(document.documentElement);
      const textColor = documentStyle.getPropertyValue("--text-color");
      const textColorSecondary = documentStyle.getPropertyValue(
        "--text-color-secondary"
      );
      const surfaceBorder = documentStyle.getPropertyValue("--surface-border");
  
        this.data = {
          labels: this.labels.reverse(),
          datasets: [
            {
              label: "Total Earings",
              backgroundColor: documentStyle.getPropertyValue("--blue-500"),
              borderColor: documentStyle.getPropertyValue("--blue-500"),
              data: this.balance.reverse()
            }
          ]
        };
  
      this.options = {
        maintainAspectRatio: false,
        aspectRatio: 0.6,
        plugins: {
          legend: {
            labels: {
              color: textColor
            }
          }
        },
        scales: {
          x: {
            ticks: {
              color: textColorSecondary,
              font: {
                weight: 1000
              }
            },
            grid: {
              color: surfaceBorder,
              drawBorder: false
            }
          },
          y: {
            ticks: {
              color: textColorSecondary
            },
            grid: {
              color: surfaceBorder,
              drawBorder: false
            }
          }
        }
      };
    })
  }
  async upcomingPayments(){
    this.stripeService.upcomingPayments().subscribe((doc:any)=>{
      this.upcomingList = doc.filter((item:any) => item.amountDue !=0)
      this.filteredResponse = doc.filter((item:any) => item.amountDue !=0)
    })
  }
  filterByPetOwnerDetails(): void {
    const query = this.petOwnerDetailsFilter.trim().toLowerCase();
    if (!query) {
      this.filteredResponse = this.upcomingList;
    } else {
      this.filteredResponse = this.upcomingList.filter((card) => {
        const customerName = card.customer?.toLowerCase() || "";
        return customerName.includes(query);
      });
    }
  }
  exportToExcel() {
    this.filteredResponse.forEach((res:any) => {
      const date = new Date(res.dueDate * 1000);
      const usDateFormat = new Intl.DateTimeFormat('en-US', {
        dateStyle: 'short',
      }).format(date);
      this.trancationList.push({
        petOwnerName:res.customer,
        petOwnerEmail: res.customerEmail,
        amountDue:(res.amountDue)/100,
        DueDate: usDateFormat,
      });
    });
    this.sharedService.exportAsExcelFile(
      this.trancationList,
      'UpComing Payment Details',
    );
  }

}
