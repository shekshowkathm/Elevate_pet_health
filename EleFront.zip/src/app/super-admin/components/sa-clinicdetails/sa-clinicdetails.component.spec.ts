import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaClinicdetailsComponent } from './sa-clinicdetails.component';

describe('SaClinicdetailsComponent', () => {
  let component: SaClinicdetailsComponent;
  let fixture: ComponentFixture<SaClinicdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SaClinicdetailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SaClinicdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
