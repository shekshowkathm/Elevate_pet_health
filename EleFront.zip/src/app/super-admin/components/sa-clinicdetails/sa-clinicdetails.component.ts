import { CommonModule, NgFor } from '@angular/common';
import { Component, signal } from '@angular/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ScrollerModule } from 'primeng/scroller';
import { TableCheckbox, TableModule } from 'primeng/table';
import { ClinicDetails } from '../../model/clinic-request-response';
import { SuperAdminService } from '../../service/super-admin.service';
import { Router } from '@angular/router';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedService } from '../../../shared/service/shared.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { FilesUploadComponent } from '../../../shared/component/files-upload/files-upload.component';
import { FileUploadService } from '../../../shared/service/file-upload.service';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { CardModule } from 'primeng/card';
import { DialogModule } from 'primeng/dialog';
import { Dropdown, DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { InputTextModule } from 'primeng/inputtext';
import { OverlayModule } from 'primeng/overlay';
import { StripeService } from '../../../clinic/services/stripe.service';

@Component({
  selector: 'app-sa-clinicdetails',
  standalone: true,
  imports: [
    CommonModule,
    TableModule,
    MatSlideToggleModule,
    ScrollerModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    OverlayPanelModule,
    CardModule,
    DialogModule,
    DropdownModule,
    ButtonModule,
    ToastModule,
    InputTextModule,
    OverlayModule,
  ],
  templateUrl: './sa-clinicdetails.component.html',
  styleUrl: './sa-clinicdetails.component.scss',
  providers: [DialogService, MessageService],
})
export class SaClinicdetailsComponent {
  allClinicDetailsResponse: any[] = [];
  filteHeadquartersResponse: any[] = [];
  headQuarterFilter: string = '';
  clinicdetailsFilter: string = '';
  allRepsResponse: any[] = [];
  allDocsResponse: any[] = [];
  filteredReps: any[] = [];
  discountValues: any[] = [];
  discountDialogue: boolean = false;
  checked = false;
  disabled = false;
  ref!: DynamicDialogRef;
  selectedRep: any;
  displayRepsDialog: boolean = false;
  isLoading: boolean = false;
  clinicId!: number;
  ngOnInit(): void {
    this.getAllClinicDetails();
    this.getAllDocsBySa();
  }
  constructor(
    private superAdminService: SuperAdminService,
    private router: Router,
    private sharedService: SharedService,
    private dialogService: DialogService,
    private messageService: MessageService,
    private stirpeService: StripeService,
  ) {}

  getAllClinicDetails() {
    this.isLoading = true;
    this.superAdminService.clinicDetails().subscribe({
      next: (response) => {
        this.allClinicDetailsResponse = response;
        this.filteHeadquartersResponse = [...response];
        this.isLoading = false;
      },
      error: (error) => {
        if (error.status === 401) {
        } else {
        }
      },
    });
  }

  applyHeadquartersFilter() { 
    if (!this.headQuarterFilter) {
      this.filteHeadquartersResponse = [...this.allClinicDetailsResponse];
    } else {
      this.filteHeadquartersResponse = this.allClinicDetailsResponse.filter((clinic) => {
        return (
          (clinic.headquater === true &&
            clinic.clinicName &&
            clinic.clinicName.toLowerCase().includes(this.headQuarterFilter.toLowerCase())) ||
          (clinic.headquater === false &&
            clinic.headquaters &&
            clinic.headquaters.toLowerCase().includes(this.headQuarterFilter.toLowerCase()))
        );
      });
    }
  }
  filterByClinicDetails() {
    if (!this.clinicdetailsFilter) {
      this.filteHeadquartersResponse = [...this.allClinicDetailsResponse];
    } else {
      const searchQuery = this.clinicdetailsFilter.toLowerCase();
      this.filteHeadquartersResponse = this.allClinicDetailsResponse.filter(
        (clinic) => {
          const clinicName = clinic.clinicName?.toLowerCase() || ''; // Ensure values are lowercase and handle undefined/null
          // const zipCode = clinic.zipCode?.toLowerCase() || "";
          const city = clinic.city?.toLowerCase() || '';
          const state = clinic.state?.toLowerCase() || '';
          const salesRepName = clinic.salesRepName?.toLowerCase() || '';

          return (
            clinicName.includes(searchQuery) ||
            // zipCode.includes(searchQuery) ||
            city.includes(searchQuery) ||
            state.includes(searchQuery) ||
            salesRepName.includes(searchQuery)
          );
        },
      );
    }
  }
  showDiscounts(rowIndex: number, discount: any[]) {
    const discountedValues = discount;
    this.discountValues = discountedValues;
    this.discountDialogue = true;
  }
  resend(allClinicDetailsResponse: any) {
    this.stirpeService
      .reSendAccountLink(allClinicDetailsResponse)
      .subscribe((doc: any) => {
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Mail Sent  Successfully',
        });
      });
  }
  clearFilter() {
    this.clinicdetailsFilter = '';
    this.filterByClinicDetails();
  }
  clearHeadequarterFilter() {
    this.headQuarterFilter = '';
    this.applyHeadquartersFilter();
  }

  isNoData(): boolean {
    return this.filteHeadquartersResponse.length === 0;
  }
  navigateToAddClinic() {
    this.router.navigate(['/superAdmin/addClinic']);
  }
  getprofileId(clinic: number) {
    this.router.navigate(['/superAdmin/showProfile'], {
      queryParams: { clinicId: clinic },
    });
  }
  exportToExcel() {
    this.sharedService.exportAsExcelFile(
      this.allClinicDetailsResponse,
      'ClinicDetails',
    );
  }

  uploadDocumentsToAllClinics() {
    this.ref = this.dialogService.open(FilesUploadComponent, {
      header: 'File Upload',
      width: '400px',
      closable: false,
      data: { url: '/shared/file_upload' },
    });

    this.ref.onClose.subscribe((files: any[]) => {
      if (files && files.length > 0) {
        // this.fileUploadService.uploadFile(file);
        const uploadedByRole = this.sharedService.getItem('role');
        const uploadedById = Number(this.sharedService.getId('id'));
        if (uploadedByRole && uploadedById) {
          // Iterate over each file in the files array
          files.forEach((file) => {
            const documentUrl = file.url;
            const description = file.name;
            const fileSize = file.size;

            if (documentUrl && description) {
              // Construct the payload for each file
              const payload = {
                documentUrl: documentUrl,
                uploadedByRole: uploadedByRole,
                uploadedById: uploadedById,
                fileSize: fileSize,
                targetType: 'AllClinic',
                clinicId: null,
                uploadDate: new Date().toISOString(),
                description: description,
              };

              // Call the service to upload each file's payload
              this.superAdminService
                .uploadfilesToAllclinics(payload)
                .subscribe({
                  next: (response) => {
                    this.getAllDocsBySa();
                  },
                  error: (error) => {},
                });
            }
          });
        } else {
        }
      }
    });
  }
  viewDocument(doc: string) {
    window.open(doc, '_blank');
  }
  getAllDocsBySa() {
    this.superAdminService.getAllDocsOfClinicBySA().subscribe({
      next: (response) => {
        this.allDocsResponse = response;
      },
      error: (error) => {
        if (error.status === 401) {
        } else {
        }
      },
    });
  }

  getSalereps() {
    this.superAdminService.getAllReps().subscribe({
      next: (response) => {
        this.allRepsResponse = response;

        this.filteredReps = this.allRepsResponse.map((rep) => ({
          label: `${rep.firstName}${rep.lastName} - ${rep.city}, ${rep.state}`, // Combining name, city, and state
          value: rep, // Store the full rep object in value
        }));
      },
      error: (error) => {},
    });
  }
  filterReps(event: { filter: string }) {
    const searchText = event.filter.toLowerCase();

    if (!searchText) {
      // If no search text, show all representatives
      this.filteredReps = this.allRepsResponse.map((rep) => ({
        label: `${rep.firstName} ${rep.lastName} - ${rep.city}, ${rep.state}`,
        value: rep,
      }));
    } else {
      // Filter by name, city, or state
      this.filteredReps = this.allRepsResponse
        .filter((rep) => {
          const nameMatch = `${rep.firstName} ${rep.lastName}`
            .toLowerCase()
            .includes(searchText);
          const cityMatch = rep.city.toLowerCase().includes(searchText);
          const stateMatch = rep.state.toLowerCase().includes(searchText);

          // Return true if search text matches any of the fields
          return nameMatch || cityMatch || stateMatch;
        })
        .map((rep) => ({
          label: `${rep.firstName} ${rep.lastName} - ${rep.city}, ${rep.state}`,
          value: rep,
        }));
    }
  }
  onAddRep(clinciId: number) {
    this.clinicId = clinciId;
    this.getSalereps(); // Fetch the sales reps when "Add" button is clicked
    this.displayRepsDialog = true; // Show the dialog
  }
  assignRep() {
    if (this.clinicId && this.selectedRep) {
      const clinicId = this.clinicId;
      const salesRepId = this.selectedRep;
      this.superAdminService.updateSalesRep(clinicId, salesRepId).subscribe({
        next: (response) => {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'Sales Rep updated',
          });
          this.getAllClinicDetails();
          this.displayRepsDialog = false;
        },
        error: (error) => {
          this.displayRepsDialog = false;
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Failed to update clinic status',
          });
        },
      });
    }
    // Close the dialog after assignment
  }

  clearDropdown() {
    this.selectedRep = null; // Clear the selected value when the dialog is closed
  }
}
