import { CommonModule, NgClass, NgFor, NgIf } from '@angular/common';
import { Component, signal } from '@angular/core';
import { TableModule } from 'primeng/table';
import { ElevateSalesRep } from '../../model/clinic-request-response';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ScrollerModule } from 'primeng/scroller';
import { Router } from '@angular/router';
import { SuperAdminService } from '../../service/super-admin.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedService } from '../../../shared/service/shared.service';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { InputTextModule } from 'primeng/inputtext';

@Component({
  selector: 'app-elevate-sales-rep',
  standalone: true,
  imports: [
    TableModule,
    MatSlideToggleModule,
    ScrollerModule,
    ReactiveFormsModule,
    FormsModule,
    DialogModule,
    ButtonModule,
    ToastModule,
    ConfirmDialogModule,
    CommonModule,
    InputTextModule,
  ],
  templateUrl: './elevate-sales-rep.component.html',
  styleUrl: './elevate-sales-rep.component.scss',
  providers: [MessageService, ConfirmationService],
})
export class ElevateSalesRepComponent {
  allsaleRepResponse: any[] = [];
  filterResponse: any[] = [];
  selectedRepId!: number;
  checked = false;
  disabled = false;
  displayDeleteDialog: boolean = false;
  isActivateDialog: boolean = false;
  displayAddDialog: boolean = false;
  previousToggleState: boolean | null = null;
  salesRepName: string = '';
  isLoading: boolean = false;

  constructor(
    private router: Router,
    private superAdminService: SuperAdminService,
    private sharedService: SharedService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
  ) {}

  ngOnInit(): void {
    this.getAllSalesRep();
  }
  getAllSalesRep() {
    this.isLoading = true;
    this.superAdminService.getTotalSalesReps().subscribe({
      next: (response) => {
        this.allsaleRepResponse = response;
        this.filterResponse = [...response];
        this.isLoading = false;
      },
      error: (error) => {
        if (error.status === 401) {
          // Optionally, redirect to login or show a user-friendly message
        } else {
        }
      },
    });
  }
  repNameFilter() {
    if (!this.salesRepName) {
      this.filterResponse = [...this.allsaleRepResponse];
    } else {
      this.filterResponse = this.allsaleRepResponse.filter((rep) => {
        const fullName = `${rep.firstName} ${rep.lastName}`.toLowerCase();
        const state = `${rep.state}`.toLowerCase();
        const city = `${rep.city}`.toLowerCase();
        const searchQuery = this.salesRepName.toLowerCase();
        return (
          fullName.includes(searchQuery) ||
          state.includes(searchQuery) ||
          city.includes(searchQuery)
        );
      });
    }
  }
  clearFilter() {
    this.salesRepName = '';
    this.repNameFilter();
  }
  isNoData(): boolean {
    return this.filterResponse.length === 0;
  }
  navigateToAddSalesRep() {
    this.router.navigate(['/superAdmin/addSalesRep']);
  }

  getprofileById(personalId: number) {
    this.router.navigate(['/superAdmin/showProfile'], {
      queryParams: { RepId: personalId },
    });
  }
  exportToExcel() {
    this.sharedService.exportAsExcelFile(this.allsaleRepResponse, 'SalesRep');
  }
  confirmDelete(userId: number) {
    this.selectedRepId = userId;
    this.displayDeleteDialog = true;
  }
  onToggleChange(checked: boolean, repId: number): void {
    this.isActivateDialog = checked;
    this.displayDeleteDialog = true;
    this.selectedRepId = repId;
  }
  deleteUser() {
    if (this.selectedRepId) {
      this.superAdminService.deleteSalesRep(this.selectedRepId).subscribe({
        next: (response) => {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'SalesRep deleted!',
          });
          this.displayDeleteDialog = false;
          this.getAllSalesRep();
          this.confirmationService.confirm({
            message: 'Do you want to add a new SalesRep to Clinics?',
            header: 'Confirmation',
            icon: 'pi pi-exclamation-circle',
            acceptLabel: 'Add',
            rejectLabel: 'No',
            accept: () => {
              this.router.navigate(['superAdmin/saclinicdetails']);
            },
            reject: () => {},
          });
        },
        error: (error) => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Error in Deleting Rep!',
          });
        },
      });

      this.displayDeleteDialog = false;
    }
  }
  activateUser() {
    if (this.selectedRepId) {
      this.superAdminService.deleteSalesRep(this.selectedRepId).subscribe({
        next: (response) => {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: 'SalesRep Activated!',
          });
          this.displayDeleteDialog = false;
          this.getAllSalesRep();
          this.confirmationService.confirm({
            message: 'Do you want to add a new SalesRep to Clinics?',
            header: 'Confirmation',
            icon: 'pi pi-exclamation-circle',
            acceptLabel: 'Add',
            rejectLabel: 'No',
            accept: () => {
              this.router.navigate(['superAdmin/saclinicdetails']);
            },
            reject: () => {},
          });
        },
        error: (error) => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Error in Activating Rep!',
          });
        },
      });

      this.displayDeleteDialog = false;
    }
  }
}
