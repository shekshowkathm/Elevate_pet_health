import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ElevateSalesRepComponent } from './elevate-sales-rep.component';

describe('ElevateSalesRepComponent', () => {
  let component: ElevateSalesRepComponent;
  let fixture: ComponentFixture<ElevateSalesRepComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ElevateSalesRepComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ElevateSalesRepComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
