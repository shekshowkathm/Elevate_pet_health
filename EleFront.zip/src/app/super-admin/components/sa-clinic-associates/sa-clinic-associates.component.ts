import { NgFor, NgClass, CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ScrollerModule } from 'primeng/scroller';
import { TableModule } from 'primeng/table';
import { ClinicAssociates } from '../../model/clinic-request-response';
import { SuperAdminService } from '../../service/super-admin.service';
import { Router } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedService } from '../../../shared/service/shared.service';
import { InputTextModule } from 'primeng/inputtext';

@Component({
  selector: 'app-sa-clinic-associates',
  standalone: true,
  imports: [
    CommonModule,
    TableModule,
    MatSlideToggleModule,
    ScrollerModule,
    FormsModule,
    ReactiveFormsModule,
    InputTextModule,
  ],
  templateUrl: './sa-clinic-associates.component.html',
  styleUrl: './sa-clinic-associates.component.scss',
})
export class SaClinicAssociatesComponent {
  allClinicAssociatesResponse: any[] = [];
  filterAssociatesResponse: any[] = [];
  clinicAssociateFilter: string = '';
  checked = false;
  disabled = false;
  isLoading: boolean = false;

  constructor(
    private superAdminService: SuperAdminService,
    private router: Router,
    private sharedService: SharedService,
  ) {}
  ngOnInit(): void {
    this.getAllClinicAssociates();
  }
  getAllClinicAssociates() {
    this.isLoading = true;
    this.superAdminService.ClinicAssociates().subscribe({
      next: (response) => {
        this.allClinicAssociatesResponse = response;
        this.filterAssociatesResponse = [...response];
        this.isLoading = false;
      },
      error: (error) => {
        if (error.status === 401) {
        } else {
        }
      },
    });
  }
  getprofileById(personalId: number) {
    this.router.navigate(['/superAdmin/showProfile'], {
      queryParams: { AssociateId: personalId },
    });
  }
  exportToExcel() {
    this.sharedService.exportAsExcelFile(
      this.allClinicAssociatesResponse,
      'ClinicAssociates',
    );
  }
  filterByClinicAssociatesDetails() {
    if (!this.clinicAssociateFilter) {
      this.filterAssociatesResponse = [...this.allClinicAssociatesResponse];
    } else {
      const searchQuery = this.clinicAssociateFilter.toLowerCase();
      this.filterAssociatesResponse = this.allClinicAssociatesResponse.filter(
        (associate) => {
          const clinicName = associate.clinicName?.toLowerCase() || ''; // Ensure values are lowercase and handle undefined/null
          const designation = associate.designation?.toLowerCase() || '';
          const associateName =
            `${associate.firstName}${associate.lastName}`.toLowerCase() || '';

          return (
            clinicName.includes(searchQuery) ||
            designation.includes(searchQuery) ||
            associateName.includes(searchQuery)
          );
        },
      );
    }
  }
  clearFilter() {
    this.clinicAssociateFilter = '';
    this.filterByClinicAssociatesDetails();
  }
  isNoData(): boolean {
    return this.filterAssociatesResponse.length === 0;
  }
}
