import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaClinicAssociatesComponent } from './sa-clinic-associates.component';

describe('SaClinicAssociatesComponent', () => {
  let component: SaClinicAssociatesComponent;
  let fixture: ComponentFixture<SaClinicAssociatesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SaClinicAssociatesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SaClinicAssociatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
