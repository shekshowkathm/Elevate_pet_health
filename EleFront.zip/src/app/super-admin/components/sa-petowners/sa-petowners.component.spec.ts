import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaPetownersComponent } from './sa-petowners.component';

describe('SaPetownersComponent', () => {
  let component: SaPetownersComponent;
  let fixture: ComponentFixture<SaPetownersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SaPetownersComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SaPetownersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
