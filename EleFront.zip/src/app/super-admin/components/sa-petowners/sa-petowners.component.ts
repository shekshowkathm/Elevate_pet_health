import { NgFor, NgClass, CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ScrollerModule } from 'primeng/scroller';
import { TableModule } from 'primeng/table';
import { PetOwners } from '../../model/clinic-request-response';
import { SuperAdminService } from '../../service/super-admin.service';
import { Router } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedService } from '../../../shared/service/shared.service';

@Component({
  selector: 'app-sa-petowners',
  standalone: true,
  imports: [
    CommonModule,
    TableModule,
    MatSlideToggleModule,
    ScrollerModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  templateUrl: './sa-petowners.component.html',
  styleUrl: './sa-petowners.component.scss',
})
export class SaPetownersComponent {
  allPetOwnersResponse: any[] = [];
  filterpetownersResponse: any[] = [];
  petownerFilter: string = '';
  checked = false;
  disabled = false;
  isLoading: boolean = false;

  constructor(
    private superAdminService: SuperAdminService,
    private router: Router,
    private sharedService: SharedService,
  ) {}
  ngOnInit(): void {
    this.getAllPetOwners();
  }
  getAllPetOwners() {
    this.isLoading = true;
    this.superAdminService.allPetOwner().subscribe({
      next: (response) => {
        this.allPetOwnersResponse = response;
        this.filterpetownersResponse = [...response];
        this.isLoading = false;
      },
      error: (error) => {
        if (error.status === 401) {
        } else {
        }
      },
    });
  }
  getprofileById(petsId: number, personalId: number) {
    this.router.navigate(['/superAdmin/showProfile'], {
      queryParams: {
        petId: petsId,
        petownerId: personalId,
      },
    });
  }
  exportToExcel() {
    this.sharedService.exportAsExcelFile(
      this.allPetOwnersResponse,
      'AllPetowner',
    );
  }
  filterByPetownerDetails() {
    if (!this.petownerFilter) {
      this.filterpetownersResponse = [...this.allPetOwnersResponse];
    } else {
      const searchQuery = this.petownerFilter.toLowerCase();
      this.filterpetownersResponse = this.allPetOwnersResponse.filter(
        (petOwner) => {
          const clinicName = petOwner.clinicName?.toLowerCase() || ''; // Ensure values are lowercase and handle undefined/null

          const petOwnerName =
            `${petOwner.ownerFirstName}${petOwner.ownerLastName}`.toLowerCase() ||
            '';

          return (
            clinicName.includes(searchQuery) ||
            petOwnerName.includes(searchQuery)
          );
        },
      );
    }
  }
  clearFilter() {
    this.petownerFilter = '';
    this.filterByPetownerDetails();
  }

  isNoData(): boolean {
    return this.filterpetownersResponse.length === 0;
  }
}
