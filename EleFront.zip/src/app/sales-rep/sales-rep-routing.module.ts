import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReplayoutComponent } from './components/replayout/replayout.component';
import { RepHeaderComponent } from './components/rep-header/rep-header.component';
import { RepleftsidenavbarComponent } from './components/repleftsidenavbar/repleftsidenavbar.component';
import { RepdashBoardComponent } from './components/repdash-board/repdash-board.component';
import { SalesRepClinicsComponent } from './components/sales-rep-clinics/sales-rep-clinics.component';
import { RepCliniownersComponent } from './components/rep-cliniowners/rep-cliniowners.component';
import { RepClinicAssociatesComponent } from './components/rep-clinic-associates/rep-clinic-associates.component';
import { RepPetOwnersComponent } from './components/rep-pet-owners/rep-pet-owners.component';
import { RepClinicAdminsComponent } from './components/rep-clinic-admins/rep-clinic-admins.component';
import { ShowProfileComponent } from './components/show-profile/show-profile.component';
import { RepServicelistComponent } from './components/rep-servicelist/rep-servicelist.component';
import { RepSetupdataComponent } from './components/rep-setupdata/rep-setupdata.component';
import { PromotionDiscountComponent } from './components/promotion-discount/promotion-discount.component';
import { ShowclinicwithpromotionhistoryComponent } from './components/showclinicwithpromotionhistory/showclinicwithpromotionhistory.component';
import { RepPaymentsComponent } from './components/rep-payments/rep-payments.component';

const routes: Routes = [

  {
    path:'',
    component:ReplayoutComponent,

    children : [
      {
        path:'repHeader',
        component:RepHeaderComponent
      },
      {
        path:'leftNavRep',
        component:RepleftsidenavbarComponent
      },
      {
        path:'',
        component:RepdashBoardComponent
      },
      {
        path:'repClinicdetails',
        component:SalesRepClinicsComponent
      },
      {
        path:'repclinicowners',
        component:RepCliniownersComponent
      },
      {
        path:'repclinicAdmins',
        component:RepClinicAdminsComponent
      },
      {
        path:'repclinicAssociates',
        component:RepClinicAssociatesComponent
      },
      {
        path:'reppetowners',
        component:RepPetOwnersComponent
      },
      {
        path:'showProfile',
        component:ShowProfileComponent
      },
      {
        path:'repservicelist',
        component:RepServicelistComponent
      },
      {
        path:'repsetupdata',
        component:RepSetupdataComponent
      },
      {
        path:'promotionDiscount',
        component:PromotionDiscountComponent
      },
      {
        path:'viewClinicwithPromotion',
        component:ShowclinicwithpromotionhistoryComponent
      },
      {
        path:'paymentstatus',
        component:RepPaymentsComponent
      }

    ]
  }


];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SalesRepRoutingModule { }
