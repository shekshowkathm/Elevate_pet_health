export interface RepProfile {
  id?: number,
  firstName?:string
  lastName?:string
  email?: string,
  doctor?: boolean,
  profile?: string,
  designation?: string,
  contactNumber?: string,
  state?: string,
  city?: string,
  zipcode?: string,
  address?:string
}
export interface ClinicDetails {
  address : string;
  city : string ;
  clinicAdminEmail : string ;
  clinicImage : string ;
  clinicName : string ;
  clinicOwnerEmail : string ;
  contactNumber : string ;
  email : string ;
  id? : number ;
  petOwnerCount : number ;
  noOfWellnessPlans? : number ;
  zipCode : string ;
  discount?: string;
  state? : string ;
  headquater : boolean;
  headquaters?:string;
}
export interface ClinicOwnerREP {
  address: string;
  city: string;
  contactNumber: string;
  created_By: string | null;
  created_On: string;
  designation: string | null;
  doctor: boolean;
  email: string;
  firstName: string;
  id: number;
  lastName: string;
  password: string;
  profile: string;
  registerStatus: boolean;
  role: string;
  state: string;
  termsAndConditions: boolean;
  zipcode: string;
  clinicName:string;
}
export interface ClinicAdmin {
  id: number;
  firstName: string | null;
  lastName: string | null;
  email: string;
  clinicName: string;
  city: string;
  profile: string | null;
  state: string | null;
  zipcode: string | null;
  contactNumber: string;
  clinicEmail: string;
  designation: string | null;
  status: boolean;
  petName: string | null;
  petType: string | null;
}

export interface ProfilebyId {
  id?: number,
  firstName?:string
  lastName?:string
  email?: string,
  doctor?: boolean,
  profile?: string,
  designation?: string,
  contactNumber?: string,
  state?: string,
  city?: string,
  zipcode?: string,
  address?:string
}
export interface showClinicProfile {
  id?: number,
  clinicName: string,
  address: string,
  zipcode: string,
  city: string,
  state: string,
  contactNumber: string,
  email: string,
  clinicImage: string,
  clinicAdminId: number,
  startDate: string,
  endDate: string,
  clinicStatus: boolean,
  qrCode: string,
  salesRepFirstName:string,
  salesRepLastName:string,
  salesRepID: number
}
export interface PetOwner {
  petOwnerId: number;
  petOwnerFirstName: string;
  petOwnerLastName: string;
  petOwnerEmail: string;
  petOwnerContact: string;
  petOwnerAddress?: string | null;
  petOwnerState?: string | null;
  petOwnerCity?: string | null;
  petOwnerImage: string;
  petOwnerZipcode?: string | null;
  petId: number;
  petName: string;
  petGender: string;
  petType: string;
  petBreed: string;
  petAge: string;
  petDOB: string;
  petWeight: string;
  petProfile: string;
  endDate?: string,
  startDate?: string
  ageGroup: string;
  historyPlans?: PlanSets;
  ongoingPlans?: PlanSets;
  futurePlans?: PlanSets;

}
export interface PlanSets {
  [key: string]: PetPlan[];
}

export interface PetPlan {
  petId: number;
  petWellnessPlanId: number;
  petType: string;
  ageGroup?: string | null;
  wellnessPlanName: string;
  serviceName: string;
  dropdownName: string;
  clinicPrice: string;
  discountPrice: string;
  clinicWellnessUpdate: number;
  clinicWellnessPlan: number;
  scheduledDateAndTime?: string | null;
  fulfilledBy?: string | null;
  fulfilled: boolean;
  startDate?: string | null;
  endDate?: string | null;
  managePetWellnessPlan: number;
  updatedPrice: string;
}
export interface GetDocsResponse {
  documentUrl: string;
  uploadedById: number;
  uploadedByRole: string;
  targetType: string;
  fileSize:string;
  targetId: number ;
  clinicId?: number;
  description: string;
  uploadDate: string;
  id?: number ;
}
export class WellnessPlanResponse {
  id! : number | null;
  petType! : string;
  ageGroup!: string;
  wellnessPlanName! : string;
  service! : ServiceListResponse[];
  status!: boolean
}
export class ServiceList {
  id?: number | null;
  petType!: string;
  service!: string;
  dropdowns!: DropdownList[];
  status!: boolean;
}
export class Breed{
  id? : number;
  petType!: string;
  breed! : string;
  breedType! : string;
  ageForPuppy! : string;
  ageForKitten! : string
  ageForAdult! : string;
  ageForSenior! : string;
}
export class WeightRange{
  id?:number;
  petType! : string;
  weight! : string;
  size! : string;
}

export class DropdownList {
  id?: number;
  dropdown! : string;
  priceBased!: string;
  industryStandardPrice!: string;
}
export class ServiceListResponse{
  id? : number;
  petType! : string;
  service ! : string;
  dropdown!: DropdownListResponseDTO[];
}
export class DropdownListResponseDTO{
  id? : number;
  dropdown! : string;
  priceBased!: string;
  industryStandardPrice!: string;
  recommendation!: string;
}
export class Promotion {
  clinicId?: number;
  clinicEmail?: string;
  clinicContact?: string;
  clinicName: string = '';
  clinicOwnerName?: string;
  thirtySixtyNinety?: string;
  startDate?: string;
  endDate?: string;
  multiPet?: boolean;
  multiYear?: boolean;
  generateCode?: string | null;
  expiryDate?: string;
  monthlyPlanCounts?: string;
  stripeAccountId?: string;
  stripeCouponId?: string | null;
  headquater?: boolean;
  headquaters?:string;
}
