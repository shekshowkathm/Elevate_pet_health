import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SalesRepRoutingModule } from './sales-rep-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SalesRepRoutingModule
  ]
})
export class SalesRepModule {

  


}
