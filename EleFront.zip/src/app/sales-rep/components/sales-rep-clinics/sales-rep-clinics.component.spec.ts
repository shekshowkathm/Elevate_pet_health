import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesRepClinicsComponent } from './sales-rep-clinics.component';

describe('SalesRepClinicsComponent', () => {
  let component: SalesRepClinicsComponent;
  let fixture: ComponentFixture<SalesRepClinicsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SalesRepClinicsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SalesRepClinicsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
