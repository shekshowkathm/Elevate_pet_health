import { Component } from '@angular/core';
import { SaleRepService } from '../../service/sale-rep.service';
import { SharedService } from '../../../shared/service/shared.service';
import { TableModule } from 'primeng/table';
import { CommonModule, NgClass, NgFor } from '@angular/common';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ScrollerModule } from 'primeng/scroller';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ClinicDetails } from '../../model/sale-rep-responses';
import { Router } from '@angular/router';
import { InputTextModule } from 'primeng/inputtext';
import { DialogModule } from 'primeng/dialog';

@Component({
  selector: 'app-sales-rep-clinics',
  standalone: true,
  imports: [
    CommonModule,
    TableModule,
    MatSlideToggleModule,
    ScrollerModule,
    ReactiveFormsModule,
    FormsModule,
    InputTextModule,
    DialogModule
  ],
  templateUrl: './sales-rep-clinics.component.html',
  styleUrl: './sales-rep-clinics.component.scss',
})
export class SalesRepClinicsComponent {
  clinicdetailsOfRep: ClinicDetails[] = [];
  filterClinicDetails:ClinicDetails[] = [];
  discountValues : any[] = [];
  discountDialogue:boolean = false;
  clinicdetailsFilter:string = '';
  headQuarterFilter:string = '';
  isLoading:boolean = false;
  checked = false;
  disabled = false;
  salesRepId!: number;
  constructor(
    private repService: SaleRepService,
    private sharedservice: SharedService,
    private router: Router
  ) {}
  ngOnInit(): void {
    this.getAllClinicsOfRep();


  }

  getAllClinicsOfRep() {
    this.isLoading  = true;
    const registerId = this.sharedservice.getId('id');
    this.salesRepId = Number(registerId);

    const repsId = this.salesRepId;
    if (repsId) {
      this.repService.getAllClinicsOfRep(repsId).subscribe({
        next: (response) => {
          this.clinicdetailsOfRep = response;
          this.filterClinicDetails = [...response];
          this.isLoading  = false;
        },
        error: (error) => {
          console.error('Error retrieving object:', error);
        },
      });
    }
  }
  showDiscounts(rowIndex:number,discount:any[]){
    const discountedValues = discount;
    this.discountValues = discountedValues;
    this.discountDialogue = true;

  }


  exportToExcel() {
    this.sharedservice.exportAsExcelFile(
      this.clinicdetailsOfRep,
      'ClinicDetails'
    );
  }

  getprofileId(clinic: number) {
    this.router.navigate(['/salesRep/showProfile'], {
      queryParams: { clinicId: clinic },
    });
  }

  filterByClinicDetails(){
    if (!this.clinicdetailsFilter) {

      this.filterClinicDetails = [...this.clinicdetailsOfRep];
    } else {
      const searchQuery = this.clinicdetailsFilter.toLowerCase();
      this.filterClinicDetails = this.clinicdetailsOfRep.filter((clinic) => {
        const clinicName = clinic.clinicName?.toLowerCase() || "";
        const city = clinic.city?.toLowerCase() || "";
        const state = clinic.state?.toLowerCase() || "";
        return (
          clinicName.includes(searchQuery) ||
          city.includes(searchQuery) ||
          state.includes(searchQuery)

        );
      });
    }
  }
  applyHeadquartersFilter() {
    if (!this.headQuarterFilter) {
      // If the filter is empty, reset to show all clinic details
      this.filterClinicDetails = [...this.clinicdetailsOfRep];
    } else {
      // Otherwise, filter based on the conditions
      this.filterClinicDetails = this.clinicdetailsOfRep.filter((clinic) => {
        return clinic.headquater === true &&
               clinic.clinicName &&
               clinic.clinicName.toLowerCase().includes(this.headQuarterFilter.toLowerCase());
      });
    }

  }
  clearFilter() {
    this.headQuarterFilter = '';
    this.applyHeadquartersFilter();
  }
  clearClinicFilter() {
    this.clinicdetailsFilter = '';
    this.filterByClinicDetails();
  }

  isNoData(): boolean {
    return this.filterClinicDetails.length === 0;
  }
}

