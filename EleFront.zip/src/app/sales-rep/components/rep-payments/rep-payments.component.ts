import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { ToastModule } from 'primeng/toast';
import { TrancationService } from '../../../pet-owner/service/trancation.service';
import { SharedService } from '../../../shared/service/shared.service';

@Component({
  selector: 'app-rep-payments',
  standalone: true,
  imports: [
        CommonModule,
        ConfirmPopupModule,
        ButtonModule,
        TableModule,
        ToastModule,
        RouterModule,
        TagModule,
        DialogModule,
        FormsModule,
        ReactiveFormsModule,
        DynamicDialogModule,
        DropdownModule,
        InputTextModule,
  ],
  templateUrl: './rep-payments.component.html',
  styleUrl: './rep-payments.component.scss'
})
export class RepPaymentsComponent implements OnInit{
  public trancation: any[] = [];
  public trancationList: any[] = [];
  public filterClinicDetails: any = [];
  clinicDetailsFilter: string = '';
  dateFilter: string = '';
  constructor(
    private trancationService: TrancationService,
    private sharedService: SharedService,
  ) {}
  ngOnInit(): void {
    this.getAllTransactionBasedOnRep();
  }
  getAllTransactionBasedOnRep() {
    const salesRepsId = this.sharedService.getId('id');
    if(salesRepsId){
    this.trancationService.getTransactionDetailsBasedOnSaleRep(salesRepsId).subscribe({
      next: (doc: any) => {
        try {
      
          this.trancation = doc.sort(
            (a: any, b: any) => b.customerPaidDate - a.customerPaidDate,
          ); 
          this.filterClinicDetails = [...this.trancation];
        } catch (error) {
          console.error('Error parsing transaction data:', error);
          this.trancation = [];
          this.filterClinicDetails = [];
        }
      },

      error: (err: any) => {
        this.trancation = [];
        this.filterClinicDetails = [];
      },
      complete: () => {
        console.log('Transaction details retrieval completed.');
      },
    });
  }


  }
  getSeverity(status: string) {
    switch (status) {
      case 'paid':
        return 'success';
      case 'LOWSTOCK':
        return 'warning';
      case 'open':
        return 'danger';
      default:
        return 'info';
    }
  }

  exportToExcel() {
    this.filterClinicDetails.forEach((res: any) => {
      const date = new Date(res.customerPaidDate * 1000);
      const usDateFormat = new Intl.DateTimeFormat('en-US', {
        dateStyle: 'short',
      }).format(date);
      this.trancationList.push({
        customerPaidDate: usDateFormat,
        InvoiceNo: res.stripeInvoiceId,
        totalAmount: res.totalAmount,
        ClincName: res.ClincName,
        elaveteAmount: res.platformReceivedAmount,
        clinicName: res.clinicName,
        clincAmount: res.connectedAccountReceived,
        petOwnerName: res.petOwnerName,
        stripeFee: res.stripeFee,
        status: res.paymentStatus,
      });
    });
    this.sharedService.exportAsExcelFile(
      this.trancationList,
      'Transaction Details',
    );
  }
  filterByclinicDetailsFilter() {
    if (!this.clinicDetailsFilter) {
      this.filterClinicDetails = [...this.trancation];
    } else {
      const searchQuery = this.clinicDetailsFilter.toLowerCase();
      this.filterClinicDetails = this.trancation.filter((item) => {
        const clinicName = item.clinicName?.toLowerCase() || '';
        const petOwnerName = item.petOwnerName?.toLowerCase() || '';
        const date = item.customerPaidDate?.toLowerCase() || '';
        return (
          clinicName.includes(searchQuery) || petOwnerName.includes(searchQuery)|| date.includes(searchQuery)
        );
      });
    }

  }
  clearNameFilter() {
    this.clinicDetailsFilter = '';
    this.filterClinicDetails();
  }
  

  filterBydateFilter() {
    if (!this.clinicDetailsFilter) {
      this.filterClinicDetails = [...this.trancation];
    } else {
      const searchQuery = this.dateFilter.toLowerCase();
      this.filterClinicDetails = this.trancation.filter((item) => {

        const date = item.customerPaidDate?.toLowerCase() || '';
        return (
           date.includes(searchQuery)
        );
      });
    }

  }
  clearFilter() {
    this.dateFilter = '';
    this.filterClinicDetails();
  }



}
