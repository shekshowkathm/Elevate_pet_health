import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepPaymentsComponent } from './rep-payments.component';

describe('RepPaymentsComponent', () => {
  let component: RepPaymentsComponent;
  let fixture: ComponentFixture<RepPaymentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RepPaymentsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RepPaymentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
