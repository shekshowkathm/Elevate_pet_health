import { Component } from '@angular/core';
import { SharedService } from '../../../shared/service/shared.service';
import { SaleRepService } from '../../service/sale-rep.service';
import { Router } from '@angular/router';
import { NgFor, NgClass, CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ScrollerModule } from 'primeng/scroller';
import { TableModule } from 'primeng/table';
import { ClinicAdmin } from '../../model/sale-rep-responses';
import { InputTextModule } from 'primeng/inputtext';

@Component({
  selector: 'app-rep-clinic-admins',
  standalone: true,
  imports: [
    CommonModule,
    TableModule,
    MatSlideToggleModule,
    ScrollerModule,
    ReactiveFormsModule,
    FormsModule,
    InputTextModule
  ],
  templateUrl: './rep-clinic-admins.component.html',
  styleUrl: './rep-clinic-admins.component.scss',
})
export class RepClinicAdminsComponent {
  clinicAdminsOfRep: ClinicAdmin[] = [];
  filterClinicAdminResponse: ClinicAdmin[] = [];
  clinicAdminFilter:string = '';
  checked = false;
  disabled = false;
  salesRepId!: number;
  isLoading:boolean = false;

  constructor(
    private repService: SaleRepService,
    private sharedservice: SharedService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getclinicAdminsofReps();
  }

  getclinicAdminsofReps() {
    this.isLoading  = true;
    const registerId = this.sharedservice.getId('id');
    this.salesRepId = Number(registerId);

    const repsId = this.salesRepId;

    if (repsId) {
      this.repService.getAllClinicAdminsOfRep(repsId).subscribe({
        next: (response) => {
          this.clinicAdminsOfRep = response;
          this.filterClinicAdminResponse = [...response];
          this.isLoading  = false;

        },
        error: (error) => {
          console.error('Error retrieving object:', error);
        },
      });
    }
  }
  exportToExcel() {
    this.sharedservice.exportAsExcelFile(
      this.clinicAdminsOfRep,
      'ClinicAdmins'
    );
  }
  getprofileById(personalId: number) {
    this.router.navigate(['/salesRep/showProfile'], {
      queryParams: { AdminId: personalId },
    });
  }
  filterByClinicAdminsDetails() {
    if (!this.clinicAdminFilter) {
      this.filterClinicAdminResponse = [...this.clinicAdminsOfRep];
    } else {
      const searchQuery = this.clinicAdminFilter.toLowerCase();
      this.filterClinicAdminResponse = this.clinicAdminsOfRep.filter(
        (clinicAdmin) => {
          const clinicName = clinicAdmin.clinicName?.toLowerCase() || ''; // Ensure values are lowercase and handle undefined/null
          const city = clinicAdmin.city?.toLowerCase() || '';
          const state = clinicAdmin.state?.toLowerCase() || '';

          return (
            clinicName.includes(searchQuery) ||
            city.includes(searchQuery) ||
            state.includes(searchQuery)
          );
        },
      );
    }
  }
  clearFilter() {
    this.clinicAdminFilter = '';
    this.filterByClinicAdminsDetails() ;
  }
  isNoData(): boolean {
    return this.filterClinicAdminResponse.length === 0;
  }
}
