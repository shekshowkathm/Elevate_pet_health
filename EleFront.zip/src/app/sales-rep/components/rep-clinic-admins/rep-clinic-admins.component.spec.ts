import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepClinicAdminsComponent } from './rep-clinic-admins.component';

describe('RepClinicAdminsComponent', () => {
  let component: RepClinicAdminsComponent;
  let fixture: ComponentFixture<RepClinicAdminsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RepClinicAdminsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RepClinicAdminsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
