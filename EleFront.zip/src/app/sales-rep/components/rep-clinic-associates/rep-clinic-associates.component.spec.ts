import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepClinicAssociatesComponent } from './rep-clinic-associates.component';

describe('RepClinicAssociatesComponent', () => {
  let component: RepClinicAssociatesComponent;
  let fixture: ComponentFixture<RepClinicAssociatesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RepClinicAssociatesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RepClinicAssociatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
