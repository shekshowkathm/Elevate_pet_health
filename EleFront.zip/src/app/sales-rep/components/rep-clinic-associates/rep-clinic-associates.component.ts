import { Component } from '@angular/core';
import { SaleRepService } from '../../service/sale-rep.service';
import { SharedService } from '../../../shared/service/shared.service';
import { ClinicAdmin } from '../../model/sale-rep-responses';
import { NgFor, NgClass, CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ScrollerModule } from 'primeng/scroller';
import { TableModule } from 'primeng/table';
import { Router } from '@angular/router';
import { InputTextModule } from 'primeng/inputtext';

@Component({
  selector: 'app-rep-clinic-associates',
  standalone: true,
  imports: [
    CommonModule,
    TableModule,
    MatSlideToggleModule,
    ScrollerModule,
    FormsModule,
    ReactiveFormsModule,
    InputTextModule
  ],
  templateUrl: './rep-clinic-associates.component.html',
  styleUrl: './rep-clinic-associates.component.scss',
})
export class RepClinicAssociatesComponent {
  clinicAssosciatesOfRep: ClinicAdmin[] = [];
  filterAssociatesResponse: ClinicAdmin[] = [];
  clinicAssociateFilter:string = '';
  checked = false;
  disabled = false;
  salesRepId!: number;
  isLoading:boolean = false;

  constructor(
    private repService: SaleRepService,
    private sharedservice: SharedService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getclinicAssociatessofReps();
  }

  getclinicAssociatessofReps() {
    this.isLoading  = true;
    const registerId = this.sharedservice.getId('id');
    this.salesRepId = Number(registerId);

    const repsId = this.salesRepId;
    if (repsId) {
      this.repService.getAllClinicassociatesOfRep(repsId).subscribe({
        next: (response) => {
          this.clinicAssosciatesOfRep = response;
          this.filterAssociatesResponse = [...response]
          this.isLoading  = false;
        },
        error: (error) => {
          console.error('Error retrieving object:', error);
        },
      });
    }
  }
  exportToExcel() {
    this.sharedservice.exportAsExcelFile(
      this.clinicAssosciatesOfRep,
      'ClinicAssociates'
    );
  }

  getprofileById(personalId: number) {
    this.router.navigate(['/salesRep/showProfile'], {
      queryParams: { AssociateId: personalId },
    });
  }
  filterByClinicAssociatesDetails(){
    if (!this.clinicAssociateFilter) {

      this.filterAssociatesResponse = [...this.clinicAssosciatesOfRep];
    } else {
      const searchQuery = this.clinicAssociateFilter.toLowerCase();
      this.filterAssociatesResponse = this.clinicAssosciatesOfRep.filter((associate) => {
        const clinicName = associate.clinicName?.toLowerCase() || ""; // Ensure values are lowercase and handle undefined/null
        const designation = associate.designation?.toLowerCase() || "";
        const associateName = `${associate.firstName}${associate.lastName}`.toLowerCase() || "";


        return (
          clinicName.includes(searchQuery) ||
          designation.includes(searchQuery) ||
          associateName.includes(searchQuery)
        );
      });
    }
  }
  clearFilter() {
    this.clinicAssociateFilter = '';
    this.filterByClinicAssociatesDetails();
  }
  isNoData(): boolean {
    return this.filterAssociatesResponse.length === 0;
  }
}
