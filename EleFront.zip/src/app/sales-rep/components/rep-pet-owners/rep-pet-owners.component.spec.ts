import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepPetOwnersComponent } from './rep-pet-owners.component';

describe('RepPetOwnersComponent', () => {
  let component: RepPetOwnersComponent;
  let fixture: ComponentFixture<RepPetOwnersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RepPetOwnersComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RepPetOwnersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
