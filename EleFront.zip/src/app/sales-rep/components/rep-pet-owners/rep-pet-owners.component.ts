import { NgFor, NgClass, CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ScrollerModule } from 'primeng/scroller';
import { TableModule } from 'primeng/table';
import { SharedService } from '../../../shared/service/shared.service';
import { SaleRepService } from '../../service/sale-rep.service';
import { ClinicOwnerREP } from '../../model/sale-rep-responses';
import { Router } from '@angular/router';
import { InputTextModule } from 'primeng/inputtext';

@Component({
  selector: 'app-rep-pet-owners',
  standalone: true,
  imports: [
    CommonModule,
    TableModule,
    MatSlideToggleModule,
    ScrollerModule,
    FormsModule,
    ReactiveFormsModule,
    InputTextModule
  ],
  templateUrl: './rep-pet-owners.component.html',
  styleUrl: './rep-pet-owners.component.scss',
})
export class RepPetOwnersComponent {
  allPetownersOfRep: ClinicOwnerREP[] = [];
  filterpetownersResponse: ClinicOwnerREP[] = [];
  petownerFilter:string = '';
  isLoading:boolean = false;
  checked = false;
  disabled = false;
  salesRepId!: number;

  constructor(
    private sharedservice: SharedService,
    private repService: SaleRepService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getAllPetownersofRep();
  }
  getAllPetownersofRep() {
    this.isLoading  = true;
    const registerId = this.sharedservice.getId('id');
    this.salesRepId = Number(registerId);

    const repsId = this.salesRepId;
    if (repsId) {
      this.repService.getAllPetsOfRep(repsId).subscribe({
        next: (response) => {
          this.allPetownersOfRep = response;
          this.filterpetownersResponse = [...response];
          this.isLoading  = false;
        },
        error: (error) => {
          console.error('Error retrieving object:', error);
        },
      });
    }
  }
  exportToExcel() {
    this.sharedservice.exportAsExcelFile(this.allPetownersOfRep, 'PetOwners');
  }
  getprofileById(petId: number, personalId: number) {
    this.router.navigate(['/salesRep/showProfile'], {
      queryParams: {
        petsId: petId,
        petownerId: personalId,
      },
    });
  }
  filterByPetownerDetails(){
    if (!this.petownerFilter) {

      this.filterpetownersResponse = [...this.allPetownersOfRep];
    } else {
      const searchQuery = this.petownerFilter.toLowerCase();
      this.filterpetownersResponse = this.allPetownersOfRep.filter((petOwner) => {
        const clinicName = petOwner.clinicName?.toLowerCase() || "";
        const state = petOwner.state?.toLowerCase() || "";
        const city = petOwner.city?.toLowerCase() || "";
        const petOwnerName = `${petOwner.firstName}${petOwner.lastName}`.toLowerCase() || "";

        return (
          clinicName.includes(searchQuery) ||
          petOwnerName.includes(searchQuery)||
          city.includes(searchQuery)||
          state.includes(searchQuery)
        );
      });
    }
  }
  clearFilter() {
    this.petownerFilter = '';
    this.filterByPetownerDetails();
  }

  isNoData(): boolean {
    return this.filterpetownersResponse.length === 0;
  }
}
