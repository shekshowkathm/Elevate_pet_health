import { Component } from '@angular/core';
import { SharedService } from '../../../shared/service/shared.service';
import { SaleRepService } from '../../service/sale-rep.service';
import { ClinicOwnerREP } from '../../model/sale-rep-responses';
import { TableModule } from 'primeng/table';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ScrollerModule } from 'primeng/scroller';
import { CommonModule, NgClass, NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { InputTextModule } from 'primeng/inputtext';

@Component({
  selector: 'app-rep-cliniowners',
  standalone: true,
  imports: [
    CommonModule,
    TableModule,
    MatSlideToggleModule,
    ScrollerModule,
    FormsModule,
    InputTextModule
  ],
  templateUrl: './rep-cliniowners.component.html',
  styleUrl: './rep-cliniowners.component.scss',
})
export class RepCliniownersComponent {
  clinicownersOfRep: ClinicOwnerREP[] = [];
  filterClinicOwnersReponse:ClinicOwnerREP[] = [];
  clinicdetailsOwnerFilter:string = '';
  checked = false;
  disabled = false;
  salesRepId!: number;
  isLoading:boolean = false;

  constructor(
    private sharedservice: SharedService,
    private repService: SaleRepService,
    private router: Router
  ) {}
  ngOnInit(): void {
    this.getclinicownersofRep();
  }

  getclinicownersofRep() {
    this.isLoading  = true;
    const registerId = this.sharedservice.getId('id');
    this.salesRepId = Number(registerId);

    const repsId = this.salesRepId;
    if (repsId) {
      this.repService.getAllClinicsownersOfRep(repsId).subscribe({
        next: (response) => {
          this.clinicownersOfRep = response;
          this.filterClinicOwnersReponse = [...response]
          this.isLoading  = false;
        },
        error: (error) => {
          console.error('Error retrieving object:', error);
        },
      });
    }
  }
  exportToExcel() {
    this.sharedservice.exportAsExcelFile(
      this.clinicownersOfRep,
      'ClinicOwners'
    );
  }

  getprofileById(personalId: number) {
    this.router.navigate(['/salesRep/showProfile'], {
      queryParams: { selectedId: personalId },
    });
  }
  filterByClinicOwnersDetails(){
    if (!this.clinicdetailsOwnerFilter) {

      this.filterClinicOwnersReponse = [...this.clinicownersOfRep];
    } else {
      const searchQuery = this.clinicdetailsOwnerFilter.toLowerCase();
      this.filterClinicOwnersReponse = this.clinicownersOfRep.filter((clinic) => {
        const clinicName = clinic.clinicName?.toLowerCase() || ""; // Ensure values are lowercase and handle undefined/null
        const city = clinic.city?.toLowerCase() || "";
        const state = clinic.state?.toLowerCase() || "";
        const clinicOwnerName = `${clinic.firstName}${clinic.lastName}`.toLowerCase() || "";


        return (
          clinicName.includes(searchQuery) ||
          city.includes(searchQuery) ||
          state.includes(searchQuery) ||
          clinicOwnerName.includes(searchQuery)
        );
      });
    }
  }
  clearFilter() {
    this.clinicdetailsOwnerFilter = '';
    this.filterByClinicOwnersDetails();
  }
  isNoData(): boolean {
    return this.filterClinicOwnersReponse.length === 0;
  }
}
