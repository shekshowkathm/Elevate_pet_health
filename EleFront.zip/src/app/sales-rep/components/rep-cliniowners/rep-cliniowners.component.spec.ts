import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepCliniownersComponent } from './rep-cliniowners.component';

describe('RepCliniownersComponent', () => {
  let component: RepCliniownersComponent;
  let fixture: ComponentFixture<RepCliniownersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RepCliniownersComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RepCliniownersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
