import { CommonModule, isPlatformBrowser } from '@angular/common';
import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, inject, Inject, PLATFORM_ID, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormGroup, FormBuilder, Validators, NgModel, NgForm } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';

import { ButtonModule } from 'primeng/button';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { DialogModule } from 'primeng/dialog';
import { DynamicDialogModule, DynamicDialogRef, DialogService } from 'primeng/dynamicdialog';
import { ToastModule } from 'primeng/toast';
import { ImageUploadComponent } from '../../../shared/component/image-upload/image-upload.component';
import { SharedService } from '../../../shared/service/shared.service';
import { SuperAdminService } from '../../../super-admin/service/super-admin.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { SaleRepService } from '../../service/sale-rep.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ClinicService } from '../../../clinic/services/clinic.service';
import { TermsAndConditionsComponent } from '../../../shared/component/terms-and-conditions/terms-and-conditions.component';
import { ClinicAuthService } from '../../../clinic/services/clinic-auth.service';
import { DropdownModule } from 'primeng/dropdown';
import { US_STATES } from '../../../shared/constants/usa-states';

@Component({
  selector: 'app-rep-header',
  standalone: true,
  imports: [
    CommonModule,
    ConfirmPopupModule,
    ButtonModule,
    ToastModule,
    RouterModule,
    DialogModule,
    FormsModule,
    ReactiveFormsModule,
    DynamicDialogModule,
    ToastModule,
    DropdownModule
  ],
  templateUrl: './rep-header.component.html',
  styleUrl: './rep-header.component.scss',
  providers: [ConfirmationService, MessageService,DialogService],
})
export class RepHeaderComponent implements AfterViewInit{
  isVisibleProfileOptions: boolean = false;
  displayDialogProfile: boolean = false;
  showAllow = true;
  clinicRequestsResponse: any[] = [];
  private isBrowser: boolean;
  salesRepId:string | null = null;
  profilebyId: any = {};
  showSaveButton: boolean = false;
  isEditable: boolean = false;
  profileForm!: FormGroup;
  selectedImageUrl:string | ArrayBuffer | null = null;
  showUpdateForm: boolean = false;
  passwordsMatching = false;
  usStates = US_STATES
  private ref : DynamicDialogRef | undefined;
  logoutDialogVisible:boolean = false;


  private clinicService = inject(ClinicService);
  constructor(
    private router: Router,
    private salesRepService: SaleRepService,
    private sharedservice : SharedService,
    public dialogService:DialogService,
    public clinicAuthService : ClinicAuthService,
    private messageService: MessageService,
    private cdRef: ChangeDetectorRef,
    private fb: FormBuilder,
    @Inject(PLATFORM_ID) private platformId: object,
  ) {
    this.isBrowser = isPlatformBrowser(this.platformId); // Check if it's the browser
  }

  ngOnInit(): void {
    // Fetch clinic requests

    const registerId = this.sharedservice.getId('id');
    this.salesRepId = registerId ? registerId.trim() : null;

    this.getSaleRepProfile();

    this.initializeForm();


  }
  ngAfterViewInit() {
    if (isPlatformBrowser(this.platformId)) {
      const terms = JSON.parse(localStorage.getItem('terms') as string);
      if (!terms) {
        this.show();
      }
    }
  }

  show() {
    this.ref = this.dialogService.open(TermsAndConditionsComponent, {
      header: 'Welcome to Your Work Place !',
      width: '70%',
      breakpoints: {
        '960px': '75vw',
        '640px': '90vw',
      },
      style: {
        'box-shadow': '#007cda 0px 0px 10px 3px',
      },
      duplicate: false,
    });
    this.ref.onClose.subscribe((res: boolean) => {
      if (res) {

        this.clinicService.updateTermsAndConditions().subscribe({
          next: (res: any) => {

            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Terms and Conditions updated',
            });
            this.clinicAuthService.setTermsAndConditions(true);
            this.showUpdateForm = true;
            localStorage.setItem('profilePage', 'open');

            if(res){
              this.displayDialogProfile = true;
            }
          },
          error: (err: HttpErrorResponse) => {

            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'somthing wrong',
            });
          },
        });
      } else {

        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'somithing wrong',
        });
        this.router.navigateByUrl('');
        this.clinicAuthService.logout();
      }
    });
  }




  initializeForm(): void {
    this.profileForm = this.fb.group({
      firstName: ['',[Validators.required]],
      lastName: ['',[Validators.required]],
      email: [this.profilebyId.email],
      contactNumber: ['',[Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/)]],
      state: ['',[Validators.required]],
      address: ['',[Validators.required]],
      city: ['',[Validators.required]],
      profile: [this.selectedImageUrl || this.profilebyId.profile]
    });
  }

  showProfileOptions() {
    this.isVisibleProfileOptions = !this.isVisibleProfileOptions;
  }



  navigateToHome() {
    this.router.navigate(['/salesRep/']);
  }

  // Ensure localStorage.clear() runs only in the browser
  confirmLogout() {
    if (this.isBrowser) {
      localStorage.clear();
    }
    this.router.navigate(['']);
    this.logoutDialogVisible = false;
  }

  showLogoutDialog() {
    this.logoutDialogVisible = true;
  }

  showDialog() {
    this.displayDialogProfile = true;
  }


  getSaleRepProfile(){
    const id =this.salesRepId
    this.salesRepService.showPersonProfileById(id).subscribe({
      next:(profileResponse) => {
        this.profilebyId = profileResponse
        this.profileForm.patchValue({
          firstName: this.profilebyId.firstName,
          lastName: this.profilebyId.lastName,
          email: this.profilebyId.email,
          contactNumber: this.profilebyId.contactNumber,
          address: this.profilebyId.address,
          city: this.profilebyId.city,
          state: this.profilebyId.state,
          profile:this.profilebyId.profile || this.selectedImageUrl
        });
        this.formatPhoneNumber();

      },
      error: (error) => {
        if (error.status === 401) {
          // Handle the 401 error gracefully, e.g., log out the user, prompt for re-authentication
          console.error('Unauthorized access. Please login again.');
          // Handle token refresh logic or redirect to login as needed
        } else {
          console.error('Error retrieving object:', error);
          // Handle other errors
        }
      },
    });

  }
  toggleButtons() {
    this.showSaveButton = true; // Show the "Save changes" button
    this.isEditable = true;
  }

  saveChanges() {
    this.showSaveButton = false;

    if (this.profileForm.valid) {
      const convertid = Number(this.salesRepId);

      const userDetails = {
        ...this.profileForm.value,
        id: convertid
      };


      this.salesRepService.updateProfile(userDetails).subscribe({
        next:(response)=>{

          this.messageService.add({severity:'success', summary:'Success', detail:'Profile Updated successfully!'});
          this.getSaleRepProfile();
          this.displayDialogProfile = false;
        },
        error: (error) => {
          this.messageService.add({severity:'error', summary:'Error', detail:'Error in Update'});
          console.error('Error retrieving object:', error);
        },
      })

      this.isEditable = false; // Exit edit mode
    }



  }


  uploadOrSelectImage() {
    this.ref = this.dialogService.open(ImageUploadComponent, {
      header: 'Upload Image',
      width: '500px',
      modal: true,
      breakpoints: {
        '640px': '90vw',
      },
    });
    this.ref.onClose.subscribe((url: any) => {

      if (url) {
        this.selectedImageUrl = url;
        const imageUrl = this.selectedImageUrl;
        this.profileForm.patchValue({
          profile: imageUrl
        });
      }

    });
  }
  // usMobileNumberFormat
  formatPhoneNumber(): void {
    const input = this.profileForm.get('contactNumber')?.value.replace(/\D/g, ''); // Remove non-numeric characters
    let formattedInput = input;

    if (input.length > 0) {
      formattedInput = `(${input.substring(0, 3)}`; // Add opening parenthesis
    }
    if (input.length >= 4) {
      formattedInput += `) ${input.substring(3, 6)}`; // Add closing parenthesis and space
    }
    if (input.length >= 7) {
      formattedInput += `-${input.substring(6, 10)}`; // Add hyphen before the last 4 digits
    }

    // Set the formatted value back to the form control
    this.profileForm
      .get('contactNumber')
      ?.setValue(formattedInput, { emitEvent: false });

    // Add the pattern validator only when the full phone number is entered
    if (input.length === 10) {
      this.profileForm.get('contactNumber')?.setValidators([
        Validators.required,
        Validators.pattern(/^\(\d{3}\) \d{3}-\d{4}$/)
      ]);
    } else {
      // Remove pattern validator if the input is not yet complete
      this.profileForm.get('contactNumber')?.setValidators([Validators.required]);
    }

    this.profileForm.get('contactNumber')?.updateValueAndValidity({ emitEvent: false });
}

ngOnDestroy() {
  if (this.ref) {
    this.ref.close();
  }
}
showPasswordUpdateForm() {
  this.showUpdateForm = !this.showUpdateForm;
}
checkPasswordMatch(
  passwordControl: NgModel,
  confirmPasswordControl: NgModel
) {
  const password = passwordControl.control.value;
  const confirmPassword = confirmPasswordControl.control.value;
  if (password === confirmPassword) {
    this.passwordsMatching = true;
  } else {
    this.passwordsMatching = false;
  }
}
submitUpdatepassword(form :NgForm){
  const regId = Number(this.salesRepId)
  this.salesRepService.updatePassword(form.value.password,regId).subscribe({
    next: (res) => {
      form.reset();
      this.showUpdateForm = false;
      this.messageService.add({
        severity: 'success',
        summary: 'Success',
        detail: 'Password updated successfully!',
      });


    },
    error: (err: HttpErrorResponse) => {

      this.messageService.add({
        severity: 'error',
        summary: 'Error',
        detail: 'Something went wrong. Try again!',
      });
    }
  });

}


}
