import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepHeaderComponent } from './rep-header.component';

describe('RepHeaderComponent', () => {
  let component: RepHeaderComponent;
  let fixture: ComponentFixture<RepHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RepHeaderComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RepHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
