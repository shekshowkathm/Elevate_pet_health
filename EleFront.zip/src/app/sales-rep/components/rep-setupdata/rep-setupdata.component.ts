import { CommonModule, NgClass, NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';
import { TabViewModule } from 'primeng/tabview';
import { Breed, WeightRange } from '../../model/sale-rep-responses';
import { SaleRepService } from '../../service/sale-rep.service';
import { MessageService } from 'primeng/api';
import { FormsModule } from '@angular/forms';
import { SharedService } from '../../../shared/service/shared.service';

@Component({
  selector: 'app-rep-setupdata',
  standalone: true,
  imports: [
    CommonModule,
    TableModule,
    TabViewModule,
    ConfirmDialogModule,
    MatSlideToggleModule,
    InputTextModule,
    FormsModule
  ],
  templateUrl: './rep-setupdata.component.html',
  styleUrl: './rep-setupdata.component.scss',
  providers: [MessageService],
})
export class RepSetupdataComponent {
  activeTab: string = 'weightRanges';
  showForm: boolean = false;
  showBreedForm: boolean = false;
  getWeightRanges: WeightRange[] = [];
  getBreeds: Breed[] = [];
  filterBreeds:Breed[] = [];
  petTypeFilter:string = '';
  breedNameFilter:string = '';
  breedTypeFilter:string = '';
  selectedRangeId: number | any;
  selectedBreedId: number | any;
  breedOptions: string[] = [];
  isLoading:boolean = false;

  constructor(
    private setupDataService: SaleRepService,
    private messageService: MessageService,
    private sharedService: SharedService
  ) {}
  ngOnInit() {
    this.fetchWeightRanges();
    this.fetchBreed();
  }

  fetchWeightRanges() {
    this.setupDataService.getAllWeightRange().subscribe(
      (response: WeightRange[]) => {
        this.getWeightRanges = response;
      },
      (error) => {
        console.error('Error fetching weight ranges:', error);
      }
    );
  }
  exportToExcelWeight() {
    this.sharedService.exportAsExcelFile(this.getWeightRanges, 'Weight-Ranges');
  }

  fetchBreed() {
    this.isLoading  = true;
    this.setupDataService.getAllBreed().subscribe(
      (response: Breed[]) => {
        this.getBreeds = response;
        this.filterBreeds =  [...response];
        this.isLoading  = false;
      },
      (error) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to get breed',
        });
      }
    );
  }
  exportToExcelBreed() {
    this.sharedService.exportAsExcelFile(this.getBreeds, 'Pet-Breed-List');
  }
  applyCombinedFilterBreed() {
    if (!this.petTypeFilter && !this.breedNameFilter && !this.breedTypeFilter) {

      this.filterBreeds = [...this.getBreeds];
    } else {
      this.filterBreeds = this.getBreeds.filter(breed => {
        const petTypeMatch = !this.petTypeFilter || breed.petType.toLowerCase().includes(this.petTypeFilter.toLowerCase());
        const breedNameMatch = !this.breedNameFilter || breed.breed.toLowerCase().includes(this.breedNameFilter.toLowerCase());

        const breedTypeMatch = !this.breedTypeFilter || breed.breedType.toLowerCase().includes(this.breedTypeFilter.toLowerCase());


        return petTypeMatch && breedNameMatch && breedTypeMatch;
      });
    }
  }
  clearPettypefilter(){
    this.petTypeFilter = ''
    this.applyCombinedFilterBreed();
  }
  clearBreednamefilter(){
    this.breedNameFilter = ''
    this.applyCombinedFilterBreed();
  }
  clearBreedtypefilter(){
    this.breedTypeFilter = ''
    this.applyCombinedFilterBreed();
  }
  isNoBreed(){
    return this.filterBreeds.length === 0;
  }

}
