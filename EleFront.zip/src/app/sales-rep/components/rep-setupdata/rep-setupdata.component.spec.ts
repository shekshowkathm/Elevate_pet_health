import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepSetupdataComponent } from './rep-setupdata.component';

describe('RepSetupdataComponent', () => {
  let component: RepSetupdataComponent;
  let fixture: ComponentFixture<RepSetupdataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RepSetupdataComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RepSetupdataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
