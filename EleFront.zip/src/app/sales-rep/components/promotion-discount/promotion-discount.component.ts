import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ScrollerModule } from 'primeng/scroller';
import { TableModule } from 'primeng/table';
import { Promotion } from '../../model/sale-rep-responses';
import { SaleRepService } from '../../service/sale-rep.service';
import { SharedService } from '../../../shared/service/shared.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-promotion-discount',
  standalone: true,
  imports:
  [
    TableModule,
    MatSlideToggleModule,
    ScrollerModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  templateUrl: './promotion-discount.component.html',
  styleUrl: './promotion-discount.component.scss'
})
export class PromotionDiscountComponent {
  isLoading :boolean = false;
  checked = false;
  disabled = false;
  promotionDiscounts : Promotion[] = [];
  filterResponse: Promotion[] = [];
  promotion: string = '';
  dropdownValue: string = '';
  headquarter: string = '';
  salesRepId!: number;


  ngOnInit(): void {
    this.getPromomtioDiscountsOfRep();
  }
  constructor(private repService: SaleRepService,
    private sharedservice:SharedService,private router :Router ){

  }
  getPromomtioDiscountsOfRep(){
    this.isLoading  = true;
    const registerId = this.sharedservice.getId('id');
    this.salesRepId = Number(registerId);
    const repsId = this.salesRepId;
    const Role = this.sharedservice.getItem('role')
    if(repsId&&Role){
      this.repService.getPromotionDiscount(Role,repsId).subscribe({
        next: (response) => {
          this.promotionDiscounts = response
          this.filterResponse = [...this.promotionDiscounts];
          this.isLoading  = false;

        },
        error: (error) => {
          this.isLoading  = false;
          console.error('Error retrieving object:', error);
        },
      });
    }

    }
    exportToExcelPromotion() {
      this.sharedservice.exportAsExcelFile(this.promotionDiscounts, 'Promotion-Discount');
    }
    getClinicdetailsById(clinicId: number) {
      this.router.navigate(['/salesRep/viewClinicwithPromotion'], {
        queryParams: { selectedId: clinicId },
      });
    }


    isNoData(): boolean {
      return this.promotionDiscounts.length === 0;
    }

    filterPromotion() {
      if (!this.promotion && !this.dropdownValue && !this.headquarter) {
        this.filterResponse = [...this.promotionDiscounts];
      } else {
        this.filterResponse = this.promotionDiscounts.filter((promo) => {
          const clinicName = `${promo.clinicName}`.toLowerCase();
          const searchQuery = this.promotion.toLowerCase() || '';
          const dropdownFilter =
          !this.dropdownValue ||
          (this.dropdownValue === 'thirtySixtyNinety' && (promo.thirtySixtyNinety === "ONGOING" || promo.thirtySixtyNinety === "TAKEN") ) ||
          (this.dropdownValue === 'multiPet' && promo.multiPet) ||
          (this.dropdownValue === 'multiYear' && promo.multiYear) ||
          (this.dropdownValue === 'generateCode' && promo.generateCode) ||
          (this.dropdownValue === 'all' &&
            promo.thirtySixtyNinety &&
            promo.multiPet &&
            promo.multiYear &&
            promo.generateCode);
            const headquarterFilter = !this.headquarter || 
            (promo.headquater && promo.clinicName.toLowerCase().includes(this.headquarter.toLowerCase())) ||
            (!promo.headquater && promo.headquaters && promo.headquaters.toLowerCase().includes(this.headquarter.toLowerCase()));
  
        return (
          (clinicName.includes(searchQuery) || searchQuery === '') &&
          dropdownFilter &&
          headquarterFilter
  
        );
      });
    }
    }
    
    clearFilter() {
      this.promotion = '';
      this.dropdownValue = '';
      this.headquarter = '';
      this.filterPromotion();
      
    }


}
