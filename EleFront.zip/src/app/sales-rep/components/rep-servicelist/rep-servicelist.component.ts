import {  CommonModule, NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';
import { TabViewModule } from 'primeng/tabview';
import { ToastModule } from 'primeng/toast';
import {
  ServiceList,
  WellnessPlanResponse,
} from '../../model/sale-rep-responses';
import { SaleRepService } from '../../service/sale-rep.service';
import { CardModule } from 'primeng/card';
import { SharedService } from '../../../shared/service/shared.service';

@Component({
  selector: 'app-rep-servicelist',
  standalone: true,
  imports: [
    TableModule,
    CommonModule,
    TabViewModule,
    MatSlideToggleModule,
    ReactiveFormsModule,
    FormsModule,
    InputTextModule,
    ToastModule,
    ConfirmDialogModule,
    CardModule
  ],
  templateUrl: './rep-servicelist.component.html',
  styleUrl: './rep-servicelist.component.scss',
  providers: [MessageService, ConfirmationService],
})
export class RepServicelistComponent {
  activeTab: string = 'serviceList';
  services: ServiceList[] = [];
  wellnessPlans: WellnessPlanResponse[] = [];
  filterWellnessPlan:WellnessPlanResponse[] = [];
  filterServices:ServiceList[] = [];
  petTypeFilter: string = '';
  serviceNameFilter: string = '';
  wellnessNameFilter: string = '';
  petTypeFilterWellnessPlan: string = '';
  serviceDropdownOptions: any[] = [];
  showServiceForm: boolean = false;
  showWellnessPlanForm: boolean = false;
  isLoading:boolean = false;

  checked = false;
  disabled = false;

  constructor(private wellnessPlanService: SaleRepService,private sharedService: SharedService) {}

  ngOnInit() {
    this.fetchServices();
    this.fetchWellnessPlan();
  }

  fetchServices() {
    this.isLoading  = true;
    this.wellnessPlanService.getAllServices().subscribe({
      next: (data: ServiceList[]) => {
        this.services = data;
        this.filterServices = [...data];
        this.isLoading  = false;
      },
      error: (error) => {
        console.error('Error fetching services', error);
      },
    });
  }
  exportToExcelService() {
    this.sharedService.exportAsExcelFile(this.services, 'Service-List');
  }

  fetchWellnessPlan() {
    this.isLoading  = true;
    this.wellnessPlanService.getAllWellnessPlan().subscribe({
      next: (data: WellnessPlanResponse[]) => {
        this.wellnessPlans = data;
        this.filterWellnessPlan = [...data];
        this.isLoading  = false;
      },
      error: (error) => {
        console.error('Error fetching services', error);
      },
    });
  }
  exportToExcelWellnesssPlan() {
    this.sharedService.exportAsExcelFile(this.wellnessPlans, 'Wellness-Plan-List');
  }
  applyCombinedFilter() {
    if(!this.petTypeFilter && !this.serviceNameFilter){
      this.filterServices = [...this.services]
    }else{
    this.filterServices = this.services.filter((service) => {
      const matchesPetType = !this.petTypeFilter || service.petType
        .toLowerCase()
        .includes(this.petTypeFilter.toLowerCase());
      const matchesServiceName = !this.serviceNameFilter || service.service
        .toLowerCase()
        .includes(this.serviceNameFilter.toLowerCase());

      return matchesPetType && matchesServiceName;
    });
  }

  }
  clearFilter() {
    this.petTypeFilter = '';
    this.applyCombinedFilter();
  }
  clearServicefilter(){
    this.serviceNameFilter = ''
    this.applyCombinedFilter();
  }

  isNoData(): boolean {
    return this.filterServices.length === 0;
  }
  applyCombinedFilterWellnessPlan() {
    if (!this.petTypeFilter && !this.wellnessNameFilter && !this.serviceNameFilter) {

      this.filterWellnessPlan = [...this.wellnessPlans];
    } else {
      this.filterWellnessPlan = this.wellnessPlans.filter(plan => {
        const petTypeMatch = !this.petTypeFilter || plan.petType.toLowerCase().includes(this.petTypeFilter.toLowerCase());
        const wellnessNameMatch = !this.wellnessNameFilter || plan.wellnessPlanName.toLowerCase().includes(this.wellnessNameFilter.toLowerCase());

        const serviceMatch = !this.serviceNameFilter || plan.service.some(svc =>
          svc.service.toLowerCase().includes(this.serviceNameFilter.toLowerCase())
        );

        return petTypeMatch && wellnessNameMatch && serviceMatch;
      });
    }
  }

  clearPetFilter() {
    this.petTypeFilter = '';
    this.applyCombinedFilterWellnessPlan();
  }
  clearWellnessfilter(){
    this.wellnessNameFilter = ''
    this.applyCombinedFilterWellnessPlan();
  }
  clearWellnessServicefilter(){
    this.serviceNameFilter = ''
    this.applyCombinedFilterWellnessPlan();
  }


  isNoWellnesPlan(): boolean {
    return this.filterWellnessPlan.length === 0;
  }

}
