import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepServicelistComponent } from './rep-servicelist.component';

describe('RepServicelistComponent', () => {
  let component: RepServicelistComponent;
  let fixture: ComponentFixture<RepServicelistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RepServicelistComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RepServicelistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
