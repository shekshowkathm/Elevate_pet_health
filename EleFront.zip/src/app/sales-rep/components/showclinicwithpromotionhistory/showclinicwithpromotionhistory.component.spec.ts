import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowclinicwithpromotionhistoryComponent } from './showclinicwithpromotionhistory.component';

describe('ShowclinicwithpromotionhistoryComponent', () => {
  let component: ShowclinicwithpromotionhistoryComponent;
  let fixture: ComponentFixture<ShowclinicwithpromotionhistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShowclinicwithpromotionhistoryComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowclinicwithpromotionhistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
