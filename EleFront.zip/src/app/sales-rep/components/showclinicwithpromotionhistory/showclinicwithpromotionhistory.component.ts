import { NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, NgModel, ReactiveFormsModule } from '@angular/forms';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { TableModule } from 'primeng/table';
import { SaleRepService } from '../../service/sale-rep.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-showclinicwithpromotionhistory',
  standalone: true,
  imports: [ FormsModule, ReactiveFormsModule, TableModule, NgIf, MatSlideToggleModule],
  templateUrl: './showclinicwithpromotionhistory.component.html',
  styleUrl: './showclinicwithpromotionhistory.component.scss'
})
export class ShowclinicwithpromotionhistoryComponent {
  promotions: any[] = [];
  clinicId! :number;
  checked = false;
  disabled = false;


constructor(
  private repService : SaleRepService,
  private route: ActivatedRoute,
){}
ngOnInit() {
  this.fetchClinicPromotionDetails();
}


  fetchClinicPromotionDetails() {
    this.route.queryParams.subscribe((params) => {
      const clinicsId = params['selectedId'];
      this.clinicId = clinicsId;
      console.log(this.clinicId,'qwdqdqd');

      if(this.clinicId){
    this.repService.viewclinicdetailswithpromotion(this.clinicId).subscribe({
      next: (response: any) => {
        this.promotions = response;
      },
      error: error => {
        console.log(error);
      }
    });
  }
}
    )}

}


