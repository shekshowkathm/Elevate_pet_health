import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplayoutComponent } from './replayout.component';

describe('ReplayoutComponent', () => {
  let component: ReplayoutComponent;
  let fixture: ComponentFixture<ReplayoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReplayoutComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReplayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
