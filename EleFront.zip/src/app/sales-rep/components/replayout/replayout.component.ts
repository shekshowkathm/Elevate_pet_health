import { Component, HostListener, signal } from '@angular/core';
import { RepHeaderComponent } from '../rep-header/rep-header.component';
import { RepleftsidenavbarComponent } from '../repleftsidenavbar/repleftsidenavbar.component';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-replayout',
  standalone: true,
  imports: [RepHeaderComponent, RepleftsidenavbarComponent, RouterOutlet],
  templateUrl: './replayout.component.html',
  styleUrl: './replayout.component.scss',
})
export class ReplayoutComponent {
  isLeftSidebarCollapsed = signal<boolean>(false);
  screenWidth = signal<number>(0);

  constructor() {
    if (typeof window !== 'undefined') {
      this.screenWidth.set(window.innerWidth);
    }
  }
  @HostListener('window:resize')
  onResize() {
    this.screenWidth.set(window.innerWidth);
    if (this.screenWidth() < 768) {
      this.isLeftSidebarCollapsed.set(true);
    }
  }

  ngOnInit(): void {
    this.isLeftSidebarCollapsed.set(this.screenWidth() < 768);
  }

  changeIsLeftSidebarCollapsed(isLeftSidebarCollapsed: boolean): void {
    this.isLeftSidebarCollapsed.set(isLeftSidebarCollapsed);
  }
}
