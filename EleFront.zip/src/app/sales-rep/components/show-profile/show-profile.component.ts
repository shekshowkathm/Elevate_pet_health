import { DatePipe, NgClass, NgFor, NgIf } from '@angular/common';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DialogModule } from 'primeng/dialog';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ScrollerModule } from 'primeng/scroller';
import { TableModule } from 'primeng/table';
import { SharedService } from '../../../shared/service/shared.service';
import { FileUploadService } from '../../../shared/service/file-upload.service';
import { SaleRepService } from '../../service/sale-rep.service';
import { FilesUploadComponent } from '../../../shared/component/files-upload/files-upload.component';
import { PetOwner, PetPlan } from '../../model/sale-rep-responses';

@Component({
  selector: 'app-show-profile',
  standalone: true,
  imports: [
    ButtonModule,
    TableModule,
    DialogModule,
    FormsModule,
    ReactiveFormsModule,
    MatSlideToggleModule,
    ScrollerModule,
    CardModule,
    NgIf,
    NgFor,
    NgClass,
    DatePipe
  ],
  templateUrl: './show-profile.component.html',
  styleUrl: './show-profile.component.scss',
  providers: [DialogService],
})
export class ShowProfileComponent {
  @ViewChild('fileInput') fileInput!: ElementRef;
  profileData: any = {};
  petOwnerProfile: PetOwner | null = null;
  clinidetailsId!: number;
  clinicOwnerId!: number;
  clinicAdminId!: number;
  clinicAssociateId!: number;
  petOwnerId!: number;
  petsId!: number;
  salesRepId!: number;
  displayDialog: boolean = false;
  selectedFile: File | null = null;
  uploadUrl: string = '';
  filePreview: string | ArrayBuffer | null = null;
  isImage: boolean = false;
  clinicsOfClinicowner: any[] = [];
  allPetsOfPetOwnerResponse: any[] = [];
  clinicdetailsOfRep: any[] = [];
  checked = false;
  disabled = false;
  ref!: DynamicDialogRef;
  petPlans?: PetPlan[];
  allDocsResponse: any[] = [];
  allDocsResponseClinicToSA: any[] = [];
  totalUpdatedPrice!: string;
  totalDiscountPrice!: string;
  showFuturePlans: boolean = false;
  showHistoryPlans: boolean = false;
  showOnGoingPlans: boolean = true;
  totalsOngoing!: {
    totalUpdatedPrice: string;
    totalDiscountPrice: string;
    firstMonthAmmount: string;
    remainingMonthAmmount: string;
    totalPrice: string;
  }[];
  totalsFuture!: {
    totalUpdatedPrice: string;
    totalDiscountPrice: string;
    firstMonthAmmount: string;
    remainingMonthAmmount: string;
    totalPrice: string;
  }[];
  totalsHistory!: {
    totalUpdatedPrice: string;
    totalDiscountPrice: string;
    firstMonthAmmount: string;
    remainingMonthAmmount: string;
    totalPrice: string;
  }[];

  constructor(
    private repService: SaleRepService,
    private route: ActivatedRoute,
    private dialogService: DialogService,
    private sharedService: SharedService,
    private fileUploadService: FileUploadService,
  ) {}
  ngOnInit(): void {
    this.getprofile();
    this.getIndvidualprofile();
    this.getclinicAdminprofile();
    this.getclinicAssociateprofile();
    this.getPetOwnerprofile();

    this.getAllDocsSAToClinic();
    this.getAllDocsbyClinictoSA();
  }
  // clinic
  getprofile() {
    this.route.queryParams.subscribe((params) => {
      const clinicId = params['clinicId'];

      this.clinidetailsId = clinicId;

      if (clinicId) {
        this.repService.showProfileById(clinicId).subscribe({
          next: (response) => {
            this.profileData = response;
          },
          error: (error) => {
            if (error.status === 401) {
              console.error(
                'Unauthorized request. Please check your authentication token.',
              );
            } else {
              console.error('Error retrieving object:', error);
            }
          },
        });
      }
    });
  }
  // owner
  getIndvidualprofile() {
    this.route.queryParams.subscribe((params) => {
      const Id = params['selectedId'];

      this.clinicOwnerId = Id;

      if (Id) {
        this.repService.showPersonProfileById(Id).subscribe({
          next: (response) => {
            this.profileData = response;
            this.repService.allClinicsOfOwner(Id).subscribe({
              next: (clinicDeatilsoftheOwner) => {
                this.clinicsOfClinicowner = clinicDeatilsoftheOwner;
              },
            });
          },
          error: (error) => {
            if (error.status === 401) {
              console.error(
                'Unauthorized request. Please check your authentication token.',
              );
            } else {
              console.error('Error retrieving object:', error);
            }
          },
        });
      }
    });
  }

  // admin
  getclinicAdminprofile() {
    this.route.queryParams.subscribe((params) => {
      const adminId = params['AdminId'];

      this.clinicAdminId = adminId;

      if (adminId) {
        this.repService.showPersonProfileById(adminId).subscribe({
          next: (response) => {
            this.profileData = response;
          },
          error: (error) => {
            if (error.status === 401) {
              console.error(
                'Unauthorized request. Please check your authentication token.',
              );
            } else {
              console.error('Error retrieving object:', error);
            }
          },
        });
      }
    });
  }
  // associate
  getclinicAssociateprofile() {
    this.route.queryParams.subscribe((params) => {
      const associateId = params['AssociateId'];

      this.clinicAssociateId = associateId;

      if (associateId) {
        this.repService.showPersonProfileById(associateId).subscribe({
          next: (response) => {
            this.profileData = response;
          },
          error: (error) => {
            if (error.status === 401) {
              console.error(
                'Unauthorized request. Please check your authentication token.',
              );
            } else {
              console.error('Error retrieving object:', error);
            }
          },
        });
      }
    });
  }
  // petowner
  getPetOwnerprofile() {
    this.route.queryParams.subscribe((params) => {
      const petOwnersId = params['petownerId'];
      const petsId = params['petsId'];

      if (petOwnersId && petsId) {
        this.repService.showpetByIdWithPlan(petsId, petOwnersId).subscribe({
          next: (response) => {
            this.petOwnerProfile = response;
            this.petOwnerId = petOwnersId
            this.calculateTotals();
          },
          error: (error) => {
            if (error.status === 401) {
              console.error(
                'Unauthorized request. Please check your authentication token.',
              );
            } else {
              console.error('Error retrieving object:', error);
            }
          },
        });
      }
    });
  }
  getOngoingPlans() {
    return Object.values(this.petOwnerProfile?.ongoingPlans || {});
  }
  getHistoryPlans() {
    return Object.values(this.petOwnerProfile?.historyPlans || {});
  }
  getFutureplans() {
    return Object.values(this.petOwnerProfile?.futurePlans || {});
  }
  calculateTotals() {
    const totalsongoing: Array<{
      totalUpdatedPrice: string;
      totalDiscountPrice: string;
      firstMonthAmmount: string;
      remainingMonthAmmount: string;
      totalPrice: string;
    }> = [];
    const totalsHistory: Array<{
      totalUpdatedPrice: string;
      totalDiscountPrice: string;
      firstMonthAmmount: string;
      remainingMonthAmmount: string;
      totalPrice: string;
    }> = [];
    const totalsFuture: Array<{
      totalUpdatedPrice: string;
      totalDiscountPrice: string;
      firstMonthAmmount: string;
      remainingMonthAmmount: string;
      totalPrice: string;
    }> = [];
    const ongoingPlans = this.getOngoingPlans();
    const planHistory = this.getHistoryPlans();
    const futurePlans = this.getFutureplans();
    if (ongoingPlans) {
      ongoingPlans.forEach((planSet, index) => {
        let totalUpdatedPrice = 0;
        let totalDiscountPrice = 0;

        planSet.forEach((plan: any) => {
          totalUpdatedPrice += parseFloat(plan.updatedPrice || '0');
          totalDiscountPrice += parseFloat(plan.discountPrice || '0');
        });
        const firstMonth = totalDiscountPrice / 12 + 49;
        const remainingMonth = totalDiscountPrice / 12 + 7;
        const total = firstMonth + remainingMonth * 11;
        totalsongoing[index] = {
          totalUpdatedPrice: totalUpdatedPrice.toFixed(2),
          totalDiscountPrice: totalDiscountPrice.toFixed(2),
          firstMonthAmmount: firstMonth.toFixed(2),
          remainingMonthAmmount: remainingMonth.toFixed(2),
          totalPrice: total.toFixed(2),
        };
      });
      this.totalsOngoing = totalsongoing;
    }
    if (planHistory) {
      planHistory.forEach((planSet, index) => {
        let totalUpdatedPrice = 0;
        let totalDiscountPrice = 0;

        planSet.forEach((plan: any) => {
          totalUpdatedPrice += parseFloat(plan.updatedPrice || '0');
          totalDiscountPrice += parseFloat(plan.discountPrice || '0');
        });
        const firstMonth = totalDiscountPrice / 12 + 49;
        const remainingMonth = totalDiscountPrice / 12 + 7;
        const total = firstMonth + remainingMonth * 11;
        totalsHistory[index] = {
          totalUpdatedPrice: totalUpdatedPrice.toFixed(2),
          totalDiscountPrice: totalDiscountPrice.toFixed(2),
          firstMonthAmmount: firstMonth.toFixed(2),
          remainingMonthAmmount: remainingMonth.toFixed(2),
          totalPrice: total.toFixed(2),
        };
      });
      this.totalsHistory = totalsHistory;
    }
    if (futurePlans) {
      futurePlans.forEach((planSet, index) => {
        let totalUpdatedPrice = 0;
        let totalDiscountPrice = 0;

        planSet.forEach((plan: any) => {
          totalUpdatedPrice += parseFloat(plan.updatedPrice || '0');
          totalDiscountPrice += parseFloat(plan.discountPrice || '0');
        });
        const firstMonth = totalDiscountPrice / 12 + 49;
        const remainingMonth = totalDiscountPrice / 12 + 7;
        const total = firstMonth + remainingMonth * 11;
        totalsFuture[index] = {
          totalUpdatedPrice: totalUpdatedPrice.toFixed(2),
          totalDiscountPrice: totalDiscountPrice.toFixed(2),
          firstMonthAmmount: firstMonth.toFixed(2),
          remainingMonthAmmount: remainingMonth.toFixed(2),
          totalPrice: total.toFixed(2),
        };
      });
      this.totalsFuture = totalsFuture;
    }
  }
  togglePlans(planType: string): void {
    if (planType === 'ongoing') {
      this.showOnGoingPlans = !this.showOnGoingPlans;
      if (this.showOnGoingPlans) {
        this.showFuturePlans = false;
        this.showHistoryPlans = false;
      }
    } else if (planType === 'future') {
      this.showFuturePlans = !this.showFuturePlans;
      if (this.showFuturePlans) {
        this.showOnGoingPlans = false;
        this.showHistoryPlans = false;
      }
    } else if (planType === 'history') {
      this.showHistoryPlans = !this.showHistoryPlans;
      if (this.showHistoryPlans) {
        this.showOnGoingPlans = false;
        this.showFuturePlans = false;
      }
    }
  }

  getAllDocsSAToClinic() {
    this.repService.getDocsOfSAtoClinics(this.clinidetailsId).subscribe({
      next: (response) => {
        this.allDocsResponse = response;
      },
      error: (error) => {
        if (error.status === 401) {
          console.error(
            'Unauthorized request. Please check your authentication token.',
          );
        } else {
          console.error('Error retrieving object:', error);
        }
      },
    });
  }

  getAllDocsbyClinictoSA() {
    this.repService.getDocsOfClinicsToSA(this.clinidetailsId).subscribe({
      next: (response) => {
        this.allDocsResponseClinicToSA = response;
      },
      error: (error) => {
        if (error.status === 401) {
          console.error(
            'Unauthorized request. Please check your authentication token.',
          );
        } else {
          console.error('Error retrieving object:', error);
        }
      },
    });
  }

  viewDocument(doc: string) {
    window.open(doc, '_blank');
  }
}
