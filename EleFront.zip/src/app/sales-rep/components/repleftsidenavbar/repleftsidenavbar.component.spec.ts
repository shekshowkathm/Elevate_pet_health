import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepleftsidenavbarComponent } from './repleftsidenavbar.component';

describe('RepleftsidenavbarComponent', () => {
  let component: RepleftsidenavbarComponent;
  let fixture: ComponentFixture<RepleftsidenavbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RepleftsidenavbarComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RepleftsidenavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
