import { CommonModule, NgClass } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  input,
  Output,
  output,
} from '@angular/core';
import {
  Router,
  RouterLink,
  RouterLinkActive,
  RouterModule,
} from '@angular/router';

interface NavItem {
  label: string;
  icon?: string;
  route?: string;
  color?: string;
  children?: NavItem[];
  isOpen?: boolean;
}

@Component({
  selector: 'app-repleftsidenavbar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './repleftsidenavbar.component.html',
  styleUrl: './repleftsidenavbar.component.scss',
})
export class RepleftsidenavbarComponent {
  @Input() isLeftSidebarCollapsed: boolean = false;
  @Output() changeIsLeftSidebarCollapsed = new EventEmitter<boolean>();
  constructor(private router: Router) {}
  navItems: NavItem[] = [
    { label: 'Dashboard', icon: 'pi-th-large', route: '/salesRep' },
    {
      label: 'Clinic Details',
      icon: 'pi-envelope',
      route: '/salesRep/repClinicdetails',
      children: [
        {
          label: 'Clinic Owners',
          icon: '',
          route: '/salesRep/repclinicowners',
          color: '#2e68d4',
        },
        {
          label: 'Clinic Admin',
          icon: '',
          route: '/salesRep/repclinicAdmins',
          color: '#ffb946',
        },
        {
          label: 'Associates',
          icon: '',
          route: '/salesRep/repclinicAssociates',
          color: '#885af8',
        },
        {
          label: 'Pet Owners',
          icon: '',
          route: '/salesRep/reppetowners',
          color: '#2ed47a',
        },
      ],
      isOpen: false,
    },
    {
      label: 'Setup Data',
      icon: 'pi pi-list',
      route: '/salesRep/repsetupdata',
    },
    {
      label: 'Service List',
      icon: 'pi-heart-fill',
      route: '/salesRep/repservicelist',
    },
    { label: 'Promotion Discounts', icon: 'pi-th-large', route: '/salesRep/promotionDiscount' },
    {
      label: 'Payment',
      icon: 'pi-calendar-clock',
      route: '/salesRep/paymentstatus',
    },
    // { label: 'Support', icon: 'pi-user', route: '' },
  ];

  toggleCollapse(): void {
    this.changeIsLeftSidebarCollapsed.emit(!this.isLeftSidebarCollapsed);
  }

  closeSidenav(): void {
    this.changeIsLeftSidebarCollapsed.emit(true);
  }

  changeDropDown(navItem: NavItem) {
    navItem.isOpen = !navItem.isOpen;
  }

  toggleDropdown(navItem: NavItem): void {
    if (navItem.children) {
      navItem.isOpen = !navItem.isOpen;
    } else if (navItem.route) {
      this.router.navigate([navItem.route]);
    }
  }

  navigateToRoute(route: any): void {
    this.router.navigate([route]);
  }
}
