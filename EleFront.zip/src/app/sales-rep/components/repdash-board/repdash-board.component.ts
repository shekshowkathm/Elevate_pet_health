import { isPlatformBrowser } from '@angular/common';
import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { Router } from '@angular/router';
import { SaleRepService } from '../../service/sale-rep.service';
import { StripeService } from '../../../clinic/services/stripe.service';
import { SharedService } from '../../../shared/service/shared.service';

interface Promotion {
  promotion: string;
  expiryDate: string | null;
  pendingDays: number;
}

interface DashboardData {
  associatesCount: number;
  petOwnersCount: number;
  activePlansCount: number;
  expiringPlanCounts: number;
  creditCardIssuesCounts: number;
  todayPaymentsCount: number;
  salesRepsCount: number;
  totalClinicsCount: number;
  promotions: Promotion[];
}

@Component({
  selector: 'app-repdash-board',
  standalone: true,
  imports: [],
  templateUrl: './repdash-board.component.html',
  styleUrl: './repdash-board.component.scss',
})
export class RepdashBoardComponent {
  dashboardData: DashboardData = {
    associatesCount: 0,
    petOwnersCount: 0,
    activePlansCount: 0,
    expiringPlanCounts: 0,
    creditCardIssuesCounts: 0,
    todayPaymentsCount: 0,
    salesRepsCount: 0,
    totalClinicsCount: 1,
    promotions: [],
  };
  creditCardIssuesCounts :number =0
  constructor(
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object,
    private salesRepService: SaleRepService,
    private StripeService: StripeService,
    private sharedService: SharedService,
  ) {}

  ngOnInit() {
    this.getDashBoardInfo();
    this.getCardIssue();
  }

  getDashBoardInfo() {
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      const id = localStorage.getItem('id') || '';
      this.salesRepService.getDashboardCount(id).subscribe({
        next: (response: any) => {
          this.dashboardData = response;
          console.log(this.dashboardData);
        },
        error(err) {
          console.log(err);
        },
      });
    }
  }
  getCardIssue() {
    const salesRepsId = this.sharedService.getId('id');
    if (salesRepsId) {
      this.StripeService.getSalesExpDetails(Number(salesRepsId)).subscribe((doc: any) => {
        this.creditCardIssuesCounts = doc.count
      });
    }
  }
  routeToClinicDetails() {
    this.router.navigate(['salesRep/repClinicdetails']);
  }
  routeToPetOwners() {
    this.router.navigate(['salesRep/reppetowners']);
  }
}
