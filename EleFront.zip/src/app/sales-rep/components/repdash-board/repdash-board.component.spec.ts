import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepdashBoardComponent } from './repdash-board.component';

describe('RepdashBoardComponent', () => {
  let component: RepdashBoardComponent;
  let fixture: ComponentFixture<RepdashBoardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RepdashBoardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RepdashBoardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
