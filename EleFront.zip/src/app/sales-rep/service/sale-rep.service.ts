import { isPlatformBrowser } from '@angular/common';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Inject, Injectable, PLATFORM_ID } from '@angular/core';
import { environment } from '../../../environments/environment.development';
import {
  Breed,
  ClinicAdmin,
  ClinicDetails,
  GetDocsResponse,
  PetOwner,
  ProfilebyId,
  Promotion,
  RepProfile,
  ServiceList,
  showClinicProfile,
  WeightRange,
  WellnessPlanResponse,
} from '../model/sale-rep-responses';
import { catchError, map, Observable, of, Subject } from 'rxjs';
import { SharedService } from '../../shared/service/shared.service';


@Injectable({
  providedIn: 'root',
})
export class SaleRepService {
  public showById = environment.apiUrl + '/clinic-details/get-profile';
  public updateSalesRepProfile =
    environment.apiUrl + '/register/update-profile';
  public updatePasswordApi = environment.apiUrl + '/register/updatePassword';
  public getClinisOfRep =
    environment.apiUrl + '/clinic-details/elevate-rep-clinic-list';
  public getclinownerofRep = environment.apiUrl + '/clinic-details/sales-rep';
  public showClinicREPapi = environment.apiUrl + '/clinic-details/get-Clinic';
  public getClinicsByOwnerId =
    environment.apiUrl + '/clinic-details/clinic-list-owner';
  public getPetWithItsplan = environment.apiUrl + '/clinic-details/getPetById';
  private getDocsBySAToClinicREP =
    environment.apiUrl + '/api/documents/superadmin/clinic';
  public getDocsByClinicToSAREP = environment.apiUrl + '/api/documents/clinic';
  private getWeightRangeUrl = environment.apiUrl + '/weightRange/getAll';
  private getWellnessPlanUrl = environment.apiUrl + '/wellnessPlan/getAll';
  private getServiceUrl = environment.apiUrl + '/service/getAllServices';
  private getBreedUrl = environment.apiUrl + '/breed/getAll';
  private getDashboardCountAPI = environment.apiUrl + '/counts/salesRep/';


  private hasAcceptedTerms = false;

  private openDialogSubject = new Subject<void>();
  private dialogClosedSubject = new Subject<boolean>();
  private promotionDiscount = environment.apiUrl + '/promotion/get-clinic-promotion';
  private getclinicDetailsinPromotiondiscount = environment.apiUrl + '/promotion/getPromotions'

  constructor(
    private http: HttpClient,
    @Inject(PLATFORM_ID) private platformId: Object,
    private sharedService: SharedService
  ) { }

  /**
   * @param token
   */
  private getRequestOptions(): { headers: HttpHeaders } {
    let token = '';

    // Check if running in the browser
    if (isPlatformBrowser(this.platformId)) {
      token = localStorage.getItem('token') || '';
    }

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: token ? `Bearer ${token}` : '',
    });

    return { headers };
  }

  /**
   *
   * @param showprofilegetbyID
   */
  showPersonProfileById(selectedId: any): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const withPersonalIdUrl = `${this.showById}/${selectedId}`;
    return this.http.get<RepProfile>(withPersonalIdUrl, requestOptions);
  }

  /**
   *
   * @param UpdateSAProfile
   */

  updateProfile(updatedValue: RepProfile) {
    const requestOptions = this.getRequestOptions();
    return this.http.put(this.updateSalesRepProfile, updatedValue, {
      headers: requestOptions.headers,
      responseType: 'text',
    });
  }

  /**
   * P-dialog for update password
   */
  pDialogOpenUpdatePassword() {
    this.openDialogSubject.next();
  }
  pDialogCloseUpdatePassword(isCanceled: boolean) {
    this.dialogClosedSubject.next(isCanceled);
  }

  /**
   * @param regid
   * @param confirmPassword
   * @returns
   */
  updatePassword(password: string, Id: number): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const body = {
      regId: Id,
      password,
    };
    return this.http.put(`${this.updatePasswordApi}`, body, {
      headers: requestOptions.headers,
      responseType: 'text',
    });
  }

  setAcceptedTerms(status: boolean): void {
    this.hasAcceptedTerms = status;
  }
  getAcceptedTerms(): boolean {
    return this.hasAcceptedTerms;
  }

  /**
   *
   * @param ClinicsOfRep
   */
  getAllClinicsOfRep(repId: number): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const RepsIdtoGetClinics = `${this.getClinisOfRep}/${repId}`;
    return this.http.get<ClinicDetails>(RepsIdtoGetClinics, requestOptions);
  }

  /**
   *
   * @param ClinicsownersOfRep
   */
  getAllClinicsownersOfRep(repId: number): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const RepsIdtoGetClinics = `${this.getclinownerofRep}/${repId}/users/CLINIC_OWNER`;
    return this.http.get<ClinicDetails>(RepsIdtoGetClinics, requestOptions);
  }
  /**
   *
   * @param GetAllClinicsofOwner
   */
  allClinicsOfOwner(ownerId: number): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const OwnerIdTogetClinics = `${this.getClinicsByOwnerId}/${ownerId}`;
    return this.http.get<ClinicDetails>(OwnerIdTogetClinics, requestOptions);
  }
  /**
   *
   * @param ClinicAdminsOfRep
   */
  getAllClinicAdminsOfRep(repId: number): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const RepsIdtoGetClinics = `${this.getclinownerofRep}/${repId}/users/CLINIC_ADMIN`;
    return this.http.get<ClinicAdmin>(RepsIdtoGetClinics, requestOptions);
  }

  /**
   *
   * @param ClinicAsociatesOfRep
   */
  getAllClinicassociatesOfRep(repId: number): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const RepsIdtoGetClinics = `${this.getclinownerofRep}/${repId}/users/CLINIC_ASSOCIATE`;
    return this.http.get<ClinicDetails>(RepsIdtoGetClinics, requestOptions);
  }
  /**
   *
   * @param PetsOfRepclinic
   */
  getAllPetsOfRep(repId: number): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const RepsIdtoGetClinics = `${this.getclinownerofRep}/${repId}/users/PET_OWNER`;
    return this.http.get<ClinicDetails>(RepsIdtoGetClinics, requestOptions);
  }
  /**
   *
   * @param showClinicbyID
   */
  showProfileById(clinicId: number): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const withIdUrl = `${this.showClinicREPapi}/${clinicId}`;
    return this.http.get<showClinicProfile>(withIdUrl, requestOptions);
  }

  /**
   *
   * @param showPetsOfpetownerwithplans
   */
  showpetByIdWithPlan(petId: number, petOwnerId: number): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const withIdUrl = `${this.getPetWithItsplan}/${petId}/${petOwnerId}`;
    return this.http.get<PetOwner>(withIdUrl, requestOptions);
  }
  /**
   *
   * @param getDocsUploadedBySuperAdminToClinic
   */
  getDocsOfSAtoClinics(clinicId: number): Observable<any> {
    if (clinicId) {
      const requestOptions = this.getRequestOptions();
      const getDocsUploadedBySAtoClinic = `${this.getDocsBySAToClinicREP}/${clinicId}`;
      return this.http.get<GetDocsResponse>(
        getDocsUploadedBySAtoClinic,
        requestOptions
      );
    } else {
      // Return an empty observable or handle the case where clinicId is not present
      return of(null); // 'of' creates an observable that emits 'null'
    }
  }

  /**
   *
   * @param getDocsUploadedByClinicToSuperAdmin
   */
  getDocsOfClinicsToSA(clinicId: number): Observable<any> {
    if (clinicId) {
      const requestOptions = this.getRequestOptions();
      const getDocsUploadedBySAtoClinic = `${this.getDocsByClinicToSAREP}/${clinicId}/superadmin`;
      return this.http.get<GetDocsResponse>(
        getDocsUploadedBySAtoClinic,
        requestOptions
      );
    } else {
      // Return an empty observable or handle the case where clinicId is not present
      return of(null); // 'of' creates an observable that emits 'null'
    }
  }
  /**
   *
   * @param getallweightrange
   */
  getAllWeightRange(): Observable<WeightRange[]> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<WeightRange[]>(this.getWeightRangeUrl, requestOptions);
  }
  /**
   *
   * @param getallbreed
   */
  getAllBreed(): Observable<Breed[]> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<Breed[]>(this.getBreedUrl, requestOptions);
  }
  /**
   *
   * @param servicelist
   */
  getAllServices(): Observable<ServiceList[]> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<ServiceList[]>(this.getServiceUrl, requestOptions);
  }
  /**
   *
   * @param getAllWellnessPlan
   */
  getAllWellnessPlan(): Observable<WellnessPlanResponse[]> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<WellnessPlanResponse[]>(
      this.getWellnessPlanUrl,
      requestOptions
    );
  }




  /***
   * 
   * Dashboard count method
   * 
   * ****/

  getDashboardCount(id: string) {
    const requestOptions = this.getRequestOptions();
    return this.http.get(
      this.getDashboardCountAPI + id,
      requestOptions
    );
  }

  /**
   *
   * @param PromotionDiscountofclinics
   */
  getPromotionDiscount(role: string, salesRepId: number): Observable<Promotion[]> {
    const requestOptions = this.getRequestOptions();
    const params = new HttpParams()
      .set('role', role)
      .set('salesRepId', salesRepId.toString());
    const RepsIdandRole = `${this.promotionDiscount}`;
    return this.http.get<Promotion[]>(RepsIdandRole, { ...requestOptions, params, responseType: 'json' });
  }
  /**
   *
   * @param showclinicdetailswithpromotiondiscounts
   */
  viewclinicdetailswithpromotion(clinicId: number): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const clinicdetailswithpromotion = `${this.getclinicDetailsinPromotiondiscount}/${clinicId}`;
    return this.http.get(clinicdetailswithpromotion, requestOptions);
  }

  /**
   * @param error
   */
  private handleError(error: any): Observable<never> {
    console.error('An error occurred:', error);
    throw error;
  }
}
