import { TestBed } from '@angular/core/testing';

import { SaleRepService } from './sale-rep.service';

describe('SaleRepService', () => {
  let service: SaleRepService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SaleRepService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
