import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { UpdatePasswordComponent } from './pet-owner/components/petOwnerStages/update-password/update-password.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,UpdatePasswordComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'elevatepethealth';
}
