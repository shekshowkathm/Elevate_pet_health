import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appNumberInput]',
  standalone: true,
})
export class NumberInputDirective {
  @HostListener('keypress', ['$event'])
  validateNumberInput(event: KeyboardEvent): void {
    const inputChar = event.key;
    const currentValue = (event.target as HTMLInputElement).value;

    const isNumberOrDot = /^[0-9.]$/.test(inputChar);
    const allowedSpecialKeys = [
      'Backspace',
      'Tab',
      'ArrowLeft',
      'ArrowRight',
      'Delete',
    ];

    if (!isNumberOrDot && !allowedSpecialKeys.includes(inputChar)) {
      event.preventDefault();
      return;
    }

    if (inputChar === '.' && currentValue.includes('.')) {
      event.preventDefault();
    }
  }
}
