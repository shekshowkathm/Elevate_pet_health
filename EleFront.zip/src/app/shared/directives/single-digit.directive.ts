import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appSingleDigit]',
  standalone: true
})
export class SingleDigitDirective {

  constructor(private el: ElementRef) {}

  @HostListener('input', ['$event'])
  onInput(event: Event): void {
    const inputElement = this.el.nativeElement as HTMLInputElement;
    let value = inputElement.value;

    if (!/^[1-4]$/.test(value)) {
      inputElement.value = '';
    }
  }

}

