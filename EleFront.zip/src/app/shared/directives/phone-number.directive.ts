import { Directive, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';

@Directive({
  selector: '[appPhoneNumber]',
  standalone: true,
})
export class PhoneNumberDirective {
  constructor(private ngControl: NgControl) {}

  @HostListener('input', ['$event'])
  onInputChange(event: Event) {
    let input = this.ngControl.control?.value.replace(/\D/g, '');
    if (input.length > 10) input = input.substring(0, 10);
    if (input.length > 6) {
      input = `(${input.substring(0, 3)}) ${input.substring(
        3,
        6
      )}-${input.substring(6, 10)}`;
    } else if (input.length > 3) {
      input = `(${input.substring(0, 3)}) ${input.substring(3, 6)}`;
    } else if (input.length > 0) {
      input = `(${input}`;
    }
    this.ngControl.control?.setValue(input, { emitEvent: true });
  }
}
