import { SingleDigitDirective } from './single-digit.directive';

describe('SingleDigitDirective', () => {
  it('should create an instance', () => {
    const directive = new SingleDigitDirective();
    expect(directive).toBeTruthy();
  });
});
