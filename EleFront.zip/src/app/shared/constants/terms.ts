import { TermsContent } from '../model/terms-content';

export const TERMS_OF_USE: TermsContent[] = [
  {
    sectionTitle: `ACCEPTANCE OF THE TERMS OF USE`,
    content: [
      {
        type: 'paragraph',
        content:
          'These terms of use are entered into by and between You and ELEVATE PET HEALTH, LLC (“<strong>Company</strong>,” “<strong>we</strong>,” or “<strong>us</strong>”). The following terms and conditions, together with any documents they expressly incorporate by reference (collectively, “<strong>Terms of Use</strong>”), govern your access to and use of elevatepethealth.com, including any content, functionality and services offered on or through elevatepethealth.com (the “<strong>Site</strong>”), whether as a guest or a registered user.',
      },
      {
        type: 'paragraph',
        content:
          'Please read the Terms of Use carefully before you start to use the Site. <strong>By using the Site, you accept and agree to be bound and abide by these Terms of Use</strong>. If you do not want to agree to these Terms of Use, you must not access or use the Site.',
      },
      {
        type: 'paragraph',
        content:
          'This Site is offered and available to users who are 18 years of age or older and reside in the United States or any of its territories or possessions. By using this Site, you represent and warrant that you meet all of the foregoing eligibility requirements. If you do not meet all of these requirements, you must not access or use the Site.',
      },
    ],
  },
  {
    sectionTitle: 'CHANGES TO THE TERMS OF USE',
    content: [
      {
        type: 'paragraph',
        content:
          'We may revise and update these Terms of Use from time to time in our sole discretion. All changes are effective immediately when we post them.',
      },
      {
        type: 'paragraph',
        content:
          'Your continued use of the Site following the posting of revised Terms of Use means that you accept and agree to the changes. You are expected to check this page from time to time so you are aware of any changes, as they are binding on you.',
      },
    ],
  },
  {
    sectionTitle: 'ACCESSING THE SITE AND ACCOUNT SECURITY',
    content: [
      {
        type: 'paragraph',
        content:
          'We reserve the right to withdraw or amend this Site, and any service or material we provide on the Site, in our sole discretion without notice. We will not be liable if for any reason all or any part of the Site is unavailable at any time or for any period. From time to time, we may restrict access to some parts of the Site, or the entire Site, to users, including registered users.',
      },
      {
        type: 'paragraph',
        content: 'You are responsible for both:',
      },
      {
        type: 'list',
        listType: 'unordered',
        items: [
          'Making all arrangements necessary for you to have access to the Site.',
          'Ensuring that all persons who access the Site through your internet connection are aware of these Terms of Use and comply with them.',
        ],
      },
      {
        type: 'paragraph',
        content:
          'To access the Site or some of the resources it offers, you may be asked to provide certain registration details or other information. It is a condition of your use of the Site that all the information you provide on the Site is correct, current and complete. You agree that all information you provide to register with this Site or otherwise, including, but not limited to, through the use of any interactive features on the Site, is governed by our <a class="text-[#007CDA]" href="#privacy">Privacy Policy</a>, and you consent to all actions we take with respect to your information consistent with our Privacy Policy.',
      },
      {
        type: 'paragraph',
        content:
          'If you choose, or are provided with, a user name, password or any other piece of information as part of our security procedures, you must treat such information as confidential, and you must not disclose it to any other person or entity. You also acknowledge that your account is personal to you and agree not to provide any other person with access to this Site or portions of it using your user name, password or other security information. You agree to notify us immediately of any unauthorized access to or use of your user name or password or any other breach of security. You also agree to ensure that you exit from your account at the end of each session. You should use particular caution when accessing your account from a public or shared computer so that others are not able to view or record your password or other personal information.',
      },
      {
        type: 'paragraph',
        content:
          'We have the right to disable any user name, password or other identifier, whether chosen by you or provided by us, at any time in our sole discretion for any or no reason, including if, in our opinion, you have violated any provision of these Terms of Use.',
      },
    ],
  },
  {
    sectionTitle: 'INTELLECTUAL PROPERTY RIGHTS',
    content: [
      {
        type: 'paragraph',
        content:
          'The Site and its entire contents, features and functionality (including but not limited to all information, software, text, displays, images, video and audio, and the design, selection and arrangement thereof), are owned by the Company, its licensors or other providers of such material and are protected by United States and international copyright, trademark, patent, trade secret and other intellectual property or proprietary rights laws. These Terms of Use permit you to use the Site for your personal, non-commercial use only. You must not reproduce, distribute, modify, create derivative works of, publicly display, publicly perform, republish, download, store or transmit any of the material on our Site, except as follows:',
      },
      {
        type: 'paragraph',
        content: 'As a user of the Site, you agree not to:',
      },
      {
        type: 'list',
        listType: 'unordered',
        items: [
          'Your computer may temporarily store copies of such materials in RAM incidental to your accessing and viewing those materials.',
          'You may store files that are automatically cached by your Web browser for display enhancement purposes.',
        ],
      },
      {
        type: 'paragraph',
        content: 'You must not:',
      },
      {
        type: 'list',
        listType: 'unordered',
        items: [
          'Modify copies of any materials from this site.',
          'Use any illustrations, photographs, video or audio sequences or any graphics separately from the accompanying text.',
          'Delete or alter any copyright, trademark or other proprietary rights notices from copies of materials from this site.',
        ],
      },
      {
        type: 'paragraph',
        content:
          'You must not access or use for any commercial purposes any part of the Site or any services or materials available through the Site.',
      },
      {
        type: 'paragraph',
        content:
          'If you print, copy, modify, download or otherwise use or provide any other person with access to any part of the Site in breach of the Terms of Use, your right to use the Site will cease immediately and you must, at our option, return or destroy any copies of the materials you have made. No right, title or interest in or to the Site or any content on the Site is transferred to you, and all rights not expressly granted are reserved by the Company. Any use of the Site not expressly permitted by these Terms of Use is a breach of these Terms of Use and may violate copyright, trademark and other laws.',
      },
    ],
  },
  {
    sectionTitle: 'TRADEMARKS',
    content: [
      {
        type: 'paragraph',
        content:
          'The Company name, and all related names, logos, product and service names, designs and slogans are trademarks of the Company or its affiliates or licensors. You must not use such marks without the prior written permission of the Company. All other names, logos, product and service names, designs and slogans on this Site are the trademarks of their respective owners',
      },
    ],
  },
  {
    sectionTitle: 'PROHIBITED USES',
    content: [
      {
        type: 'paragraph',
        content:
          'You may use the Site only for lawful purposes and in accordance with these Terms of Use. You agree not to use the Site:',
      },
      {
        type: 'list',
        listType: 'unordered',
        items: [
          'In any way that violates any applicable federal, state, local or international law or regulation (including, without limitation, any laws regarding the export of data or software to and from the US or other countries). ',
        ],
      },
      {
        type: 'paragraph',
        content: 'Additionally, you agree not to:',
      },
      {
        type: 'list',
        listType: 'unordered',
        items: [
          'Use the Site in any manner that could disable, overburden, damage, or impair the site or interfere with any other party’s use of the Site, including their ability to engage in real time activities through the Site.',
          'Use any robot, spider or other automatic device, process or means to access the Site for any purpose, including monitoring or copying any of the material on the Site.',
          'Use any manual process to monitor or copy any of the material on the Site, or for any other purpose not expressly authorized in these Terms of Use, without our prior written consent.',
          'Use any device, software or routine that interferes with the proper working of the Site.',
          'Introduce any viruses, trojan horses, worms, logic bombs or other material which is malicious or technologically harmful.',
          'Attempt to gain unauthorized access to, interfere with, damage or disrupt any parts of the Site, the server on which the Site is stored, or any server, computer or database connected to the Site.',
          'Attack the Site via a denial-of-service attack or a distributed denial-of-service attack',
          'Otherwise attempt to interfere with the proper working of the Site.',
        ],
      },
    ],
  },
  {
    sectionTitle: 'CHANGES TO THE SITE',
    content: [
      {
        type: 'paragraph',
        content:
          'We may update the content on this Site from time to time, but its content is not necessarily complete or up-to-date. Any of the material on the Site may be out of date at any given time, and we are under no obligation to update such material.',
      },
    ],
  },
  {
    sectionTitle: 'INFORMATION ABOUT YOU AND YOUR VISITS TO THE SITE',
    content: [
      {
        type: 'paragraph',
        content:
          'All information we collect on this Site is subject to our <a class="text-[#007CDA] href="#privacy">Privacy Policy</a>. By using the Site, you consent to all actions taken by us with respect to your information in compliance with the Privacy Policy.',
      },
    ],
  },
  {
    sectionTitle: 'ONLINE PURCHASES AND OTHER TERMS AND CONDITIONS',
    content: [
      {
        type: 'paragraph',
        content:
          'All purchases through our site or other transactions for the sale of services formed through the Site, or as a result of visits made by you are governed by our <a class="text-[#007CDA] href="legal/elevate-terms-of-service.pdf" target="_blank">Terms of Service</a> which are hereby incorporated into these Terms of Use.',
      },
      {
        type: 'paragraph',
        content:
          'Additional terms and conditions may also apply to specific portions, services or features of the Site. All such additional terms and conditions are hereby incorporated by this reference into these Terms of Use.',
      },
    ],
  },
  {
    sectionTitle: 'LINKING TO THE SITE AND SOCIAL MEDIA FEATURES',
    content: [
      {
        type: 'paragraph',
        content:
          'You may link to our homepage, provided you do so in a way that is fair and legal and does not damage our reputation or take advantage of it, but you must not establish a link in such a way as to suggest any form of association, approval or endorsement on our part without our express written consent.',
      },
      {
        type: 'paragraph',
        content:
          'This Site may provide certain social media features that enable you to:',
      },
      {
        type: 'list',
        listType: 'unordered',
        items: [
          'Link from your own or certain third-party websites to certain content on this Site.',
          'Send e-mails or other communications with certain content, or links to certain content, on this Site.',
          'Cause limited portions of content on this Site to be displayed or appear to be displayed on your own or certain third-party websites.',
        ],
      },
      {
        type: 'paragraph',
        content:
          'You may use these features solely as they are provided by us[,][ and] solely with respect to the content they are displayed with[, and otherwise in accordance with any additional terms and conditions we provide with respect to such features]. Subject to the foregoing, you must not:',
      },
      {
        type: 'list',
        listType: 'unordered',
        items: [
          'Establish a link from any website that is not owned by you.',
          'Cause the Site or portions of it to be displayed, or appear to be displayed by, for example, framing, deep linking or in-line linking, on any other site.',
          'Link to any part of the Site other than the homepage.',
          'Otherwise take any action with respect to the materials on this Site that is inconsistent with any other provision of these Terms of Use.',
        ],
      },
      {
        type: 'paragraph',
        content:
          'You agree to cooperate with us in causing any unauthorized framing or linking immediately to cease. We reserve the right to withdraw linking permission without notice. We may disable all or any social media features and any links at any time without notice in our discretion.',
      },
    ],
  },
  {
    sectionTitle: 'LINKS FROM THE SITE',
    content: [
      {
        type: 'paragraph',
        content:
          'If the Site contains links to other sites and resources provided by third parties, these links are provided for your convenience only. This includes links contained in advertisements, including banner advertisements and sponsored links. We have no control over the contents of those sites or resources, and accept no responsibility for them or for any loss or damage that may arise from your use of them. If you decide to access any of the third party websites linked to this Site, you do so entirely at your own risk and subject to the terms and conditions of use for such websites.',
      },
    ],
  },
  {
    sectionTitle: 'GEOGRAPHIC RESTRICTIONS',
    content: [
      {
        type: 'paragraph',
        content:
          'The owner of the Site is based in the Commonwealth of Pennsylvania in the United States. We provide this Site for use only by persons located in the United States. We make no claims that the Site or any of its content is accessible or appropriate outside of the United States. Access to the Site may not be legal by certain persons or in certain countries. If you access the Site from outside the United States, you do so on your own initiative and are responsible for compliance with local laws.',
      },
    ],
  },
  {
    sectionTitle: 'DISCLAIMER OF WARRANTIES',
    content: [
      {
        type: 'paragraph',
        content:
          'WE WILL NOT BE LIABLE FOR ANY LOSS OR DAMAGE CAUSED BY A DISTRIBUTED DENIAL-OF-SERVICE ATTACK, VIRUSES OR OTHER TECHNOLOGICALLY HARMFUL MATERIAL THAT MAY INFECT YOUR COMPUTER EQUIPMENT, COMPUTER PROGRAMS, DATA OR OTHER PROPRIETARY MATERIAL DUE TO YOUR USE OF THE WEBSITE OR ANY SERVICES OR ITEMS OBTAINED THROUGH THE WEBSITE OR TO YOUR DOWNLOADING OF ANY MATERIAL POSTED ON IT, OR ON ANY WEBSITE LINKED TO IT.',
      },
      {
        type: 'paragraph',
        content:
          'YOUR USE OF THE WEBSITE, ITS CONTENT AND ANY SERVICES OR ITEMS OBTAINED THROUGH THE WEBSITE IS AT YOUR OWN RISK. THE WEBSITE, ITS CONTENT AND ANY SERVICES OR ITEMS OBTAINED THROUGH THE WEBSITE ARE PROVIDED ON AN “AS IS” AND “AS AVAILABLE” BASIS, WITHOUT ANY WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED. NEITHER THE COMPANY NOR ANY PERSON ASSOCIATED WITH THE COMPANY MAKES ANY WARRANTY OR REPRESENTATION WITH RESPECT TO THE COMPLETENESS, SECURITY, RELIABILITY, QUALITY, ACCURACY OR AVAILABILITY OF THE WEBSITE. WITHOUT LIMITING THE FOREGOING, NEITHER THE COMPANY NOR ANYONE ASSOCIATED WITH THE COMPANY REPRESENTS OR WARRANTS THAT THE WEBSITE, ITS CONTENT OR ANY SERVICES OR ITEMS OBTAINED THROUGH THE WEBSITE WILL BE ACCURATE, RELIABLE, ERROR-FREE OR UNINTERRUPTED, THAT DEFECTS WILL BE CORRECTED, THAT OUR SITE OR THE SERVER THAT MAKES IT AVAILABLE ARE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS OR THAT THE WEBSITE OR ANY SERVICES OR ITEMS OBTAINED THROUGH THE WEBSITE WILL OTHERWISE MEET YOUR NEEDS OR EXPECTATIONS.<br>THE COMPANY HEREBY DISCLAIMS ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, STATUTORY OR OTHERWISE, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF MERCHANTABILITY, NON-INFRINGEMENT AND FITNESS FOR PARTICULAR PURPOSE.<br>THE FOREGOING DOES NOT AFFECT ANY WARRANTIES WHICH CANNOT BE EXCLUDED OR LIMITED UNDER APPLICABLE LAW.',
      },
    ],
  },
  {
    sectionTitle: 'LIMITATION ON LIABILITY',
    content: [
      {
        type: 'paragraph',
        content:
          'TO THE FULLEST EXTENT PROVIDED BY LAW, IN NO EVENT WILL THE COMPANY, ITS AFFILIATES OR THEIR LICENSORS, SERVICE PROVIDERS, EMPLOYEES, AGENTS, OFFICERS OR DIRECTORS BE LIABLE FOR DAMAGES OF ANY KIND, UNDER ANY LEGAL THEORY, ARISING OUT OF OR IN CONNECTION WITH YOUR USE, OR INABILITY TO USE, THE WEBSITE, ANY WEBSITES LINKED TO IT, ANY CONTENT ON THE WEBSITE OR SUCH OTHER WEBSITES OR ANY SERVICES OR ITEMS OBTAINED THROUGH THE WEBSITE OR SUCH OTHER WEBSITES, INCLUDING ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL OR PUNITIVE DAMAGES, INCLUDING BUT NOT LIMITED TO, PERSONAL INJURY, PAIN AND SUFFERING, EMOTIONAL DISTRESS, LOSS OF REVENUE, LOSS OF PROFITS, LOSS OF BUSINESS OR ANTICIPATED SAVINGS, LOSS OF USE, LOSS OF GOODWILL, LOSS OF DATA, AND WHETHER CAUSED BY TORT (INCLUDING NEGLIGENCE), BREACH OF CONTRACT OR OTHERWISE, EVEN IF FORESEEABLE.<br>THE FOREGOING DOES NOT AFFECT ANY LIABILITY WHICH CANNOT BE EXCLUDED OR LIMITED UNDER APPLICABLE LAW.',
      },
    ],
  },
  {
    sectionTitle: 'INDEMNIFICATION',
    content: [
      {
        type: 'paragraph',
        content:
          'You agree to defend, indemnify and hold harmless the Company, its affiliates, licensors and service providers, and its and their respective officers, directors, employees, contractors, agents, licensors, suppliers, successors and assigns from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses or fees (including reasonable attorneys’ fees) arising out of or relating to your violation of these Terms of Use or your use of the Site, any use of the Site’s content, services and products other than as expressly authorized in these Terms of Use, or your use of any information obtained from the Site.',
      },
    ],
  },
  {
    sectionTitle: 'GOVERNING LAW AND JURISDICTION',
    content: [
      {
        type: 'paragraph',
        content:
          'All matters relating to the Site and these Terms of Use, and any dispute or claim arising therefrom or related thereto (in each case, including non-contractual disputes or claims), shall be governed by and construed in accordance with the internal laws of the Commonwealth of Pennsylvania without giving effect to any choice or conflict of law provision or rule (whether of the Commonwealth of Pennsylvania or any other jurisdiction). Any legal suit, action or proceeding arising out of, or related to, these Terms of Use or the Site shall be instituted exclusively in the federal courts of the United States or the courts of the Commonwealth of Pennsylvania. You waive any and all objections to the exercise of jurisdiction over you by such courts and to venue in such courts.',
      },
    ],
  },
  {
    sectionTitle: 'ARBITRATION',
    content: [
      {
        type: 'paragraph',
        content:
          'At Company’s sole discretion, it may require You to submit any disputes arising from these Terms of Use or use of the Site, including disputes arising from or concerning their interpretation, violation, invalidity, non-performance, or termination, to final and binding arbitration under the Rules of Arbitration of the American Arbitration Association applying Pennsylvania law.',
      },
    ],
  },
  {
    sectionTitle: 'LIMITATION ON TIME TO FILE CLAIMS',
    content: [
      {
        type: 'paragraph',
        content:
          'ANY CAUSE OF ACTION OR CLAIM YOU MAY HAVE ARISING OUT OF OR RELATING TO THESE TERMS OF USE OR THE WEBSITE MUST BE COMMENCED WITHIN ONE (1) YEAR AFTER THE CAUSE OF ACTION ACCRUES; OTHERWISE, SUCH CAUSE OF ACTION OR CLAIM IS PERMANENTLY BARRED.',
      },
    ],
  },
  {
    sectionTitle: 'WAIVER AND SEVERABILITY',
    content: [
      {
        type: 'paragraph',
        content:
          'No waiver of by the Company of any term or condition set forth in these Terms of Use shall be deemed a further or continuing waiver of such term or condition or a waiver of any other term or condition, and any failure of the Company to assert a right or provision under these Terms of Use shall not constitute a waiver of such right or provision.<br>If any provision of these Terms of Use is held by a court or other tribunal of competent jurisdiction to be invalid, illegal or unenforceable for any reason, such provision shall be eliminated or limited to the minimum extent such that the remaining provisions of the Terms of Use will continue in full force and effect.',
      },
    ],
  },
  {
    sectionTitle: 'ENTIRE AGREEMENT',
    content: [
      {
        type: 'paragraph',
        content:
          'The Terms of Use, our Privacy Policy, Terms of Sale, and Terms of Service and Privacy Policy constitute the sole and entire agreement between you and ELEVATE PET HEALTH, LLC with respect to the Site and supersede all prior and contemporaneous understandings, agreements, representations and warranties, both written and oral, with respect to the Site.',
      },
    ],
  },
  {
    sectionTitle: 'YOUR COMMENTS AND CONCERNS',
    content: [
      {
        type: 'paragraph',
        content:
          'This website is operated by ELEVATE PET HEALTH, LLC, Cranberry Township, Pennsylvania. All other feedback, comments, requests for technical support and other communications relating to the Site should be directed to: <a href="mailto:dataofficer@elevatepethealth.com">dataofficer@elevatepethealth.com</a>',
      },
    ],
  },
];
