export interface TimeZone {
  fullName: string;
  abbreviation: string;
  utcOffset: string;
}

export const TIME_ZONES: TimeZone[] = [
  {
    fullName: 'Eastern Standard Time',
    abbreviation: 'EST',
    utcOffset: 'UTC -5',
  },
  {
    fullName: 'Central Standard Time',
    abbreviation: 'CST',
    utcOffset: 'UTC -6',
  },
  {
    fullName: 'Mountain Standard Time',
    abbreviation: 'MST',
    utcOffset: 'UTC -7',
  },
  {
    fullName: 'Pacific Standard Time',
    abbreviation: 'PST',
    utcOffset: 'UTC -8',
  },
  {
    fullName: 'Alaska Standard Time',
    abbreviation: 'AKST',
    utcOffset: 'UTC -9',
  },
  {
    fullName: 'Hawaii–Aleutian Standard Time',
    abbreviation: 'HST',
    utcOffset: 'UTC -10',
  },
];
