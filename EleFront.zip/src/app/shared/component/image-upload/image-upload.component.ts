import { ImageUploadService } from './../../service/image-upload.service';
import { Component } from '@angular/core';
import { ImageResizeService } from '../../service/image-resize.service';
import { NgIf } from '@angular/common';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

@Component({
  selector: 'app-image-upload',
  standalone: true,
  imports: [NgIf, ProgressSpinnerModule],
  templateUrl: './image-upload.component.html',
  styleUrl: './image-upload.component.scss',
})
export class ImageUploadComponent {
  previewUrl: string | ArrayBuffer | null = null;
  loader: boolean = false;

  constructor(
    private imageResizeService: ImageResizeService,
    private imageUploadService: ImageUploadService,
    private ref: DynamicDialogRef
  ) {}

  async onFileSelected(event: Event) {
    this.loader = true;
    const input = event.target as HTMLInputElement;
    if (!input.files?.length) return;

    const file = input.files[0];
    const originalFileName = file.name.split('.')[0];
    const timestamp = Date.now();

    try {
      const resized400x400 = await this.imageResizeService.resizeImage(
        file,
        400,
        400
      ); // Blob --> size , type
      const fileName400x400 = `${originalFileName}-${timestamp}.jpg`;
      const url = await this.imageUploadService.uploadFile(
        resized400x400,
        fileName400x400
      );
      this.loader = false;
      this.previewUrl = url;
    } catch (error) {
      this.loader = false;
      console.error('Error resizing image:', error);
    }
  }

  saveUrl() {
    this.ref.close(this.previewUrl);
  }
  cancelUrl() {
    this.ref.close();
  }
}
