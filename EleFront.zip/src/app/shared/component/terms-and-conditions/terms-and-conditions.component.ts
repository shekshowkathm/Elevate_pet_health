import { Component, inject, signal } from '@angular/core';
import { DynamicDialogRef, DynamicDialogConfig } from 'primeng/dynamicdialog';
import { TermsContent } from '../../model/terms-content';
import { TERMS_OF_USE } from '../../constants/terms';

@Component({
  selector: 'app-terms-and-conditions',
  standalone: true,
  imports: [],
  templateUrl: './terms-and-conditions.component.html',
  styleUrl: './terms-and-conditions.component.scss',
})
export class TermsAndConditionsComponent {
  readonly ref = inject(DynamicDialogRef);
  readonly config = inject(DynamicDialogConfig);

  termsContent = signal<TermsContent[]>(TERMS_OF_USE);
  onAcceptTermsAndConditions() {
    this.ref.close(true);
  }
  onNoClick() {
    this.ref.close(false);
  }
}
