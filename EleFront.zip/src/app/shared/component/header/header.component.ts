import { isPlatformBrowser, NgClass, NgFor, NgIf } from '@angular/common';
import { Component, Inject, PLATFORM_ID, ElementRef, Renderer2, HostListener, OnDestroy } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { SharedService } from '../../service/shared.service';
import { PetOwnerService } from '../../../pet-owner/service/pet-owner.service'
import { UserProfile } from '../../../pet-owner/model/pet-owner';
import { MenubarModule } from 'primeng/menubar';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { BadgeModule } from 'primeng/badge';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { DialogModule } from 'primeng/dialog';
import { Subscription } from 'rxjs';


interface NavLinks {
  title: string;
  link: string;
  clickHandler?: () => void;
}

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [NgClass, RouterLink, NgIf, MenubarModule, ConfirmDialogModule, BadgeModule, DialogModule, DynamicDialogModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
  providers: [ConfirmationService]
})
export class HeaderComponent {
  isMenuhidden: boolean = true;
  isLaptopView: boolean = true;
  logoutDialogVisible: boolean = false;
  private isBrowser: boolean;
  role: string | null = null;
  profileMenuVisible: boolean = false;
  userProfile!: UserProfile;
  regId: string | null = null;

  private documentClickListener: () => void;

  notificationCount: number = 0;


  private refreshSubscription!: Subscription;


  constructor(private sharedservice: SharedService, private router: Router, private PetOwnerService: PetOwnerService, @Inject(PLATFORM_ID) private platformId: Object, private renderer: Renderer2, private elementRef: ElementRef, private confirmationService: ConfirmationService,) {
    this.documentClickListener = this.renderer.listen('document', 'click', (event: Event) => {
      this.onDocumentClick(event);
    });
    if (isPlatformBrowser(this.platformId)) {
      this.checkScreenWidth();
    }

    this.isBrowser = isPlatformBrowser(this.platformId);
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: Event): void {
    if (isPlatformBrowser(this.platformId)) {
      this.checkScreenWidth();
    }
  }

  private checkScreenWidth(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.isLaptopView = window.innerWidth >= 1024;
    }
  }


  ngOnInit(): void {
    const roleFromStorage = this.sharedservice.getItem('role');
    this.role = roleFromStorage ? roleFromStorage.trim() : null;
    const registerId = this.sharedservice.getId('id');
    this.regId = registerId ? registerId.trim() : null;
    this.updateNavigationLinks();
    this.getUserProfile();

    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      const registerId = this.sharedservice.getId('id');
      if (this.role === 'PET_OWNER') {
        this.getGetNotificationsForPlans();
      }
    }

    this.refreshSubscription = this.PetOwnerService.refresh$.subscribe(() => {
      this.refreshHeader();
    });

    this.PetOwnerService.profileUpdated.subscribe(() => {
      this.refreshHeaderForProfile()
    });
  }


  navigationLinks: NavLinks[] = [];
  updateNavigationLinks(): void {
    switch (this.role) {
      case 'PET_OWNER':
        this.navigationLinks = [
          { title: 'Home', link: '/petOwners/pet-owner-home' },
          { title: 'About Us', link: '/petOwners/aboutUs' },
          { title: 'Why Wellness', link: '/petOwners/why-wellness' },
          { title: 'My Pet', link: '/petOwners/pet-owher-navhar-layout' },
          { title: 'FAQs', link: '/petOwners/faq' },
        ];
        this.getPetOwnerProfile();
        break;
      default:
        this.setDefaultNavigationLinks();
        break;
    }
  }
  private setDefaultNavigationLinks(): void {
    this.navigationLinks = [
      { title: 'Home', link: '' },
      { title: 'About Us', link: '/about' },
      { title: 'Why Wellness', link: '/why-wellness' },
      { title: 'FAQs', link: '/faq' },
      { title: 'Sign In', link: '/login' }
    ];
  }
  showMenu() {
    this.isMenuhidden = !this.isMenuhidden;
  }

  routeToHomePage() {
    if (this.role === "PET_OWNER") {
      this.router.navigate(['/petOwners/pet-owner-home'])

    } else {
      this.router.navigate([''])
    }
  }

  // confirmLogout() {
  //   this.confirmationService.confirm({
  //     message: 'Are you sure you want to log out?',
  //     header: 'Confirmation',
  //     icon: 'pi pi-exclamation-triangle',
  //     acceptLabel: 'Yes',
  //     rejectLabel: 'No',
  //     acceptButtonStyleClass: 'custom-accept-button',
  //     rejectButtonStyleClass: 'custom-reject-button',
  //     accept: () => {
  //       // Logic to execute on confirmation
  //       this.logout();
  //     },
  //     reject: () => {
  //       // Optional: Logic to execute on rejection
  //       console.log('Logout canceled');
  //     },
  //   });
  // }


  showLogoutDialog() {
    this.logoutDialogVisible = true;
  }
  // Ensure localStorage.clear() runs only in the browser
  confirmLogout() {
    if (this.isBrowser) {
      localStorage.clear();
    }
    this.router.navigate(['']);
    this.logoutDialogVisible = false;
  }


  getGetNotificationsForPlans() {
    this.PetOwnerService.getNotificationForPetOwners(this.regId).subscribe({
      next: (value) => {
        console.log(value);
        this.notificationCount = value.TotalNotifications

      }, error: (err) => {
        console.log(err);
      }
    })
  }


  logout() {
    localStorage.clear();
    this.updateNavigationLinks();
    this.router.navigate([''])
  }

  toggleProfileMenu(): void {
    this.profileMenuVisible = !this.profileMenuVisible;
  }

  navigateToNotifications() {
    this.router.navigate(['/petOwners/pet-owher-navhar-layout/notifications']);

  }

  navigateTo(path: string): void {
    this.router.navigate([path]);
    this.profileMenuVisible = false;
  }

  openUpdatePassword() {
    console.log("Open update password pop up");

    this.PetOwnerService.pDialogOpenUpdatePassword();
  }

  getUserProfile() {
    if (isPlatformBrowser(this.platformId)) {
      const userRole = localStorage.getItem('role');
      const registerId = this.regId;
      if (registerId && userRole === 'localStorage role') {
        this.PetOwnerService.getUserFromProfile(registerId).subscribe({
          next: (response: UserProfile) => {
            this.userProfile = response;
            console.log('User profile data:', this.userProfile);
          },
          error: (error) => {
            console.error('Error fetching user profile:', error);
          }
        });
      }
    } else {
      console.log('Local storage is not available on the server side.');
    }
  }

  openClinicAddPet() {
    setTimeout(() => {
      this.PetOwnerService.pDialogOpenClinicDetails();
    }, 300);
    this.profileMenuVisible = false;
    this.router.navigate(['/petOwners/pet-owher-navhar-layout/clinic-details-popup']);
  }

  getPetOwnerProfile() {
    if (isPlatformBrowser(this.platformId)) {
      const regId = localStorage.getItem('id') || null;
      if (regId) {
        this.PetOwnerService.getUserFromProfile(regId).subscribe({
          next: (response: UserProfile) => {
            console.log("pet owner profile ready");

            this.userProfile = response

          },
          error: (error) => {
            console.error('Error fetching user profile:', error);
          }
        });
      }
    }
  }


  onDocumentClick(event: Event) {
    // Check if the click is outside the component
    const clickedInside = this.elementRef.nativeElement.contains(event.target);
    if (!clickedInside) {
      this.profileMenuVisible = false;
    }
  }


  refreshHeader() {
    // Logic to refresh header data
    console.log('Header refreshed');
    if (isPlatformBrowser(this.platformId) && typeof window !== 'undefined') {
      const registerId = this.sharedservice.getId('id');
      if (this.role === 'PET_OWNER') {
        this.getGetNotificationsForPlans();
      }
    }
  }

  refreshHeaderForProfile() {
    console.log("is updated for profile");
    this.getUserProfile()
    this.getPetOwnerProfile()
  }

  ngOnDestroy() {
    // Remove event listener when component is destroyed
    if (this.documentClickListener) {
      this.documentClickListener();
    }

    if (this.refreshSubscription) {
      this.refreshSubscription.unsubscribe();
    }
  }
}
