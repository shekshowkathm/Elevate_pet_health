import { ViewportScroller } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.scss'
})
export class FooterComponent {

  constructor(private router : Router , private scrollToTop : ViewportScroller){}

    routeToHome(){
      const role = localStorage.getItem('role');
      if(role==='SUPER_ADMIN' || role === 'SALES_REP'){
          this.router.navigate(['']).then(() => {
            this.scrollToTop.scrollToPosition([0,0])
          })
      }else if(role === 'PET_OWNER'){
        this.router.navigate(['/petOwners/pet-owner-home']).then(() => {
          this.scrollToTop.scrollToPosition([0,0])
        })
      }else {
        this.router.navigate(['']).then(() => {
          this.scrollToTop.scrollToPosition([0,0])
        })
      }
    }

    routeToAbout(){
      const role = localStorage.getItem('role');
      if(role==='SUPER_ADMIN' || role === 'SALES_REP'){
          this.router.navigate(['/about']).then(() => {
            this.scrollToTop.scrollToPosition([0,0])
          })
      }else if(role === 'PET_OWNER'){
        this.router.navigate(['/petOwners/aboutUs']).then(() => {
          this.scrollToTop.scrollToPosition([0,0])
        })
      }else {
        this.router.navigate(['/about']).then(() => {
          this.scrollToTop.scrollToPosition([0,0])
        })
      }
    }

    routeToWhyWellness(){
      const role = localStorage.getItem('role');
      if(role==='SUPER_ADMIN' || role === 'SALES_REP'){
          this.router.navigate(['/why-wellness']).then(() => {
            this.scrollToTop.scrollToPosition([0,0])
          })
      }else if(role === 'PET_OWNER'){
        this.router.navigate(['/petOwners/why-wellness']).then(() => {
          this.scrollToTop.scrollToPosition([0,0])
        })
      }else {
        this.router.navigate(['/why-wellness']).then(() => {
          this.scrollToTop.scrollToPosition([0,0])
        })
      }
    }

    routeToFAQ(){
      const role = localStorage.getItem('role');
      if(role==='SUPER_ADMIN' || role === 'SALES_REP'){
          this.router.navigate(['/faq']).then(() => {
            this.scrollToTop.scrollToPosition([0,0])
          })
      }else if(role === 'PET_OWNER'){
        this.router.navigate(['/petOwners/faq']).then(() => {
          this.scrollToTop.scrollToPosition([0,0])
        })
      }else {
        this.router.navigate(['/faq']).then(() => {
          this.scrollToTop.scrollToPosition([0,0])
        })
      }
    }

    routeToContact(){
      const role = localStorage.getItem('role');
      if(role==='SUPER_ADMIN' || role === 'SALES_REP'){
          this.router.navigate(['/faq']).then(() => {
            this.scrollToTop.scrollToPosition([0,0])
          })
      }else if(role === 'PET_OWNER'){
        this.router.navigate(['/petOwners/faq']).then(() => {
          this.scrollToTop.scrollToPosition([0,0])
        })
      }else {
        this.router.navigate(['/faq']).then(() => {
          this.scrollToTop.scrollToPosition([0,0])
        })
      }
    }
}
