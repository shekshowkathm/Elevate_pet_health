import { Component, OnInit } from '@angular/core';
import { S3Client, PutObjectCommand, ObjectCannedACL } from '@aws-sdk/client-s3';
import { environment } from '../../../../environments/environment.development';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-image-uploader',
  imports:[NgIf],
  standalone: true,
  templateUrl: './image-uploader.component.html',
  styleUrls: ['./image-uploader.component.scss']
})
export class ImageUploaderComponent implements OnInit {
  copyToClipboard(inputElement: HTMLInputElement) {
    inputElement.select();
    document.execCommand('copy');
  }
  selectedFile: File | null= null;
  uploadUrl: string = '';
  selectedFileUrl: string | null = null; // for image preview

  s3Client = new S3Client({
    region: environment.AWS_REGION,
    credentials: {
      accessKeyId: environment.AWS_ACCESS_KEY,
      secretAccessKey: environment.AWS_SECRET_KEY
    }
  });

  constructor() {}

  ngOnInit(): void {
  }

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];

    // Create a URL object from the selected file for preview
    if (this.selectedFile) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.selectedFileUrl = e.target.result;
      };
      reader.readAsDataURL(this.selectedFile);
    }
  }

  async uploadFile() {
    if (this.selectedFile) {
      const contentType = this.selectedFile.type; // Get the file's content type
      const mediaFolder = 'media/'; // Replace with your desired folder name
      const params = {
        Bucket: 'elevatepethealth-imagestorage', // Replace with your bucket name
        Key: `${mediaFolder}${this.selectedFile.name}`, // Include folder path in the Key
        Body: this.selectedFile,
        ContentType: contentType ,
        ContentDisposition:"inline",
        ACL: 'public-read' as ObjectCannedACL // Set public access for the uploaded file
      };

      try {
        const command = new PutObjectCommand(params);
        const data = await this.s3Client.send(command);
       this.uploadUrl = `https://${params.Bucket}.s3.${environment.AWS_REGION}.amazonaws.com/${params.Key}`;
        console.log('Upload successful:', this.uploadUrl);
      } catch (err) {
        console.error('Upload error:', err);
      }
    }
  }
}
