import { Router } from '@angular/router';
import { Component, inject } from '@angular/core';
import { ClinicAuthService } from '../../../clinic/services/clinic-auth.service';

@Component({
  selector: 'app-access-denied',
  standalone: true,
  imports: [],
  templateUrl: './access-denied.component.html',
  styleUrl: './access-denied.component.scss',
})
export class AccessDeniedComponent {
  private router = inject(Router);
  goBack() {
    this.router.navigate(['']);
  }
}
