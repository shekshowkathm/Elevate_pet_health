import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, inject, OnInit, PLATFORM_ID } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StripeService } from '../../../clinic/services/stripe.service';

@Component({
  selector: 'app-stirpe-connect',
  standalone: true,
  imports: [],
  templateUrl: './stirpe-connect.component.html',
  styleUrl: './stirpe-connect.component.scss',
})
export class StirpeConnectComponent implements OnInit {
  router = inject(Router);
  activedRoute = inject(ActivatedRoute);
  platformId = inject(PLATFORM_ID);
  constructor(  private stirpeService : StripeService) {}
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      const accountIdFromRoute = this.activedRoute.params.subscribe(
        (doc: any) => {
          let accountId = doc.accountId
   
          
          // const stripeUrl = `https://connect.stripe.com/refresh/${doc.accountId}`;
          // window.location.href = stripeUrl;
          this.stirpeService.refreshAccountLink(accountId).subscribe((newAccountLink:any)=>{
            window.location.href = newAccountLink;
            
            
          })
        },
      );
    }
  }
}
