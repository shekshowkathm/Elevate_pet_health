import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StirpeConnectComponent } from './stirpe-connect.component';

describe('StirpeConnectComponent', () => {
  let component: StirpeConnectComponent;
  let fixture: ComponentFixture<StirpeConnectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StirpeConnectComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StirpeConnectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
