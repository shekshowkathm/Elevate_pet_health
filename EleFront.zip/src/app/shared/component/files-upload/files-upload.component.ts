import { Component, HostListener, OnInit } from '@angular/core';
import { FileUploadService } from '../../service/file-upload.service';
import { DatePipe, NgClass, NgFor } from '@angular/common';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { UploadedFileDetail } from '../../model/upload-file-detail';
import { FileSizePipe } from '../../pipes/file-size.pipe';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

@Component({
  selector: 'app-files-upload',
  templateUrl: './files-upload.component.html',
  styleUrls: ['./files-upload.component.scss'],
  standalone: true,
  imports: [FileSizePipe, NgClass, ProgressSpinnerModule],
})
export class FilesUploadComponent {
  uploadedFiles: UploadedFileDetail[] = [];
  isDragOver: boolean = false;
  loader: boolean = false;

  selectedFiles: File[] = [];

  constructor(
    private fileUploadService: FileUploadService,
    public ref: DynamicDialogRef,
  ) {}

  handleDrop(event: DragEvent) {
    event.preventDefault();
    this.isDragOver = false;
    const files = event.dataTransfer?.files;
    if (files) {
      this.handleFileUploadByDrag(files);
    }
  }

  @HostListener('dragover', ['$event'])
  onDragOver(event: DragEvent) {
    event.preventDefault();
    this.isDragOver = true;
  }

  @HostListener('dragleave', ['$event'])
  onDragLeave(event: DragEvent) {
    event.preventDefault();
    this.isDragOver = false;
  }

  handleFileUpload(event: any) {
    const files = event.target.files;
    this.selectedFiles = Array.from(files);
  }
  handleFileUploadByDrag(files: FileList) {
    this.selectedFiles = Array.from(files);
  }

  async uploadFiles() {
    this.loader = true;
    const filteredFiles = this.selectedFiles.filter(
      (f) => f.size <= 15 * 1024 * 1024,
    );
    this.uploadedFiles =
      await this.fileUploadService.uploadMultipleFilesPublic(filteredFiles);
    this.loader = false;
    this.ref.close(this.uploadedFiles);
  }

  closeDialog() {
    this.ref.close();
  }
}
