import { CommonModule } from "@angular/common";
import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { MatDialogModule } from "@angular/material/dialog";
import { MatButtonModule } from "@angular/material/button";
import { MatIconModule } from "@angular/material/icon"; // If you're using icons
import { MatFormFieldModule } from "@angular/material/form-field"; // Optional, for form fields
import { MatInputModule } from "@angular/material/input";

@Component({
  selector: "app-status-toggle",
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule
  ],
  templateUrl: "./status-toggle.component.html",
  styleUrl: "./status-toggle.component.scss"
})
export class StatusToggleComponent implements OnInit {
  constructor(
    private dialogRef: MatDialogRef<StatusToggleComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.data = data;  
  }

  ngOnInit(): void {}

  confirm(): void {
    this.dialogRef.close(1);
  }
  cancel(): void {
    this.dialogRef.close(0);
  }
}
