export interface UploadedFileDetail {
  name: string;
  url: string;
  fileType: string;
  uploadDate: string;
  size: number;
}