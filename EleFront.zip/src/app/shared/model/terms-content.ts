export interface SectionContent {
  type: 'heading' | 'paragraph' | 'list' | 'note';
  content?: string;
  style?: string;
  listType?: 'unordered' | 'ordered';
  items?: string[];
}

export interface TermsContent {
  sectionTitle: string;
  content: SectionContent[];
}
