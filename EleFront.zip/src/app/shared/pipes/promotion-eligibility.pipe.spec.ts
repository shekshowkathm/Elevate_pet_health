import { PromotionEligibilityPipe } from './promotion-eligibility.pipe';

describe('PromotionEligibilityPipe', () => {
  let pipe: PromotionEligibilityPipe;

  beforeEach(() => {
    pipe = new PromotionEligibilityPipe();
  });

  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('should format a single string promotion correctly', () => {
    const input = ['30-60-90 Days'];
    const result = pipe.transform(input);
    expect(result).toBe(
      "The '30-60-90 Days' promotion has been activated for this plan.",
    );
  });

  it('should format multiple string promotions correctly', () => {
    const input = ['30-60-90 Days', 'Multi-Pet'];
    const result = pipe.transform(input);
    expect(result).toBe(
      "The '30-60-90 Days' and 'Multi-Pet' promotions have been activated for this plan.",
    );
  });

  it('should format string promotions with commas for three or more names', () => {
    const input = ['30-60-90 Days', 'Multi-Pet', 'Elevate633'];
    const result = pipe.transform(input);
    expect(result).toBe(
      "The '30-60-90 Days', 'Multi-Pet' and 'Elevate633' promotions have been activated for this plan.",
    );
  });

  it('should format a single promotion object correctly', () => {
    const input = [{ id: 1, name: '30-60-90 Days', status: true }];
    const result = pipe.transform(input);
    expect(result).toBe(
      "The '30-60-90 Days' promotion has been activated for this plan.",
    );
  });

  it('should format multiple promotion objects correctly', () => {
    const input = [
      { id: 1, name: '30-60-90 Days', status: true },
      { id: 2, name: 'Multi-Pet', status: true },
    ];
    const result = pipe.transform(input);
    expect(result).toBe(
      "The '30-60-90 Days' and 'Multi-Pet' promotions have been activated for this plan.",
    );
  });

  it('should return a message for no active promotions from objects', () => {
    const input = [
      { id: 1, name: '30-60-90 Days', status: false },
      { id: 2, name: 'Multi-Pet', status: false },
    ];
    const result = pipe.transform(input);
    expect(result).toBe('No promotions have been activated for this plan.');
  });

  it('should return a message for no promotions from an empty array', () => {
    const input: any[] = [];
    const result = pipe.transform(input);
    expect(result).toBe('No promotions have been activated for this plan.');
  });

  it('should return invalid input message for incorrect input type', () => {
    const input = null as any;
    const result = pipe.transform(input);
    expect(result).toBe('Invalid input.');
  });
});
