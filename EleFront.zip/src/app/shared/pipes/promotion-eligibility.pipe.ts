import { Pipe, PipeTransform } from '@angular/core';
import { PromotionWithAvailabityStatus } from '../../clinic/models/wellness-plan-response';

@Pipe({
  name: 'promotionEligibility',
  standalone: true,
})
export class PromotionEligibilityPipe implements PipeTransform {
  transform(input: PromotionWithAvailabityStatus[] | string[]): string {
    let eligibleNames: string[];

    if (Array.isArray(input) && typeof input[0] === 'string') {
      eligibleNames = input as string[];
    } else if (Array.isArray(input) && typeof input[0] === 'object') {
      eligibleNames = (input as PromotionWithAvailabityStatus[])
        .filter((obj) => obj.status)
        .map((obj) => obj.name);
    } else {
      return 'Invalid input.';
    }

    if (eligibleNames.length === 0) {
      return 'No promotions have been activated for this plan.';
    }
    if (eligibleNames.length === 1) {
      return `The '${eligibleNames[0]}' promotion has been activated for this plan.`;
    }

    const allButLast = eligibleNames
      .slice(0, -1)
      .map((name) => `'${name}'`)
      .join(', ');
    const last = `'${eligibleNames[eligibleNames.length - 1]}'`;
    return `The ${allButLast} and ${last} promotions have been activated for this plan.`;
  }
}
