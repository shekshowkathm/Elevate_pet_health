import { Injectable } from '@angular/core';
import Pica from 'pica';
@Injectable({
  providedIn: 'root',
})
export class ImageResizeService {
  private pica = new Pica();

  constructor() {}
  async resizeImage(file: File, width: number, height: number): Promise<Blob> {
    const img = document.createElement('img');
    img.src = URL.createObjectURL(file);

    return new Promise((resolve, reject) => {
      img.onload = async () => {
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        try {
          await this.pica.resize(img, canvas);
          const resizedBlob = await this.pica.toBlob(canvas, 'image/jpeg', 0.9);
          resolve(resizedBlob);
        } catch (error) {
          reject(error);
        }
      };
    });
  }
}
