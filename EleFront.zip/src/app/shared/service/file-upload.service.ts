import { Injectable } from '@angular/core';
import { Observable, from } from 'rxjs';
import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  ObjectCannedACL,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { environment } from '../../../environments/environment.development';
import { UploadedFileDetail } from '../model/upload-file-detail';

@Injectable({
  providedIn: 'root',
})
export class FileUploadService {
  private s3Client: S3Client;
  constructor() {
    this.s3Client = new S3Client({
      region: environment.AWS_REGION,
      credentials: {
        accessKeyId: environment.AWS_ACCESS_KEY,
        secretAccessKey: environment.AWS_SECRET_KEY,
      },
    });
  }

  async uploadFile(file: File) {
    const params = {
      Bucket: 'elevatepethealth-imagestorage',
      Key: `files/${file.name}`,
      Body: file,
      ACL: ObjectCannedACL.public_read,
      ContentType: file.type,
    };

    const command = new PutObjectCommand(params);
    const data = await this.s3Client.send(command);
    const uploadUrl = `https://${params.Bucket}.s3.${environment.AWS_REGION}.amazonaws.com/${params.Key}`;
    console.log('Upload successful:', uploadUrl);
    return uploadUrl;
  }

  /**
   * Upload a single file publicly (public-read).
   * @param file File to be uploaded
   */
  async uploadFilePublic(file: File): Promise<string> {
    const params = {
      Bucket: 'elevatepethealth-imagestorage',
      Key: `files/${file.name}`,
      Body: file,
      ACL: ObjectCannedACL.public_read,
      ContentType: file.type,
    };

    const command = new PutObjectCommand(params);
    try {
      await this.s3Client.send(command);
      const uploadUrl = `https://${params.Bucket}.s3.${environment.AWS_REGION}.amazonaws.com/${params.Key}`;
      console.log('Public upload successful:', uploadUrl);
      return uploadUrl;
    } catch (error) {
      console.error('Error uploading public file:', error);
      throw error;
    }
  }

  /**
   * Upload a single file privately (private ACL).
   * @param file File to be uploaded
   */
  async uploadFilePrivate(file: File): Promise<string> {
    const params = {
      Bucket: 'elevatepethealth-imagestorage',
      Key: `files/${file.name}`,
      Body: file,
      ACL: ObjectCannedACL.private,
      ContentType: file.type,
    };

    const command = new PutObjectCommand(params);
    try {
      await this.s3Client.send(command);
      const uploadUrl = `https://${params.Bucket}.s3.${environment.AWS_REGION}.amazonaws.com/${params.Key}`;
      console.log('Private upload successful:', uploadUrl);
      return uploadUrl;
    } catch (error) {
      console.error('Error uploading private file:', error);
      throw error;
    }
  }

  /**
   * Generate a presigned URL to access a private file.
   * @param fileName The file name (or key) stored in S3
   */
  async generatePresignedUrl(fileName: string): Promise<string> {
    const params = {
      Bucket: 'elevatepethealth-imagestorage',
      Key: `files/${fileName}`,
      Expires: 3600,
    };

    try {
      const command = new GetObjectCommand(params);
      const url = await getSignedUrl(this.s3Client, command, {
        expiresIn: 3600,
      });
      console.log('Generated presigned URL:', url);
      return url;
    } catch (error) {
      console.error('Error generating presigned URL:', error);
      throw error;
    }
  }

  /**
   * Upload multiple files publicly.
   * @param files Array of files to be uploaded
   */
  async uploadMultipleFilesPublic(
    files: File[]
  ): Promise<UploadedFileDetail[]> {
    const uploadedFileDetails: UploadedFileDetail[] = [];
    for (const file of files) {
      const url = await this.uploadFilePublic(file);
      const fileDetails: UploadedFileDetail = {
        name: file.name,
        size: file.size,
        url: url,
        fileType: file.type,
        uploadDate: new Date().toISOString(),
      };

      uploadedFileDetails.push(fileDetails);
    }

    return uploadedFileDetails;
  }

  /**
   * Upload multiple files privately.
   * @param files Array of files to be uploaded
   */
  async uploadMultipleFilesPrivate(
    files: File[]
  ): Promise<UploadedFileDetail[]> {
    const uploadedFileDetails: UploadedFileDetail[] = [];

    for (const file of files) {
      const url = await this.uploadFilePrivate(file);
      const fileDetails: UploadedFileDetail = {
        name: file.name,
        size: file.size,
        url: url,
        fileType: file.type,
        uploadDate: new Date().toISOString(),
      };

      uploadedFileDetails.push(fileDetails);
    }

    return uploadedFileDetails;
  }

  /**
   * Generate a presigned URL to access a private file.
   * @param fileName The file name (or key) stored in S3
   */
  getPresignedUrl(key: string): Observable<string> {
    const params = {
      Bucket: 'elevatepethealth-imagestorage',
      Key: `files/${key}`,
    };

    const command = new GetObjectCommand(params);
    return from(getSignedUrl(this.s3Client, command, { expiresIn: 3600 }));
  }
}
