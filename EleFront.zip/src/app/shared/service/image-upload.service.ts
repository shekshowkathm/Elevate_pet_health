import { Injectable } from '@angular/core';
import {
  S3Client,
  PutObjectCommand,
  ObjectCannedACL,
} from '@aws-sdk/client-s3';
import { environment } from '../../../environments/environment.development';
@Injectable({
  providedIn: 'root',
})
export class ImageUploadService {
  s3Client = new S3Client({
    region: environment.AWS_REGION,
    credentials: {
      accessKeyId: environment.AWS_ACCESS_KEY,
      secretAccessKey: environment.AWS_SECRET_KEY,
    },
  });

  constructor() {}

  async uploadFile(file: Blob, fileName: string): Promise<string> {
    const contentType = file.type;
    const mediaFolder = 'media/';
    const params = {
      Bucket: 'elevatepethealth-imagestorage', // Replace with your bucket name
      Key: `${mediaFolder}${fileName}`, // Include folder path in the Key
      Body: file,
      ContentType: contentType,
      ContentDisposition: 'inline',
      ACL: 'public-read' as ObjectCannedACL, //
    };

    try {
      const command = new PutObjectCommand(params);
      const data = await this.s3Client.send(command);
      const uploadUrl = `https://${params.Bucket}.s3.${environment.AWS_REGION}.amazonaws.com/${params.Key}`;
      console.log('Upload successful:', uploadUrl);
      return uploadUrl;
    } catch (error) {
      console.error('Upload error:', error);
      throw error;
    }
  }
}
