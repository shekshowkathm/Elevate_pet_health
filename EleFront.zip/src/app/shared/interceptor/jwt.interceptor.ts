import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { jwtDecode } from 'jwt-decode';
import { ClinicAuthService } from '../../clinic/services/clinic-auth.service';
import { Router } from '@angular/router';
import { EMPTY } from 'rxjs';

export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const clinicAuthService = inject(ClinicAuthService);
  const router = inject(Router);
  const token = clinicAuthService.getToken();
  if (token) {
    if (isTokenExpired(token)) {
      clinicAuthService.logout();
      router.navigate(['/login']);
      return EMPTY;
    } else {
      const clonedRequest = req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`,
        },
      });
      return next(clonedRequest);
    }
  }
  return next(req);
};

function isTokenExpired(token: string): boolean {
  try {
    const decoded: any = jwtDecode(token);
    const currentTime = Math.floor(Date.now() / 1000);
    return decoded.exp && currentTime >= decoded.exp;
  } catch (error) {
    console.error('Error decoding token', error);
    return true;
  }
}
