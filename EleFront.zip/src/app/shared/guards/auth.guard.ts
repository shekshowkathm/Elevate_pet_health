import { inject, PLATFORM_ID } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { ClinicAuthService } from '../../clinic/services/clinic-auth.service';
import { Roles } from '../enum/roles';
import { isPlatformBrowser } from '@angular/common';

export const authGuard: CanActivateFn = (route, state) => {
  const clinicAuthService = inject(ClinicAuthService);
  const router = inject(Router);
  const platformId = inject(PLATFORM_ID);

  if (isPlatformBrowser(platformId)) {
    const expectedRoles: Roles[] = route.data['roles'];

    const userRole = clinicAuthService.getRole() as Roles;

    const accountIdFromRoute = route.params['accountId'];

    if (expectedRoles && expectedRoles.includes(userRole)) {
      return true;
    } else if (accountIdFromRoute) {
      const stripeUrl = `https://connect.stripe.com/refresh/${accountIdFromRoute}`;
      window.location.href = stripeUrl;
      return false;
    } else {
      router.navigate(['/access-denied']);
      return false;
    }
  }

  return false;
};
