/** @type {import('tailwindcss').Config} */
module.exports = {
  // corePlugins: {
  //   preflight: false,
  // },
  content: ["./src/**/*.{html,ts}"],
  theme: {
    extend: {
      animation: {
        shake: "shake 3s infinite",
        fadeIn: 'fadeIn 4s ease-in-out infinite',
        slideInBottom: 'slideInBottom 5s ease-out forwards',
      },
      keyframes: {
        shake: {
          "0%, 100%": { transform: "translateX(0)" },
          "10%, 30%, 50%, 70%, 90%": { transform: "translateX(-4px)" },
          "20%, 40%, 60%, 80%": { transform: "translateX(4px)" },
        },
        fadeIn: {
          '0%': {
            opacity: 0,
          },
          '100%': {
            opacity: 1,
          },
        },
        slideInBottom: {
          '0%': { transform: 'translateY(100%)', opacity: 0 },
          '100%': { transform: 'translateY(0)', opacity: 1 },
        }
      },
      backgroundImage: {
        whywellness: "url('https://elevatepethealth-imagestorage.s3.us-east-1.amazonaws.com/media/hero0.png')",
        background:"url('/assets/dogBG.jpg')"
      },
      colors: {
        primary: '#009DFF',
        elevatesalesrepD: '#FFE9D0',
        totalclinicD: '#FFFED3',
        petownerD: '#BBE9FF',
        creditcardissueD: '#FFC7B6',
        todaypaymentD: '#B1AFFF',
        wellnessplanD: '#E7D4B5',
        reminderblueD: '#009DFF',
        reminderyellowD: '#FFDE4D',
      },
      fontFamily: {
        oswald: ['Oswald', 'sans-serif'],
      },
      height: {
        'custom-md': '512px',
        'custom-lg': '400px',
        'custom-xl': '350px',
      },
    },
  },
  plugins: [],
};
