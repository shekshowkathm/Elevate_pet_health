<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <style>
        .mail {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            font-family: Arial, sans-serif;
        }

        .mail-content {
            padding: 20px;
        }

        h1 {
            color: #333;
            font-size: 24px;
        }

        p {
            color: #555;
            font-size: 16px;
            line-height: 1.6;
        }

        .details {
            color: #333;
            font-size: 18px;
            margin: 10px 0;
        }

        .activate-button {
            display: inline-block;
            background-color: #007bd9;
            color: white;
            padding: 15px 30px;
            font-size: 18px;
            border-radius: 5px;
            text-align: center;
            margin: 20px auto;
            text-decoration: none;
        }

        .activate-button:hover {
            background-color: #005fa3;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            min-height: 100px;
        }
        .regards {
            margin-top: 30px;
            font-style: italic;
        }
    </style>
</head>

<body>
<div class="mail">
    <div class="mail-content"> 
   <strong>Hello ${name},</strong>
        <p>We’re thrilled to have you join <strong>Elevate Pet Health!</strong> To get started, please activate your Stripe account by clicking the button below:</p>
       <div class="container">
           <a href="${activationLink}" class="activate-button">Activate Your Account</a>
       </div>
        <p>If you didn’t request this account, you can safely ignore this email.</p>
        <p>We look forward to supporting you on your journey to providing excellent care for pets.</p>
        <p class="regards">Warm regards,</p>
        <strong>The Elevate Pet Health Team</strong>
    </div>
</div>
</body>
</html>
