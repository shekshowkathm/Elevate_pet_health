<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <style>
      .mail {
        width: 80%;
        margin: 20px auto;
        padding: 20px;
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        font-family: Arial, sans-serif;
      }

      .mail-content {
        padding: 20px;
      }

      h1 {
        color: #333;
        font-size: 24px;
      }

      p {
        color: #555;
        font-size: 16px;
        line-height: 1.6;
      }

      .details {
        color: #333;
        font-size: 18px;
        margin: 10px 0;
      }

      button {
        background-color: #007bd9;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        text-align: center;
      }

      button a {
        color: white;
        text-decoration: none;
      }

      .regards {
        margin-top: 30px;
        font-style: italic;
      }
    </style>
  </head>

  <body>
    <div class="mail">
      <div class="mail-content">
        <div>
          <h1>Hello Super Admin</h1>
          <p>
            We have received a new clinic registration request on our platform.
            Please find the details of the clinic below:
          </p>
          <h3 class="details">Requested By: </h3>
          <h3 class="details">Contact Email: ${email}</h3>
          <h3 class="details">Clinic Address: ${clinicAddress}</h3>
          <h3 class="details">City: ${city} </h3>
          <h3 class="details">Clinic Zip Code: ${zipCode} </h3>
        
          <p>
            Kindly review this request at your earliest convenience and proceed
            with the necessary actions to approve or deny the registration.
          </p>
          <button><a href="https://demo.elevatepethealth.com/login">Login</a></button>
          <p class="regards">Warm regards,</p>
          <p>The Elevate Pet Health Team</p>
        </div>
      </div>
    </div>
  </body>
</html>
