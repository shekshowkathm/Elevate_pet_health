<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333333;
            margin: 0;
            padding: 0;
        }
        .email-container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #ffffff;
            border: 1px solid #dddddd;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .email-header {
            background-color: #D2E0FB; 
            color: #1e90ff;
            padding: 20px;
            text-align: center;
            font-size: 24px;
        }
        .email-body {
            padding: 20px;
        }
        .email-body h2 {
            color: #1e90ff; /* Blue */
        }
        .appointment-details {
            margin: 20px 0;
            padding: 25px;
            background-color: #e0f7fa; /* Light Sky Blue */
            border-radius: 8px;
        }
        .appointment-details p {
            margin: 5px 0;
            font-size: 14px;
        }
        .email-footer {
            background-color: #f1f1f1;
            color: #666666;
            text-align: center;
            padding: 10px;
            font-size: 12px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 20px 0;
            background-color: #1e90ff; /* Blue */
            color: #ffffff;
            text-decoration: none;
            border-radius: 5px;
        }
        .btn:hover {
            background-color: #4682b4; /* Darker Blue */
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="email-header">
            <strong>🐾 Wellness Appointment Confirmed! 🐾</strong>
        </div>
        <div class="email-body">
            <h2>Hello ${petOwnerName},</h2>
            <p>We're excited to let you know that an appointment for your pet, <strong>${petName}</strong>, has been scheduled! Here are the details:</p>
            <div class="appointment-details">
                <p><strong>📅 Date & Time:</strong> ${scheduledDateTime}</p>
                <p><strong>🏢 Clinic Name:</strong> ${clinicName}</p>
                <p><strong>📍 Location:</strong> ${clinicAddress}</p>
            </div>
            <p>If you have any questions or need to reschedule, please don't hesitate to contact us. We're here to help keep your furry friend happy and healthy!</p>
            <a href="${1234567890}" class="btn">Contact Us</a>
        </div>
        <div class="email-footer">
            <p>Thank you for choosing <strong>${clinicName}</strong> for <strong>${petName}</strong>'s wellness care!</p>
            <p><strong>${clinicName}</strong><br>${clinicAddress}<br></p>
        </div>
    </div>
</body>
</html>
