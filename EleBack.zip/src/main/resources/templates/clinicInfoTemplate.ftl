<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Clinic Information Submission</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            color: #333;
            text-align: center;
        }
        .email-container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #ffffff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            border: 2px solid #2d87f0; 
            border-radius: 8px;
            overflow: hidden;
        }
        .header {
            background-color: #2d87f0;
            padding: 20px;
            font-family: 'Helvetica Neue', sans-serif; 
        }
        .header h1 {
            color: #ffffff;
            font-size: 24px;
            margin: 0;
            font-weight: bold;
        }
        .content {
            padding: 20px 30px;
            color: #333;
            text-align: left;
            font-family: 'Georgia', serif; 
        }
        .content h2 {
            font-size: 22px;
            color: #2d87f0;
            font-family: 'Verdana', sans-serif; 
        }
        .content p {
            font-size: 16px;
            line-height: 1.5;
            margin-bottom: 20px;
        }
        .clinic-info {
            background-color: #f0f7ff;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
        }
        .clinic-info li {
            list-style: none;
            font-size: 14px;
            font-family: 'Verdana', sans-serif; 
            margin: 10px 0;
            line-height: 1.4;
        }
        .clinic-info strong {
            color: #2d87f0;
        }
        .footer {
            padding: 15px;
            font-size: 14px;
            color: rgb(78,72,72);
            background-color: #f4f4f9;
            text-align: center;
            font-family: 'Courier New', Courier, monospace; 
        }
    </style>
</head>
<body>
    <div class="email-container">
        <!-- Header Section -->
        <div class="header">
            <h1>New Clinic Information - Let’s Get Them Onboard!</h1>
        </div>

        <!-- Email Content -->
        <div class="content">
            <h2>Ready to Bring Another Clinic Aboard?</h2>
            <p>Hey Admin!</p>
            <p>We’ve got some exciting news!A pet owner expressed interest in having their preferred clinic join Elevate Pet Health. They searched for this clinic on our platform. Now, it's time for us to reach out and give them a warm welcome. Here’s what you need to get started:</p>

            <!-- Clinic Information -->
            <div class="clinic-info">
                <ul>
                    <li><strong>Clinic Name:</strong> ${clinicName}</li>
                    <li><strong>State:</strong> ${state}</li>
                    <li><strong>City:</strong> ${city}</li>
                    <li><strong>Zip Code:</strong> ${zipCode}</li>
                </ul>
            </div>

            <p>Let’s reach out and make them part of our network of trusted clinics. Together, we can make a difference in pet health. Come on, let’s grab this opportunity!</p>
        </div>

        <!-- Footer Section -->
        <div class="footer">
            <p>&copy; 2024 Elevate Pet Health. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
