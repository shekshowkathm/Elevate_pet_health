<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; background-color: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); }
        .header { background-color: #0044cc; color: #fff; padding: 10px; text-align: center; border-radius: 8px 8px 0 0; }
        .content { margin-top: 20px; }
        .issue { font-size: 18px; font-weight: bold; color: #333; }
        .message { font-size: 16px; color: #555; margin-top: 10px; }
        .footer { background-color: #f1f1f1; padding: 10px; text-align: center; color: #333; font-size: 14px; margin-top: 20px; border-radius: 0 0 8px 8px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>${clinicName} - Response to Your Query</h2>
        </div>
        <div class="content">
            <p>Dear ${petOwnerName},</p>
            <p>We have reviewed your query regarding:</p>
            <p class="issue">${issueDescription}</p>
            <p>Here is our response:</p>
            <div class="message">
                <p>${replyMessage}</p>
            </div>
            <p>If you have further questions or concerns, please feel free to contact us.</p>
        </div>
        <div class="footer">
            <p>Thank you for trusting ${clinicName} with your pet's care!</p>
        </div>
    </div>
</body>
</html>
