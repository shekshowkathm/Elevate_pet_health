<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Wellness Plan Notification</title>
    <style>
        /* General styles for email */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333333;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 20px;
            border : 1px solid rgb(155,183,212);
            max-width: 300px;
            box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;
            margin: auto;
            text-align: center;
		    background-size: cover;
		    background-position: center;
        }
        h3 {
            color: rgb(0,112,162);
            font-size: 20px;
            margin-bottom: 15px;
        }
        p {
            font-size: 14px;
            line-height: 1.5;
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: rgb(0,112,162);
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }
        small {
           color: #ffffff;
           font-size: 14px;
        }
        .button:hover {
            background-color: rgb(189,232,231);
        }
        small:hover {
           color: #ffffff;
           font-size: 14px;
        }
        .footer {
            margin-top: 30px;
            font-size: 12px;
            color: #888888;
        }
    </style>
</head>
<body>
    <div class="container">
        <h3>Dear ${petOwnerName},</h3>
        <p>We are excited to inform you that new wellness plans are now available for your pet, <strong>${petName}</strong>, from the clinic <strong>${clinicName}</strong>.</p>
        <p>Please log in to your account and select the appropriate plan for your pet’s health and well-being.</p>
        
        <a href="https://demo.elevatepethealth.com/login" class="button"><small>Choose Your Plan</small></a>

        <div class="footer">
            <p>Best regards,<br/>${clinicName} Team</p>
        </div>
    </div>
</body>
</html>
