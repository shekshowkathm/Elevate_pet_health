<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <style>
      body {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
        background-color: #f0f0f0;
      }
      .mail {
        width: 350px;
        padding: 20px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2),
          0 6px 20px 0 rgba(0, 0, 0, 0.19);
        background-color: #ffffff;
      }

      .mail-content {
        margin: 0;
        text-align: justify;
      }
      .mail-content img {
          margin-left: 75px;
      }
      .mail-content h1 {
        font-size: 20px;
      }

      p {
        margin-top: 10px;
        font-size: 14px;
      }

      .details {
        font-size: 15px;
        color: #007bd9;
      }

      .regards {
        margin: 0;
        padding-top: 20px;
      }

      button {
        width: 100px;
        height: 40px;
        background-color: #007bd9;
        border: none;
        border-radius: 5px;
        margin: 20px 0 0 130px;
        display: block;
        text-align: center;
      }
     button p{
        color: white;
        font-size: 16px;
        font-weight: 400;
       top:0;
      }
      button a {
        text-decoration: none;
      }
    </style>
  </head>

  <body>
    <div class="mail">
      <div class="mail-content">
        <h1>Hello User</h1>
      
        <p>
          Welcome to the Elevate Pet Health family! We're thrilled to have you
          join our community of pet lovers dedicated to ensuring the best health
          and wellness for our furry friends.
        </p>
        <h3 class="details">Email : ${email}</h3>
        <h3 class="details">Temporary Password:${password}</h3>
        <p>
          Please log in to your account using these details and update your
          Password to something secure and memorable. We're here to elevate your
          pet's health and well-being, and we can't wait to support you on this
          journey! If you have any questions or need assistance, please don’t
          hesitate to reach out to us at
          <b>Info@elevate.com </b> or <b>(+916) 765435545</b>. Thank you for
          choosing Elevate Pet Health. Let's make your pet's life happier and
          healthier together!
        </p>
        <a href="https://demo.elevatepethealth.com/login" style="display: inline-block; padding: 10px 20px; background-color: #007bff; color: white; text-align: center; text-decoration: none; border-radius: 5px;">
             Login
        </a>
   
       
        <p class="regards">Warm regards,</p>
        <p>The Elevate Pet Health Team</p>
      </div>
    </div>
  </body>
</html>
