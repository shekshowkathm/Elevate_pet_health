<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plan Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e6f7ff; 
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; /* Full viewport height */
        }
        .email-container {
            background-color: #ffffff;
            width: 80%;
            max-width: 600px;
            margin: 20px auto;
            padding: 30px;
            border: 1px solid #dddddd;
            border-radius: 8px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.15); 
        }
        .plan-confirmation {
            background-color: #cce7ff; /* Background color for plan confirmation */
            padding: 15px;
            border-radius: 8px;
        }
        .plan-confirmation h2 {
            color: #333333;
            text-align: center;
        }
        .message-container {
            margin-top: 20px;
        }
        .message-container p {
            color: #555555;
            line-height: 1.6;
        }
        .email-footer {
            margin-top: 20px;
            text-align: center;
            font-size: 12px;
            color: #888888;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="plan-confirmation">
            <h2>Plan Confirmation</h2>
        </div>
        <div class="message-container">
            <p>
                We’re delighted to inform you that the wellness plan for your pet, <strong>${petName}</strong>, has been successfully confirmed.
            </p>
            <p>
                The clinic <strong>${clinicName}</strong> is ready to provide comprehensive care and services as per the plan.
            </p>
            <p>
                Please find the attached invoice for your records. Thank you for choosing our clinic for your pet’s health and wellness.
            </p>
            <p>Warm regards,</p>
            <p><strong>${clinicName}</strong></p>
        </div>
        <div class="email-footer">
            This email is auto-generated. Please do not reply.
        </div>
    </div>
</body>
</html>
