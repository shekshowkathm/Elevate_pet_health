<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
    <style>
        /* General Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            padding: 20px;
            margin: 0;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 30px;
            text-align: center;
        }

        .header {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
        }

        .otp-code {
            font-size: 36px;
            font-weight: bold;
            color: #4CAF50;
            border: 2px solid #4CAF50;
            padding: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
            margin: 20px 0;
        }

        .content {
            font-size: 16px;
            color: #555;
            line-height: 1.5;
            margin-bottom: 30px;
        }

        .footer {
            font-size: 14px;
            color: #777;
        }

        .button {
            background-color: #4CAF50;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            margin-top: 20px;
        }

        .button:hover {
            background-color: #45a049;
        }

        /* Mobile Responsive */
        @media screen and (max-width: 600px) {
            .container {
                padding: 15px;
            }
            .header {
                font-size: 20px;
            }
            .otp-code {
                font-size: 30px;
                padding: 15px;
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="header">
            OTP Verification for Password Reset
        </div>

        <div class="content">
            <p>Hello,</p>
            <p>We received a request to reset your password. Please use the following One-Time Password (OTP) to complete the process:</p>

            <div class="otp-code">
                ${otpNumber}
            </div>

            <p>If you did not request this change, please ignore this email.</p>
            <p>For any further assistance, feel free to contact our support team.</p>
        </div>

        <a href="#" class="button">Reset Password</a>

        <div class="footer">
            <p>Thank you for choosing our services.</p>
            <p>Regards,<br>Elevate Pet Health</p>
        </div>
    </div>

</body>
</html>
