<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed Notification</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            padding: 20px;
            margin: 0;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 30px;
            text-align: center;
        }

        .header {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
        }

        .content {
            font-size: 16px;
            color: #555;
            line-height: 1.5;
            margin-bottom: 30px;
        }

        .payment-failed {
            font-size: 20px;
            font-weight: bold;
            color: #e74c3c;
            border: 2px solid #e74c3c;
            padding: 20px;
            border-radius: 8px;
            background-color: #fdecea;
            margin: 20px 0;
        }

        .invoice-details {
            margin: 20px 0;
            text-align: left;
        }

        .invoice-details p {
            margin: 5px 0;
            font-size: 16px;
        }

        .footer {
            font-size: 14px;
            color: #777;
        }

        .button {
            background-color: #4CAF50;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            margin-top: 20px;
        }

        .button:hover {
            background-color: #45a049;
        }

        @media screen and (max-width: 600px) {
            .container {
                padding: 15px;
            }
            .header {
                font-size: 20px;
            }
            .payment-failed {
                font-size: 18px;
                padding: 15px;
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="header">
            Payment Failed Notification
        </div>

        <div class="content">
            <p>Hello ${name},</p>
            <p>We encountered an issue processing your recent payment. Here are the details:</p>

            <div class="payment-failed">
                Payment Failed
            </div>

            <div class="invoice-details">
                <p><strong>Amount Due:</strong> $ ${activationLink} </p>
            </div>

            <p>Please update your payment method to ensure uninterrupted service. You can do so by clicking the button below:</p>

            <a  href="https://demo.elevatepethealth.com/login" class="button">Update Payment Method</a>
        </div>

        <div class="footer">
            <p>Thank you for your attention to this matter.</p>
            <p>For further assistance, please contact our support team.</p>
            <p>Regards,<br>Elevate Pet Health</p>
        </div>
    </div>

</body>
</html>
