<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Confirmation</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            padding: 20px;
            margin: 0;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 30px;
            text-align: center;
        }

        .header {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
        }

        .content {
            font-size: 16px;
            color: #555;
            line-height: 1.5;
            margin-bottom: 30px;
        }

        .payment-success {
            font-size: 20px;
            font-weight: bold;
            color: #2ecc71;
            border: 2px solid #2ecc71;
            padding: 20px;
            border-radius: 8px;
            background-color: #d4f8e2;
            margin: 20px 0;
        }

        .invoice-details {
            margin: 20px 0;
            text-align: left;
        }

        .invoice-details p {
            margin: 5px 0;
            font-size: 16px;
        }

        .footer {
            font-size: 14px;
            color: #777;
        }

        .button {
            background-color: #4CAF50;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            margin-top: 20px;
        }

        .button:hover {
            background-color: #45a049;
        }

        @media screen and (max-width: 600px) {
            .container {
                padding: 15px;
            }
            .header {
                font-size: 20px;
            }
            .payment-success {
                font-size: 18px;
                padding: 15px;
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="header">
            Payment Confirmation
        </div>

        <div class="content">
            <p>Hello ${name},</p>
            <p>We are pleased to inform you that your payment has been successfully processed. Here are the details:</p>

            <div class="payment-success">
                Payment Successful
            </div>

            <div class="invoice-details">
                <p><strong>Amount Paid:</strong>$ ${amount}</p>
            </div>

            <p>Thank you for your payment! Your transaction was successfully completed.</p>

            <a href="https://demo.elevatepethealth.com/login" class="button">View Your Account</a>
        </div>

        <div class="footer">
            <p>Thank you for choosing Elevate Pet Health.</p>
            <p>For further assistance, please contact our support team.</p>
            <p>Regards,<br>Elevate Pet Health</p>
        </div>
    </div>

</body>
</html>
