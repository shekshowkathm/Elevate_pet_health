package com.elevate.dto;

import java.util.List;

public class CountsDTO {
	
	private int associatesCount;
	private int petOwnersCount;
	private int petCounts;
	private int activePlansCount;
	private int expiringPlanCounts;
	private int creditCardIssuesCounts;
	private int todayPaymentsCount;
	private int salesRepsCount;
	private int totalClinicsCount;
	private List<SetPromotionReminder> promotions;

	public int getAssociatesCount() {
		return associatesCount;
	}
	public void setAssociatesCount(int associatesCount) {
		this.associatesCount = associatesCount;
	}
	public int getPetOwnersCount() {
		return petOwnersCount;
	}
	public void setPetOwnersCount(int petOwnersCount) {
		this.petOwnersCount = petOwnersCount;
	}
	public int getActivePlansCount() {
		return activePlansCount;
	}
	public void setActivePlansCount(int activePlansCount) {
		this.activePlansCount = activePlansCount;
	}
	public int getExpiringPlanCounts() {
		return expiringPlanCounts;
	}
	public void setExpiringPlanCounts(int expiringPlanCounts) {
		this.expiringPlanCounts = expiringPlanCounts;
	}
	public int getCreditCardIssuesCounts() {
		return creditCardIssuesCounts;
	}
	public void setCreditCardIssuesCounts(int creditCardIssuesCounts) {
		this.creditCardIssuesCounts = creditCardIssuesCounts;
	}
	public int getTodayPaymentsCount() {
		return todayPaymentsCount;
	}
	public void setTodayPaymentsCount(int todayPaymentsCount) {
		this.todayPaymentsCount = todayPaymentsCount;
	}
	public int getSalesRepsCount() {
		return salesRepsCount;
	}
	public void setSalesRepsCount(int salesRepsCount) {
		this.salesRepsCount = salesRepsCount;
	}
	public int getTotalClinicsCount() {
		return totalClinicsCount;
	}
	public void setTotalClinicsCount(int totalClinicsCount) {
		this.totalClinicsCount = totalClinicsCount;
	}
	public List<SetPromotionReminder> getPromotions() {
		return promotions;
	}
	public void setPromotions(List<SetPromotionReminder> promotions) {
		this.promotions = promotions;
	}
	public int getPetCounts() {
		return petCounts;
	}
	public void setPetCounts(int petCounts) {
		this.petCounts = petCounts;
	}
}