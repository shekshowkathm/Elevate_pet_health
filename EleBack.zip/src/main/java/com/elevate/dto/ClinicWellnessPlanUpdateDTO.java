package com.elevate.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClinicWellnessPlanUpdateDTO {

	private Long wellnessUpdateId;
	private String updateRecommendation;
	private String discountPercentage;
	private String discountPriceForQuantity;
	private String discountPriceForSmall;
	private String discountPriceForMedium;
	private String discountPriceForLarge;
	private String discountPriceForXLarge;
	private String doctorPercentage;
	private String updatedPriceForSmall;
	private String updatedPriceForMedium;
	private String updatedPriceForLarge;
	private String updatedPriceForXLarge;
	private String updatedPriceForQuantity;
	private boolean status;
	private String stripeProductIdSmall;
	private String stripeProductIdMedium;
	private String stripeProductIdLarge;
	private String stripeProductIdXLarge;
	private String stripePriceIdSmall;
	private String stripePriceIdMedium;
	private String stripePriceIdLarge;
	private String stripePriceIdXLarge;
	private String stripePriceId;
	private String stripeProductId;
	private String stipeAccountId;
	private String price;
	private String priceBased;

	public Long getWellnessUpdateId() {
		return wellnessUpdateId;
	}

	public void setWellnessUpdateId(Long wellnessUpdateId) {
		this.wellnessUpdateId = wellnessUpdateId;
	}

	public String getUpdateRecommendation() {
		return updateRecommendation;
	}

	public void setUpdateRecommendation(String updateRecommendation) {
		this.updateRecommendation = updateRecommendation;
	}

	// public String getClinicPrice() {
	// return clinicPrice;
	// }
	//
	// public void setClinicPrice(String clinicPrice) {
	// this.clinicPrice = clinicPrice;
	// }

	public String getDiscountPercentage() {
		return discountPercentage;
	}

	public void setDiscountPercentage(String discountPercentage) {
		this.discountPercentage = discountPercentage;
	}

	public String getDiscountPriceForQuantity() {
		return discountPriceForQuantity;
	}

	public void setDiscountPriceForQuantity(String discountPriceForQuantity) {
		this.discountPriceForQuantity = discountPriceForQuantity;
	}

	public String getDiscountPriceForSmall() {
		return discountPriceForSmall;
	}

	public void setDiscountPriceForSmall(String discountPriceForSmall) {
		this.discountPriceForSmall = discountPriceForSmall;
	}

	public String getDiscountPriceForMedium() {
		return discountPriceForMedium;
	}

	public void setDiscountPriceForMedium(String discountPriceForMedium) {
		this.discountPriceForMedium = discountPriceForMedium;
	}

	public String getDiscountPriceForLarge() {
		return discountPriceForLarge;
	}

	public void setDiscountPriceForLarge(String discountPriceForLarge) {
		this.discountPriceForLarge = discountPriceForLarge;
	}

	public String getDiscountPriceForXLarge() {
		return discountPriceForXLarge;
	}

	public void setDiscountPriceForXLarge(String discountPriceForXLarge) {
		this.discountPriceForXLarge = discountPriceForXLarge;
	}

	public String getDoctorPercentage() {
		return doctorPercentage;
	}

	public void setDoctorPercentage(String doctorPercentage) {
		this.doctorPercentage = doctorPercentage;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getStripePriceId() {
		return stripePriceId;
	}

	public void setStripePriceId(String stripePriceId) {
		this.stripePriceId = stripePriceId;
	}

	public String getStripeProductId() {
		return stripeProductId;
	}

	public String getStipeAccountId() {
		return stipeAccountId;
	}

	public void setStipeAccountId(String stipeAccountId) {
		this.stipeAccountId = stipeAccountId;
	}

	public void setStripeProductId(String stripeProductId) {
		this.stripeProductId = stripeProductId;
	}

	public String getUpdatedPriceForSmall() {
		return updatedPriceForSmall;
	}

	public void setUpdatedPriceForSmall(String updatedPriceForSmall) {
		this.updatedPriceForSmall = updatedPriceForSmall;
	}

	public String getUpdatedPriceForMedium() {
		return updatedPriceForMedium;
	}

	public void setUpdatedPriceForMedium(String updatedPriceForMedium) {
		this.updatedPriceForMedium = updatedPriceForMedium;
	}

	public String getUpdatedPriceForLarge() {
		return updatedPriceForLarge;
	}

	public void setUpdatedPriceForLarge(String updatedPriceForLarge) {
		this.updatedPriceForLarge = updatedPriceForLarge;
	}

	public String getUpdatedPriceForXLarge() {
		return updatedPriceForXLarge;
	}

	public void setUpdatedPriceForXLarge(String updatedPriceForXLarge) {
		this.updatedPriceForXLarge = updatedPriceForXLarge;
	}

	public String getUpdatedPriceForQuantity() {
		return updatedPriceForQuantity;
	}

	public void setUpdatedPriceForQuantity(String updatedPriceForQuantity) {
		this.updatedPriceForQuantity = updatedPriceForQuantity;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getStripeProductIdSmall() {
		return stripeProductIdSmall;
	}

	public void setStripeProductIdSmall(String stripeProductIdSmall) {
		this.stripeProductIdSmall = stripeProductIdSmall;
	}

	public String getStripeProductIdMedium() {
		return stripeProductIdMedium;
	}

	public void setStripeProductIdMedium(String stripeProductIdMedium) {
		this.stripeProductIdMedium = stripeProductIdMedium;
	}

	public String getStripeProductIdLarge() {
		return stripeProductIdLarge;
	}

	public void setStripeProductIdLarge(String stripeProductIdLarge) {
		this.stripeProductIdLarge = stripeProductIdLarge;
	}

	public String getStripeProductIdXLarge() {
		return stripeProductIdXLarge;
	}

	public void setStripeProductIdXLarge(String stripeProductIdXLarge) {
		this.stripeProductIdXLarge = stripeProductIdXLarge;
	}

	public String getStripePriceIdSmall() {
		return stripePriceIdSmall;
	}

	public void setStripePriceIdSmall(String stripePriceIdSmall) {
		this.stripePriceIdSmall = stripePriceIdSmall;
	}

	public String getStripePriceIdMedium() {
		return stripePriceIdMedium;
	}

	public void setStripePriceIdMedium(String stripePriceIdMedium) {
		this.stripePriceIdMedium = stripePriceIdMedium;
	}

	public String getStripePriceIdLarge() {
		return stripePriceIdLarge;
	}

	public void setStripePriceIdLarge(String stripePriceIdLarge) {
		this.stripePriceIdLarge = stripePriceIdLarge;
	}

	public String getStripePriceIdXLarge() {
		return stripePriceIdXLarge;
	}

	public void setStripePriceIdXLarge(String stripePriceIdXLarge) {
		this.stripePriceIdXLarge = stripePriceIdXLarge;
	}

	public String getPriceBased() {
		return priceBased;
	}

	public void setPriceBased(String priceBased) {
		this.priceBased = priceBased;
	}
}