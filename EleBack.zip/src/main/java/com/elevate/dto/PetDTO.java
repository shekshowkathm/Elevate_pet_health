package com.elevate.dto;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class PetDTO {

	private Long id;
	private String petName;
	private String petType;
	private String gender;
	private String petBreed;
	private String petAge;
	private String ageGroup;
	private String weight;
	private boolean status;
	private String image;
	private String dob;
	private LocalDate startDate;
	private String clinicName; 
	private ClinicDTO clinic;
	// // private List<PetOwnerPlanDTO> wellnessPlans;
	private List<SetPromotionReminder> activePromotions;
	private String paymentStatus;
	private String stripeCustomerId;
	private Map<Integer, List<PetOwnerPlanDTO>> ongoingPlans;
	private Map<Integer, List<PetOwnerPlanDTO>> futurePlans;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public String getPetType() {
		return petType;
	}

	public void setPetType(String petType) {
		this.petType = petType;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPetBreed() {
		return petBreed;
	}

	public void setPetBreed(String petBreed) {
		this.petBreed = petBreed;
	}

	public String getPetAge() {
		return petAge;
	}

	public void setPetAge(String petAge) {
		this.petAge = petAge;
	}

	public String getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public String getClinicName() {
		return clinicName;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public ClinicDTO getClinic() {
		return clinic;
	}

	public void setClinic(ClinicDTO clinic) {
		this.clinic = clinic;
	}

//	public List<PetOwnerPlanDTO> getWellnessPlans() {
//		return wellnessPlans;
//	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getStripeCustomerId() {
		return stripeCustomerId;
	}

	public void setStripeCustomerId(String stripeCustomerId) {
		this.stripeCustomerId = stripeCustomerId;
	}

//	public void setWellnessPlans(List<PetOwnerPlanDTO> wellnessPlans) {
//		this.wellnessPlans = wellnessPlans;
//	}

	public Map<Integer, List<PetOwnerPlanDTO>> getFuturePlans() {
		return futurePlans;
	}

	public void setFuturePlans(Map<Integer, List<PetOwnerPlanDTO>> futurePlans) {
		this.futurePlans = futurePlans;
	}
//	public void setOngoingPlans(Map<Integer, List<PetOwnerPlanDTO>> ongoingPlans) {
//		this.ongoingPlans = ongoingPlans;
//	}
	public Map<Integer, List<PetOwnerPlanDTO>> getOngoingPlans() {
		return ongoingPlans;
	}

	public void setOngoingPlans(Map<Integer, List<PetOwnerPlanDTO>> ongoingPlans) {
		this.ongoingPlans = ongoingPlans;
	}
	public List<SetPromotionReminder> getActivePromotions() {
		return activePromotions;
	}

	public void setActivePromotions(List<SetPromotionReminder> activePromotions) {
		this.activePromotions = activePromotions;
	}
}