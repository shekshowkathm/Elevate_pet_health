package com.elevate.dto;

public class PriceDetails {
    private String priceId;
    private long quantity;

    // Getters and Setters
    public String getPriceId() {
        return priceId;
    }

    public void setPriceId(String priceId) {
        this.priceId = priceId;
    }

    public long getQuantity() {
        return quantity;
    }

    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }
}
