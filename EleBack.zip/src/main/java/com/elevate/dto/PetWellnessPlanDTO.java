package com.elevate.dto;


public class PetWellnessPlanDTO {
	private Long petOwnerId;
	private Long petId;
	private Long assignedBy;
	private Long clinicWellnessPlan;
	private Long wellnessPlanUpdate;
	
	public Long getPetOwnerId() {
		return petOwnerId;
	}
	public void setPetOwnerId(Long petOwnerId) {
		this.petOwnerId = petOwnerId;
	}
	public Long getPetId() {
		return petId;
	}
	public void setPetId(Long petId) {
		this.petId = petId;
	}
	public Long getAssignedBy() {
		return assignedBy;
	}
	public void setAssignedBy(Long assignedBy) {
		this.assignedBy = assignedBy;
	}
	public Long getClinicWellnessPlan() {
		return clinicWellnessPlan;
	}
	public void setClinicWellnessPlan(Long clinicWellnessPlan) {
		this.clinicWellnessPlan = clinicWellnessPlan;
	}
	public Long getWellnessPlanUpdate() {
		return wellnessPlanUpdate;
	}
	public void setWellnessPlanUpdate(Long wellnessPlanUpdate) {
		this.wellnessPlanUpdate = wellnessPlanUpdate;
	}
}