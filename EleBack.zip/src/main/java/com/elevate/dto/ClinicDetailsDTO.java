package com.elevate.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClinicDetailsDTO {

	private Long id; // clinic id
	private String clinicName;
	private String address;
	private String zipCode;
	private String city;
	private String state;
	private Long clinicOwnerId;
	private String contactNumber;
	private String email;
	private String clinicImage;
	private Long clinicAdminId;
	private Long superAdminId;
	private String startDate;
	private String endDate;
	private boolean clinicStatus;
	private String qrCode;
	private String salesRepFirstName;
	private String salesRepLastName;
	private Long salesRepId;
	private boolean headquater;
	private String stripeAccountId;
	private String headquaters;
	private String clinicLogo;
	private String socialLinkOne;
	private String socialLinkTwo;
	private String socialLinkThree;
	private String socialLinkFour;
	private String clinicEmail;
	private boolean stripeStatus;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClinicName() {
		return clinicName;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getClinicOwnerId() {
		return clinicOwnerId;
	}

	public void setClinicOwnerId(Long clinicOwnerId) {
		this.clinicOwnerId = clinicOwnerId;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getClinicImage() {
		return clinicImage;
	}

	public void setClinicImage(String clinicImage) {
		this.clinicImage = clinicImage;
	}

	public Long getClinicAdminId() {
		return clinicAdminId;
	}

	public void setClinicAdminId(Long clinicAdminId) {
		this.clinicAdminId = clinicAdminId;
	}

	public Long getSuperAdminId() {
		return superAdminId;
	}

	public void setSuperAdminId(Long superAdminId) {
		this.superAdminId = superAdminId;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public boolean isClinicStatus() {
		return clinicStatus;
	}

	public void setClinicStatus(boolean clinicStatus) {
		this.clinicStatus = clinicStatus;
	}

	public String getQrCode() {
		return qrCode;
	}

	public void setQrCode(String qrCode) {
		this.qrCode = qrCode;
	}

	public String getSalesRepFirstName() {
		return salesRepFirstName;
	}

	public void setSalesRepFirstName(String salesRepFirstName) {
		this.salesRepFirstName = salesRepFirstName;
	}

	public String getSalesRepLastName() {
		return salesRepLastName;
	}

	public void setSalesRepLastName(String salesRepLastName) {
		this.salesRepLastName = salesRepLastName;
	}

	public Long getSalesRepId() {
		return salesRepId;
	}

	public void setSalesRepId(Long salesRepId) {
		this.salesRepId = salesRepId;
	}

	public boolean isHeadquater() {
		return headquater;
	}

	public void setHeadquater(boolean headquater) {
		this.headquater = headquater;
	}

	public String getStripeAccountId() {
		return stripeAccountId;
	}

	public void setStripeAccountId(String stripeAccountId) {
		this.stripeAccountId = stripeAccountId;
	}

	public String getHeadquaters() {
		return headquaters;
	}

	public void setHeadquaters(String headquaters) {
		this.headquaters = headquaters;
	}

	public String getClinicLogo() {
		return clinicLogo;
	}

	public void setClinicLogo(String clinicLogo) {
		this.clinicLogo = clinicLogo;
	}

	public String getSocialLinkOne() {
		return socialLinkOne;
	}

	public void setSocialLinkOne(String socialLinkOne) {
		this.socialLinkOne = socialLinkOne;
	}

	public String getSocialLinkTwo() {
		return socialLinkTwo;
	}

	public void setSocialLinkTwo(String socialLinkTwo) {
		this.socialLinkTwo = socialLinkTwo;
	}

	public String getSocialLinkThree() {
		return socialLinkThree;
	}

	public void setSocialLinkThree(String socialLinkThree) {
		this.socialLinkThree = socialLinkThree;
	}

	public String getSocialLinkFour() {
		return socialLinkFour;
	}

	public void setSocialLinkFour(String socialLinkFour) {
		this.socialLinkFour = socialLinkFour;
	}

	public String getClinicEmail() {
		return clinicEmail;
	}

	public void setClinicEmail(String clinicEmail) {
		this.clinicEmail = clinicEmail;
	}

	public boolean isStripeStatus() {
		return stripeStatus;
	}

	public void setStripeStatus(boolean stripeStatus) {
		this.stripeStatus = stripeStatus;
	}
}