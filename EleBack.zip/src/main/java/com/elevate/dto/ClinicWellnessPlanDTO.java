package com.elevate.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClinicWellnessPlanDTO {

	private Long clinicWellnessPlanId;
	private String petType;
	private String ageGroup;
	private String wellnessPlanName;
	private String serviceName;
	private List<DropdownListResponseDTO> clinicDropDowns;
	private boolean petPlanStatus;
	

	public Long getClinicWellnessPlanId() {
		return clinicWellnessPlanId;
	}

	public void setClinicWellnessPlanId(Long clinicWellnessPlanId) {
		this.clinicWellnessPlanId = clinicWellnessPlanId;
	}

	public String getPetType() {
		return petType;
	}

	public void setPetType(String petType) {
		this.petType = petType;
	}

	public String getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}

	public String getWellnessPlanName() {
		return wellnessPlanName;
	}

	public void setWellnessPlanName(String wellnessPlanName) {
		this.wellnessPlanName = wellnessPlanName;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public List<DropdownListResponseDTO> getClinicDropDowns() {
		return clinicDropDowns;
	}

	public void setClinicDropDowns(List<DropdownListResponseDTO> clinicDropDowns) {
		this.clinicDropDowns = clinicDropDowns;
	}

	public boolean isPetPlanStatus() {
		return petPlanStatus;
	}

	public void setPetPlanStatus(boolean petPlanStatus) {
		this.petPlanStatus = petPlanStatus;
	}

	@Override
	public String toString() {
		return "ClinicWellnessPlanDTO [clinicWellnessPlanId=" + clinicWellnessPlanId + ", petType=" + petType
				+ ", ageGroup=" + ageGroup + ", wellnessPlanName=" + wellnessPlanName + ", serviceName=" + serviceName
				+ ", clinicDropDowns=" + clinicDropDowns + ", petPlanStatus=" + petPlanStatus + "]";
	}
}
