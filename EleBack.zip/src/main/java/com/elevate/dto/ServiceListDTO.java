package com.elevate.dto;

import java.util.List;

public class ServiceListDTO {
	
	private String petType;
	private String service;
	private List<DropdownDTO> dropdown;
	
	public String getPetType() {
		return petType;
	}
	public void setPetType(String petType) {
		this.petType = petType;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public List<DropdownDTO> getDropdown() {
		return dropdown;
	}
	public void setDropdown(List<DropdownDTO> dropdown) {
		this.dropdown = dropdown;
	}
	

}
