package com.elevate.dto;

import java.util.List;

public class AppoinmentDTO {

	private String petOwnerName;
	private String email;
	private String phoneNumber;
	private String petName;
	private String petType;
	private String dateOfAppoinment;
	private String service;       // Current selected service
	private List<String> dropdown; // Dropdown list of service options
	private String status;        // Appointment status (Scheduled, Not Scheduled, Missed Scheduled)

	public String getPetOwnerName() {
		return petOwnerName;
	}

	public void setPetOwnerName(String petOwnerName) {
		this.petOwnerName = petOwnerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public String getPetType() {
		return petType;
	}

	public void setPetType(String petType) {
		this.petType = petType;
	}

	public String getDateOfAppoinment() {
		return dateOfAppoinment;
	}

	public void setDateOfAppoinment(String dateOfAppoinment) {
		this.dateOfAppoinment = dateOfAppoinment;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public List<String> getDropdown() {
		return dropdown;
	}

	public void setDropdown(List<String> dropdown) {
		this.dropdown = dropdown;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
