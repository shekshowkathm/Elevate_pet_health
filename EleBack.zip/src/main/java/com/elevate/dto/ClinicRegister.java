package com.elevate.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClinicRegister {

	private long registerId;
	private long clinicId;
	private String clinicOwnerFirstName;
	private String clinicOwnerLastName;
	private String clinicEmail;
	private String clinicOwnerEmail;
	private String email;
	private String clinicName;
	private String clinicAddress;
	private String contact;
	private String zipCode;
	private String role;
	private boolean doctor;
	private boolean registerStatus;
	private String startDate;
	private String city;
	private boolean headquater;
	private String headquaters;
	private String state;
	private String timezone;

	public long getRegisterId() {
		return registerId;
	}

	public void setRegisterId(long registerId) {
		this.registerId = registerId;
	}

	public long getClinicId() {
		return clinicId;
	}

	public void setClinicId(long clinicId) {
		this.clinicId = clinicId;
	}

	public String getClinicOwnerFirstName() {
		return clinicOwnerFirstName;
	}

	public void setClinicOwnerFirstName(String clinicOwnerFirstName) {
		this.clinicOwnerFirstName = clinicOwnerFirstName;
	}

	public String getClinicOwnerLastName() {
		return clinicOwnerLastName;
	}

	public void setClinicOwnerLastName(String clinicOwnerLastName) {
		this.clinicOwnerLastName = clinicOwnerLastName;
	}

	public String getClinicEmail() {
		return clinicEmail;
	}

	public void setClinicEmail(String clinicEmail) {
		this.clinicEmail = clinicEmail;
	}

	public String getClinicOwnerEmail() {
		return clinicOwnerEmail;
	}

	public void setClinicOwnerEmail(String clinicOwnerEmail) {
		this.clinicOwnerEmail = clinicOwnerEmail;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getClinicName() {
		return clinicName;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public String getClinicAddress() {
		return clinicAddress;
	}

	public void setClinicAddress(String clinicAddress) {
		this.clinicAddress = clinicAddress;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public boolean isDoctor() {
		return doctor;
	}

	public void setDoctor(boolean doctor) {
		this.doctor = doctor;
	}

	public boolean isRegisterStatus() {
		return registerStatus;
	}

	public void setRegisterStatus(boolean registerStatus) {
		this.registerStatus = registerStatus;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public boolean isHeadquater() {
		return headquater;
	}

	public void setHeadquater(boolean headquater) {
		this.headquater = headquater;
	}

	public String getHeadquaters() {
		return headquaters;
	}

	public void setHeadquaters(String headquaters) {
		this.headquaters = headquaters;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}
}
