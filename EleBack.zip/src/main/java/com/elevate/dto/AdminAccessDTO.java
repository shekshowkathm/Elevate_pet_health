package com.elevate.dto;

public class AdminAccessDTO {
	private long clinicAdminId;
	private boolean updateWeightRange;
	private boolean updateClinicPrice;
	private boolean updateRecommendation;
	private boolean updateDiscountPercentage;
	private boolean updateDiscountPrice;
	private boolean updateDoctorPercentage;
	private boolean viewPayment;
	
	public long getClinicAdminId() {
		return clinicAdminId;
	}
	public void setClinicAdminId(long clinicAdminId) {
		this.clinicAdminId = clinicAdminId;
	}
	public boolean isUpdateWeightRange() {
		return updateWeightRange;
	}
	public void setUpdateWeightRange(boolean updateWeightRange) {
		this.updateWeightRange = updateWeightRange;
	}
	public boolean isUpdateClinicPrice() {
		return updateClinicPrice;
	}
	public void setUpdateClinicPrice(boolean updateClinicPrice) {
		this.updateClinicPrice = updateClinicPrice;
	}
	public boolean isUpdateRecommendation() {
		return updateRecommendation;
	}
	public void setUpdateRecommendation(boolean updateRecommendation) {
		this.updateRecommendation = updateRecommendation;
	}
	public boolean isUpdateDiscountPercentage() {
		return updateDiscountPercentage;
	}
	public void setUpdateDiscountPercentage(boolean updateDiscountPercentage) {
		this.updateDiscountPercentage = updateDiscountPercentage;
	}
	public boolean isUpdateDiscountPrice() {
		return updateDiscountPrice;
	}
	public void setUpdateDiscountPrice(boolean updateDiscountPrice) {
		this.updateDiscountPrice = updateDiscountPrice;
	}
	public boolean isUpdateDoctorPercentage() {
		return updateDoctorPercentage;
	}
	public void setUpdateDoctorPercentage(boolean updateDoctorPercentage) {
		this.updateDoctorPercentage = updateDoctorPercentage;
	}
	public boolean isViewPayment() {
		return viewPayment;
	}
	public void setViewPayment(boolean viewPayment) {
		this.viewPayment = viewPayment;
	}
}