package com.elevate.dto;

import java.util.List;

public class UpdatePlanDTO {
	
	private List<GetPetWellnessPlanDTO> petWellnessPlan;

	public List<GetPetWellnessPlanDTO> getPetWellnessPlan() {
		return petWellnessPlan;
	}

	public void setPetWellnessPlan(List<GetPetWellnessPlanDTO> petWellnessPlan) {
		this.petWellnessPlan = petWellnessPlan;
	}

    
	

}
