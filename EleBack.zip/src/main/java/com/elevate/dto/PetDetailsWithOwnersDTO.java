package com.elevate.dto;

import java.util.List;
import java.util.Map;

public class PetDetailsWithOwnersDTO {
	private Long petOwnerId;
	private String petOwnerFirstName;
	private String petOwnerLastName;
	private String petOwnerEmail;
	private String petOwnerContact;
	private String petOwnerAddress;
	private String petOwnerState;
	private String petOwnerCity;
	private String petOwnerImage;
	private String petOwnerZipcode;
	private String petOwnerStartDate;
	private String petOwnerEndDate;
	private Long petId;
	private String petName;
	private String petGender;
	private String petType;
	private String petBreed;
	private String petAge;
	private String petDOB;
	private String petWeight;
	private String petSize;
	private String petProfile;
	private String startDate;
	private String endDate;
	private String ageGroup;
	private Map<Integer, List<GetPetWellnessPlanDTO>> historyPlans;
    private Map<Integer, List<GetPetWellnessPlanDTO>> ongoingPlans;
    private Map<Integer, List<GetPetWellnessPlanDTO>> futurePlans;

	private String stripeSubscriptionId;
	private String stripeCustomerId;
	
	public Long getPetOwnerId() {
		return petOwnerId;
	}
	public void setPetOwnerId(Long petOwnerId) {
		this.petOwnerId = petOwnerId;
	}
	public String getPetOwnerFirstName() {
		return petOwnerFirstName;
	}
	public void setPetOwnerFirstName(String petOwnerFirstName) {
		this.petOwnerFirstName = petOwnerFirstName;
	}
	public String getPetOwnerLastName() {
		return petOwnerLastName;
	}
	public void setPetOwnerLastName(String petOwnerLastName) {
		this.petOwnerLastName = petOwnerLastName;
	}
	public String getPetOwnerEmail() {
		return petOwnerEmail;
	}
	public void setPetOwnerEmail(String petOwnerEmail) {
		this.petOwnerEmail = petOwnerEmail;
	}
	public String getPetOwnerContact() {
		return petOwnerContact;
	}
	public void setPetOwnerContact(String petOwnerContact) {
		this.petOwnerContact = petOwnerContact;
	}
	public String getPetOwnerAddress() {
		return petOwnerAddress;
	}
	public void setPetOwnerAddress(String petOwnerAddress) {
		this.petOwnerAddress = petOwnerAddress;
	}
	public String getPetOwnerState() {
		return petOwnerState;
	}
	public void setPetOwnerState(String petOwnerState) {
		this.petOwnerState = petOwnerState;
	}
	public String getPetOwnerCity() {
		return petOwnerCity;
	}
	public void setPetOwnerCity(String petOwnerCity) {
		this.petOwnerCity = petOwnerCity;
	}
	public String getPetOwnerImage() {
		return petOwnerImage;
	}
	public void setPetOwnerImage(String petOwnerImage) {
		this.petOwnerImage = petOwnerImage;
	}
	public String getPetOwnerZipcode() {
		return petOwnerZipcode;
	}
	public void setPetOwnerZipcode(String petOwnerZipcode) {
		this.petOwnerZipcode = petOwnerZipcode;
	}
	public Long getPetId() {
		return petId;
	}
	public void setPetId(Long petId) {
		this.petId = petId;
	}
	public String getPetName() {
		return petName;
	}
	public void setPetName(String petName) {
		this.petName = petName;
	}
	public String getPetGender() {
		return petGender;
	}
	public void setPetGender(String petGender) {
		this.petGender = petGender;
	}
	public String getPetType() {
		return petType;
	}
	public void setPetType(String petType) {
		this.petType = petType;
	}
	public String getPetBreed() {
		return petBreed;
	}
	public void setPetBreed(String petBreed) {
		this.petBreed = petBreed;
	}
	public String getPetAge() {
		return petAge;
	}
	public void setPetAge(String petAge) {
		this.petAge = petAge;
	}
	public String getPetDOB() {
		return petDOB;
	}
	public void setPetDOB(String petDOB) {
		this.petDOB = petDOB;
	}
	public String getPetWeight() {
		return petWeight;
	}
	public void setPetWeight(String petWeight) {
		this.petWeight = petWeight;
	}
	public String getPetSize() {
		return petSize;
	}
	public void setPetSize(String petSize) {
		this.petSize = petSize;
	}
	public String getPetProfile() {
		return petProfile;
	}
	public void setPetProfile(String petProfile) {
		this.petProfile = petProfile;
	}
	public String getAgeGroup() {
		return ageGroup;
	}
	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}
	public Map<Integer, List<GetPetWellnessPlanDTO>> getHistoryPlans() {
		return historyPlans;
	}
	public void setHistoryPlans(Map<Integer, List<GetPetWellnessPlanDTO>> historyPlans) {
		this.historyPlans = historyPlans;
	}
	public Map<Integer, List<GetPetWellnessPlanDTO>> getOngoingPlans() {
		return ongoingPlans;
	}
	public void setOngoingPlans(Map<Integer, List<GetPetWellnessPlanDTO>> ongoingPlans) {
		this.ongoingPlans = ongoingPlans;
	}
	public Map<Integer, List<GetPetWellnessPlanDTO>> getFuturePlans() {
		return futurePlans;
	}
	public void setFuturePlans(Map<Integer, List<GetPetWellnessPlanDTO>> futurePlans) {
		this.futurePlans = futurePlans;
	}
	public String getStripeSubscriptionId() {
		return stripeSubscriptionId;
	}
	public void setStripeSubscriptionId(String stripeSubscriptionId) {
		this.stripeSubscriptionId = stripeSubscriptionId;
	}
	public String getStripeCustomerId() {
		return stripeCustomerId;
	}
	public void setStripeCustomerId(String stripeCustomerId) {
		this.stripeCustomerId = stripeCustomerId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getPetOwnerStartDate() {
		return petOwnerStartDate;
	}
	public void setPetOwnerStartDate(String petOwnerStartDate) {
		this.petOwnerStartDate = petOwnerStartDate;
	}
	public String getPetOwnerEndDate() {
		return petOwnerEndDate;
	}
	public void setPetOwnerEndDate(String petOwnerEndDate) {
		this.petOwnerEndDate = petOwnerEndDate;
	}
}