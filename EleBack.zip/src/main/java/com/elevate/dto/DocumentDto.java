package com.elevate.dto;

public class DocumentDto {

    private String documentUrl;
    private Long uploadedById;
    private String uploadedByRole;
    private String targetType;
    private Long targetId;
    private Long clinicId;
    private String description;
    private String uploadDate;
    private Long id;
    private String fileSize;
    private Long managePlanId;


    public DocumentDto() {}

    public DocumentDto(String documentUrl, Long uploadedById, String uploadedByRole,
                       String targetType, Long targetId, Long clinicId, String description,String fileSize ,String uploadDate) {
        this.documentUrl = documentUrl;
        this.uploadedById = uploadedById;
        this.uploadedByRole = uploadedByRole;
        this.targetType = targetType;
        this.targetId = targetId;
        this.clinicId = clinicId;
        this.description = description;
        this.fileSize = fileSize;
        this.uploadDate = uploadDate;
    }

    public Long getTargetId() {
        return targetId;
    }

    public void setTargetId(Long targetId) {
        this.targetId = targetId;
    }

    public String getDocumentUrl() {
        return documentUrl;
    }

    public void setDocumentUrl(String documentUrl) {
        this.documentUrl = documentUrl;
    }

    public Long getUploadedById() {
        return uploadedById;
    }

    public void setUploadedById(Long uploadedById) {
        this.uploadedById = uploadedById;
    }

    public String getUploadedByRole() {
        return uploadedByRole;
    }

    public void setUploadedByRole(String uploadedByRole) {
        this.uploadedByRole = uploadedByRole;
    }

    public String getTargetType() {
        return targetType;
    }

    public void setTargetType(String targetType) {
        this.targetType = targetType;
    }

    public Long getClinicId() {
        return clinicId;
    }

    public void setClinicId(Long clinicId) {
        this.clinicId = clinicId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(String uploadDate) {
        this.uploadDate = uploadDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFileSize() {
        return fileSize;
    }

    public void setFileSize(String fileSize) {
        this.fileSize = fileSize;
    }

	public Long getManagePlanId() {
		return managePlanId;
	}

	public void setManagePlanId(Long managePlanId) {
		this.managePlanId = managePlanId;
	}
}