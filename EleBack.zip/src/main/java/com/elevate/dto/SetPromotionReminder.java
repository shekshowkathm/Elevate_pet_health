package com.elevate.dto;

public class SetPromotionReminder {
	
	public String promotion;
	private String expiryDate;
	private int pendingDays;
	
	public String getPromotion() {
		return promotion;
	}
	public void setPromotion(String promotion) {
		this.promotion = promotion;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public int getPendingDays() {
		return pendingDays;
	}
	public void setPendingDays(int pendingDays) {
		this.pendingDays = pendingDays;
	}
}
