package com.elevate.dto;

public class DropdownDTO {
	
	private String dropdown;
	private String priceBased;
	private String priceForSmall;
	private String priceForMedium;
	private String priceForLarge;
	private String priceForXLarge;
	private String priceForQuantity;
	private String industryStandardPrice;
	
	public String getDropdown() {
		return dropdown;
	}
	public void setDropdown(String dropdown) {
		this.dropdown = dropdown;
	}
	public String getPriceBased() {
		return priceBased;
	}
	public void setPriceBased(String priceBased) {
		this.priceBased = priceBased;
	}
	public String getPriceForSmall() {
		return priceForSmall;
	}
	public void setPriceForSmall(String priceForSmall) {
		this.priceForSmall = priceForSmall;
	}
	public String getPriceForMedium() {
		return priceForMedium;
	}
	public void setPriceForMedium(String priceForMedium) {
		this.priceForMedium = priceForMedium;
	}
	public String getPriceForLarge() {
		return priceForLarge;
	}
	public void setPriceForLarge(String priceForLarge) {
		this.priceForLarge = priceForLarge;
	}
	public String getPriceForXLarge() {
		return priceForXLarge;
	}
	public void setPriceForXLarge(String priceForXLarge) {
		this.priceForXLarge = priceForXLarge;
	}
	public String getPriceForQuantity() {
		return priceForQuantity;
	}
	public void setPriceForQuantity(String priceForQuantity) {
		this.priceForQuantity = priceForQuantity;
	}
	public String getIndustryStandardPrice() {
		return industryStandardPrice;
	}
	public void setIndustryStandardPrice(String industryStandardPrice) {
		this.industryStandardPrice = industryStandardPrice;
	}
}
