package com.elevate.dto;

import java.util.List;

public class ConfirmPlanRequestDTO {
	
	private List<Long> petWellnessPlanIds;
	private Long managePetWellnessPlanId;
	private String startDate;
	private String endDate;
	private String totalAmount;
	private String updatedAmount;
	
	public List<Long> getPetWellnessPlanIds() {
		return petWellnessPlanIds;
	}
	public void setPetWellnessPlanIds(List<Long> petWellnessPlanIds) {
		this.petWellnessPlanIds = petWellnessPlanIds;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Long getManagePetWellnessPlanId() {
		return managePetWellnessPlanId;
	}
	public void setManagePetWellnessPlanId(Long managePetWellnessPlanId) {
		this.managePetWellnessPlanId = managePetWellnessPlanId;
	}
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getUpdatedAmount() {
		return updatedAmount;
	}
	public void setUpdatedAmount(String updatedAmount) {
		this.updatedAmount = updatedAmount;
	}
}