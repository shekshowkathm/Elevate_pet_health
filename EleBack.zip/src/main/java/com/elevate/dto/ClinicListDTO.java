package com.elevate.dto;

import java.util.List;

public class ClinicListDTO {
	private Long id;
	private String ClinicEmail;
	private String clinicImage;
	private String clinicName;
	private String address;
	private String zipCode;
	private String ContactNumber;
	private String city;
	private String state;
	private String clinicAdminEmail;
	private String clinicOwnerEmail;
	private Long petOwnerCount;
	private boolean status;
	private String salesRepName;
	private boolean headquater;
	private String headquaters;
	private Long wellnessPlanCount;
	private List<String> discount;
	private String stripeAccountId;
	private boolean stripeStatus;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClinicEmail() {
		return ClinicEmail;
	}

	public void setClinicEmail(String clinicEmail) {
		ClinicEmail = clinicEmail;
	}

	public String getClinicImage() {
		return clinicImage;
	}

	public void setClinicImage(String clinicImage) {
		this.clinicImage = clinicImage;
	}

	public String getClinicName() {
		return clinicName;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getContactNumber() {
		return ContactNumber;
	}

	public void setContactNumber(String contactNumber) {
		ContactNumber = contactNumber;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getClinicAdminEmail() {
		return clinicAdminEmail;
	}

	public void setClinicAdminEmail(String clinicAdminEmail) {
		this.clinicAdminEmail = clinicAdminEmail;
	}

	public String getClinicOwnerEmail() {
		return clinicOwnerEmail;
	}

	public void setClinicOwnerEmail(String clinicOwnerEmail) {
		this.clinicOwnerEmail = clinicOwnerEmail;
	}

	public Long getPetOwnerCount() {
		return petOwnerCount;
	}

	public void setPetOwnerCount(Long petOwnerCount) {
		this.petOwnerCount = petOwnerCount;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getSalesRepName() {
		return salesRepName;
	}

	public void setSalesRepName(String salesRepName) {
		this.salesRepName = salesRepName;
	}

	public boolean isHeadquater() {
		return headquater;
	}

	public void setHeadquater(boolean headquater) {
		this.headquater = headquater;
	}

	public String getHeadquaters() {
		return headquaters;
	}

	public void setHeadquaters(String headquaters) {
		this.headquaters = headquaters;
	}

	public Long getWellnessPlanCount() {
		return wellnessPlanCount;
	}

	public void setWellnessPlanCount(Long wellnessPlanCount) {
		this.wellnessPlanCount = wellnessPlanCount;
	}

	public List<String> getDiscount() {
		return discount;
	}

	public void setDiscount(List<String> discount) {
		this.discount = discount;
	}

	public String getStripeAccountId() {
		return stripeAccountId;
	}

	public void setStripeAccountId(String stripeAccountId) {
		this.stripeAccountId = stripeAccountId;
	}

	public boolean isStripeStatus() {
		return stripeStatus;
	}

	public void setStripeStatus(boolean stripeStatus) {
		this.stripeStatus = stripeStatus;
	}
}
