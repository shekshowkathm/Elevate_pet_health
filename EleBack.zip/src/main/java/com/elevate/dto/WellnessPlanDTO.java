package com.elevate.dto;

import java.util.List;

public class WellnessPlanDTO {
	private String petType;
	private String ageGroup;
	private String wellnessPlanName;
	private Long serviceId;
	private List<RecommendationDTO> recommendation;
	private boolean status;;
	public String getPetType() {
		return petType;
	}
	public void setPetType(String petType) {
		this.petType = petType;
	}
	public String getAgeGroup() {
		return ageGroup;
	}
	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}
	public String getWellnessPlanName() {
		return wellnessPlanName;
	}
	public void setWellnessPlanName(String wellnessPlanName) {
		this.wellnessPlanName = wellnessPlanName;
	}
	public Long getServiceId() {
		return serviceId;
	}
	public void setServiceId(Long serviceId) {
		this.serviceId = serviceId;
	}
	public List<RecommendationDTO> getRecommendation() {
		return recommendation;
	}
	public void setRecommendation(List<RecommendationDTO> recommendation) {
		this.recommendation = recommendation;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
}