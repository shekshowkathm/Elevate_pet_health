package com.elevate.dto;

import java.util.List;

public class GetUpdateWellnessPlansDTO {
	
	private Long clinicWellnessPlanId;
    private String petType;
    private String ageGroup;
    private String wellnessPlanName;
    private String serviceName;
    private List<DropdownListResponseDTO> clinicDropDowns;
    private Long petId;        
    private Long petOwnerId;
    private Integer serviceFrequency;
    private String planStatus;
	private List<String> promotions;

	public List<String> getPromotions() {
		return promotions;
	}

	public void setPromotions(List<String> promotions) {
		this.promotions = promotions;
	}

	public Long getClinicWellnessPlanId() {
		return clinicWellnessPlanId;
	}
	public void setClinicWellnessPlanId(Long clinicWellnessPlanId) {
		this.clinicWellnessPlanId = clinicWellnessPlanId;
	}
	public String getPetType() {
		return petType;
	}
	public void setPetType(String petType) {
		this.petType = petType;
	}
	public String getAgeGroup() {
		return ageGroup;
	}
	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}
	public String getWellnessPlanName() {
		return wellnessPlanName;
	}
	public void setWellnessPlanName(String wellnessPlanName) {
		this.wellnessPlanName = wellnessPlanName;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public List<DropdownListResponseDTO> getClinicDropDowns() {
		return clinicDropDowns;
	}
	public void setClinicDropDowns(List<DropdownListResponseDTO> clinicDropDowns) {
		this.clinicDropDowns = clinicDropDowns;
	}
	public Long getPetId() {
		return petId;
	}
	public void setPetId(Long petId) {
		this.petId = petId;
	}
	public Long getPetOwnerId() {
		return petOwnerId;
	}
	public void setPetOwnerId(Long petOwnerId) {
		this.petOwnerId = petOwnerId;
	}
	public Integer getServiceFrequency() {
		return serviceFrequency;
	}
	public void setServiceFrequency(Integer serviceFrequency) {
		this.serviceFrequency = serviceFrequency;
	}
	public String getPlanStatus() {
		return planStatus;
	}
	public void setPlanStatus(String planStatus) {
		this.planStatus = planStatus;
	}
}