package com.elevate.dto;

import java.util.List;

public class ServiceListResponseDTO {
	
	private Long id;
	private String petType;
	private String service;
	private List<DropdownListResponseDTO> dropdown;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPetType() {
		return petType;
	}
	public void setPetType(String petType) {
		this.petType = petType;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public List<DropdownListResponseDTO> getDropdown() {
		return dropdown;
	}
	public void setDropdown(List<DropdownListResponseDTO> dropdown) {
		this.dropdown = dropdown;
	}
	

}
