package com.elevate.dto;


public class AddNewSetPlansDRTO {
	
	private Long petId;
    private Long clinicWellnessPlanId;
    private Long clinicWellnessUpdateId;
    private Long petOwnerId;
    private Long assignedById;
    private boolean pending;
    private String status;
    private boolean confirmed;
    private Long managePetWellnessPlanId;
    private String startDate;
    private String endDate;
    private int serviceFrequency;
	public Long getPetId() {
		return petId;
	}
	public void setPetId(Long petId) {
		this.petId = petId;
	}
	public Long getClinicWellnessPlanId() {
		return clinicWellnessPlanId;
	}
	public void setClinicWellnessPlanId(Long clinicWellnessPlanId) {
		this.clinicWellnessPlanId = clinicWellnessPlanId;
	}
	public Long getClinicWellnessUpdateId() {
		return clinicWellnessUpdateId;
	}
	public void setClinicWellnessUpdateId(Long clinicWellnessUpdateId) {
		this.clinicWellnessUpdateId = clinicWellnessUpdateId;
	}
	public Long getPetOwnerId() {
		return petOwnerId;
	}
	public void setPetOwnerId(Long petOwnerId) {
		this.petOwnerId = petOwnerId;
	}
	public Long getAssignedById() {
		return assignedById;
	}
	public void setAssignedById(Long assignedById) {
		this.assignedById = assignedById;
	}
	public boolean isPending() {
		return pending;
	}
	public void setPending(boolean pending) {
		this.pending = pending;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public boolean isConfirmed() {
		return confirmed;
	}
	public void setConfirmed(boolean confirmed) {
		this.confirmed = confirmed;
	}
	public Long getManagePetWellnessPlanId() {
		return managePetWellnessPlanId;
	}
	public void setManagePetWellnessPlanId(Long managePetWellnessPlanId) {
		this.managePetWellnessPlanId = managePetWellnessPlanId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public int getServiceFrequency() {
		return serviceFrequency;
	}
	public void setServiceFrequency(int serviceFrequency) {
		this.serviceFrequency = serviceFrequency;
	}
}