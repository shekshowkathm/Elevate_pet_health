package com.elevate.dto;

public class RecommendationDTO {

	private Long dropdownId;
	private String recommendation;
	
	public Long getDropdownId() {
		return dropdownId;
	}
	public void setDropdownId(Long dropdownId) {
		this.dropdownId = dropdownId;
	}
	public String getRecommendation() {
		return recommendation;
	}
	public void setRecommendation(String recommendation) {
		this.recommendation = recommendation;
	}
}
