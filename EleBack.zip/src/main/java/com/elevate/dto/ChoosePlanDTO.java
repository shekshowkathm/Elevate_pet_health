package com.elevate.dto;

public class ChoosePlanDTO {
	
	private Long petId;
	private Long petOwnerId;
	private Long clinicWellnessPlan;
	private Long clinicWellnessUpdate;
	private String sendDate;
	private Long sentBy;
	private Long serviceFrequency;
	private Long managePetWellnessPlanId;


	
	public Long getPetId() {
		return petId;
	}
	public void setPetId(Long petId) {
		this.petId = petId;
	}
	public Long getPetOwnerId() {
		return petOwnerId;
	}
	public void setPetOwnerId(Long petOwnerId) {
		this.petOwnerId = petOwnerId;
	}
	public Long getClinicWellnessPlan() {
		return clinicWellnessPlan;
	}
	public void setClinicWellnessPlan(Long clinicWellnessPlan) {
		this.clinicWellnessPlan = clinicWellnessPlan;
	}
	public Long getClinicWellnessUpdate() {
		return clinicWellnessUpdate;
	}
	public void setClinicWellnessUpdate(Long clinicWellnessUpdate) {
		this.clinicWellnessUpdate = clinicWellnessUpdate;
	}
	public String getSendDate() {
		return sendDate;
	}
	public void setSendDate(String sendDate) {
		this.sendDate = sendDate;
	}
	public Long getSentBy() {
		return sentBy;
	}
	public void setSentBy(Long sentBy) {
		this.sentBy = sentBy;
	}
	public Long getServiceFrequency() {
		return serviceFrequency;
	}
	public void setServiceFrequency(Long serviceFrequency) {
		this.serviceFrequency = serviceFrequency;
	}
	public Long getManagePetWellnessPlanId() {
		return managePetWellnessPlanId;
	}
	public void setManagePetWellnessPlanId(Long managePetWellnessPlanId) {
		this.managePetWellnessPlanId = managePetWellnessPlanId;
	}


}