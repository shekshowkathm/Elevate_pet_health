package com.elevate.dto;

import java.util.List;

public class WellnessPlanResponseDTO {
	
	private Long id;
    private String petType;
    private String ageGroup;
    private String wellnessPlanName;
    private List<ServiceListResponseDTO> service; 
    private boolean status;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPetType() {
		return petType;
	}
	public void setPetType(String petType) {
		this.petType = petType;
	}
	public String getAgeGroup() {
		return ageGroup;
	}
	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}
	public String getWellnessPlanName() {
		return wellnessPlanName;
	}
	public void setWellnessPlanName(String wellnessPlanName) {
		this.wellnessPlanName = wellnessPlanName;
	}
	public List<ServiceListResponseDTO> getService() {
		return service;
	}
	public void setService(List<ServiceListResponseDTO> service) {
		this.service = service;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	} 

    
}
