package com.elevate.dto;

import java.util.List;

public class ClinicWellnessPlansWithPromotionStatusDTO {

    private List<ClinicWellnessPlanDTO> wellnessPlans;
    private List<PromotionStatusDTO> promotions;

    public List<PromotionStatusDTO> getPromotions() {
        return promotions;
    }

    public List<ClinicWellnessPlanDTO> getWellnessPlans() {
        return wellnessPlans;
    }

    public void setWellnessPlans(List<ClinicWellnessPlanDTO> wellnessPlans) {
        this.wellnessPlans = wellnessPlans;
    }

    public void setPromotions(List<PromotionStatusDTO> promotions) {
        this.promotions = promotions;
    }


    public static class PromotionStatusDTO {
        private Long id;
        private String name;
        private boolean status;
        public PromotionStatusDTO(Long id, String name, boolean status) {
            this.id = id;
            this.name = name;
            this.status = status;
        }

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public boolean isStatus() {
            return status;
        }

        public void setStatus(boolean status) {
            this.status = status;
        }
    }
}
