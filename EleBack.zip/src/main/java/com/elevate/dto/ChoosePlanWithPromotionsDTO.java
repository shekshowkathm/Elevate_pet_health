package com.elevate.dto;

import java.util.List;

import com.elevate.entity.PromotionDiscount;

public class ChoosePlanWithPromotionsDTO {
    private List<PromotionDiscount> promotionDiscounts;
    private List<ChoosePlanDTO> choosePlans;

    public List<PromotionDiscount> getPromotionDiscounts() {
        return promotionDiscounts;
    }

    public void setPromotionDiscounts(List<PromotionDiscount> promotionDiscounts) {
        this.promotionDiscounts = promotionDiscounts;
    }

    public List<ChoosePlanDTO> getChoosePlans() {
        return choosePlans;
    }

    public void setChoosePlans(List<ChoosePlanDTO> choosePlans) {
        this.choosePlans = choosePlans;
    }
}
