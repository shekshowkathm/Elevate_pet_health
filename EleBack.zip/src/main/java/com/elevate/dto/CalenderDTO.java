package com.elevate.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

public class CalenderDTO {

	private String petName;
	private String serviceName;
	private String dropDown;
	private String scheduledDateAndTime;
	private String clinicName;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String doctorName;

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getDropDown() {
		return dropDown;
	}

	public void setDropDown(String dropDown) {
		this.dropDown = dropDown;
	}

	public String getScheduledDateAndTime() {
		return scheduledDateAndTime;
	}

	public void setScheduledDateAndTime(String scheduledDateAndTime) {
		this.scheduledDateAndTime = scheduledDateAndTime;
	}

	public String getClinicName() {
		return clinicName;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

}
