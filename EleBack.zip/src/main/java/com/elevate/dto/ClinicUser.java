package com.elevate.dto;

import java.util.List;

public class ClinicUser {
    private User ClinicOwner;
    private User ClinicAdmin;
    private List<User> ClinicAssociateList;

    public User getClinicOwner() {
        return ClinicOwner;
    }

    public void setClinicOwner(User clinicOwner) {
        ClinicOwner = clinicOwner;
    }

    public User getClinicAdmin() {
        return ClinicAdmin;
    }

    public void setClinicAdmin(User clinicAdmin) {
        ClinicAdmin = clinicAdmin;
    }

    public List<User> getClinicAssociateList() {
        return ClinicAssociateList;
    }

    public void setClinicAssociateList(List<User> clinicAssociateList) {
        ClinicAssociateList = clinicAssociateList;
    }

    public static class User {
        private Long id;
        private String email;
        private String contactNumber;
        private String firstName;
        private String lastName;

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getContactNumber() {
            return contactNumber;
        }

        public void setContactNumber(String contactNumber) {
            this.contactNumber = contactNumber;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }
    }

}
