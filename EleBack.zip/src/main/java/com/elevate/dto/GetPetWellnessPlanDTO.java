package com.elevate.dto;

import java.util.List;

public class GetPetWellnessPlanDTO {
	private Long petId;
	private Long petWellnessPlanId;
	private String petType;
	private String ageGroup;
	private String wellnessPlanName;
	private String serviceName;
	private String dropdownName;
	private String updatedPrice;
	private String discountPrice;
	private Long clinicWellnessUpdate;
	private Long clinicWellnessPlan;
	private String scheduledDateAndTime;
	private DoctorDTO fulfilledBy;
	private String status;
	private String startDate;
	private String endDate;
	private Long managePetWellnessPlan;
	private List<String> promotions;
	private String paymentStatus;
	private  String planStatus;

	public Long getPetId() {
		return petId;
	}

	public void setPetId(Long petId) {
		this.petId = petId;
	}

	public Long getPetWellnessPlanId() {
		return petWellnessPlanId;
	}

	public void setPetWellnessPlanId(Long petWellnessPlanId) {
		this.petWellnessPlanId = petWellnessPlanId;
	}

	public String getPetType() {
		return petType;
	}

	public void setPetType(String petType) {
		this.petType = petType;
	}

	public String getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}

	public String getWellnessPlanName() {
		return wellnessPlanName;
	}

	public void setWellnessPlanName(String wellnessPlanName) {
		this.wellnessPlanName = wellnessPlanName;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getDropdownName() {
		return dropdownName;
	}

	public void setDropdownName(String dropdownName) {
		this.dropdownName = dropdownName;
	}

	public String getUpdatedPrice() {
		return updatedPrice;
	}

	public void setUpdatedPrice(String updatedPrice) {
		this.updatedPrice = updatedPrice;
	}

	public String getDiscountPrice() {
		return discountPrice;
	}

	public void setDiscountPrice(String discountPrice) {
		this.discountPrice = discountPrice;
	}

	public Long getClinicWellnessUpdate() {
		return clinicWellnessUpdate;
	}

	public void setClinicWellnessUpdate(Long clinicWellnessUpdate) {
		this.clinicWellnessUpdate = clinicWellnessUpdate;
	}

	public Long getClinicWellnessPlan() {
		return clinicWellnessPlan;
	}

	public void setClinicWellnessPlan(Long clinicWellnessPlan) {
		this.clinicWellnessPlan = clinicWellnessPlan;
	}

	public String getScheduledDateAndTime() {
		return scheduledDateAndTime;
	}

	public void setScheduledDateAndTime(String scheduledDateAndTime) {
		this.scheduledDateAndTime = scheduledDateAndTime;
	}

	public DoctorDTO getFulfilledBy() {
		return fulfilledBy;
	}

	public void setFulfilledBy(DoctorDTO fulfilledBy) {
		this.fulfilledBy = fulfilledBy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public Long getManagePetWellnessPlan() {
		return managePetWellnessPlan;
	}

	public void setManagePetWellnessPlan(Long managePetWellnessPlan) {
		this.managePetWellnessPlan = managePetWellnessPlan;
	}

	public List<String> getPromotions() {
		return promotions;
	}

	public void setPromotions(List<String> promotions) {
		this.promotions = promotions;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getPlanStatus() {
		return planStatus;
	}

	public void setPlanStatus(String planStatus) {
		this.planStatus = planStatus;
	}
}