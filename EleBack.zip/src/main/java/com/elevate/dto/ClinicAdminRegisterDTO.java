package com.elevate.dto;

import com.elevate.entity.ClinicDetails;
import com.elevate.entity.Register;

public class ClinicAdminRegisterDTO {

	private String email;
	private ClinicDetails clinicId;
	private String role;
	private String address;
	private String state;
	private String city;
	private String zipcode;
	private Register createdBy;
	private String firstName;
	private String lastName;
	private boolean doctor;
	private String contactNumber;
	private String designation;
	private String timezone;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public ClinicDetails getClinicId() {
		return clinicId;
	}

	public void setClinicId(ClinicDetails clinicId) {
		this.clinicId = clinicId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public Register getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Register createdBy) {
		this.createdBy = createdBy;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public boolean isDoctor() {
		return doctor;
	}

	public void setDoctor(boolean doctor) {
		this.doctor = doctor;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

}