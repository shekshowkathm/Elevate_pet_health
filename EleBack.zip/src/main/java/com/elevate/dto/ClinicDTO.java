package com.elevate.dto;

public class ClinicDTO {

	private Long clinicId;
	private String clinicName;
	private String address;
	private String zipCode;
	private String city;
	private String state;
	private String contactNumber;
	private String email;
	private String qrCode;
	private String clinicImage;
	private String clinicLogo;
	private String socialLinkOne;
	private String socialLinkTwo;
	private String socialLinkThree;
	private String socialLinkFour;

	public Long getClinicId() {
		return clinicId;
	}

	public void setClinicId(Long clinicId) {
		this.clinicId = clinicId;
	}

	public String getClinicName() {
		return clinicName;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getQrCode() {
		return qrCode;
	}

	public void setQrCode(String qrCode) {
		this.qrCode = qrCode;
	}

	public String getClinicImage() {
		return clinicImage;
	}

	public void setClinicImage(String clinicImage) {
		this.clinicImage = clinicImage;
	}

	public String getClinicLogo() {
		return clinicLogo;
	}

	public void setClinicLogo(String clinicLogo) {
		this.clinicLogo = clinicLogo;
	}

	public String getSocialLinkOne() {
		return socialLinkOne;
	}

	public void setSocialLinkOne(String socialLinkOne) {
		this.socialLinkOne = socialLinkOne;
	}

	public String getSocialLinkTwo() {
		return socialLinkTwo;
	}

	public void setSocialLinkTwo(String socialLinkTwo) {
		this.socialLinkTwo = socialLinkTwo;
	}

	public String getSocialLinkThree() {
		return socialLinkThree;
	}

	public void setSocialLinkThree(String socialLinkThree) {
		this.socialLinkThree = socialLinkThree;
	}

	public String getSocialLinkFour() {
		return socialLinkFour;
	}

	public void setSocialLinkFour(String socialLinkFour) {
		this.socialLinkFour = socialLinkFour;
	}
}