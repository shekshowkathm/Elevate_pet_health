package com.elevate.dto;

public class ClinicWeightRangeDTO {

	private String petType;
	private String weight;
	private String size;
	private String updatedWeight;
	private Long clinicWeightRangeId;

	public String getPetType() {
		return petType;
	}

	public void setPetType(String petType) {
		this.petType = petType;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getUpdatedWeight() {
		return updatedWeight;
	}

	public void setUpdatedWeight(String updatedWeight) {
		this.updatedWeight = updatedWeight;
	}

	public Long getClinicWeightRangeId() {
		return clinicWeightRangeId;
	}

	public void setClinicWeightRangeId(Long clinicWeightRangeId) {
		this.clinicWeightRangeId = clinicWeightRangeId;
	}

}
