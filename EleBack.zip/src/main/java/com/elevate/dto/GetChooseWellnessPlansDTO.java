package com.elevate.dto;

import java.util.List;

public class GetChooseWellnessPlansDTO {

	private Long choosePlanId;
	private Long petId;
	private String petName;
	private String petImage;
	private Long petOwnerId;
	private String petOwnerFirstName;
	private String petOwnerLastName;
	private ClinicWellnessPlanDTO clinicWellnessPlan;
	private ClinicWellnessPlanUpdateDTO wellnessPlanUpdate;
	private String status;
	private String petSize;
	private Long managePetWellnessPlanId;
	private String startDate;
	private String endDate;
	private String totalAmount;
	private boolean planAccpetance;
	private List<String> promotions;

	public Long getChoosePlanId() {
		return choosePlanId;
	}

	public void setChoosePlanId(Long choosePlanId) {
		this.choosePlanId = choosePlanId;
	}

	public Long getPetId() {
		return petId;
	}

	public void setPetId(Long petId) {
		this.petId = petId;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public String getPetImage() {
		return petImage;
	}

	public void setPetImage(String petImage) {
		this.petImage = petImage;
	}

	public Long getPetOwnerId() {
		return petOwnerId;
	}

	public void setPetOwnerId(Long petOwnerId) {
		this.petOwnerId = petOwnerId;
	}

	public String getPetOwnerFirstName() {
		return petOwnerFirstName;
	}

	public void setPetOwnerFirstName(String petOwnerFirstName) {
		this.petOwnerFirstName = petOwnerFirstName;
	}

	public String getPetOwnerLastName() {
		return petOwnerLastName;
	}

	public void setPetOwnerLastName(String petOwnerLastName) {
		this.petOwnerLastName = petOwnerLastName;
	}

	public ClinicWellnessPlanDTO getClinicWellnessPlan() {
		return clinicWellnessPlan;
	}

	public void setClinicWellnessPlan(ClinicWellnessPlanDTO clinicWellnessPlan) {
		this.clinicWellnessPlan = clinicWellnessPlan;
	}

	public ClinicWellnessPlanUpdateDTO getWellnessPlanUpdate() {
		return wellnessPlanUpdate;
	}

	public void setWellnessPlanUpdate(ClinicWellnessPlanUpdateDTO wellnessPlanUpdate) {
		this.wellnessPlanUpdate = wellnessPlanUpdate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPetSize() {
		return petSize;
	}

	public void setPetSize(String petSize) {
		this.petSize = petSize;
	}

	public Long getManagePetWellnessPlanId() {
		return managePetWellnessPlanId;
	}

	public void setManagePetWellnessPlanId(Long managePetWellnessPlanId) {
		this.managePetWellnessPlanId = managePetWellnessPlanId;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public List<String> getPromotions() {
		return promotions;
	}

	public void setPromotions(List<String> promotions) {
		this.promotions = promotions;
	}

	public boolean isPlanAccpetance() {
		return planAccpetance;
	}

	public void setPlanAccpetance(boolean planAccpetance) {
		this.planAccpetance = planAccpetance;
	}

}