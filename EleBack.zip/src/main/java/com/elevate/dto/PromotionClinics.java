package com.elevate.dto;

import com.elevate.Enum.ThirtySixtyNinetyStatus;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

public class PromotionClinics {

	private Long clinicId;
	private String clinicEmail;
	private String clinicContact;
	private String clinicName;
	private String clinicOnwerName;
	private boolean headquater;
	private String headquaters;
	@Enumerated(EnumType.STRING)
	private ThirtySixtyNinetyStatus thirtySixtyNinety;
	private String startDate;
	private String endDate;
	private boolean multiPet;
	private boolean multiYear;
	private String generateCode;
	private String expiryDate;
	private String monthlyPlanCounts;
	private String stripeAccountId;
	private String stripeCouponId;

	public Long getClinicId() {
		return clinicId;
	}

	public void setClinicId(Long clinicId) {
		this.clinicId = clinicId;
	}

	public String getClinicEmail() {
		return clinicEmail;
	}

	public void setClinicEmail(String clinicEmail) {
		this.clinicEmail = clinicEmail;
	}

	public String getClinicContact() {
		return clinicContact;
	}

	public void setClinicContact(String clinicContact) {
		this.clinicContact = clinicContact;
	}

	public String getClinicName() {
		return clinicName;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public String getClinicOnwerName() {
		return clinicOnwerName;
	}

	public void setClinicOnwerName(String clinicOnwerName) {
		this.clinicOnwerName = clinicOnwerName;
	}

	public boolean isHeadquater() {
		return headquater;
	}

	public void setHeadquater(boolean headquater) {
		this.headquater = headquater;
	}

	public String getHeadquaters() {
		return headquaters;
	}

	public void setHeadquaters(String headquaters) {
		this.headquaters = headquaters;
	}

	public ThirtySixtyNinetyStatus getThirtySixtyNinety() {
		return thirtySixtyNinety;
	}

	public void setThirtySixtyNinety(ThirtySixtyNinetyStatus thirtySixtyNinety) {
		this.thirtySixtyNinety = thirtySixtyNinety;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public boolean isMultiPet() {
		return multiPet;
	}

	public void setMultiPet(boolean multiPet) {
		this.multiPet = multiPet;
	}

	public boolean isMultiYear() {
		return multiYear;
	}

	public void setMultiYear(boolean multiYear) {
		this.multiYear = multiYear;
	}

	public String getGenerateCode() {
		return generateCode;
	}

	public void setGenerateCode(String generateCode) {
		this.generateCode = generateCode;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getMonthlyPlanCounts() {
		return monthlyPlanCounts;
	}

	public void setMonthlyPlanCounts(String monthlyPlanCounts) {
		this.monthlyPlanCounts = monthlyPlanCounts;
	}

	public String getStripeAccountId() {
		return stripeAccountId;
	}

	public void setStripeAccountId(String stripeAccountId) {
		this.stripeAccountId = stripeAccountId;
	}

	public String getStripeCouponId() {
		return stripeCouponId;
	}

	public void setStripeCouponId(String stripeCouponId) {
		this.stripeCouponId = stripeCouponId;
	}

}