package com.elevate.dto;

import java.util.List;
import java.util.Map;

public class PetPlansDTO {
	
	    private PetImageList petSummary; 
	    private Map<Integer, List<GetPetWellnessPlanDTO>> historyPlans; 
	    private Map<Integer, List<GetPetWellnessPlanDTO>> ongoingPlans; 
	    private Map<Integer, List<GetPetWellnessPlanDTO>> futurePlans;
	    
		public PetImageList getPetSummary() {
			return petSummary;
		}
		public void setPetSummary(PetImageList petSummary) {
			this.petSummary = petSummary;
		}
		public Map<Integer, List<GetPetWellnessPlanDTO>> getHistoryPlans() {
			return historyPlans;
		}
		public void setHistoryPlans(Map<Integer, List<GetPetWellnessPlanDTO>> historyPlans) {
			this.historyPlans = historyPlans;
		}
		public Map<Integer, List<GetPetWellnessPlanDTO>> getOngoingPlans() {
			return ongoingPlans;
		}
		public void setOngoingPlans(Map<Integer, List<GetPetWellnessPlanDTO>> ongoingPlans) {
			this.ongoingPlans = ongoingPlans;
		}
		public Map<Integer, List<GetPetWellnessPlanDTO>> getFuturePlans() {
			return futurePlans;
		}
		public void setFuturePlans(Map<Integer, List<GetPetWellnessPlanDTO>> futurePlans) {
			this.futurePlans = futurePlans;
		} 
	}
