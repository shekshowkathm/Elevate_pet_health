package com.elevate.dto;

public class DoctorsHistory {

	private Long regId;
	private String serviceName;
	private String dropdownName;
	private String fulfilledStatus;
	private Double paidAmount;
	private String doctorPercentage;
	private String fulfilledOn;
	private String clinicName;
	private String petName;
	
	public Long getRegId() {
		return regId;
	}
	public void setRegId(Long regId) {
		this.regId = regId;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getDropdownName() {
		return dropdownName;
	}
	public void setDropdownName(String dropdownName) {
		this.dropdownName = dropdownName;
	}
	public String getFulfilledStatus() {
		return fulfilledStatus;
	}
	public void setFulfilledStatus(String fulfilledStatus) {
		this.fulfilledStatus = fulfilledStatus;
	}
	public Double getPaidAmount() {
		return paidAmount;
	}
	public void setPaidAmount(Double paidAmount) {
		this.paidAmount = paidAmount;
	}
	public String getDoctorPercentage() {
		return doctorPercentage;
	}
	public void setDoctorPercentage(String doctorPercentage) {
		this.doctorPercentage = doctorPercentage;
	}
	public String getFulfilledOn() {
		return fulfilledOn;
	}
	public void setFulfilledOn(String fulfilledOn) {
		this.fulfilledOn = fulfilledOn;
	}
	public String getClinicName() {
		return clinicName;
	}
	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}
	public String getPetName() {
		return petName;
	}
	public void setPetName(String petName) {
		this.petName = petName;
	}
}