package com.elevate.dto;

import java.time.LocalDate;
import java.util.List;

public class StripeDetails {
    private String accountId;
    private String productName;
    private String productDescription;
    private long price;
    private long clinicWellnessUpdateId;
    private String productId;
    private String customerId;
    private String priceId;
    private List<PriceDetails> priceIds;
    private String oneTimePriceId;
    private long petDetailsId;
    private LocalDate startDate;
    private String endDate;
    private String paymentMethodId;
    private long durationMonths;
    private double discountPercent;
    private String subscriptionId;
    private String couponName;
    private int expMonth;
    private int expYear;
    private String cardLast4;
    private String cardBrand;
    private String customerEmail;
    private String customerName;
    private String clinicName;
    private String type;
    private String size;
    private long quantity;
    private boolean isDefaultPayment;
    private String couponCode;
    private long discountAmount;
    private String stripeCouponId;
    private long promotionId;
    private long maxRedemptions;
    private Boolean firstTimeOnly;
    private String couponExpiryDate;
    private long[] petWellnessPlanId;
    private long billingCycle;

    public StripeDetails(String email, String name, int expMonth, int expYear, String last4, String brand, String clinicName) {
        this.customerEmail = email;
        this.customerName = name;
        this.expMonth = expMonth;
        this.expYear = expYear;
        this.cardLast4 = last4;
        this.cardBrand = brand;
        this.clinicName = clinicName;
    }



    public String getAccountId() {
        return accountId;
    }
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public long getPrice() {
        return price;
    }

    public void setPrice(long price) {
        this.price = price;
    }

    public long getClinicWellnessUpdateId() {
        return clinicWellnessUpdateId;
    }

    public void setClinicWellnessUpdateId(long clinicWellnessUpdateId) {
        this.clinicWellnessUpdateId = clinicWellnessUpdateId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getPriceId() {
        return priceId;
    }

    public void setPriceId(String priceId) {
        this.priceId = priceId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public List<PriceDetails> getPriceIds() {
        return priceIds;
    }

    public void setPriceIds(List<PriceDetails> priceIds) {
        this.priceIds = priceIds;
    }

    public String getOneTimePriceId() {
        return oneTimePriceId;
    }

    public void setOneTimePriceId(String oneTimePriceId) {
        this.oneTimePriceId = oneTimePriceId;
    }

    public long getPetDetailsId() {
        return petDetailsId;
    }

    public void setPetDetailsId(long petDetailsId) {
        this.petDetailsId = petDetailsId;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getPaymentMethodId() {
        return paymentMethodId;
    }

    public void setPaymentMethodId(String paymentMethodId) {
        this.paymentMethodId = paymentMethodId;
    }

    public long getDurationMonths() {
        return durationMonths;
    }

    public void setDurationMonths(long durationMonths) {
        this.durationMonths = durationMonths;
    }

    public double getDiscountPercent() {
        return discountPercent;
    }

    public void setDiscountPercent(double discountPercent) {
        this.discountPercent = discountPercent;
    }

    public String getSubscriptionId() {
        return subscriptionId;
    }

    public void setSubscriptionId(String subscriptionId) {
        this.subscriptionId = subscriptionId;
    }

    public String getCouponName() {
        return couponName;
    }

    public void setCouponName(String couponName) {
        this.couponName = couponName;
    }

    public String getCardLast4() {
        return cardLast4;
    }

    public void setCardLast4(String cardLast4) {
        this.cardLast4 = cardLast4;
    }

    public String getCardBrand() {
        return cardBrand;
    }

    public void setCardBrand(String cardBrand) {
        this.cardBrand = cardBrand;
    }

    public void setExpMonth(int expMonth) {
        this.expMonth = expMonth;
    }

    public void setExpYear(int expYear) {
        this.expYear = expYear;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getExpMonth() {
        return expMonth;
    }

    public int getExpYear() {
        return expYear;
    }

    public String getClinicName() {
        return clinicName;
    }

    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public long getQuantity() {
        return quantity;
    }

    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }

    public boolean isDefaultPayment() {
        return isDefaultPayment;
    }

    public void setDefaultPayment(boolean defaultPayment) {
        isDefaultPayment = defaultPayment;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public long getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(long discountAmount) {
        this.discountAmount = discountAmount;
    }

    public String getStripeCouponId() {
        return stripeCouponId;
    }

    public void setStripeCouponId(String stripeCouponId) {
        this.stripeCouponId = stripeCouponId;
    }

    public long getPromotionId() {
        return promotionId;
    }

    public void setPromotionId(long promotionId) {
        this.promotionId = promotionId;
    }

    public long getMaxRedemptions() {
        return maxRedemptions;
    }

    public void setMaxRedemptions(long maxRedemptions) {
        this.maxRedemptions = maxRedemptions;
    }

    public Boolean getFirstTimeOnly() {
        return firstTimeOnly;
    }

    public void setFirstTimeOnly(Boolean firstTimeOnly) {
        this.firstTimeOnly = firstTimeOnly;
    }

    public String getCouponExpiryDate() {
        return couponExpiryDate;
    }

    public void setCouponExpiryDate(String couponExpiryDate) {
        this.couponExpiryDate = couponExpiryDate;
    }

    public long[] getPetWellnessPlanId() {
        return petWellnessPlanId;
    }

    public void setPetWellnessPlanId(long[] petWellnessPlanId) {
        this.petWellnessPlanId = petWellnessPlanId;
    }

    public long getBillingCycle() {
        return billingCycle;
    }

    public void setBillingCycle(long billingCycle) {
        this.billingCycle = billingCycle;
    }
}



