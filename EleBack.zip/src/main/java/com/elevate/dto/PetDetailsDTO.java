package com.elevate.dto;

import com.elevate.Enum.Status;

import java.util.List;
import java.util.Map;

public class PetDetailsDTO {

	private Long id;
	private String ownerFirstName;
	private String ownerLastName;
	private String email;
	private String contact;
	private String petName;
	private String petType;
	private String petBreed;
	private String ageGroup;
	private String weight;
	private String profile;
	private String image;
	private String dob;
	private String clinicName;
	private String clinicEmail;
	private String clinicState;
	private String clinicCity;
	private String state;
	private String city;
	private Long ownerId;
	private String gender;
	private String petAge;
	private Status planStatus;
    private boolean pending;
    private boolean confirmedPlan;
    private String paymentStatus;
    private Long petId;
    private String petSize;
    private Map<Integer, List<GetPetWellnessPlanDTO>> historyPlans;
    private Map<Integer, List<GetPetWellnessPlanDTO>> ongoingPlans;
    private Map<Integer, List<GetPetWellnessPlanDTO>> futurePlans;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOwnerFirstName() {
        return ownerFirstName;
    }

    public void setOwnerFirstName(String ownerFirstName) {
        this.ownerFirstName = ownerFirstName;
    }

    public String getOwnerLastName() {
        return ownerLastName;
    }

    public void setOwnerLastName(String ownerLastName) {
        this.ownerLastName = ownerLastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getPetType() {
        return petType;
    }

    public void setPetType(String petType) {
        this.petType = petType;
    }

    public String getPetBreed() {
        return petBreed;
    }

    public void setPetBreed(String petBreed) {
        this.petBreed = petBreed;
    }

	public String getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

    public String getProfile() {
        return profile;
    }

	public void setProfile(String profile) {
		this.profile = profile;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

    public String getClinicName() {
        return clinicName;
    }

    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    public String getClinicEmail() {
        return clinicEmail;
    }

    public void setClinicEmail(String clinicEmail) {
        this.clinicEmail = clinicEmail;
    }

    public String getClinicState() {
        return clinicState;
    }

    public void setClinicState(String clinicState) {
        this.clinicState = clinicState;
    }

    public String getClinicCity() {
        return clinicCity;
    }

    public void setClinicCity(String clinicCity) {
        this.clinicCity = clinicCity;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPetAge() {
        return petAge;
    }

	public void setPetAge(String petAge) {
		this.petAge = petAge;
	}

    public Long getPetId() {
        return petId;
    }

    public void setPetId(Long petId) {
        this.petId = petId;
    }

	public Status getPlanStatus() {
		return planStatus;
	}

	public void setPlanStatus(Status planStatus) {
		this.planStatus = planStatus;
	}

	public boolean isPending() {
		return pending;
	}

	public void setPending(boolean pending) {
		this.pending = pending;
	}

	public boolean isConfirmedPlan() {
		return confirmedPlan;
	}

	public void setConfirmedPlan(boolean confirmedPlan) {
		this.confirmedPlan = confirmedPlan;
	}

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

	public String getPetSize() {
		return petSize;
	}

	public void setPetSize(String petSize) {
		this.petSize = petSize;
	}

    public Map<Integer, List<GetPetWellnessPlanDTO>> getHistoryPlans() {
        return historyPlans;
    }

    public void setHistoryPlans(Map<Integer, List<GetPetWellnessPlanDTO>> historyPlans) {
        this.historyPlans = historyPlans;
    }

    public Map<Integer, List<GetPetWellnessPlanDTO>> getFuturePlans() {
        return futurePlans;
    }

    public void setFuturePlans(Map<Integer, List<GetPetWellnessPlanDTO>> futurePlans) {
        this.futurePlans = futurePlans;
    }

    public Map<Integer, List<GetPetWellnessPlanDTO>> getOngoingPlans() {
        return ongoingPlans;
    }

    public void setOngoingPlans(Map<Integer, List<GetPetWellnessPlanDTO>> ongoingPlans) {
        this.ongoingPlans = ongoingPlans;
    }
}