package com.elevate.dto;

public class UpdateNewSetPlansDTO {

	private Long petId;
    private Long clinicWellnessPlanId;
    private Long clinicWellnessUpdateId;
    private Long petOwnerId;
    private Long assignedById;
    private String status;
    private Long managePetWellnessPlanId;
    private int serviceFrequency;
	public Long getPetId() {
		return petId;
	}
	public void setPetId(Long petId) {
		this.petId = petId;
	}
	public Long getClinicWellnessPlanId() {
		return clinicWellnessPlanId;
	}
	public void setClinicWellnessPlanId(Long clinicWellnessPlanId) {
		this.clinicWellnessPlanId = clinicWellnessPlanId;
	}
	public Long getClinicWellnessUpdateId() {
		return clinicWellnessUpdateId;
	}
	public void setClinicWellnessUpdateId(Long clinicWellnessUpdateId) {
		this.clinicWellnessUpdateId = clinicWellnessUpdateId;
	}
	public Long getPetOwnerId() {
		return petOwnerId;
	}
	public void setPetOwnerId(Long petOwnerId) {
		this.petOwnerId = petOwnerId;
	}
	public Long getAssignedById() {
		return assignedById;
	}
	public void setAssignedById(Long assignedById) {
		this.assignedById = assignedById;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getManagePetWellnessPlanId() {
		return managePetWellnessPlanId;
	}
	public void setManagePetWellnessPlanId(Long managePetWellnessPlanId) {
		this.managePetWellnessPlanId = managePetWellnessPlanId;
	}
	public int getServiceFrequency() {
		return serviceFrequency;
	}
	public void setServiceFrequency(int serviceFrequency) {
		this.serviceFrequency = serviceFrequency;
	}
    
}