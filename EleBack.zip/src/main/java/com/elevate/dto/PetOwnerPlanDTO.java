package com.elevate.dto;

import java.util.List;

public class PetOwnerPlanDTO {

	private Long petWellnessPlanId;
	private String startDate;
	private String scheduledDate;
	private ClinicWellnessPlanDTO clinicWellnessPlan;
	private ClinicWellnessPlanUpdateDTO wellnessPlanUpdate;
	private String endDate;
	private String planStatus;
	private String paymentStatus;
	private String StripeSubscriptionId;
	private Long managepetWellnessPlanId;
	private String initialAmount;
	private String updatedAmount;
	private List<String> promotions;

	public Long getPetWellnessPlanId() {
		return petWellnessPlanId;
	}

	public void setPetWellnessPlanId(Long petWellnessPlanId) {
		this.petWellnessPlanId = petWellnessPlanId;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(String scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public ClinicWellnessPlanDTO getClinicWellnessPlan() {
		return clinicWellnessPlan;
	}

	public void setClinicWellnessPlan(ClinicWellnessPlanDTO clinicWellnessPlan) {
		this.clinicWellnessPlan = clinicWellnessPlan;
	}

	public ClinicWellnessPlanUpdateDTO getWellnessPlanUpdate() {
		return wellnessPlanUpdate;
	}

	public void setWellnessPlanUpdate(ClinicWellnessPlanUpdateDTO wellnessPlanUpdate) {
		this.wellnessPlanUpdate = wellnessPlanUpdate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getPlanStatus() {
		return planStatus;
	}

	public void setPlanStatus(String planStatus) {
		this.planStatus = planStatus;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getStripeSubscriptionId() {
		return StripeSubscriptionId;
	}

	public void setStripeSubscriptionId(String stripeSubscriptionId) {
		StripeSubscriptionId = stripeSubscriptionId;
	}

	public Long getManagepetWellnessPlanId() {
		return managepetWellnessPlanId;
	}

	public void setManagepetWellnessPlanId(Long managepetWellnessPlanId) {
		this.managepetWellnessPlanId = managepetWellnessPlanId;
	}

	public String getInitialAmount() {
		return initialAmount;
	}

	public void setInitialAmount(String initialAmount) {
		this.initialAmount = initialAmount;
	}

	public String getUpdatedAmount() {
		return updatedAmount;
	}

	public void setUpdatedAmount(String updatedAmount) {
		this.updatedAmount = updatedAmount;
	}

	public List<String> getPromotions() {
		return promotions;
	}

	public void setPromotions(List<String> promotions) {
		this.promotions = promotions;
	}

}