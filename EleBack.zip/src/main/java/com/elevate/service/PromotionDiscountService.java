package com.elevate.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.elevate.Enum.ThirtySixtyNinetyStatus;
import com.elevate.dto.GenerateCodeRequestDTO;
import com.elevate.dto.PromotionClinics;
import com.elevate.dto.PromotionDiscountDTO;
import com.elevate.entity.ClinicDetails;
import com.elevate.entity.PromotionDiscount;
import com.elevate.entity.Register;
import com.elevate.repository.IClinicDetailsRepository;
import com.elevate.repository.IPetWellnessPlanRepository;
import com.elevate.repository.IPromotionDiscountRepository;
import com.elevate.repository.IRegisterRepository;
import com.elevate.utils.GeneratePromotionCode;
import com.elevate.utils.USDateFormat;

@Service
public class PromotionDiscountService {

	@Autowired
	private IPromotionDiscountRepository promotionDiscountRepository;

	@Autowired
	private IPetWellnessPlanRepository petWellnessPlanRepository;

	@Autowired
	private IClinicDetailsRepository clinicRepository;

	@Autowired
	private IRegisterRepository registerRepository;

	public String addPromotion(PromotionDiscount promotionDiscount) {
		promotionDiscount.setStatus(true);
		promotionDiscount.setStartDate(USDateFormat.dateFormat());
		promotionDiscountRepository.save(promotionDiscount);
		return "Promotion added";
	}

	public List<PromotionDiscountDTO> getAllPromotion(Long clinicId) {
		List<PromotionDiscount> promotions = promotionDiscountRepository.findByClinic_Id(clinicId);
		List<PromotionDiscountDTO> promotionDiscounts = new ArrayList<>();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		LocalDate today = LocalDate.now();

		for (PromotionDiscount promotion : promotions) {
			PromotionDiscountDTO promotionDiscount = new PromotionDiscountDTO();
			promotionDiscount.setPromotionId(promotion.getId());
			promotionDiscount.setClinicId(promotion.getClinic().getId());
			promotionDiscount.setClinicEmail(promotion.getClinic().getEmail());
			promotionDiscount.setClinicContact(promotion.getClinic().getContactNumber());
			promotionDiscount.setClinicName(promotion.getClinic().getClinicName());
			promotionDiscount.setStripeCouponId(promotion.getStripeCouponId());

			Register register = registerRepository.findById(promotion.getClinic().getClinicOwner().getId())
					.orElse(null);
			if (register != null) {
				promotionDiscount.setClinicOnwerName(register.getFirstName() + " " + register.getLastName());
			}

			promotionDiscount.setPromotionType(promotion.getPromotionType());
			promotionDiscount.setStartDate(promotion.getStartDate());
			promotionDiscount.setEndDate(promotion.getEndDate());

			LocalDate endLocalDate = null;
			if (promotion.getEndDate() != null) {
				try {
					endLocalDate = LocalDate.parse(promotion.getEndDate(), formatter);
				} catch (DateTimeParseException e) {
					System.err.println("Invalid end date format for promotion ID: " + promotion.getId());
				}
			}

			if (endLocalDate != null && (endLocalDate.isBefore(today) && !endLocalDate.isEqual(today))) {
				promotionDiscount.setStatus(false);
			} else {
				promotionDiscount.setStatus(promotion.isStatus());
			}

			promotionDiscount.setState(promotion.getClinic().getState());
			promotionDiscount.setAddress(promotion.getClinic().getAddress());
			promotionDiscount.setCity(promotion.getClinic().getCity());
			promotionDiscount.setZipcode(promotion.getClinic().getZipCode());

			promotionDiscounts.add(promotionDiscount);
		}

		return promotionDiscounts;
	}

	public String generateCode(GenerateCodeRequestDTO code) {
		ClinicDetails clinicDetails = clinicRepository.findById(code.getClinicId()).get();
		if (clinicDetails != null) {
			String generatedCode = GeneratePromotionCode.generatePromotionCode(10);
			PromotionDiscount promotion = new PromotionDiscount();
			promotion.setPromotionType(generatedCode);
			promotion.setClinic(clinicDetails);
			promotion.setStatus(true);
			promotion.setEndDate(code.getExpiryDate());
			promotion.setStartDate(USDateFormat.dateFormat());
			promotionDiscountRepository.save(promotion);
			return generatedCode;
		} else {
			return "No Clinic Id Found";
		}
	}

	// public String updateCodeExpiryDate(String expiryDate, Long promotionId) {
	// PromotionDiscount promotion =
	// promotionDiscountRepository.findById(promotionId).get();
	// promotion.setExpiryDate(expiryDate);
	// promotionDiscountRepository.save(promotion);
	// return "Date set";
	// }

	public String updatePromotionDiscount(PromotionDiscount promotionDiscount) {
		PromotionDiscount promotion = promotionDiscountRepository.findById(promotionDiscount.getId()).get();
		promotion.setEndDate(promotionDiscount.getEndDate());
		promotion.setStatus(promotionDiscount.isStatus());
		promotionDiscountRepository.save(promotion);
		return "Modified";
	}

	public String countUniqueWellnessPlansByClinicAndMonth(Long clinicId, String monthYear) {
		if (!clinicRepository.existsById(clinicId)) {
			return "No Clinic Found";
		}
		Long count = petWellnessPlanRepository.countUniquePlansByClinicAndMonth(clinicId, monthYear);
		if (count == 0) {
			return "No wellness plans found for the specified month and year.";
		}
		return String.valueOf(count);
	}

	public Long getCountWithinDateRange(String startDate, Long clinicId) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		String currentDate = LocalDate.now().format(formatter);
		return petWellnessPlanRepository.countByDateRangeAndClinicId(startDate, currentDate, clinicId);
	}

	public int getCountWithinDateRange(String startDate, String endDate, Long clinicId) {
		return petWellnessPlanRepository.countByCreatedOnBetweenAndClinicId(startDate, endDate, clinicId);
	}

	@Scheduled(cron = "0 0 0 * * ?")
	public void updateStatusIfEndDateReached() {
		LocalDate today = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		List<PromotionDiscount> promotions = promotionDiscountRepository.findByStatusIsTrue();

		for (PromotionDiscount promotion : promotions) {
			if (promotion.getEndDate() != null) {
				LocalDate endDate = LocalDate.parse(promotion.getEndDate(), formatter);

				if (endDate.equals(today)) {
					promotion.setStatus(false);
					promotionDiscountRepository.save(promotion);
				}
			}
		}
	}

	public List<PromotionClinics> getClinicDetailsInPromotions(String role, Long salesRepId) {
		List<ClinicDetails> clinics = new ArrayList<ClinicDetails>();
		if (role.equals("SUPER_ADMIN")) {
			clinics = clinicRepository.findByClinicStatusIsTrue();
		} else {
			clinics = clinicRepository.findBySalesRepId(salesRepId);
		}

		List<PromotionClinics> PromotionClinics = new ArrayList<PromotionClinics>();
		LocalDate today = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		for (ClinicDetails clinic : clinics) {
			PromotionClinics PromotionClinic = new PromotionClinics();
			PromotionClinic.setClinicName(clinic.getClinicName());
			PromotionClinic.setClinicEmail(clinic.getEmail());
			PromotionClinic.setClinicContact(clinic.getContactNumber());
			PromotionClinic.setHeadquaters(clinic.getHeadquaters());
			PromotionClinic.setHeadquater(clinic.isHeadquater());
			PromotionClinic.setStripeAccountId(clinic.getStripeAccountId());
			Register register = registerRepository.findById(clinic.getClinicOwner().getId()).get();
			PromotionClinic.setClinicOnwerName(register.getFirstName() + " " + register.getLastName());
			PromotionClinic.setClinicId(clinic.getId());
			List<String> excludedPromotionTypes = Arrays.asList("Multi Pet", "30-60-90 Days", "Multi Years");
			List<PromotionDiscount> thirtySixtyNinety = promotionDiscountRepository
					.findByClinic_IdAndStatusIsTrueAndPromotionType(clinic.getId(), "30-60-90 Days");
			if (!thirtySixtyNinety.isEmpty()) {
				for (PromotionDiscount thirtySixtyNinetyPromotion : thirtySixtyNinety) {
					if (thirtySixtyNinetyPromotion.getStartDate() != null) {
						PromotionClinic.setStartDate(thirtySixtyNinetyPromotion.getStartDate());
						LocalDate startLocalDate = LocalDate.parse(thirtySixtyNinetyPromotion.getStartDate(),
								formatter);

						String previousMonthStart = startLocalDate.minusMonths(1).withDayOfMonth(1).format(formatter);
						String previousMonthEnd = startLocalDate.minusMonths(1)
								.withDayOfMonth(startLocalDate.minusMonths(1).lengthOfMonth()).format(formatter);

						String startMonthStart = startLocalDate.withDayOfMonth(1).format(formatter);
						String startMonthEnd = startLocalDate.withDayOfMonth(startLocalDate.lengthOfMonth())
								.format(formatter);

						String nextMonthStart = startLocalDate.plusMonths(1).withDayOfMonth(1).format(formatter);
						String nextMonthEnd = startLocalDate.plusMonths(1)
								.withDayOfMonth(startLocalDate.plusMonths(1).lengthOfMonth()).format(formatter);

						int countPreviousMonth = getCountWithinDateRange(previousMonthStart, previousMonthEnd,
								clinic.getId());
						int countStartMonth = getCountWithinDateRange(startMonthStart, startMonthEnd, clinic.getId());
						int countNextMonth = getCountWithinDateRange(nextMonthStart, nextMonthEnd, clinic.getId());

						int cumulativeCount30 = countPreviousMonth;
						int cumulativeCount60 = countPreviousMonth + countStartMonth;
						int cumulativeCount90 = countPreviousMonth + countStartMonth + countNextMonth;

						if (cumulativeCount90 >= 90) {
							PromotionClinic.setThirtySixtyNinety(ThirtySixtyNinetyStatus.ONGOING);
							PromotionClinic.setMonthlyPlanCounts(cumulativeCount90 + "");
						} else if (cumulativeCount60 >= 60) {
							PromotionClinic.setThirtySixtyNinety(ThirtySixtyNinetyStatus.ONGOING);
							PromotionClinic.setMonthlyPlanCounts(cumulativeCount60 + "");
						} else if (cumulativeCount30 >= 30) {
							PromotionClinic.setThirtySixtyNinety(ThirtySixtyNinetyStatus.ONGOING);
							PromotionClinic.setMonthlyPlanCounts(cumulativeCount30 + "");
						} else {
							PromotionClinic.setThirtySixtyNinety(ThirtySixtyNinetyStatus.TAKEN);
//							String previousMonthStartDate = calculatePreviousMonth(
//									thirtySixtyNinetyPromotion.getStartDate());
//							String uniqueWellnessPlansCount = getCountWithinDateRange(previousMonthStartDate,
//									clinic.getId()).toString();
							PromotionClinic.setMonthlyPlanCounts(cumulativeCount60 + "");
						}
					} else {
						PromotionClinic.setThirtySixtyNinety(ThirtySixtyNinetyStatus.NOT_YET);
						String monthYear = formatDateToMonthYear(USDateFormat.dateFormat());
						String uniqueWellnessPlansCount = countUniqueWellnessPlansByClinicAndMonth(clinic.getId(),
								monthYear);
						PromotionClinic.setMonthlyPlanCounts(uniqueWellnessPlansCount);
					}
				}
			} else {
				PromotionClinic.setThirtySixtyNinety(ThirtySixtyNinetyStatus.NOT_YET);
				String monthYear = formatDateToMonthYear(USDateFormat.dateFormat());
				String uniqueWellnessPlansCount = countUniqueWellnessPlansByClinicAndMonth(clinic.getId(), monthYear);
				PromotionClinic.setMonthlyPlanCounts(uniqueWellnessPlansCount);
			}

			List<PromotionDiscount> multiPetPromotions = promotionDiscountRepository
					.findByClinic_IdAndStatusIsTrueAndPromotionType(clinic.getId(), "Multi Pet");
			for (PromotionDiscount multiPetPromotion : multiPetPromotions) {
				if (multiPetPromotion.getEndDate() != null) {
					LocalDate endDate = LocalDate.parse(multiPetPromotion.getEndDate(), formatter);
					if (endDate.isBefore(today)) {
						PromotionClinic.setMultiPet(false);
					} else {
						PromotionClinic.setMultiPet(true);
						break;
					}
				} else {
					PromotionClinic.setMultiPet(true);
				}
			}

			List<PromotionDiscount> multiYearPromotions = promotionDiscountRepository
					.findByClinic_IdAndStatusIsTrueAndPromotionType(clinic.getId(), "Multi Years");
			for (PromotionDiscount multiYearPromotion : multiYearPromotions) {
				if (multiYearPromotion.getEndDate() != null) {
					LocalDate endDate = LocalDate.parse(multiYearPromotion.getEndDate(), formatter);
					if (endDate.isBefore(today)) {
						PromotionClinic.setMultiYear(false);
					} else {
						PromotionClinic.setMultiYear(true);
						break;
					}
				} else {
					PromotionClinic.setMultiYear(true);
				}
			}

			List<PromotionDiscount> generateCodePromotions = promotionDiscountRepository
					.findByClinic_IdAndStatusIsTrueAndPromotionTypeNotIn(clinic.getId(), excludedPromotionTypes);
			for (PromotionDiscount generateCodePromotion : generateCodePromotions) {
				if (generateCodePromotion != null) {
					if (generateCodePromotion.getEndDate() != null) {
						PromotionClinic.setExpiryDate(generateCodePromotion.getEndDate());
						PromotionClinic.setStripeCouponId(generateCodePromotion.getStripeCouponId());
						LocalDate endDate = LocalDate.parse(generateCodePromotion.getEndDate(), formatter);
						if (!endDate.isBefore(today)) {
							PromotionClinic.setGenerateCode(generateCodePromotion.getPromotionType());
							break;
						}
					}
				}
			}

			PromotionClinics.add(PromotionClinic);

		}
		return PromotionClinics;

	}

	private String formatDateToMonthYear(String date) {
		try {
			DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
			LocalDate parsedDate = LocalDate.parse(date, inputFormatter);
			DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM");
			return parsedDate.format(outputFormatter);
		} catch (Exception e) {
			throw new RuntimeException("Invalid date format: " + date, e);
		}
	}
}