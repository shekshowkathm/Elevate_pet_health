package com.elevate.service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elevate.Enum.Status;
import com.elevate.dto.CountsDTO;
import com.elevate.dto.SetPromotionReminder;
import com.elevate.entity.ClinicDetails;
import com.elevate.entity.PetDetails;
import com.elevate.entity.PetWellnessPlan;
import com.elevate.entity.PromotionDiscount;
import com.elevate.entity.Register;
import com.elevate.repository.IClinicDetailsRepository;
import com.elevate.repository.IPetDetailsRepository;
import com.elevate.repository.IPetWellnessPlanRepository;
import com.elevate.repository.IPromotionDiscountRepository;
import com.elevate.repository.IRegisterRepository;
import com.elevate.utils.USDateFormat;

@Service
public class CountsService {
	
	@Autowired
	private IClinicDetailsRepository clinicDetailsRepository;
	
	@Autowired
	private IPetDetailsRepository petDetailsRepository;
	
	@Autowired
	private IPetWellnessPlanRepository petWellnessPlanRepository;
	
	@Autowired
	private IRegisterRepository registerRepository;
	
	@Autowired
	private IPromotionDiscountRepository promotionDiscountRepository;

	public CountsDTO getCountsForClinic(Long clinicId) {
	    ClinicDetails clinicDetails = clinicDetailsRepository.findById(clinicId)
	            .orElseThrow(() -> new RuntimeException("Clinic Id Not Found"));
	    
	    List<PetDetails> petDetails = petDetailsRepository.findByClinic_IdAndStatusTrue(clinicId);
	    List<Register> petOwners = petDetailsRepository.findDistinctPetOwnersByClinicId(clinicId);

	    List<PetWellnessPlan> activePlans = petWellnessPlanRepository.findByPetIdClinicIdAndWorkFlowStatus(clinicId, Status.ACTIVE);

	    Set<Long> uniqueManagePlanIdsForActivePlans = new HashSet<>();
	    for (PetWellnessPlan plan : activePlans) {
	        if (plan.getManagePetWellnessPlan() != null && plan.getManagePetWellnessPlan().getId() != null) {
	            uniqueManagePlanIdsForActivePlans.add(plan.getManagePetWellnessPlan().getId());
	        }
	    }
	    int distinctActivePlanPetsCount = uniqueManagePlanIdsForActivePlans.size();

	    Instant thirtyDaysFromNow = Instant.now().plus(30, ChronoUnit.DAYS);
	    List<PetWellnessPlan> expiringPlans = petWellnessPlanRepository.findExpiringActivePlans(Status.ACTIVE, thirtyDaysFromNow);
	    Set<Long> uniqueManagePlanIdsForExpiringPlans = new HashSet<>();
	    for (PetWellnessPlan plan : expiringPlans) {
	        if (plan.getPetOwnerId() != null && petOwners.contains(plan.getPetOwnerId())) {
	            if (plan.getManagePetWellnessPlan() != null && plan.getManagePetWellnessPlan().getId() != null) {
	                uniqueManagePlanIdsForExpiringPlans.add(plan.getManagePetWellnessPlan().getId());
	            }
	        }
	    }
	    int distinctExpiringPlanCount = uniqueManagePlanIdsForExpiringPlans.size();

	    CountsDTO countsDTO = new CountsDTO();
	    countsDTO.setAssociatesCount(clinicDetails.getClinicAssociate() != null ? clinicDetails.getClinicAssociate().size() : 0);
	    countsDTO.setPetCounts(petDetails != null ? petDetails.size() : 0);
	    countsDTO.setPetOwnersCount(petOwners != null ? petOwners.size() : 0);
	    countsDTO.setActivePlansCount(distinctActivePlanPetsCount);
	    countsDTO.setExpiringPlanCounts(distinctExpiringPlanCount);

	    List<PromotionDiscount> promotionDiscounts = promotionDiscountRepository.findByClinic_IdAndStatusIsTrue(clinicDetails.getId());
	    List<SetPromotionReminder> allPromotions = new ArrayList<>();
	    if (promotionDiscounts != null && !promotionDiscounts.isEmpty()) {
	        for (PromotionDiscount promotion : promotionDiscounts) {
	            SetPromotionReminder reminder = new SetPromotionReminder();
	            reminder.setPromotion(promotion.getPromotionType());

	            if (promotion.getEndDate() != null) {
	                reminder.setExpiryDate(promotion.getEndDate());

	                String currentDate = USDateFormat.dateFormat();
	                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	                LocalDate currentLocalDate = LocalDate.parse(currentDate, formatter);
	                LocalDate expiryDate = LocalDate.parse(promotion.getEndDate(), formatter);

	                long pendingDays = ChronoUnit.DAYS.between(currentLocalDate, expiryDate);
	                reminder.setPendingDays((int) pendingDays);
	            } else {
	                reminder.setExpiryDate(null);
	                reminder.setPendingDays(0);
	            }
	            allPromotions.add(reminder);
	        }
	    }

	    countsDTO.setPromotions(allPromotions);
	    return countsDTO;
	}

	
	public CountsDTO getCountsForSuperAdmin() {
		List<ClinicDetails> getAllClinics = clinicDetailsRepository.findAllActiveClinics();
		List<PetDetails> getAllPets = petDetailsRepository.findAllActivePets();
		List<Register> getAllSalesRep = registerRepository.findByRegisterStatusIsTrueAndRole("SALES_REP");
		List<PetWellnessPlan> getAllActivePlans = petWellnessPlanRepository.findAllActivePlans(Status.ACTIVE);
		CountsDTO countsDto = new CountsDTO();
		countsDto.setPetOwnersCount(getAllPets.isEmpty() ? 0 : getAllPets.size());
		countsDto.setTotalClinicsCount(getAllClinics.isEmpty() ? 0 :  getAllClinics.size());
		countsDto.setSalesRepsCount(getAllSalesRep.isEmpty() ? 0 : getAllSalesRep.size());
        countsDto.setActivePlansCount(getAllActivePlans.isEmpty() ? 0 : getAllActivePlans.size());
        
		return countsDto;
	}
	
	
	public CountsDTO getCountsForSalesRep(Long regId) {
	    List<ClinicDetails> assignedClinics = clinicDetailsRepository.findBySalesRepId(regId);

	    Instant thirtyDaysFromNow = Instant.now().plus(30, ChronoUnit.DAYS);
	    List<PetWellnessPlan> expiringPlans = petWellnessPlanRepository.findExpiringActivePlans(Status.ACTIVE, thirtyDaysFromNow);

	    int totalPetsCount = 0;
	    int managePetWellnessPlanCount = 0;

	    for (ClinicDetails clinic : assignedClinics) {
	        Long clinicId = clinic.getId();

	        List<PetDetails> pets = petDetailsRepository.findByClinic_IdAndStatusTrue(clinicId);
	        totalPetsCount += pets.size();

	        for (PetDetails pet : pets) {
	            List<PetWellnessPlan> activePlans = petWellnessPlanRepository.findByPetId_IdAndWorkFlowStatusIn(
	                pet.getId(),
	                List.of(Status.ACTIVE, Status.FULFILLED)
	            );

	            managePetWellnessPlanCount += activePlans.stream()
	                .map(PetWellnessPlan::getManagePetWellnessPlan)
	                .filter(Objects::nonNull)
	                .distinct()
	                .count();
	        }
	    }

	    List<SetPromotionReminder> allPromotions = new ArrayList<>();
	    if (!assignedClinics.isEmpty()) {
	        for (ClinicDetails clinic : assignedClinics) {
	            List<PromotionDiscount> promotionDiscounts = promotionDiscountRepository.findByClinic_IdAndStatusIsTrue(clinic.getId());
	            
	            if (promotionDiscounts != null && !promotionDiscounts.isEmpty()) {
	                for (PromotionDiscount promotion : promotionDiscounts) {
	                    SetPromotionReminder reminder = new SetPromotionReminder();
	                    reminder.setPromotion(promotion.getPromotionType());

	                    if (promotion.getEndDate() != null) {
	                        String currentDate = USDateFormat.dateFormat();
	                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	                        LocalDate currentLocalDate = LocalDate.parse(currentDate, formatter);
	                        LocalDate expiryDate = LocalDate.parse(promotion.getEndDate(), formatter);

	                        long pendingDays = ChronoUnit.DAYS.between(currentLocalDate, expiryDate);
	                        reminder.setPendingDays((int) pendingDays);
	                        reminder.setExpiryDate(promotion.getEndDate());
	                    } else {
	                        reminder.setExpiryDate(null);
	                        reminder.setPendingDays(0);
	                    }

	                    allPromotions.add(reminder);
	                }
	            } else {
	                System.out.println("No active promotions found for clinic ID: " + clinic.getId());
	            }
	        }
	    }

	    CountsDTO countsDTO = new CountsDTO();
	    countsDTO.setTotalClinicsCount(assignedClinics.size());
	    countsDTO.setPetOwnersCount(totalPetsCount);
	    countsDTO.setActivePlansCount(managePetWellnessPlanCount);
	    countsDTO.setExpiringPlanCounts(expiringPlans.size());
	    countsDTO.setPromotions(allPromotions);

	    return countsDTO;
	}



}