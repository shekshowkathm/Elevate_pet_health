package com.elevate.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.elevate.entity.LoginInfo;
import com.elevate.entity.Register;
import com.elevate.repository.IRegisterRepository;

@Service
public class LoginService implements UserDetailsService {

	@Autowired
	private IRegisterRepository registerRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<Register> userInfo = registerRepository.findByEmail(username);
		return userInfo.map(LoginInfo::new).orElseThrow(() -> new UsernameNotFoundException(username));
	}

}
