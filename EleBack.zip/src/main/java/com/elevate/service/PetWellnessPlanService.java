package com.elevate.service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.elevate.Enum.Status;
import com.elevate.dto.AppoinmentDTO;
import com.elevate.dto.CalenderDTO;
import com.elevate.dto.ClinicWellnessPlanDTO;
import com.elevate.dto.ClinicWellnessPlanUpdateDTO;
import com.elevate.dto.DropdownListResponseDTO;
import com.elevate.dto.GetChooseWellnessPlansDTO;
import com.elevate.entity.ClinicWellnessPlan;
import com.elevate.entity.ClinicWellnessUpdate;
import com.elevate.entity.DropdownList;
import com.elevate.entity.ManagePetWellnessPlans;
import com.elevate.entity.PetWellnessPlan;
import com.elevate.entity.PromotionDiscount;
import com.elevate.entity.Register;
import com.elevate.repository.IClinicWellnessPlanRepository;
import com.elevate.repository.IClinicWellnessUpdateRepository;
import com.elevate.repository.IDropdownListRepository;
import com.elevate.repository.IManagePetWellnessPlansRepository;
import com.elevate.repository.IPetWellnessPlanRepository;
import com.elevate.repository.IRegisterRepository;
import com.elevate.repository.IWeightRangeRepository;
import com.elevate.utils.EmailSender;
import com.elevate.utils.Timezone;

@Service
public class PetWellnessPlanService {

	@Autowired
	private IPetWellnessPlanRepository petWellnessPlanRepository;

	@Autowired
	private IClinicWellnessPlanRepository clinicWellnessPlanRepository;

	@Autowired
	private IClinicWellnessUpdateRepository clinicWellnessUpdateRepository;

	@Autowired
	private IRegisterRepository registerRepository;

	@Autowired
	private IWeightRangeRepository weightRangeRepository;

	@Autowired
	private EmailSender emailSender;

	@Autowired
	private IDropdownListRepository dropdownListRepository;

	@Autowired
	private IManagePetWellnessPlansRepository managePetWellnessPlanRepository;

	public String updateWellnessPlanScheduledDate(Long petWellnessPlanId, String scheduledDateAndTime) {
		PetWellnessPlan checkPlan = petWellnessPlanRepository.findById(petWellnessPlanId).orElse(null);
		if (checkPlan != null) {
			Register register = registerRepository.findById(checkPlan.getAssignedBy().getId()).orElse(null);
			if (register == null)
				return "Register not found";

			checkPlan.setScheduledDateAndTime(Timezone.convertToUTC(scheduledDateAndTime, register.getTimezone()));
			petWellnessPlanRepository.save(checkPlan);

			String petName = checkPlan.getPetId().getPetName();
			String petOwnerEmail = checkPlan.getPetOwnerId().getEmail();
			String clinicEmail = checkPlan.getPetId().getClinic().getEmail();
			String clinicName = checkPlan.getPetId().getClinic().getClinicName();
			String clinicAddress = checkPlan.getPetId().getClinic().getAddress();
			String petOwnerName = checkPlan.getPetOwnerId().getFirstName() + " "
					+ checkPlan.getPetOwnerId().getLastName();

			emailSender.sendScheduledAppointmentEmail(petOwnerEmail, petName, scheduledDateAndTime, clinicName,
					clinicAddress, petOwnerName, clinicEmail);

			return "Scheduled Date Added";
		}
		return "Pet Wellness Plan Id not found";
	}

	public List<GetChooseWellnessPlansDTO> getSentPlans(Long petId, String role) {
		List<PetWellnessPlan> getAllPlans;

		if ("PET_OWNER".equalsIgnoreCase(role)) {
			getAllPlans = petWellnessPlanRepository.findByPetId_IdAndWorkFlowStatus(petId, Status.SENT_TO_PET_OWNER);
		} else if ("CLINIC_OWNER".equalsIgnoreCase(role) || "CLINIC_ADMIN".equalsIgnoreCase(role)
				|| "CLINIC_ASSOCIATE".equalsIgnoreCase(role)) {
			getAllPlans = petWellnessPlanRepository.findByPetId_IdAndWorkFlowStatus(petId, Status.SENT_TO_CLINIC);
		} else {
			throw new IllegalArgumentException("Invalid role specified: " + role);
		}

		List<GetChooseWellnessPlansDTO> allList = new ArrayList<>();

		for (PetWellnessPlan plans : getAllPlans) {
			GetChooseWellnessPlansDTO dto = new GetChooseWellnessPlansDTO();
			dto.setChoosePlanId(plans.getId());
			dto.setPetId(plans.getPetId().getId());
			dto.setPetImage(plans.getPetId().getImage());
			dto.setPetName(plans.getPetId().getPetName());
			dto.setPetOwnerId(plans.getPetOwnerId().getId());
			dto.setPetOwnerFirstName(plans.getPetOwnerId().getFirstName());
			dto.setPetOwnerLastName(plans.getPetOwnerId().getLastName());
			dto.setStatus(plans.getWorkFlowStatus().name());
			dto.setManagePetWellnessPlanId(plans.getManagePetWellnessPlan().getId());
			dto.setPlanAccpetance(plans.getManagePetWellnessPlan().isPlanAcceptance());
			ManagePetWellnessPlans managePetWellnessPlans = managePetWellnessPlanRepository
					.findById(plans.getManagePetWellnessPlan().getId()).get();
			List<String> promotions = new ArrayList<String>();
			for (PromotionDiscount promotionDiscount : managePetWellnessPlans.getPromotionDiscounts()) {
				promotions.add(promotionDiscount.getPromotionType());
			}
			dto.setPromotions(promotions);
			if (plans.getPetId().getWeight() != null && plans.getPetId().getPetType() != null) {
				try {
					double weight = Double.parseDouble(plans.getPetId().getWeight().replace("lb", "").trim());
					String size = weightRangeRepository.findSizeByPetTypeAndWeight(plans.getPetId().getPetType(),
							weight);
					dto.setPetSize(size);
				} catch (NumberFormatException | NullPointerException e) {
					dto.setPetSize(null);
				}
			}

			ClinicWellnessPlan clinicPlan = clinicWellnessPlanRepository.findById(plans.getClinicWellnessPlan().getId())
					.orElseThrow(() -> new RuntimeException("Clinic Wellness Plan ID Not Found"));
			ClinicWellnessPlanDTO clinicDto = new ClinicWellnessPlanDTO();
			clinicDto.setAgeGroup(clinicPlan.getWellnessPlan().getAgeGroup());
			clinicDto.setPetType(clinicPlan.getWellnessPlan().getPetType());
			clinicDto.setClinicWellnessPlanId(clinicPlan.getId());
			clinicDto.setServiceName(clinicPlan.getWellnessPlan().getService().getService());
			clinicDto.setWellnessPlanName(clinicPlan.getWellnessPlan().getWellnessPlanName());

			ClinicWellnessUpdate clinicWellnessUpdate = clinicWellnessUpdateRepository
					.findById(plans.getClinicWellnessUpdate().getId())
					.orElseThrow(() -> new RuntimeException("Wellness Update ID Not Found"));
			ClinicWellnessPlanUpdateDTO wellnssPlanDTO = new ClinicWellnessPlanUpdateDTO();
			wellnssPlanDTO.setDiscountPercentage(clinicWellnessUpdate.getDiscountPercentage());
			wellnssPlanDTO.setDoctorPercentage(clinicWellnessUpdate.getDoctorPercentage());
			wellnssPlanDTO.setUpdateRecommendation(clinicWellnessUpdate.getUpdateRecommendation());
			wellnssPlanDTO.setStripeProductId(clinicWellnessUpdate.getStripeProductId());
			wellnssPlanDTO.setStripePriceId(clinicWellnessUpdate.getStripePriceId());
			wellnssPlanDTO.setStipeAccountId(clinicWellnessUpdate.getStripeAccountId());
			wellnssPlanDTO.setWellnessUpdateId(clinicWellnessUpdate.getId());
			wellnssPlanDTO.setPriceBased(clinicWellnessUpdate.getDropDown().getPriceBased());

			if ("QTY".equalsIgnoreCase(clinicWellnessUpdate.getDropDown().getPriceBased())) {
				wellnssPlanDTO.setDiscountPriceForQuantity(clinicWellnessUpdate.getDiscountPriceForQuantity());
				wellnssPlanDTO.setUpdatedPriceForQuantity(clinicWellnessUpdate.getUpdatedPriceForQuantity());
			} else if ("WGT".equalsIgnoreCase(clinicWellnessUpdate.getDropDown().getPriceBased())) {
				switch (dto.getPetSize().toUpperCase()) {
				case "SMALL":
					wellnssPlanDTO.setDiscountPriceForSmall(clinicWellnessUpdate.getDiscountPriceForSmall());
					wellnssPlanDTO.setUpdatedPriceForSmall(clinicWellnessUpdate.getUpdatedPriceForSmall());
					break;

				case "MEDIUM":
					wellnssPlanDTO.setDiscountPriceForMedium(clinicWellnessUpdate.getDiscountPriceForMedium());
					wellnssPlanDTO.setUpdatedPriceForMedium(clinicWellnessUpdate.getUpdatedPriceForMedium());
					break;

				case "LARGE":
					wellnssPlanDTO.setDiscountPriceForLarge(clinicWellnessUpdate.getDiscountPriceForLarge());
					wellnssPlanDTO.setUpdatedPriceForLarge(clinicWellnessUpdate.getUpdatedPriceForLarge());
					break;

				case "X-LARGE":
					wellnssPlanDTO.setDiscountPriceForXLarge(clinicWellnessUpdate.getDiscountPriceForXLarge());
					wellnssPlanDTO.setUpdatedPriceForXLarge(clinicWellnessUpdate.getUpdatedPriceForXLarge());
					break;
				}
			}

			if (clinicWellnessUpdate.getDropDown() != null) {
				DropdownList dropDown = clinicWellnessUpdate.getDropDown();
				List<DropdownListResponseDTO> dropDownList = new ArrayList<>();

				DropdownListResponseDTO dropDownDto = new DropdownListResponseDTO();
				dropDownDto.setId(dropDown.getId());
				dropDownDto.setDropdown(dropDown.getDropdown());
				dropDownList.add(dropDownDto);

				clinicDto.setClinicDropDowns(dropDownList);
			} else {
				clinicDto.setClinicDropDowns(null);
			}

			dto.setClinicWellnessPlan(clinicDto);
			dto.setWellnessPlanUpdate(wellnssPlanDTO);

			allList.add(dto);
		}

		return allList;
	}

	public List<GetChooseWellnessPlansDTO> getUpdatedSentPlans(Long petId, String role) {
		List<PetWellnessPlan> getAllPlans;

		if ("PET_OWNER".equalsIgnoreCase(role)) {
			getAllPlans = petWellnessPlanRepository.findByPetId_IdAndWorkFlowStatus(petId,
					Status.UPDATED_PLANS_TO_OWNER);
		} else if ("CLINIC_OWNER".equalsIgnoreCase(role) || "CLINIC_ADMIN".equalsIgnoreCase(role)
				|| "CLINIC_ASSOCIATE".equalsIgnoreCase(role)) {
			getAllPlans = petWellnessPlanRepository.findByPetId_IdAndWorkFlowStatus(petId,
					Status.UPDATED_PLANS_TO_CLINIC);
		} else {
			throw new IllegalArgumentException("Invalid role specified: " + role);
		}

		List<GetChooseWellnessPlansDTO> allList = new ArrayList<>();

		for (PetWellnessPlan plans : getAllPlans) {
			GetChooseWellnessPlansDTO dto = new GetChooseWellnessPlansDTO();
			dto.setChoosePlanId(plans.getId());
			dto.setPetId(plans.getPetId().getId());
			dto.setPetImage(plans.getPetId().getImage());
			dto.setPetName(plans.getPetId().getPetName());
			dto.setPetOwnerId(plans.getPetOwnerId().getId());
			dto.setPetOwnerFirstName(plans.getPetOwnerId().getFirstName());
			dto.setPetOwnerLastName(plans.getPetOwnerId().getLastName());
			dto.setStatus(plans.getWorkFlowStatus().name());
			dto.setManagePetWellnessPlanId(plans.getManagePetWellnessPlan().getId());
			dto.setStartDate(plans.getManagePetWellnessPlan().getStartDate());
			dto.setEndDate(plans.getManagePetWellnessPlan().getEndDate());
			dto.setTotalAmount(plans.getManagePetWellnessPlan().getTotalAmount());
			dto.setPlanAccpetance(plans.getManagePetWellnessPlan().isPlanAcceptance());
			if (plans.getPetId().getWeight() != null && plans.getPetId().getPetType() != null) {
				try {
					double weight = Double.parseDouble(plans.getPetId().getWeight().replace("lb", "").trim());
					String size = weightRangeRepository.findSizeByPetTypeAndWeight(plans.getPetId().getPetType(),
							weight);
					dto.setPetSize(size);
				} catch (NumberFormatException | NullPointerException e) {
					dto.setPetSize(null);
				}
			}

			ClinicWellnessPlan clinicPlan = clinicWellnessPlanRepository.findById(plans.getClinicWellnessPlan().getId())
					.orElseThrow(() -> new RuntimeException("Clinic Wellness Plan ID Not Found"));
			ClinicWellnessPlanDTO clinicDto = new ClinicWellnessPlanDTO();
			clinicDto.setAgeGroup(clinicPlan.getWellnessPlan().getAgeGroup());
			clinicDto.setPetType(clinicPlan.getWellnessPlan().getPetType());
			clinicDto.setClinicWellnessPlanId(clinicPlan.getId());
			clinicDto.setServiceName(clinicPlan.getWellnessPlan().getService().getService());
			clinicDto.setWellnessPlanName(clinicPlan.getWellnessPlan().getWellnessPlanName());

			ClinicWellnessUpdate clinicWellnessUpdate = clinicWellnessUpdateRepository
					.findById(plans.getClinicWellnessUpdate().getId())
					.orElseThrow(() -> new RuntimeException("Wellness Update ID Not Found"));
			ClinicWellnessPlanUpdateDTO wellnssPlanDTO = new ClinicWellnessPlanUpdateDTO();
			wellnssPlanDTO.setDiscountPercentage(clinicWellnessUpdate.getDiscountPercentage());
			wellnssPlanDTO.setDoctorPercentage(clinicWellnessUpdate.getDoctorPercentage());
			wellnssPlanDTO.setUpdateRecommendation(clinicWellnessUpdate.getUpdateRecommendation());
			wellnssPlanDTO.setStripeProductId(clinicWellnessUpdate.getStripeProductId());
			wellnssPlanDTO.setStripePriceId(clinicWellnessUpdate.getStripePriceId());
			wellnssPlanDTO.setStipeAccountId(clinicWellnessUpdate.getStripeAccountId());
			wellnssPlanDTO.setWellnessUpdateId(clinicWellnessUpdate.getId());
			wellnssPlanDTO.setPriceBased(clinicWellnessUpdate.getDropDown().getPriceBased());

			if ("QTY".equalsIgnoreCase(clinicWellnessUpdate.getDropDown().getPriceBased())) {
				wellnssPlanDTO.setDiscountPriceForQuantity(clinicWellnessUpdate.getDiscountPriceForQuantity());
				wellnssPlanDTO.setUpdatedPriceForQuantity(clinicWellnessUpdate.getUpdatedPriceForQuantity());
			} else if ("WGT".equalsIgnoreCase(clinicWellnessUpdate.getDropDown().getPriceBased())) {
				switch (dto.getPetSize().toUpperCase()) {
				case "SMALL":
					wellnssPlanDTO.setDiscountPriceForSmall(clinicWellnessUpdate.getDiscountPriceForSmall());
					wellnssPlanDTO.setUpdatedPriceForSmall(clinicWellnessUpdate.getUpdatedPriceForSmall());
					break;

				case "MEDIUM":
					wellnssPlanDTO.setDiscountPriceForMedium(clinicWellnessUpdate.getDiscountPriceForMedium());
					wellnssPlanDTO.setUpdatedPriceForMedium(clinicWellnessUpdate.getUpdatedPriceForMedium());
					break;

				case "LARGE":
					wellnssPlanDTO.setDiscountPriceForLarge(clinicWellnessUpdate.getDiscountPriceForLarge());
					wellnssPlanDTO.setUpdatedPriceForLarge(clinicWellnessUpdate.getUpdatedPriceForLarge());
					break;

				case "X-LARGE":
					wellnssPlanDTO.setDiscountPriceForXLarge(clinicWellnessUpdate.getDiscountPriceForXLarge());
					wellnssPlanDTO.setUpdatedPriceForXLarge(clinicWellnessUpdate.getUpdatedPriceForXLarge());
					break;
				}
			}

			if (clinicWellnessUpdate.getDropDown() != null) {
				DropdownList dropDown = clinicWellnessUpdate.getDropDown();
				List<DropdownListResponseDTO> dropDownList = new ArrayList<>();

				DropdownListResponseDTO dropDownDto = new DropdownListResponseDTO();
				dropDownDto.setId(dropDown.getId());
				dropDownDto.setDropdown(dropDown.getDropdown());
				dropDownList.add(dropDownDto);

				clinicDto.setClinicDropDowns(dropDownList);
			} else {
				clinicDto.setClinicDropDowns(null);
			}

			dto.setClinicWellnessPlan(clinicDto);
			dto.setWellnessPlanUpdate(wellnssPlanDTO);

			allList.add(dto);
		}

		return allList;
	}

	public List<GetChooseWellnessPlansDTO> getNewSetPlans(Long petId, String role) {
		List<PetWellnessPlan> getAllPlans;

		if ("PET_OWNER".equalsIgnoreCase(role)) {
			getAllPlans = petWellnessPlanRepository.findByPetId_IdAndWorkFlowStatus(petId, Status.NEW_SET_TO_PET_OWNER);
		} else if ("CLINIC_OWNER".equalsIgnoreCase(role) || "CLINIC_ADMIN".equalsIgnoreCase(role)
				|| "CLINIC_ASSOCIATE".equalsIgnoreCase(role)) {
			getAllPlans = petWellnessPlanRepository.findByPetId_IdAndWorkFlowStatus(petId, Status.NEW_SET_TO_CLINIC);
		} else {
			throw new IllegalArgumentException("Invalid role specified: " + role);
		}

		List<GetChooseWellnessPlansDTO> allList = new ArrayList<>();

		for (PetWellnessPlan plans : getAllPlans) {
			GetChooseWellnessPlansDTO dto = new GetChooseWellnessPlansDTO();
			dto.setChoosePlanId(plans.getId());
			dto.setPetId(plans.getPetId().getId());
			dto.setPetImage(plans.getPetId().getImage());
			dto.setPetName(plans.getPetId().getPetName());
			dto.setPetOwnerId(plans.getPetOwnerId().getId());
			dto.setPetOwnerFirstName(plans.getPetOwnerId().getFirstName());
			dto.setPetOwnerLastName(plans.getPetOwnerId().getLastName());
			dto.setStatus(plans.getWorkFlowStatus().name());
			dto.setManagePetWellnessPlanId(plans.getManagePetWellnessPlan().getId());
			dto.setPlanAccpetance(plans.getManagePetWellnessPlan().isPlanAcceptance());
			ManagePetWellnessPlans managePetWellnessPlans = managePetWellnessPlanRepository
					.findById(plans.getManagePetWellnessPlan().getId()).get();
			List<String> promotions = new ArrayList<String>();
			for (PromotionDiscount promotionDiscount : managePetWellnessPlans.getPromotionDiscounts()) {
				promotions.add(promotionDiscount.getPromotionType());
			}
			dto.setPromotions(promotions);

			if (plans.getPetId().getWeight() != null && plans.getPetId().getPetType() != null) {
				try {
					double weight = Double.parseDouble(plans.getPetId().getWeight().replace("lb", "").trim());
					String size = weightRangeRepository.findSizeByPetTypeAndWeight(plans.getPetId().getPetType(),
							weight);
					dto.setPetSize(size);
				} catch (NumberFormatException | NullPointerException e) {
					dto.setPetSize(null);
				}
			}

			ClinicWellnessPlan clinicPlan = clinicWellnessPlanRepository.findById(plans.getClinicWellnessPlan().getId())
					.orElseThrow(() -> new RuntimeException("Clinic Wellness Plan ID Not Found"));
			ClinicWellnessPlanDTO clinicDto = new ClinicWellnessPlanDTO();
			clinicDto.setAgeGroup(clinicPlan.getWellnessPlan().getAgeGroup());
			clinicDto.setPetType(clinicPlan.getWellnessPlan().getPetType());
			clinicDto.setClinicWellnessPlanId(clinicPlan.getId());
			clinicDto.setServiceName(clinicPlan.getWellnessPlan().getService().getService());
			clinicDto.setWellnessPlanName(clinicPlan.getWellnessPlan().getWellnessPlanName());

			ClinicWellnessUpdate clinicWellnessUpdate = clinicWellnessUpdateRepository
					.findById(plans.getClinicWellnessUpdate().getId())
					.orElseThrow(() -> new RuntimeException("Wellness Update ID Not Found"));
			ClinicWellnessPlanUpdateDTO wellnssPlanDTO = new ClinicWellnessPlanUpdateDTO();
			wellnssPlanDTO.setDiscountPercentage(clinicWellnessUpdate.getDiscountPercentage());
			wellnssPlanDTO.setDoctorPercentage(clinicWellnessUpdate.getDoctorPercentage());
			wellnssPlanDTO.setUpdateRecommendation(clinicWellnessUpdate.getUpdateRecommendation());
			wellnssPlanDTO.setStripeProductId(clinicWellnessUpdate.getStripeProductId());
			wellnssPlanDTO.setStripePriceId(clinicWellnessUpdate.getStripePriceId());
			wellnssPlanDTO.setStipeAccountId(clinicWellnessUpdate.getStripeAccountId());
			wellnssPlanDTO.setWellnessUpdateId(clinicWellnessUpdate.getId());
			wellnssPlanDTO.setPriceBased(clinicWellnessUpdate.getDropDown().getPriceBased());

			if ("QTY".equalsIgnoreCase(clinicWellnessUpdate.getDropDown().getPriceBased())) {
				wellnssPlanDTO.setDiscountPriceForQuantity(clinicWellnessUpdate.getDiscountPriceForQuantity());
				wellnssPlanDTO.setUpdatedPriceForQuantity(clinicWellnessUpdate.getUpdatedPriceForQuantity());
			} else if ("WGT".equalsIgnoreCase(clinicWellnessUpdate.getDropDown().getPriceBased())) {
				switch (dto.getPetSize().toUpperCase()) {
				case "SMALL":
					wellnssPlanDTO.setDiscountPriceForSmall(clinicWellnessUpdate.getDiscountPriceForSmall());
					wellnssPlanDTO.setUpdatedPriceForSmall(clinicWellnessUpdate.getUpdatedPriceForSmall());
					break;

				case "MEDIUM":
					wellnssPlanDTO.setDiscountPriceForMedium(clinicWellnessUpdate.getDiscountPriceForMedium());
					wellnssPlanDTO.setUpdatedPriceForMedium(clinicWellnessUpdate.getUpdatedPriceForMedium());
					break;

				case "LARGE":
					wellnssPlanDTO.setDiscountPriceForLarge(clinicWellnessUpdate.getDiscountPriceForLarge());
					wellnssPlanDTO.setUpdatedPriceForLarge(clinicWellnessUpdate.getUpdatedPriceForLarge());
					break;

				case "X-LARGE":
					wellnssPlanDTO.setDiscountPriceForXLarge(clinicWellnessUpdate.getDiscountPriceForXLarge());
					wellnssPlanDTO.setUpdatedPriceForXLarge(clinicWellnessUpdate.getUpdatedPriceForXLarge());
					break;
				}
			}

			if (clinicWellnessUpdate.getDropDown() != null) {
				DropdownList dropDown = clinicWellnessUpdate.getDropDown();
				List<DropdownListResponseDTO> dropDownList = new ArrayList<>();

				DropdownListResponseDTO dropDownDto = new DropdownListResponseDTO();
				dropDownDto.setId(dropDown.getId());
				dropDownDto.setDropdown(dropDown.getDropdown());
				dropDownList.add(dropDownDto);

				clinicDto.setClinicDropDowns(dropDownList);
			} else {
				clinicDto.setClinicDropDowns(null);
			}

			dto.setClinicWellnessPlan(clinicDto);
			dto.setWellnessPlanUpdate(wellnssPlanDTO);

			allList.add(dto);
		}

		return allList;
	}

	public String singlePlanStatus(Long petWellnessPlanId, String status) {
		PetWellnessPlan checkPlan = petWellnessPlanRepository.findById(petWellnessPlanId)
				.orElseThrow(() -> new RuntimeException("Pet Wellness Plan ID nOt found"));
		if (checkPlan != null) {
			checkPlan.setWorkFlowStatus(Status.valueOf(status.toUpperCase()));
			petWellnessPlanRepository.save(checkPlan);
		}
		return null;
	}

	public ResponseEntity<String> acceptPlans(List<Long> petWellnessPlanIds, String status) {
	    List<PetWellnessPlan> plans = petWellnessPlanRepository.findAllById(petWellnessPlanIds);

	    if (plans.isEmpty()) {
	        throw new RuntimeException("No Pet Wellness Plans found for the provided IDs.");
	    }

	    if (!plans.get(0).getManagePetWellnessPlan().isPlanAcceptance()) {
	        return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("Not Accpeted because still terms and conditions are not accpeted yet");
	    }

	    Status workflowStatus = Status.valueOf(status.toUpperCase());
	    for (PetWellnessPlan plan : plans) {
	        plan.setWorkFlowStatus(workflowStatus);

	        if ("SENT_TO_CLINIC".equalsIgnoreCase(status) || "NEW_SET_TO_CLINIC".equalsIgnoreCase(status)) {
	            plan.setPlanStatus("confirmed");
	        } else {
	            plan.setPlanStatus("updated");
	        }
	    }

	    petWellnessPlanRepository.saveAll(plans);
	    return ResponseEntity.status(HttpStatus.ACCEPTED).body("Statuses updated successfully for the provided plans.");
	}


	public List<AppoinmentDTO> getAppoinments(Long clinicId, String timezone) {
		List<PetWellnessPlan> petWellnessPlans = petWellnessPlanRepository
				.findByClinicWellnessPlan_ClinicIdAndActiveWorkFlowStatus(clinicId);
		List<AppoinmentDTO> appoinments = new ArrayList<AppoinmentDTO>();
		for (PetWellnessPlan petWellnessPlan : petWellnessPlans) {
			if (petWellnessPlan.getScheduledDateAndTime() != null) {
				AppoinmentDTO appoinmnet = new AppoinmentDTO();
				appoinmnet.setPetName(petWellnessPlan.getPetId().getPetName());
				appoinmnet.setEmail(petWellnessPlan.getPetOwnerId().getEmail());
				appoinmnet.setPetOwnerName(petWellnessPlan.getPetOwnerId().getFirstName() + " "
						+ petWellnessPlan.getPetOwnerId().getLastName());
				appoinmnet.setPhoneNumber(petWellnessPlan.getPetOwnerId().getContactNumber());
				appoinmnet.setPetType(petWellnessPlan.getPetId().getPetType());
				appoinmnet.setDateOfAppoinment(
						Timezone.convertToTimeZone(petWellnessPlan.getScheduledDateAndTime(), timezone));
				appoinments.add(appoinmnet);
			}
		}

		return appoinments;
	}

	public List<CalenderDTO> getCalendar(Long clinicId, String timezone) {
		List<PetWellnessPlan> petWellnessPlans = petWellnessPlanRepository.findActivePlansByClinicId(clinicId);
		List<CalenderDTO> calenderList = new ArrayList<CalenderDTO>();
		for (PetWellnessPlan petWellnessPlan : petWellnessPlans) {
			if (petWellnessPlan.getScheduledDateAndTime() != null) {
				CalenderDTO calender = new CalenderDTO();
				calender.setPetName(petWellnessPlan.getPetId().getPetName());
				calender.setScheduledDateAndTime(
						Timezone.convertToTimeZone(petWellnessPlan.getScheduledDateAndTime(), timezone));
				calender.setServiceName(
						petWellnessPlan.getClinicWellnessPlan().getWellnessPlan().getService().getService());
				calender.setDropDown(petWellnessPlan.getClinicWellnessUpdate().getDropDown().getDropdown());
				calender.setClinicName(petWellnessPlan.getClinicWellnessPlan().getClinic().getClinicName());
				calenderList.add(calender);
			}
		}
		return calenderList;
	}

	public List<CalenderDTO> getPetOwnerCalender(Long petOwnerId) {
//		List<PetWellnessPlan> petWellnessPlans = petWellnessPlanRepository.findByPetOwnerIdAndConfirmedTrue(petOwnerId);
		List<PetWellnessPlan> petWellnessPlans = petWellnessPlanRepository
				.findByPetOwnerIdAndActiveWorkFlowStatus(petOwnerId);
		List<CalenderDTO> calenderList = new ArrayList<CalenderDTO>();
		for (PetWellnessPlan petWellnessPlan : petWellnessPlans) {
			if (petWellnessPlan.getScheduledDateAndTime() != null) {
				Register register = registerRepository.findById(petWellnessPlan.getPetOwnerId().getId())
						.orElseThrow(() -> new RuntimeException("No Pet Owner Id Found"));
				CalenderDTO calender = new CalenderDTO();
				calender.setPetName(petWellnessPlan.getPetId().getPetName());
				if (calender != null) {
					calender.setScheduledDateAndTime(Timezone
							.convertToTimeZone(petWellnessPlan.getScheduledDateAndTime(), register.getTimezone()));
				}
				calender.setServiceName(
						petWellnessPlan.getClinicWellnessPlan().getWellnessPlan().getService().getService());
				calender.setDropDown(petWellnessPlan.getClinicWellnessUpdate().getDropDown().getDropdown());
				calender.setClinicName(petWellnessPlan.getClinicWellnessPlan().getClinic().getClinicName());
				if (petWellnessPlan.getFulfilledBy() != null) {
					Register fulFilledBy = registerRepository.findById(petWellnessPlan.getFulfilledBy()).get();
					calender.setDoctorName(fulFilledBy.getFirstName() + " " + fulFilledBy.getLastName());
				} else {
					calender.setDoctorName(null);
				}
				calenderList.add(calender);
			}
		}
		return calenderList;
	}

	public List<AppoinmentDTO> getAppointmentsStatus(Long clinicId, String timezone) {
		List<PetWellnessPlan> petWellnessPlans = petWellnessPlanRepository
				.findByClinicWellnessPlan_ClinicIdAndActiveWorkFlowStatus(clinicId);

		List<AppoinmentDTO> appoinments = new ArrayList<>();

		for (PetWellnessPlan petWellnessPlan : petWellnessPlans) {
			AppoinmentDTO appoinment = new AppoinmentDTO();
			appoinment.setPetName(petWellnessPlan.getPetId().getPetName());
			appoinment.setEmail(petWellnessPlan.getPetOwnerId().getEmail());
			appoinment.setPhoneNumber(petWellnessPlan.getPetOwnerId().getContactNumber());
			appoinment.setPetOwnerName(petWellnessPlan.getPetOwnerId().getFirstName() + " "
					+ petWellnessPlan.getPetOwnerId().getLastName());
			appoinment.setPetType(petWellnessPlan.getPetId().getPetType());

			Instant scheduledDate = petWellnessPlan.getScheduledDateAndTime();
			if (scheduledDate == null) {
				appoinment.setDateOfAppoinment("Not Scheduled");
				appoinment.setStatus("Not Scheduled");
			} else {
				Instant currentTime = Instant.now();
				if (scheduledDate.isAfter(currentTime)) {
					appoinment.setStatus("Scheduled");
				} else if (scheduledDate.isBefore(currentTime) && petWellnessPlan.getFulfilledBy() == null) {
					appoinment.setStatus("Missed Scheduled");
				}
				appoinment.setDateOfAppoinment(Timezone.convertToTimeZone(scheduledDate, timezone));
			}

			String service = petWellnessPlan.getClinicWellnessPlan() != null
					? petWellnessPlan.getClinicWellnessPlan().getWellnessPlan().getService().getService()
					: "No Service Selected";
			appoinment.setService(service);

			if (petWellnessPlan.getClinicWellnessUpdate() != null) {
				Long dropdownId = petWellnessPlan.getClinicWellnessUpdate().getDropDown().getId();
				List<String> dropdownOptions = dropdownListRepository.findById(dropdownId).stream()
						.map(DropdownList::getDropdown).collect(Collectors.toList());
				appoinment.setDropdown(dropdownOptions);
			} else {
				appoinment.setDropdown(Collections.emptyList());
			}

			appoinments.add(appoinment);
		}

		return appoinments;
	}
	
	public String acceptPlanTermsAndConditions(Long managePetWellnessPlanId) {
		ManagePetWellnessPlans managePetPlans = managePetWellnessPlanRepository.findById(managePetWellnessPlanId).get();
		if(managePetPlans==null) {
			return "No manage pet plans id found";
		}
		managePetPlans.setPlanAcceptance(true);
		managePetWellnessPlanRepository.save(managePetPlans);
		return "Updated";
	}

}