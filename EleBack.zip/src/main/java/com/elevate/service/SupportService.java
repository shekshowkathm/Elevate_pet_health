package com.elevate.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elevate.dto.SupportDTO;
import com.elevate.dto.SupportResponseDTO;
import com.elevate.entity.ClinicDetails;
import com.elevate.entity.PetDetails;
import com.elevate.entity.Register;
import com.elevate.entity.Support;
import com.elevate.repository.IClinicDetailsRepository;
import com.elevate.repository.IPetDetailsRepository;
import com.elevate.repository.IRegisterRepository;
import com.elevate.repository.ISupportRepository;
import com.elevate.utils.EmailSender;

@Service
public class SupportService {

	@Autowired
	private ISupportRepository supportRepository;

	@Autowired
	private IRegisterRepository registrationRepository;

	@Autowired
	private IPetDetailsRepository petDetailsRepository;

	@Autowired
	private IClinicDetailsRepository clinicDetailsRepository;
	
	@Autowired
	private EmailSender emailSender;

	public String addSupport(Support support) {
		support.setStatus("Pending");
		supportRepository.save(support);
		return "Added";
	}

	public List<SupportDTO> getDetails(String email) {
		List<SupportDTO> supportDetails = new ArrayList<SupportDTO>();
		List<Support> supports = supportRepository.findByReceiver(email);

		for (Support support : supports) {
			SupportDTO supportDTO = new SupportDTO();
			Optional<Register> register = registrationRepository.findByEmail(support.getSender());
			Register details = register.get();
			supportDTO.setId(support.getId());
			supportDTO.setName(details.getFirstName() + " " + details.getLastName());
			supportDTO.setEmail(details.getEmail());
			supportDTO.setImage(details.getProfile());
			supportDTO.setMessage(support.getMessage());
			supportDTO.setPhonenumber(details.getContactNumber());
			if(support.getStatus().equals("Responded")) {
				supportDTO.setReplyMessage(support.getReplyMessage());
				supportDTO.setStatus(support.getStatus());
			}else {
				supportDTO.setStatus(support.getStatus());
			}
			supportDetails.add(supportDTO);
			
		}
		return supportDetails;
	}
	
	public void replyMessage(SupportResponseDTO supportResponse) {
		Support checkSupport = supportRepository.findById(supportResponse.getSupportId()).get();
		if(checkSupport!=null) {
			checkSupport.setReplyMessage(supportResponse.getReplyMessage());
			checkSupport.setStatus("Responded");
		}
		Register checkPetOwner = registrationRepository.findByEmail(checkSupport.getSender()).get();
		PetDetails checkClinic = petDetailsRepository.findByPetOwnerId(checkPetOwner.getId());
		supportRepository.save(checkSupport);
		emailSender.sendReplyEmail(checkSupport.getSender(), checkPetOwner.getFirstName() + " " + checkPetOwner.getLastName(), checkSupport.getIssue() , checkSupport.getReplyMessage(), checkClinic.getClinic().getClinicName() , checkSupport.getReceiver());
	}

	public Set<String> getCliniEmails(Long petOwnerId) {
		List<PetDetails> petDetails = petDetailsRepository.findByPetOwner_IdAndStatusIsTrue(petOwnerId);
		Set<String> clinicEmails = new HashSet<String>();
		for (PetDetails petDetail : petDetails) {
			ClinicDetails clinic = clinicDetailsRepository.findById(petDetail.getClinic().getId()).get();
			String email = clinic.getEmail();
			clinicEmails.add(email);
		}
		return clinicEmails;
	}
}
