package com.elevate.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elevate.dto.ClinicWeightRangeDTO;
import com.elevate.entity.ClinicWeightRange;
import com.elevate.entity.WeightRange;
import com.elevate.repository.IClinicWeightRangeRepository;
import com.elevate.repository.IWeightRangeRepository;

@Service
public class ClinicWeightRangeService {

	@Autowired
	private IClinicWeightRangeRepository clinicWeightRangeRepository;

	@Autowired
	private IWeightRangeRepository weightRangeRepository;

	public List<ClinicWeightRangeDTO> getClinicWeightRange(Long id) {
		List<ClinicWeightRange> clinicWeightRanges = clinicWeightRangeRepository.findAllByClinicId(id);

		List<ClinicWeightRangeDTO> results = new ArrayList<ClinicWeightRangeDTO>();
		for (ClinicWeightRange clinicWeightRange : clinicWeightRanges) {
			WeightRange weightRange = weightRangeRepository.findById(clinicWeightRange.getWeightRange().getId()).get();
			ClinicWeightRangeDTO dto = new ClinicWeightRangeDTO();
			dto.setPetType(weightRange.getPetType());
			dto.setWeight(weightRange.getWeight());
			dto.setSize(weightRange.getSize());
			dto.setUpdatedWeight(clinicWeightRange.getUpdatedWeight());
			dto.setClinicWeightRangeId(clinicWeightRange.getId());
			results.add(dto);
		}
		return results;
	}
	
	public String updateClinicWeightRange(Long id,String updateWeightRange) {
		ClinicWeightRange clinicWeightRange = clinicWeightRangeRepository.findById(id).get();
		clinicWeightRange.setUpdatedWeight(updateWeightRange);
		clinicWeightRangeRepository.save(clinicWeightRange);
		return "Updated";
	}
}
