package com.elevate.service;


import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.elevate.dto.TransactionDetailsDTO;
import com.elevate.entity.ClinicDetails;
import com.elevate.entity.Register;
import com.elevate.entity.TransactionDetails;
import com.elevate.repository.IClinicDetailsRepository;
import com.elevate.repository.IRegisterRepository;
import com.elevate.repository.ITransactionDetailsRepository;


import jakarta.persistence.NonUniqueResultException;


@Service
public class TransactionDetailsService {

    @Autowired
    ITransactionDetailsRepository transactionDetailsRepository;

    @Autowired
    IClinicDetailsRepository clinicDetailsRepository;

    @Autowired
    IRegisterRepository registerRepository;

    public ResponseEntity<?> getTransactionDetails(String customerId){
        List<TransactionDetailsDTO> details = new ArrayList<>();
       List <TransactionDetails> transactionDetailsList=transactionDetailsRepository.findByStripeCustomerIdAndCreatedAtDesc(customerId);
        if (transactionDetailsList.isEmpty()) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Transaction details is empty");
        }
        for(TransactionDetails transactionDetails:transactionDetailsList){
            ClinicDetails clinicDetails=clinicDetailsRepository.findByStripeAccountId(transactionDetails.getStripeConnectedAccountId()).get();
            Register register=registerRepository.findByStripeCustomerId(transactionDetails.getStripeCustomerId());
            TransactionDetailsDTO dto=new TransactionDetailsDTO();
            dto.setId(transactionDetails.getId());
            dto.setStripeCustomerId(transactionDetails.getStripeCustomerId());
            dto.setClinicName(clinicDetails.getClinicName());
            dto.setPetOwnerName(register.getFirstName());
            dto.setStripeConnectedAccountId(transactionDetails.getStripeConnectedAccountId());
            dto.setStripeSubscriptionId(transactionDetails.getStripeSubscriptionId());
            dto.setInvoiceNumber(transactionDetails.getInvoiceNumber());
            dto.setStripePaymentId(transactionDetails.getStripePaymentId());
            dto.setStripeInvoiceId(transactionDetails.getStripeInvoiceId());
            dto.setTotalAmount(transactionDetails.getTotalAmount());
            dto.setConnectedAccountReceived(transactionDetails.getConnectedAccountReceived());
            dto.setPlatformReceivedAmount(transactionDetails.getPlatformReceivedAmount());
            dto.setStripeFee(transactionDetails.getStripeFee());
            dto.setStripeTransferId(transactionDetails.getStripeTransferId());
            dto.setTransferStatus(transactionDetails.getTransferStatus());
            dto.setCustomerPaidDate(transactionDetails.getCustomerPaidDate());
            dto.setPaymentStatus(transactionDetails.getPaymentStatus());
            dto.setUrl(transactionDetails.getUrl());
            details.add(dto);
        }

        return ResponseEntity.status(HttpStatus.OK).body(details);
    }

    public ResponseEntity<?> getTransactionDetailsByStatus(){
        try {
            List<TransactionDetailsDTO> details = new ArrayList<>();
            String paymentStatus = "paid";
            List<TransactionDetails> transactionDetailsList = transactionDetailsRepository.findByPaymentStatusAndCreatedAtDesc(paymentStatus);
            for(TransactionDetails transactionDetails:transactionDetailsList) {
                System.out.println(transactionDetails.getStripeConnectedAccountId()+transactionDetails.getStripeCustomerId()+"uuuuuuuuuuuuuu");
                ClinicDetails clinicDetails=clinicDetailsRepository.findByStripeAccountId(transactionDetails.getStripeConnectedAccountId()).orElse(null);
                String clinicName = (clinicDetails != null) ? clinicDetails.getClinicName() : "Unknown Clinic";

                Register register= registerRepository.findByStripeCustomerId(transactionDetails.getStripeCustomerId());
                TransactionDetailsDTO dto = new TransactionDetailsDTO();
                dto.setId(transactionDetails.getId());
                dto.setStripeCustomerId(transactionDetails.getStripeCustomerId());
                dto.setClinicName(clinicName);
                dto.setPetOwnerName(register.getFirstName());
                dto.setStripeConnectedAccountId(transactionDetails.getStripeConnectedAccountId());
                dto.setStripeSubscriptionId(transactionDetails.getStripeSubscriptionId());
                dto.setStripePaymentId(transactionDetails.getStripePaymentId());
                dto.setStripeInvoiceId(transactionDetails.getStripeInvoiceId());
                dto.setInvoiceNumber(transactionDetails.getInvoiceNumber());
                dto.setTotalAmount(transactionDetails.getTotalAmount());
                dto.setConnectedAccountReceived(transactionDetails.getConnectedAccountReceived());
                dto.setPlatformReceivedAmount(transactionDetails.getPlatformReceivedAmount());
                dto.setStripeFee(transactionDetails.getStripeFee());
                dto.setStripeTransferId(transactionDetails.getStripeTransferId());
                dto.setTransferStatus(transactionDetails.getTransferStatus());
                dto.setCustomerPaidDate(transactionDetails.getCustomerPaidDate());
                dto.setPaymentStatus(transactionDetails.getPaymentStatus());
                dto.setDiscountAmount(transactionDetails.getDiscountAmount());
                dto.setStripeFeeElevate(transactionDetails.getStripeFeeElevate());
                dto.setStripeFeeClinic(transactionDetails.getStripeFeeClinic());
                details.add(dto);
            }
            return ResponseEntity.status(HttpStatus.OK).body(details);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server Error:"+e.getMessage());
        }
    }

    public ResponseEntity<?> getTotalByConnectedAcc(String accountId) {
        double total=0;
        try {
            LocalDateTime today = LocalDateTime.now();
            LocalDateTime startOfDay = today.toLocalDate().atStartOfDay();
            LocalDateTime endOfDay = today.toLocalDate().atTime(LocalTime.MAX);

            List<TransactionDetails> transactionDetails = transactionDetailsRepository.findByStripeConnectedAccountIdAndCreatedAtBetween(accountId, startOfDay, endOfDay);

            for (TransactionDetails transactionDetail : transactionDetails) {
                total = total + transactionDetail.getConnectedAccountReceived();
            }
        } catch (Exception e) {
            System.err.println("Failed to fetch upcoming invoice for subscription schedule: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage());
        }
        return ResponseEntity.status(HttpStatus.OK).body(total);
    }

    public ResponseEntity<?> getTotalByPlatform(){
        double total=0;
        try {
            LocalDateTime today = LocalDateTime.now();
            LocalDateTime startOfDay = today.toLocalDate().atStartOfDay();
            LocalDateTime endOfDay = today.toLocalDate().atTime(LocalTime.MAX);
            List<TransactionDetails> transactionDetails = transactionDetailsRepository.findByCreatedAtBetween(startOfDay, endOfDay);
            for (TransactionDetails transactionDetail : transactionDetails) {
                total = total + transactionDetail.getPlatformReceivedAmount();
            }
        } catch (Exception e) {
            System.err.println("Failed to fetch upcoming invoice for subscription schedule: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage());
        }
        return ResponseEntity.status(HttpStatus.OK).body(total);
    }

    public ResponseEntity<?> getTransactionDetailsByAccId(String accountId, String Status) {
        try {
            String paymentStatus = Status;
            List<TransactionDetails> transactionDetails = transactionDetailsRepository.findByStripeConnectedAccountIdAndPaymentStatusAndCreatedAtDesc(accountId, paymentStatus);
            return ResponseEntity.status(HttpStatus.OK).body(transactionDetails);
        } catch (Exception e) {
            System.err.println("Failed to fetch upcoming invoice for subscription schedule: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage());
        }
    }


    public ResponseEntity<?> getAllTransactions() {
        try {
         
            List<TransactionDetails> transactionDetailsList = transactionDetailsRepository.findAll();

            List<TransactionDetailsDTO> details = new ArrayList<>();
            for (TransactionDetails transactionDetails : transactionDetailsList) {
                if(transactionDetails.getStripeCustomerId() != null) {
                    ClinicDetails clinicDetails = clinicDetailsRepository.findByStripeAccountId(transactionDetails.getStripeConnectedAccountId()).orElse(null);
                    Register register = registerRepository.findByStripeCustomerId(transactionDetails.getStripeCustomerId());
                    TransactionDetailsDTO dto = new TransactionDetailsDTO();
                    dto.setId(transactionDetails.getId());
                    dto.setStripeCustomerId(transactionDetails.getStripeCustomerId());
                    dto.setClinicName(clinicDetails != null ? clinicDetails.getClinicName() : "Unknown Clinic");
                    dto.setPetOwnerName(register != null ? register.getFirstName() : "Unknown Owner");
                    dto.setStripeConnectedAccountId(transactionDetails.getStripeConnectedAccountId());
                    dto.setStripeSubscriptionId(transactionDetails.getStripeSubscriptionId());
                    dto.setStripePaymentId(transactionDetails.getStripePaymentId());
                    dto.setStripeInvoiceId(transactionDetails.getStripeInvoiceId());
                    dto.setInvoiceNumber(transactionDetails.getInvoiceNumber());
                    dto.setTotalAmount(transactionDetails.getTotalAmount());
                    dto.setConnectedAccountReceived(transactionDetails.getConnectedAccountReceived());
                    dto.setPlatformReceivedAmount(transactionDetails.getPlatformReceivedAmount());
                    dto.setStripeFee(transactionDetails.getStripeFee());
                    dto.setStripeTransferId(transactionDetails.getStripeTransferId());
                    dto.setTransferStatus(transactionDetails.getTransferStatus());
                    dto.setCustomerPaidDate(transactionDetails.getCustomerPaidDate());
                    dto.setPaymentStatus(transactionDetails.getPaymentStatus());
                    dto.setUrl(transactionDetails.getUrl());
                    dto.setDiscountAmount(transactionDetails.getDiscountAmount());
                    dto.setPaymentFailedMsg(transactionDetails.getPaymentFailedMsg());
                    dto.setStripeFee(transactionDetails.getStripeFee());
                    dto.setStripeFeeClinic(transactionDetails.getStripeFeeClinic());
                    dto.setStripeFeeElevate(transactionDetails.getStripeFeeElevate());
                    details.add(dto);
                }
            }
            return ResponseEntity.status(HttpStatus.OK).body(details);

        }catch (NonUniqueResultException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage());
        }  catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage());
        }
    }

    public ResponseEntity<?>getCustomerDetails(String customerId){
        try {
            String paymentStatus = "open";
            List<TransactionDetails> transactionDetails =
                    transactionDetailsRepository.findByStripeCustomerIdAndPaymentStatus(customerId, paymentStatus);
            return ResponseEntity.status(HttpStatus.OK).body(transactionDetails);
        } catch (Exception e) {
            System.err.println("Failed to fetch upcoming invoice for subscription schedule: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage());
        }
   }

   public ResponseEntity<?>getclinicPaymentsDetails(Long salesRepId){
       try {
           List<ClinicDetails> clinics = clinicDetailsRepository.findBySalesRepId(salesRepId);
           if (clinics.isEmpty()) {
               return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No clinics found for the given Sales Rep ID");
           }
           List<TransactionDetails> allTransactions = new ArrayList<>();
           for (ClinicDetails clinic : clinics) {
               String paymentStatus = "paid";
               List<TransactionDetails> transactions = transactionDetailsRepository.findByStripeConnectedAccountIdAndPaymentStatusAndCreatedAtDesc(clinic.getStripeAccountId(),paymentStatus);
               if (transactions != null) {
                   allTransactions.addAll(transactions);
               }
           }

           return ResponseEntity.ok(allTransactions);
       } catch (Exception e) {
           e.printStackTrace();
           return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage());
       }

   }

   public ResponseEntity<?>getPaymentStatus(Long id){
       try {
           List<TransactionDetails> allTransactions = new ArrayList<>();
           Optional<TransactionDetails> transactionDetailsOpt = transactionDetailsRepository.findById(id);

           transactionDetailsOpt.ifPresent(allTransactions::add);

           if (allTransactions.isEmpty()) {
               return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Transaction not found");
           }

           return ResponseEntity.ok(allTransactions);
   } catch (Exception e) {
        e.printStackTrace();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage());
    }

}

}
