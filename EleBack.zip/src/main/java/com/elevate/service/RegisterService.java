package com.elevate.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.elevate.dto.ClinicRegister;
import com.elevate.dto.Email;
import com.elevate.dto.ForgetPassword;
import com.elevate.dto.GetClinicInfoDTO;
import com.elevate.dto.SalesRepDTO;
import com.elevate.dto.UpdatePassword;
import com.elevate.dto.UpdateRegister;
import com.elevate.entity.ClinicDetails;
import com.elevate.entity.Register;
import com.elevate.repository.IClinicDetailsRepository;
import com.elevate.repository.IRegisterRepository;
import com.elevate.utils.EmailSender;
import com.elevate.utils.GeneratePassword;
import com.elevate.utils.USDateFormat;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;

@Service
public class RegisterService {

	@Autowired
	private IRegisterRepository registerRepository;

	@Autowired
	private IClinicDetailsRepository clinicRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private EmailSender emailSender;

	private final Cache<String, String> otpCache = CacheBuilder.newBuilder().expireAfterWrite(5, TimeUnit.MINUTES)
			.build();

	public Register addSuperAdmin(Register register) {
		register.setPassword(passwordEncoder.encode(register.getPassword()));
		register.setCreated_On(USDateFormat.dateFormat());
		register.setRegisterStatus(true);
		return registerRepository.save(register);
	}

	public ResponseEntity<String> add(Register register) {
		Optional<Register> registerIsExist = registerRepository.findByEmail(register.getEmail());
		if (registerIsExist.isPresent()) {
			return new ResponseEntity<>("Email Already Exists", HttpStatus.CONFLICT);
		} else {
			String generatedPassword = GeneratePassword.generateRandomPassword(8);
			String newPassword = passwordEncoder.encode(generatedPassword);
			register.setCreated_On(USDateFormat.dateFormat());
			register.setState(register.getState());
			register.setCity(register.getCity());
			register.setZipcode(register.getZipcode());
			register.setFirstName(register.getFirstName());
			register.setLastName(register.getLastName());
			register.setContactNumber(register.getContactNumber());
			register.setTimezone(register.getTimezone());
			register.setRegisterStatus(true);
			register.setPassword(newPassword);
			registerRepository.save(register);
			emailSender.sendEmail(register.getEmail(), welcomeEmail(register, generatedPassword));
			return new ResponseEntity<>("Sales Rep Added", HttpStatus.CREATED);
		}
	}

	public String updateRegStatus(Long regId ) {
		Register register = registerRepository.findById(regId).get();

		if (register.isRegisterStatus() == false) {
			String generatedPassword = GeneratePassword.generateRandomPassword(8);
			String newPassword = passwordEncoder.encode(generatedPassword);
			register.setPassword(newPassword);
			register.setRegisterStatus(true);
//            try {
//               String connectedCustomer = stripeConnect.createConnectedCustomer(reg.getStripeAccountId(),register.getFirstName(),register.getEmail());
//				register.setStripeCustomerId(connectedCustomer);
//				PetDetails existingPetDetails=petDetailsRepository.findByPetOwnerId(regId);
//				existingPetDetails.setStripeCustomerId(connectedCustomer);
//				petDetailsRepository.save(existingPetDetails);
//            } catch (Exception e) {
//                throw new RuntimeException(e);
//            }
			registerRepository.save(register);
			emailSender.sendEmail(register.getEmail(), welcomeEmail(register, generatedPassword));
		}
		return "UPDATED";
	}

	public List<ClinicRegister> notVerifiedRegisters() {
		List<Register> registers = registerRepository.findByRegisterStatusIsFalseAndRole("CLINIC_OWNER");
		List<ClinicRegister> clinicRequest = new ArrayList<>();
		Set<Long> processedClinicIds = new HashSet<>();

		if (registers != null && !registers.isEmpty()) {
			for (Register register : registers) {
				ClinicDetails clinic = clinicRepository.findByClinicOwner_Id(register.getId());
				if (clinic != null && !processedClinicIds.contains(clinic.getId())) {
					ClinicRegister clinicRequestObj = new ClinicRegister();
					clinicRequestObj.setClinicId(clinic.getId());
					clinicRequestObj.setClinicOwnerFirstName(register.getFirstName());
					clinicRequestObj.setClinicOwnerLastName(register.getLastName());
					clinicRequestObj.setStartDate(register.getCreated_On());
					clinicRequestObj.setRegisterId(register.getId());
					clinicRequestObj.setClinicName(clinic.getClinicName());
					clinicRequestObj.setClinicAddress(clinic.getAddress());
					clinicRequestObj.setContact(clinic.getContactNumber());
					clinicRequestObj.setClinicEmail(clinic.getEmail());
					clinicRequestObj.setZipCode(clinic.getZipCode());
					clinicRequestObj.setRegisterStatus(register.isRegisterStatus());
					clinicRequest.add(clinicRequestObj);
				    clinicRequestObj.setClinicOwnerEmail(register.getEmail());

					processedClinicIds.add(clinic.getId());
				}
			}
		}

		List<ClinicDetails> clinics = clinicRepository.findByClinicStatusIsFalse();
		for (ClinicDetails clinic : clinics) {
			if (!processedClinicIds.contains(clinic.getId())) {
				Register clinicOwner = registerRepository.findById(clinic.getClinicOwner().getId()).orElse(null);
				if (clinicOwner != null) {
					ClinicRegister clinicRegisterDTO = new ClinicRegister();
					clinicRegisterDTO.setClinicId(clinic.getId());
					clinicRegisterDTO.setClinicOwnerFirstName(clinicOwner.getFirstName());
					clinicRegisterDTO.setClinicOwnerLastName(clinicOwner.getLastName());
					clinicRegisterDTO.setEmail(clinicOwner.getEmail());
					clinicRegisterDTO.setClinicEmail(clinic.getEmail());
					clinicRegisterDTO.setClinicName(clinic.getClinicName());
					clinicRegisterDTO.setClinicAddress(clinic.getAddress());
					clinicRegisterDTO.setContact(clinic.getContactNumber());
					clinicRegisterDTO.setZipCode(clinic.getZipCode());
					clinicRegisterDTO.setCity(clinic.getCity());
					clinicRegisterDTO.setRegisterId(clinicOwner.getId());
					clinicRegisterDTO.setRole(clinicOwner.getRole());
					clinicRegisterDTO.setRegisterStatus(clinicOwner.isRegisterStatus());
					clinicRegisterDTO.setStartDate(clinicOwner.getCreated_On());
					clinicRequest.add(clinicRegisterDTO);

					processedClinicIds.add(clinic.getId());
				}
			}
		}
		return clinicRequest;
	}

	public String updatePassword(UpdatePassword updatePassword) {
		Register register = registerRepository.findById(updatePassword.getRegId()).get();
		if (register.isTermsAndConditions() == false) {
			return "Can't update";
		} else {
			register.setPassword(passwordEncoder.encode(updatePassword.getPassword()));
			registerRepository.save(register);
			return "updated";
		}
	}

	public String updateTermsAndConditiond(long regId) {
		Register register = registerRepository.findById(regId).get();
		register.setTermsAndConditions(true);
		registerRepository.save(register);
		return "updated";
	}

	public String updateProfile(UpdateRegister updateRegister) {
		Register register = registerRepository.findById(updateRegister.getId()).get();
		register.setFirstName(updateRegister.getFirstName());
		register.setLastName(updateRegister.getLastName());
//		register.setEmail(updateRegister.getEmail());
		register.setContactNumber(updateRegister.getContactNumber());
		register.setProfile(updateRegister.getProfile());
		register.setDesignation(updateRegister.getDesignation());
		register.setDoctor(updateRegister.isDoctor());
		register.setState(updateRegister.getState());
		register.setCity(updateRegister.getCity());
		register.setZipcode(updateRegister.getZipcode());
		register.setTimezone(updateRegister.getTimezone());
		register.setAddress(updateRegister.getAddress());
		registerRepository.save(register);
		return "Updated";
	}

	// Private methods
	private Email welcomeEmail(Register register, String generatePassword) {
		Email email = new Email();
		email.setLoginUrl("login");
		email.setPassword(generatePassword);
		email.setEmail(register.getEmail());
		return email;
	}

	public List<SalesRepDTO> getSalesRep() {
		List<Register> registers = registerRepository.findByRegisterStatusIsTrueAndRole("SALES_REP");

		List<SalesRepDTO> salesReps = new ArrayList<SalesRepDTO>();

		for (Register register : registers) {
			SalesRepDTO salesRep = new SalesRepDTO();
			salesRep.setId(register.getId());
			salesRep.setAddress(register.getAddress());
			salesRep.setCity(register.getCity());
			salesRep.setFirstName(register.getFirstName());
			salesRep.setLastName(register.getLastName());
			salesRep.setState(register.getState());
			salesReps.add(salesRep);
		}
		return salesReps;
	}

	public SalesRepDTO getSalesRepById(Long id) {
		Register salesRep = registerRepository.findById(id).get();

		SalesRepDTO dto = new SalesRepDTO();
		dto.setId(salesRep.getId());
		dto.setFirstName(salesRep.getFirstName());
		dto.setLastName(salesRep.getLastName());
		dto.setAddress(salesRep.getAddress());
		dto.setState(salesRep.getState());
		dto.setEmail(salesRep.getEmail());
		dto.setContactNumber(salesRep.getContactNumber());

		return dto;
	}

	public String checkEmailForPasswordChange(String email) {
		if (registerRepository.existsByEmail(email)) {
			String otp = createOtp();
			otpCache.put(email, otp);
			emailSender.sendOtpMail(email, otp);
			return "OTP generated and sent";
		} else {
			return "Email Not Exist";
		}
	}

	public String verifyOtp(String email, String otp) {
		String chachedOtp = otpCache.getIfPresent(email);
		if (chachedOtp != null && chachedOtp.equals(otp)) {
			otpCache.invalidate(email);
			return "OTP Verified Successfully , Procees to change password";
		} else {
			return "Invalid or expired Password";
		}
	}

	public String createOtp() {
		Random randomotp = new Random();
		int otp = 100000 + randomotp.nextInt(900000);
		return Integer.toString(otp);
	}

	public String forgetPassword(ForgetPassword forgetpassword) {
		Register registerUser = registerRepository.findByEmail(forgetpassword.getEmail()).get();
		if (registerUser != null) {
			registerUser.setPassword(passwordEncoder.encode(forgetpassword.getPassword()));
			registerRepository.save(registerUser);
			return "Updated Successfully";
		}
		return "Not updated";

	}

	public List<SalesRepDTO> getActiveSalesRep() {
		List<Register> registerList = registerRepository.findByRole("SALES_REP");
		List<SalesRepDTO> registerDTOList = new ArrayList<>();
		for (Register register : registerList) {
			SalesRepDTO dto = new SalesRepDTO();
			dto.setId(register.getId());
			dto.setFirstName(register.getFirstName());
			dto.setLastName(register.getLastName());
			dto.setAddress(register.getAddress());
			dto.setCity(register.getCity());
			dto.setState(register.getState());
			dto.setEmail(register.getEmail());
			dto.setContactNumber(register.getContactNumber());
			dto.setRegisterStatus(register.isRegisterStatus());
			dto.setProfile(register.getProfile());
			registerDTOList.add(dto);
		}
		return registerDTOList;
	}

	public List<String> getAllDoctors() {
		List<Register> allDcotorsList = registerRepository.findByDoctorTrue();
		List<String> doctors = new ArrayList<String>();
		for (Register register : allDcotorsList) {
			String fullName = register.getFirstName() + " " + register.getLastName();
			doctors.add(fullName);
		}
		return doctors;
	}

	public String updateStatus(Long regId) {
		Register register = registerRepository.findById(regId).get();
		register.setRegisterStatus(!register.isRegisterStatus());
		registerRepository.save(register);
		return "updated";
	}
	
	public void sendClinicInfoEmail(GetClinicInfoDTO clinicInfo) {
		emailSender.sendClinicInfoEmail(clinicInfo);
	}
}