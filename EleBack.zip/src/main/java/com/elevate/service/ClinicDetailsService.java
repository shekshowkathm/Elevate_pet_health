package com.elevate.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import com.elevate.Enum.Status;
import com.elevate.config.StripeConnect;
import com.elevate.dto.*;
import com.elevate.entity.*;
import com.elevate.repository.*;
import com.stripe.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.elevate.utils.Agegroup;
import com.elevate.utils.CalculateAge;
import com.elevate.utils.EmailSender;
import com.elevate.utils.GeneratePassword;
import com.elevate.utils.USDateFormat;

@Service
public class ClinicDetailsService {

	@Value("${Stripe.apiKey}")
	private String apiKey;

	@Autowired
	private IClinicDetailsRepository clinicDetailsRepository;

	@Autowired
	private IRegisterRepository registerRepository;

	@Autowired
	private EmailSender emailSender;

	@Autowired
	private IPetDetailsRepository petDetailsRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private EmailSender emalSender;

	@Autowired
	private StripeConnect stripeConnect;

	@Autowired
	private IWeightRangeRepository weightRangeRepository;

	@Autowired
	private IClinicWeightRangeRepository clinicWeightRangeRepository;

	@Autowired
	private IWellnessPlanRepository wellnessPlanRepository;

	@Autowired
	private IClinicWellnessPlanRepository clinicWellnessPlanRepository;

	@Autowired
	private IClinicWellnessUpdateRepository clinicWellnessPlanUpdateRepository;

	@Autowired
	private IRecommendationRepository recommendationRepository;

	@Autowired
	private IPetWellnessPlanRepository petWellnessPlanRepository;

	@Autowired
	private IPetBreedAgeRepository petBreedAgeRepository;

	@Autowired
	private IPromotionDiscountRepository promotionDiscountRepository;

	@Autowired
	private ITransactionDetailsRepository transactionDetailsRepository;

	@Autowired
	private IManagePetWellnessPlansRepository managePetWellnessPlanRepository;

	public ResponseEntity<String> clinicRegister(ClinicRegister clinicRegister) {
		List<Register> registers = registerRepository.findByRole("SUPER_ADMIN");
		if (registerRepository.existsByEmail(clinicRegister.getEmail())) {
			return new ResponseEntity<>("Email Already Exists", HttpStatus.CONFLICT);
		}
		Register register = new Register();
		register.setEmail(clinicRegister.getEmail());
		register.setCreated_On(USDateFormat.dateFormat());
		register.setRole(clinicRegister.getRole());
		register.setTimezone(clinicRegister.getTimezone());
		register.setFirstName(clinicRegister.getClinicOwnerFirstName());
		register.setLastName(clinicRegister.getClinicOwnerLastName());
		Register registerObj = registerRepository.save(register);

		ClinicDetails clinic = new ClinicDetails();
		clinic.setEmail(clinicRegister.getEmail());
		clinic.setClinicName(clinicRegister.getClinicName());
		clinic.setAddress(clinicRegister.getClinicAddress());
		clinic.setContactNumber(clinicRegister.getContact());
		clinic.setZipCode(clinicRegister.getZipCode());
		clinic.setCity(clinicRegister.getCity());
		clinic.setCreatedOn(USDateFormat.dateFormat());
		clinic.setState(clinicRegister.getState());
		clinic.setClinicOwner(registerObj);
		clinic.setClinicImage(
				"https://elevatepethealth-imagestorage.s3.us-east-1.amazonaws.com/media/6198c0067db6520001bc3618.jpg");
		clinic.setHeadquater(clinicRegister.isHeadquater());
		clinic.setHeadquaters(clinicRegister.getHeadquaters());
		clinicDetailsRepository.save(clinic);
		for (Register super_admin : registers) {
			emailSender.sendAlertEmail(super_admin.getEmail(), clinicRegister);
		}
		return new ResponseEntity<>("REQUEST SUBMITTED", HttpStatus.ACCEPTED);
	}

	public ResponseEntity<String> addClinic(ClinicDetailsDTO clinicDetailsDTO) {

		var clinic = clinicDetailsRepository.findByEmail(clinicDetailsDTO.getEmail());
		var user = registerRepository.findByEmail(clinicDetailsDTO.getEmail());
		if (clinic != null || user.isPresent()) {
			if (user.isPresent()) {
				String role = user.get().getRole();
				return ResponseEntity.status(HttpStatus.CONFLICT)
						.body("Email already exists as " + role + ". Please enter a new clinic email.");
			} else {
				return ResponseEntity.status(HttpStatus.CONFLICT)
						.body("Email already exists as a Clinic. Please enter a new clinic email.");
			}
		}

		ClinicDetails clinicDetails = new ClinicDetails();
		clinicDetails.setAddress(clinicDetailsDTO.getAddress());
		clinicDetails.setCity(clinicDetailsDTO.getCity());
		clinicDetails.setZipCode(clinicDetailsDTO.getZipCode());
		clinicDetails.setClinicName(clinicDetailsDTO.getClinicName());
		clinicDetails.setState(clinicDetailsDTO.getState());
		Register register = registerRepository.findById(clinicDetailsDTO.getClinicOwnerId()).get();
		clinicDetails.setClinicOwner(register);
		clinicDetails.setCreatedOn(USDateFormat.dateFormat());
		clinicDetails.setContactNumber(clinicDetailsDTO.getContactNumber());
		clinicDetails.setEmail(clinicDetailsDTO.getEmail());
		clinicDetails.setHeadquater(clinicDetailsDTO.isHeadquater());
		clinicDetails.setHeadquaters(clinicDetailsDTO.getHeadquaters());
		clinicDetails.setClinicImage(
				"https://elevatepethealth-imagestorage.s3.us-east-1.amazonaws.com/media/6198c0067db6520001bc3618.jpg");

		clinicDetailsRepository.save(clinicDetails);

		return ResponseEntity.status(HttpStatus.CREATED).body("Added new Clinic");
	}
	public String updateStatus(Long clinicid, Long regId) {
		ClinicDetails clinic = clinicDetailsRepository.findById(clinicid).get();
		clinic.setClinicStatus(true);
		clinic.setStartDate(USDateFormat.dateFormat());
		Register register = registerRepository.findById(regId).get();
		clinic.setSalesRep(register);
//		try {
//			Account account = stripeConnect.createConnectedAccount(clinic.getEmail());
//			String accountLink = stripeConnect.createAccountLink(account.getId());
//			emalSender.stripAccountCreationMail(clinic.getEmail(), clinic.getClinicName(), accountLink);
//			clinic.setStripeAccountId(account.getId());
//		} catch (Exception e) {
//			throw new RuntimeException(e);
//		}
		clinicDetailsRepository.save(clinic);
		List<WeightRange> weightRanges = weightRangeRepository.findByStatusIsTrue();
		for (WeightRange weightRange : weightRanges) {
			ClinicWeightRange clinicWeightRange = new ClinicWeightRange();
			clinicWeightRange.setWeightRange(weightRange);
			clinicWeightRange.setClinic(clinic);
			clinicWeightRangeRepository.save(clinicWeightRange);
		}
		List<WellnessPlan> wellnessPlan = wellnessPlanRepository.findByStatusIsTrue();
		for (WellnessPlan wellnessPlanObj : wellnessPlan) {
			ClinicWellnessPlan clinicWellnessPlan = new ClinicWellnessPlan();
			clinicWellnessPlan.setClinic(clinic);
			clinicWellnessPlan.setWellnessPlan(wellnessPlanObj);

			List<ClinicWellnessUpdate> wellnessUpdateList = new ArrayList<ClinicWellnessUpdate>();
			for (Recommendation recommendation : wellnessPlanObj.getRecommendation()) {
				Recommendation recommendationObj = recommendationRepository.findById(recommendation.getId()).get();
				ClinicWellnessUpdate wellnessUpdate = new ClinicWellnessUpdate();
				wellnessUpdate.setDropDown(recommendationObj.getDropdownList());
				clinicWellnessPlanUpdateRepository.save(wellnessUpdate);
				wellnessUpdateList.add(wellnessUpdate);
			}
			clinicWellnessPlan.setWellnessUpdate(wellnessUpdateList);
			clinicWellnessPlanRepository.save(clinicWellnessPlan);
		}

		return "UPDATED";
	}

	public ResponseEntity<String> updateClinicDetails(ClinicDetailsDTO updatedClinicDetailsDto) {
		ClinicDetails existingClinicDetails = clinicDetailsRepository.findById(updatedClinicDetailsDto.getId())
				.orElseThrow(() -> new RuntimeException("Clinic details not found"));

		existingClinicDetails.setEmail(updatedClinicDetailsDto.getEmail());
		if (existingClinicDetails.getClinicName() != updatedClinicDetailsDto.getClinicName()) {
			List<ClinicDetails> clinics = clinicDetailsRepository
					.findByHeadquaters(existingClinicDetails.getClinicName());
			for (ClinicDetails clinicDetails : clinics) {
				clinicDetails.setHeadquaters(updatedClinicDetailsDto.getClinicName());
				clinicDetailsRepository.save(clinicDetails);
			}
		}
		existingClinicDetails.setClinicName(updatedClinicDetailsDto.getClinicName());

		existingClinicDetails.setAddress(updatedClinicDetailsDto.getAddress());
		existingClinicDetails.setZipCode(updatedClinicDetailsDto.getZipCode());
		existingClinicDetails.setContactNumber(updatedClinicDetailsDto.getContactNumber());
		existingClinicDetails.setClinicImage(updatedClinicDetailsDto.getClinicImage());
		existingClinicDetails.setHeadquater(updatedClinicDetailsDto.isHeadquater());
		existingClinicDetails.setState(updatedClinicDetailsDto.getState());
		existingClinicDetails.setCity(updatedClinicDetailsDto.getCity());
		existingClinicDetails.setClinicLogo(updatedClinicDetailsDto.getClinicLogo());
		existingClinicDetails.setSocialLinkOne(updatedClinicDetailsDto.getSocialLinkOne());
		existingClinicDetails.setSocialLinkTwo(updatedClinicDetailsDto.getSocialLinkTwo());
		existingClinicDetails.setSocialLinkThree(updatedClinicDetailsDto.getSocialLinkThree());
		existingClinicDetails.setSocialLinkFour(updatedClinicDetailsDto.getSocialLinkFour());
		clinicDetailsRepository.save(existingClinicDetails);
		return ResponseEntity.ok("Clinic details updated successfully");
	}

	public List<ClinicDetailsDTO> findAllByClinicStatusTrue() {
		List<ClinicDetails> activeClinics = clinicDetailsRepository.findByClinicStatusIsTrue();

		return activeClinics.stream().map(clinic -> {
			ClinicDetailsDTO dto = new ClinicDetailsDTO();
			dto.setId(clinic.getId());
			dto.setClinicName(clinic.getClinicName());
			dto.setAddress(clinic.getAddress());
			dto.setZipCode(clinic.getZipCode());
			dto.setCity(clinic.getCity());
			dto.setState(clinic.getState());
			dto.setHeadquater(clinic.isHeadquater());
			dto.setClinicStatus(clinic.isClinicStatus());
			return dto;
		}).collect(Collectors.toList());
	}

	public ClinicDetailsDTO getClinicDetails(Long clinicId) {
		ClinicDetails clinic = clinicDetailsRepository.findById(clinicId).get();
		ClinicDetailsDTO dto = new ClinicDetailsDTO();
		dto.setId(clinic.getId());
		dto.setClinicImage(clinic.getClinicImage());
		dto.setClinicName(clinic.getClinicName());
		dto.setAddress(clinic.getAddress());
		dto.setZipCode(clinic.getZipCode());
		dto.setContactNumber(clinic.getContactNumber());
		dto.setCity(clinic.getCity());
		dto.setEmail(clinic.getEmail());
		dto.setState(clinic.getState());
		dto.setStartDate(clinic.getStartDate());
		dto.setEndDate(clinic.getEndDate());
		dto.setClinicStatus(clinic.isClinicStatus());
		dto.setQrCode(clinic.getQrCode());
		dto.setHeadquater(clinic.isHeadquater());
		dto.setHeadquaters(clinic.getHeadquaters());
		dto.setClinicLogo(clinic.getClinicLogo());
		dto.setSocialLinkOne(clinic.getSocialLinkOne());
		dto.setSocialLinkTwo(clinic.getSocialLinkTwo());
		dto.setSocialLinkThree(clinic.getSocialLinkThree());
		dto.setSocialLinkFour(clinic.getSocialLinkFour());

		if (clinic.getSalesRep() != null) {
			dto.setSalesRepId(clinic.getSalesRep().getId());
			dto.setSalesRepFirstName(clinic.getSalesRep().getFirstName());
			dto.setSalesRepLastName(clinic.getSalesRep().getLastName());
		}
		if (clinic.getClinicAdmin() != null) {
			dto.setClinicAdminId(clinic.getClinicAdmin().getId());
		}
		return dto;
	}

	public List<ClinicAssociatesDTO> getAssociates(Long clinicId) {
		ClinicDetails clinic = clinicDetailsRepository.findById(clinicId).get();
		List<ClinicAssociatesDTO> clinicAssociates = new ArrayList<ClinicAssociatesDTO>();
		for (Register associates : clinic.getClinicAssociate()) {
			Register register = registerRepository.findById(associates.getId()).get();
			ClinicAssociatesDTO clinicAssociate = new ClinicAssociatesDTO();
			clinicAssociate.setId(register.getId());
			clinicAssociate.setEmail(register.getEmail());
			clinicAssociate.setFirstName(register.getFirstName());
			clinicAssociate.setLastName(register.getLastName());
			clinicAssociate.setProfile(register.getProfile());
			clinicAssociate.setDesignation(register.getDesignation());
			clinicAssociate.setContact(register.getContactNumber());
			clinicAssociate.setCity(register.getCity());
			clinicAssociate.setState(register.getState());
			clinicAssociate.setZipcode(register.getZipcode());
			clinicAssociates.add(clinicAssociate);
		}
		return clinicAssociates;
	}

	public ClinicAdminDTO getClinicAdmins(Long clinicId) {
		ClinicDetails clinic = clinicDetailsRepository.findById(clinicId).get();
		if (clinic != null) {
			Register register = registerRepository.findById(clinic.getClinicAdmin().getId()).get();
			ClinicAdminDTO clinicAdmin = new ClinicAdminDTO();
			clinicAdmin.setId(register.getId());
			clinicAdmin.setEmail(register.getEmail());
			clinicAdmin.setProfile(register.getProfile());
			clinicAdmin.setCity(clinic.getCity());
			clinicAdmin.setClinicName(clinic.getClinicName());
			clinicAdmin.setFirstName(register.getFirstName());
			clinicAdmin.setLastName(register.getLastName());
			clinicAdmin.setZipcode(register.getZipcode());
			clinicAdmin.setState(register.getState());
			return clinicAdmin;
		}
		return null;
	}

	public List<PetDetailsDTO> getPetDetails(Long clinicId) {
		List<PetDetails> pets = petDetailsRepository.findByClinic_IdAndStatusTrue(clinicId);
		List<PetDetailsDTO> petDetails = new ArrayList<>();
		for (PetDetails details : pets) {
			PetDetailsDTO dto = new PetDetailsDTO();
			dto.setId(details.getId());
			dto.setAgeGroup(details.getAgeGroup());
			dto.setPetBreed(details.getPetBreed());
			dto.setPetName(details.getPetName());
			dto.setPetType(details.getPetType());
			dto.setWeight(details.getWeight());
			dto.setProfile(details.getImage());

			if (details.getWeight() != null && details.getPetType() != null) {
				try {
					double weight = Double.parseDouble(details.getWeight().replace("lb", "").trim());
					String size = weightRangeRepository.findSizeByPetTypeAndWeight(details.getPetType(), weight);
					dto.setPetSize(size);
				} catch (NumberFormatException | NullPointerException e) {
					dto.setPetSize(null);
				}
			}

			List<PetWellnessPlan> checkPlans = petWellnessPlanRepository.findByPetId_Id(details.getId());
			if (checkPlans != null) {
				for (PetWellnessPlan plan : checkPlans) {
					dto.setPlanStatus(plan.getWorkFlowStatus());
//					dto.setPending(plan.isPending());
//					dto.setConfirmedPlan(plan.isConfirmed());
				}
			}

			Register register = registerRepository.findById(details.getPetOwner().getId()).get();
			if (register != null) {
				dto.setCity(register.getCity());
				dto.setContact(register.getContactNumber());
				dto.setEmail(register.getEmail());
				dto.setOwnerFirstName(register.getFirstName());
				dto.setOwnerLastName(register.getLastName());
				dto.setOwnerId(register.getId());
				dto.setState(register.getState());
			}

			ClinicDetails clinicDetails = clinicDetailsRepository.findById(clinicId).get();
			if (clinicDetails != null) {
				dto.setClinicCity(clinicDetails.getCity());
				dto.setClinicEmail(clinicDetails.getEmail());
				dto.setClinicName(clinicDetails.getClinicName());
				dto.setClinicState(clinicDetails.getState());
			}
			petDetails.add(dto);

		}
		return petDetails;
	}

	public String updateClinicMembers(Long clinicId, Long regId, String role) {
		Optional<ClinicDetails> clinicOptional = clinicDetailsRepository.findById(clinicId);
		Optional<Register> registerOptional = registerRepository.findById(regId);

		if (!clinicOptional.isPresent() || !registerOptional.isPresent()) {
			return "Invalid clinic or register ID";
		}
		if (!clinicOptional.isPresent() || !registerOptional.isPresent()) {
			return "Invalid clinic or register ID";
		}

		ClinicDetails clinic = clinicOptional.get();
		Register register = registerOptional.get();

		if ("CLINIC_ASSOCIATE".equals(role)) {
			List<Register> associates = clinic.getClinicAssociate();
			associates.add(register);
			clinic.setClinicAssociate(associates);
			clinicDetailsRepository.save(clinic);
		} else if ("CLINIC_ADMIN".equals(role)) {
			clinic.setClinicAdmin(register);
			clinicDetailsRepository.save(clinic);
		} else if ("SALES_REP".equals(role)) {
			clinic.setSalesRep(register);
			clinicDetailsRepository.save(clinic);
		} else {
			return "Role not matched";
		}
		return "updated";
	}

	public List<ClinicDetailsDTO> getClinicdetailsByRole(Long regId, String role) {
		List<ClinicDetails> clinicDetails = new ArrayList<ClinicDetails>();

		if ("CLINIC_OWNER".equals(role)) {
			clinicDetails = clinicDetailsRepository.findByClinicOwnerId(regId);
		} else if ("CLINIC_ADMIN".equals(role)) {
			clinicDetails = clinicDetailsRepository.findByClinicAdminId(regId);
		} else if ("SALES_REP".equals(role)) {
			clinicDetails = clinicDetailsRepository.findBySalesRepId(regId);
		} else {
			clinicDetails = clinicDetailsRepository.findByClinicAssociateId(regId); // Associate
		}

		List<ClinicDetailsDTO> clinicDetailsDTO = new ArrayList<>();

		for (ClinicDetails clinics : clinicDetails) {
			if (clinics.isClinicStatus() == true) {
				ClinicDetailsDTO dto = new ClinicDetailsDTO();
				dto.setId(clinics.getId());
				dto.setClinicName(clinics.getClinicName());
				dto.setEmail(clinics.getEmail());
				dto.setAddress(clinics.getAddress());
				dto.setCity(clinics.getCity());
				dto.setContactNumber(clinics.getContactNumber());
				dto.setClinicImage(clinics.getClinicImage());
				dto.setState(clinics.getState());
				dto.setHeadquater(clinics.isHeadquater());
				dto.setStripeAccountId(clinics.getStripeAccountId());
				dto.setHeadquaters(clinics.getHeadquaters());
				clinicDetailsDTO.add(dto);
			}
		}
		return clinicDetailsDTO;
	}

	public ResponseEntity<String> addClinicAdminAndAssociate(ClinicAdminRegisterDTO clinicRegisterDTO) {
		if (registerRepository.existsByEmail(clinicRegisterDTO.getEmail())) {
			return new ResponseEntity<>("Email Already Exists", HttpStatus.CONFLICT);
		}

		String password = GeneratePassword.generateRandomPassword(8);
		String encodedPassword = passwordEncoder.encode(password);

		Register register = new Register();
		register.setEmail(clinicRegisterDTO.getEmail());
		register.setCreated_On(USDateFormat.dateFormat());
		register.setPassword(encodedPassword);
		register.setAddress(clinicRegisterDTO.getAddress());
		register.setState(clinicRegisterDTO.getState());
		register.setCity(clinicRegisterDTO.getCity());
		register.setZipcode(clinicRegisterDTO.getZipcode());
		register.setFirstName(clinicRegisterDTO.getFirstName());
		register.setLastName(clinicRegisterDTO.getLastName());
		register.setRole(clinicRegisterDTO.getRole());
		register.setDoctor(clinicRegisterDTO.isDoctor());
		register.setTimezone(clinicRegisterDTO.getTimezone());
		register.setContactNumber(clinicRegisterDTO.getContactNumber());
		register.setDesignation(clinicRegisterDTO.getDesignation());
		Register checkRegister = registerRepository.findById(clinicRegisterDTO.getCreatedBy().getId()).get();
		register.setCreated_By(checkRegister);
		register.setRegisterStatus(true);

		if (clinicRegisterDTO.getRole().equals("CLINIC_ADMIN")) {
			ClinicDetails checkClinic = clinicDetailsRepository.findById(clinicRegisterDTO.getClinicId().getId()).get();
			if (checkClinic.getClinicAdmin() != null) {
				return new ResponseEntity<>("Admin Already Present", HttpStatus.CONFLICT);
			}
			checkClinic.setClinicAdmin(register);
			registerRepository.save(register);
			clinicDetailsRepository.save(checkClinic);
			emalSender.sendEmail(clinicRegisterDTO.getEmail(), welcomeEmail(clinicRegisterDTO, password));
			return new ResponseEntity<>("Admin Created", HttpStatus.CREATED);
		} else if (clinicRegisterDTO.getRole().equals("CLINIC_ASSOCIATE")) {
			ClinicDetails clinic = clinicDetailsRepository.findById(clinicRegisterDTO.getClinicId().getId()).get();
			clinic.getClinicAssociate().add(register);
			registerRepository.save(register);
			clinicDetailsRepository.save(clinic);
			emalSender.sendEmail(clinicRegisterDTO.getEmail(), welcomeEmail(clinicRegisterDTO, password));
			return new ResponseEntity<>("Associate Added", HttpStatus.CREATED);
		}
		return new ResponseEntity<>("Added Successfully", HttpStatus.CREATED);
	}

	private Email welcomeEmail(ClinicAdminRegisterDTO register, String generatePassword) {
		Email email = new Email();
		email.setLoginUrl("login");
		email.setPassword(generatePassword);
		email.setEmail(register.getEmail());
		return email;
	}

	public List<ClinicAdminDTO> getAllClinicMembersByRole(String role) {
		List<Register> registeredUsersDetails = registerRepository.findByRoleAndRegisterStatusIsTrue(role);
		List<ClinicAdminDTO> details = new ArrayList<>();
		for (Register register : registeredUsersDetails) {
			List<ClinicDetails> clinics = new ArrayList<>();
			if ("CLINIC_OWNER".equals(role)) {
				clinics = clinicDetailsRepository.findByClinicOwnerId(register.getId());
			} else if ("CLINIC_ADMIN".equals(role)) {
				clinics = clinicDetailsRepository.findByClinicAdminId(register.getId());
			} else if ("CLINIC_ASSOCIATE".equals(role)) {
				clinics = clinicDetailsRepository.findByClinicAssociateId(register.getId());
			}
			for (ClinicDetails clinic : clinics) {
				ClinicAdminDTO dto = new ClinicAdminDTO();
				dto.setEmail(register.getEmail());
				dto.setId(register.getId());
				dto.setFirstName(register.getFirstName());
				dto.setLastName(register.getLastName());
				dto.setProfile(register.getProfile());
				dto.setState(clinic.getState());
				dto.setCity(clinic.getCity());
				dto.setZipcode(clinic.getZipCode());
				dto.setContactNumber(clinic.getContactNumber());
				dto.setClinicName(clinic.getClinicName());
				dto.setClinicEmail(clinic.getEmail());
				dto.setStatus(clinic.isClinicStatus());
				if ("CLINIC_ASSOCIATE".equals(role)) {
					dto.setDesignation(register.getDesignation());
				}
				details.add(dto);
			}
		}
		return details;
	}

	public List<ClinicAssociatesDTO> getAllClinicAssociate() {
		List<Register> register = registerRepository.findByRoleAndRegisterStatusIsTrue("CLINIC_ASSOCIATE");
		List<ClinicAssociatesDTO> clinicAssociates = new ArrayList<>();

		for (Register associates : register) {
			List<ClinicDetails> clinics = clinicDetailsRepository.findByClinicAssociateId(associates.getId());

			for (ClinicDetails clinicDetails : clinics) {
				ClinicAssociatesDTO dto = new ClinicAssociatesDTO();
				dto.setId(associates.getId());
				dto.setEmail(associates.getEmail());
				dto.setFirstName(associates.getFirstName());
				dto.setLastName(associates.getLastName());
				dto.setContact(associates.getContactNumber());
				dto.setCity(associates.getCity());
				dto.setState(associates.getState());
				dto.setZipcode(associates.getZipcode());
				dto.setDesignation(associates.getDesignation());
				dto.setProfile(associates.getProfile());

				dto.setClinicEmail(clinicDetails.getEmail());
				dto.setClinicName(clinicDetails.getClinicName());
				clinicAssociates.add(dto);
			}
		}
		return clinicAssociates;
	}

	public ClinicRollDTO getRegisterById(Long id) {
		// Fetching Register entity from the repository
		Register register = registerRepository.findById(id).get();

		// Mapping entity to DTO
		ClinicRollDTO dto = new ClinicRollDTO();
		dto.setId(register.getId());
		dto.setFirstName(register.getFirstName());
		dto.setLastName(register.getLastName());
		dto.setEmail(register.getEmail());
		dto.setDoctor(register.isDoctor());
		dto.setProfile(register.getProfile());
		dto.setTimezone(register.getTimezone());
		dto.setDesignation(register.getDesignation());
		dto.setContactNumber(register.getContactNumber());
		dto.setState(register.getState());
		dto.setCity(register.getCity());
		dto.setZipcode(register.getZipcode());
		dto.setAddress(register.getAddress());
		dto.setStartDate(register.getCreated_On());
		dto.setDoctorsHistory(getDoctorsHistoryInPlans(register.getId()));
		return dto;
	}

	private List<DoctorsHistory> getDoctorsHistoryInPlans(Long regId) {
		Optional<Register> doctorOptional = registerRepository.findByDoctorTrueAndId(regId);

		if (doctorOptional.isEmpty()) {
			return Collections.emptyList();
		}

		Register doctor = doctorOptional.get();

		List<ClinicDetails> clinicOwnerList = clinicDetailsRepository.findByClinicOwnerId(doctor.getId());
		List<ClinicDetails> clinicAdminList = clinicDetailsRepository.findByClinicAdminId(doctor.getId());
		List<ClinicDetails> clinicAssociateList = clinicDetailsRepository.findByClinicAssociateId(doctor.getId());

		Set<ClinicDetails> allClinics = new HashSet<>();
		allClinics.addAll(clinicOwnerList);
		allClinics.addAll(clinicAdminList);
		allClinics.addAll(clinicAssociateList);

		List<DoctorsHistory> doctorsHistoryList = new ArrayList<>();

		List<PetWellnessPlan> fulfilledPlans = petWellnessPlanRepository
				.findByWorkFlowStatusAndFulfilledBy(Status.FULFILLED, doctor.getId());

		for (PetWellnessPlan plan : fulfilledPlans) {
			DoctorsHistory history = new DoctorsHistory();

			history.setClinicName(plan.getClinicWellnessPlan().getClinic().getClinicName());
			history.setDoctorPercentage(plan.getClinicWellnessUpdate().getDoctorPercentage());
			history.setDropdownName(plan.getClinicWellnessUpdate().getDropDown().getDropdown());
			history.setFulfilledOn(plan.getScheduledDateAndTime().toString());
			history.setFulfilledStatus(plan.getWorkFlowStatus().name());
			history.setRegId(doctor.getId());
			history.setServiceName(plan.getClinicWellnessPlan().getWellnessPlan().getService().getService());
			history.setPetName(plan.getPetId().getPetName());

			TransactionDetails transaction = transactionDetailsRepository
					.findByStripeCustomerId(plan.getPetId().getStripeCustomerId());
			if (transaction != null) {
				history.setPaidAmount(transaction.getConnectedAccountReceived());
			}

			doctorsHistoryList.add(history);
		}

		return doctorsHistoryList;
	}

	public List<ClinicListDTO> getClinicList() {
		List<ClinicListDTO> clinicList = new ArrayList<>();

		List<ClinicDetails> clinics = clinicDetailsRepository.findAll();

		clinics.forEach((clinic) -> {
			String clinicAdminEmail = null;
			if (clinic.getClinicAdmin() != null) {
				Register clinicAdmin = registerRepository.findById(clinic.getClinicAdmin().getId()).orElse(null);
				clinicAdminEmail = clinicAdmin != null ? clinicAdmin.getEmail() : null;
			}

			String clinicOwnerEmail = null;
			if (clinic.getClinicOwner() != null) {
				Register clinicOwner = registerRepository.findById(clinic.getClinicOwner().getId()).orElse(null);
				clinicOwnerEmail = clinicOwner != null ? clinicOwner.getEmail() : null;
			}

			String salesRepName = null;
			if (clinic.getSalesRep() != null) {
				Register salesRep = registerRepository.findById(clinic.getSalesRep().getId()).orElse(null);
				if (salesRep.isRegisterStatus() == true) {
					salesRepName = salesRep != null ? salesRep.getFirstName() + " " + salesRep.getLastName() : null;
				} else {
					salesRepName = "Update";
				}

			}

			ClinicListDTO clinicListDTO = new ClinicListDTO();
			clinicListDTO.setId(clinic.getId());
			clinicListDTO.setClinicName(clinic.getClinicName());
			clinicListDTO.setClinicImage(clinic.getClinicImage());
			clinicListDTO.setClinicEmail(clinic.getEmail());
			clinicListDTO.setAddress(clinic.getAddress());
			clinicListDTO.setZipCode(clinic.getZipCode());
			clinicListDTO.setContactNumber(clinic.getContactNumber());
			clinicListDTO.setCity(clinic.getCity());
			clinicListDTO.setClinicOwnerEmail(clinicOwnerEmail);
			clinicListDTO.setClinicAdminEmail(clinicAdminEmail);
			clinicListDTO.setSalesRepName(salesRepName);
			clinicListDTO.setState(clinic.getState());
			clinicListDTO.setHeadquater(clinic.isHeadquater());
			clinicListDTO.setHeadquaters(clinic.getHeadquaters());
			clinicListDTO.setStatus(clinic.isClinicStatus());
			clinicListDTO.setStripeAccountId(clinic.getStripeAccountId());
			clinicListDTO.setStripeStatus(clinic.isStripeStatus());

			Long petOwnerCount = petDetailsRepository.findByClinic_Id(clinic.getId()).stream()
					.map(PetDetails::getPetOwner).distinct().count();

			clinicListDTO.setPetOwnerCount(petOwnerCount);

			Long wellnessPlanCount = clinicWellnessPlanRepository
					.countByClinic_IdAndWellnessUpdate_StatusTrue(clinic.getId());
			clinicListDTO.setWellnessPlanCount(wellnessPlanCount);

			List<String> promotionTypes = promotionDiscountRepository.findByClinic_IdAndStatusTrue(clinic.getId())
					.stream().map(PromotionDiscount::getPromotionType).toList();
			clinicListDTO.setDiscount(promotionTypes);
			clinicList.add(clinicListDTO);
		});

		return clinicList;
	}

	public ResponseEntity<String> addClinicBySuperAdmin(ClinicDetailsDTO clinicDetails) {
		boolean register = registerRepository.existsByEmail(clinicDetails.getEmail());
		if (register) {
			return new ResponseEntity<>("Email already exist", HttpStatus.CONFLICT);
		} else {
			ClinicDetails clinic = new ClinicDetails();
			clinic.setAddress(clinicDetails.getAddress());
			clinic.setCity(clinicDetails.getCity());
			clinic.setState(clinicDetails.getState());
			clinic.setZipCode(clinicDetails.getZipCode());
			clinic.setClinicName(clinicDetails.getClinicName());
			clinic.setClinicStatus(true);
			if (clinicDetails.getSalesRepId() != null) {
				Register salesRep = registerRepository.findById(clinicDetails.getSalesRepId()).orElse(null);
				if (salesRep != null) {
					clinic.setSalesRep(salesRep);
				}
			}
			Register reg = new Register();
			try {
				Account account = stripeConnect.createConnectedAccount(clinicDetails.getEmail());
				String accountLink = stripeConnect.createAccountLink(account.getId());
				emalSender.stripAccountCreationMail(clinicDetails.getEmail(), clinicDetails.getClinicName(),
						accountLink);
				clinic.setStripeAccountId(account.getId());
				reg.setStripeAccountId(account.getId());
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
			reg.setEmail(clinicDetails.getEmail());
			reg.setCreated_On(USDateFormat.dateFormat());
			reg.setRegisterStatus(true);
			reg.setContactNumber(clinicDetails.getContactNumber());
			Register superAdminRegister = registerRepository.findById(clinicDetails.getSuperAdminId()).get();
			reg.setCreated_By(superAdminRegister);
			reg.setZipcode(clinicDetails.getZipCode());
			reg.setRole("CLINIC_OWNER");
			String password = GeneratePassword.generateRandomPassword(8);
			String encodedPassword = passwordEncoder.encode(password);
			reg.setPassword(encodedPassword);
			Register regDetail = registerRepository.save(reg);
			emalSender.sendEmail(clinicDetails.getEmail(), welcomeEmail(regDetail, password));
			clinic.setClinicOwner(regDetail);
			clinic.setCreatedOn(USDateFormat.dateFormat());
			clinic.setContactNumber(clinicDetails.getContactNumber());
			clinic.setEmail(clinicDetails.getEmail());
			clinic.setHeadquater(clinicDetails.isHeadquater());
			clinic.setHeadquaters(clinicDetails.getHeadquaters());
			clinic.setStartDate(USDateFormat.dateFormat());
			clinicDetailsRepository.save(clinic);

			return new ResponseEntity<>("Added new Clinic", HttpStatus.CREATED);
		}
	}

	// Private methods

	private Email welcomeEmail(Register register, String generatePassword) {
		Email email = new Email();
		email.setLoginUrl("login");
		email.setPassword(generatePassword);
		email.setEmail(register.getEmail());
		return email;
	}

	public List<ClinicListDTO> getClinicsByClinicOwnerId(Long clinicOwnerId) {
		List<ClinicDetails> clinicDetailsList = clinicDetailsRepository.findByClinicOwnerId(clinicOwnerId);
		List<ClinicListDTO> clinicListDTOs = new ArrayList<>();

		for (ClinicDetails clinicDetails : clinicDetailsList) {
			ClinicListDTO clinicDTO = new ClinicListDTO();
			clinicDTO.setId(clinicDetails.getId());
			clinicDTO.setClinicName(clinicDetails.getClinicName());
			clinicDTO.setClinicEmail(clinicDetails.getEmail());
			clinicDTO.setState(clinicDetails.getState());
			clinicDTO.setCity(clinicDetails.getCity());
			clinicDTO.setClinicImage(clinicDetails.getClinicImage());
			clinicDTO.setContactNumber(clinicDetails.getContactNumber());
			clinicDTO.setZipCode(clinicDetails.getZipCode());
			clinicDTO.setAddress(clinicDetails.getAddress());
			clinicDTO.setSalesRepName(
					clinicDetails.getSalesRep().getFirstName() + " " + clinicDetails.getSalesRep().getLastName());
			clinicDTO.setStatus(clinicDetails.isClinicStatus());

			List<PetDetails> petDetails = petDetailsRepository.findByClinic_Id(clinicDetails.getId());
			long petOwnerCount = (petDetails != null) ? petDetails.size() : 0L;
			clinicDTO.setPetOwnerCount(petOwnerCount);

			if (clinicDetails.getClinicAdmin() != null) {
				clinicDTO.setClinicAdminEmail(clinicDetails.getClinicAdmin().getEmail());
			}
			clinicListDTOs.add(clinicDTO);
		}
		return clinicListDTOs;
	}

	public ClinicUser getClinicmemberslist(Long clinicId) {

		ClinicDetails clinic = clinicDetailsRepository.findById(clinicId).orElse(null);

		if (clinic == null) {
			return null;
		}

		ClinicUser clinicUsers = new ClinicUser();

		ClinicUser.User clinicOwner = Optional.ofNullable(clinic.getClinicOwner()).map(owner -> {
			ClinicUser.User user = new ClinicUser.User();
			user.setId(owner.getId());
			user.setEmail(owner.getEmail());
			user.setContactNumber(owner.getContactNumber());
			user.setFirstName(owner.getFirstName());
			user.setLastName(owner.getLastName());
			return user;
		}).orElse(null);

		ClinicUser.User clinicAdmin = Optional.ofNullable(clinic.getClinicAdmin()).map(admin -> {
			ClinicUser.User user = new ClinicUser.User();
			user.setId(admin.getId());
			user.setEmail(admin.getEmail());
			user.setContactNumber(admin.getContactNumber());
			user.setFirstName(admin.getFirstName());
			user.setLastName(admin.getLastName());
			return user;
		}).orElse(null);

		List<ClinicUser.User> clinicAssociates = Optional.ofNullable(clinic.getClinicAssociate())
				.map(associates -> associates.stream().map(associate -> {
					ClinicUser.User user = new ClinicUser.User();
					user.setId(associate.getId());
					user.setEmail(associate.getEmail());
					user.setContactNumber(associate.getContactNumber());
					user.setFirstName(associate.getFirstName());
					user.setLastName(associate.getLastName());
					return user;
				}).collect(Collectors.toList())).orElse(Collections.emptyList());

		clinicUsers.setClinicOwner(clinicOwner);
		clinicUsers.setClinicAdmin(clinicAdmin);
		clinicUsers.setClinicAssociateList(clinicAssociates);

		return clinicUsers;
	}

	public List<ClinicListDTO> getClinicBySalesRep(Long salesRepId) {
		Register register = registerRepository.findById(salesRepId).get();
		if (register.isRegisterStatus()) {
			List<ClinicDetails> clinics = clinicDetailsRepository.findBySalesRepId(salesRepId);
			return clinics.stream().map(clinic -> {
				ClinicListDTO dto = new ClinicListDTO();

				dto.setId(clinic.getId());
				dto.setClinicName(clinic.getClinicName());
				dto.setAddress(clinic.getAddress());
				dto.setZipCode(clinic.getZipCode());
				dto.setCity(clinic.getCity());
				dto.setState(clinic.getState());
				dto.setContactNumber(clinic.getContactNumber());
				dto.setClinicEmail(clinic.getEmail());
				dto.setClinicImage(clinic.getClinicImage());
				dto.setStatus(clinic.isClinicStatus());
				dto.setHeadquater(clinic.isHeadquater());
				dto.setHeadquaters(clinic.getHeadquaters());
				if (clinic.getClinicOwner() != null) {
					dto.setClinicOwnerEmail(clinic.getClinicOwner().getEmail());
				}

				if (clinic.getClinicAdmin() != null) {
					dto.setClinicAdminEmail(clinic.getClinicAdmin().getEmail());
				}

				List<PetDetails> petDetailsList = petDetailsRepository.findByClinic_Id(clinic.getId());
				long petOwnerCount = petDetailsList.stream().map(PetDetails::getPetOwner).filter(Objects::nonNull)
						.distinct().count();

				dto.setPetOwnerCount(petOwnerCount);

				Long wellnessPlanCount = clinicWellnessPlanRepository
						.countByClinic_IdAndWellnessUpdate_StatusTrue(clinic.getId());
				dto.setWellnessPlanCount(wellnessPlanCount);

				List<String> promotionTypes = promotionDiscountRepository.findByClinic_IdAndStatusTrue(clinic.getId())
						.stream().map(PromotionDiscount::getPromotionType).toList();
				dto.setDiscount(promotionTypes);

				return dto;

			}).collect(Collectors.toList());
		}
		return new ArrayList<>();
	}

	public String adminAccess(AdminAccessDTO adminAccess) {
		ClinicDetails checkAdmin = clinicDetailsRepository.findByClinicAdmin_Id(adminAccess.getClinicAdminId());
		if (checkAdmin != null) {
			checkAdmin.setUpdateWeightRange(adminAccess.isUpdateWeightRange());
			checkAdmin.setUpdateRecommendation(adminAccess.isUpdateRecommendation());
			checkAdmin.setUpdateClinicPrice(adminAccess.isUpdateClinicPrice());
			checkAdmin.setUpdateDiscountPercentage(adminAccess.isUpdateDiscountPercentage());
			checkAdmin.setUpdateDiscountPrice(adminAccess.isUpdateDiscountPrice());
			checkAdmin.setUpdateDoctorPercentage(adminAccess.isUpdateDoctorPercentage());
			checkAdmin.setViewPayment(adminAccess.isViewPayment());
			clinicDetailsRepository.save(checkAdmin);
			return "Updated";
		} else {
			return "Admin Id is Not found";
		}
	}

	public AdminAccessDTO getAccessOfAdmin(Long clinicAdminId) {
		ClinicDetails clinicAdmin = clinicDetailsRepository.findByClinicAdmin_Id(clinicAdminId);
		if (clinicAdmin != null) {
			AdminAccessDTO adminAccess = new AdminAccessDTO();
			adminAccess.setClinicAdminId(clinicAdminId);
			adminAccess.setUpdateClinicPrice(clinicAdmin.isUpdateClinicPrice());
			adminAccess.setUpdateDiscountPercentage(clinicAdmin.isUpdateDiscountPercentage());
			adminAccess.setUpdateDiscountPrice(clinicAdmin.isUpdateDiscountPrice());
			adminAccess.setUpdateDoctorPercentage(clinicAdmin.isUpdateDoctorPercentage());
			adminAccess.setUpdateRecommendation(clinicAdmin.isUpdateRecommendation());
			adminAccess.setUpdateWeightRange(clinicAdmin.isUpdateWeightRange());
			adminAccess.setViewPayment(clinicAdmin.isViewPayment());
			return adminAccess;
		}
		return null;
	}

	public Set<ClinicAdminDTO> getUsersByRoleUnderSalesRep(Long salesRepId, String role) {
		List<ClinicDetails> clinics = clinicDetailsRepository.findBySalesRepId(salesRepId);
		Set<ClinicAdminDTO> usersDTO = new HashSet<>();

		if (role == null) {
			return usersDTO;
		}

		clinics.forEach(clinic -> {
			switch (role) {
			case "CLINIC_OWNER" -> {
				if (clinic.getClinicOwner() != null) {
					ClinicAdminDTO dto = buildClinicAdminDTO(clinic, clinic.getClinicOwner());
					usersDTO.add(dto);
				}
			}
			case "CLINIC_ADMIN" -> {
				if (clinic.getClinicAdmin() != null) {
					ClinicAdminDTO dto = buildClinicAdminDTO(clinic, clinic.getClinicAdmin());
					usersDTO.add(dto);
				}
			}
			case "CLINIC_ASSOCIATE" -> {
				if (clinic.getClinicAssociate() != null) {
					clinic.getClinicAssociate().forEach(associate -> {
						ClinicAdminDTO dto = buildClinicAdminDTO(clinic, associate);
						usersDTO.add(dto);
					});
				}
			}
			case "PET_OWNER" -> {
				List<PetDetails> petDetailsList = petDetailsRepository.findByClinic_Id(clinic.getId());
				List<Long> petOwnerIds = petDetailsList.stream().map(PetDetails::getPetOwner).filter(Objects::nonNull)
						.map(Register::getId).distinct().collect(Collectors.toList());

				List<Register> petOwners = registerRepository.findAllById(petOwnerIds);

				petOwners.forEach(petOwner -> {
					petDetailsList.stream()
							.filter(petDetail -> petDetail.getPetOwner().getId().equals(petOwner.getId()))
							.forEach(petDetail -> {
								ClinicAdminDTO dto = buildClinicAdminDTO(clinic, petOwner);
								dto.setPetId(petDetail.getId());
								dto.setPetName(petDetail.getPetName());
								dto.setPetType(petDetail.getPetType());
								usersDTO.add(dto);
							});
				});
			}
			}
		});

		return usersDTO;
	}

	private ClinicAdminDTO buildClinicAdminDTO(ClinicDetails clinic, Register user) {
		ClinicAdminDTO dto = new ClinicAdminDTO();
		dto.setId(user.getId());
		dto.setFirstName(user.getFirstName());
		dto.setLastName(user.getLastName());
		dto.setEmail(user.getEmail());
		dto.setClinicName(clinic.getClinicName());
		dto.setCity(clinic.getCity());
		dto.setProfile(user.getProfile());
		dto.setState(clinic.getState());
		dto.setContactNumber(clinic.getContactNumber());
		dto.setClinicEmail(clinic.getEmail());
		dto.setDesignation(user.getDesignation());
		dto.setStatus(user.isRegisterStatus());
		return dto;
	}

	public Set<String> getHeadquaterClinics() {
		List<ClinicDetails> clinics = clinicDetailsRepository.findByHeadquaterIsTrueAndClinicStatusIsTrue();
		Set<String> headQuaters = new HashSet<String>();
		for (ClinicDetails clinic : clinics) {
			String headQuater;
			headQuater = clinic.getClinicName();
			headQuaters.add(headQuater);
		}
		return headQuaters;
	}

	public PetDetailsWithOwnersDTO getSinglePetDetailsWithOwner(Long petId, Long petOwnerId) {
		Register checkPetOwner = registerRepository.findById(petOwnerId).orElse(null);
		PetDetails checkPet = petDetailsRepository.findById(petId).orElse(null);

		if (checkPetOwner == null || checkPet == null) {
			return new PetDetailsWithOwnersDTO();
		}

		PetDetailsWithOwnersDTO petDetails = new PetDetailsWithOwnersDTO();
		setPetOwnerDetails(petDetails, checkPetOwner);
		setPetDetails(petDetails, checkPet);

		LocalDate currentDate = LocalDate.now();

		List<Status> statuses = Arrays.asList(Status.ACTIVE, Status.FULFILLED);
		List<PetWellnessPlan> plans = petWellnessPlanRepository.findByPetIdAndWorkFlowStatusIn(checkPet.getId(),
				statuses);

		if (plans == null || plans.isEmpty()) {
			return petDetails;
		}

		List<GetPetWellnessPlanDTO> historical = new ArrayList<>();
		List<GetPetWellnessPlanDTO> ongoing = new ArrayList<>();
		List<GetPetWellnessPlanDTO> future = new ArrayList<>();

		for (PetWellnessPlan plan : plans) {
			GetPetWellnessPlanDTO planDTO = mapToGetPetWellnessPlanDTO(plan, checkPet);

			LocalDate startDate = LocalDate.parse(planDTO.getStartDate());
			LocalDate endDate = LocalDate.parse(planDTO.getEndDate());

			if (endDate.isBefore(currentDate)) {
				historical.add(planDTO);
			} else if (startDate.isBefore(currentDate) && endDate.isAfter(currentDate)) {
				ongoing.add(planDTO);
			} else if (startDate.isAfter(currentDate)) {
				future.add(planDTO);
			} else if (startDate.isEqual(currentDate)) {
				ongoing.add(planDTO);
			}
		}

		petDetails.setHistoryPlans(categorizePlans(historical));
		petDetails.setOngoingPlans(categorizePlans(ongoing));
		petDetails.setFuturePlans(categorizePlans(future));

		return petDetails;
	}

	private Map<Integer, List<GetPetWellnessPlanDTO>> categorizePlans(List<GetPetWellnessPlanDTO> plans) {
		Map<Long, List<GetPetWellnessPlanDTO>> groupedPlans = new HashMap<>();

		for (GetPetWellnessPlanDTO plan : plans) {
			Long manageId = plan.getManagePetWellnessPlan();
			ManagePetWellnessPlans managePetWellnessPlans = managePetWellnessPlanRepository.findById(manageId).get();
			List<String> promotions = new ArrayList<String>();
			for (PromotionDiscount promotionDiscount : managePetWellnessPlans.getPromotionDiscounts()) {
				promotions.add(promotionDiscount.getPromotionType());
			}
			plan.setPromotions(promotions);
			groupedPlans.computeIfAbsent(manageId, k -> new ArrayList<>()).add(plan);
		}

		Map<Integer, List<GetPetWellnessPlanDTO>> dynamicSets = new HashMap<>();

		List<Map.Entry<Long, List<GetPetWellnessPlanDTO>>> sortedEntries = new ArrayList<>(groupedPlans.entrySet());
		sortedEntries.sort(Map.Entry.comparingByKey());

		for (int i = 0; i < sortedEntries.size() && i < 4; i++) {
			dynamicSets.put(i + 1, sortedEntries.get(i).getValue());
		}

		return dynamicSets;
	}

	private void setPetOwnerDetails(PetDetailsWithOwnersDTO petDetails, Register checkPetOwner) {
		petDetails.setPetOwnerId(checkPetOwner.getId());
		petDetails.setPetOwnerFirstName(checkPetOwner.getFirstName());
		petDetails.setPetOwnerLastName(checkPetOwner.getLastName());
		petDetails.setPetOwnerEmail(checkPetOwner.getEmail());
		petDetails.setPetOwnerContact(checkPetOwner.getContactNumber());
		petDetails.setPetOwnerAddress(checkPetOwner.getAddress());
		petDetails.setPetOwnerState(checkPetOwner.getState());
		petDetails.setPetOwnerCity(checkPetOwner.getCity());
		petDetails.setPetOwnerZipcode(checkPetOwner.getZipcode());
		petDetails.setPetOwnerImage(checkPetOwner.getProfile());
		petDetails.setPetOwnerStartDate(checkPetOwner.getCreated_On());
		petDetails.setPetOwnerEndDate(null);

	}

	private void setPetDetails(PetDetailsWithOwnersDTO petDetails, PetDetails checkPet) {
		petDetails.setPetId(checkPet.getId());
		petDetails.setPetName(checkPet.getPetName());
		petDetails.setPetGender(checkPet.getGender());
		petDetails.setPetType(checkPet.getPetType());
		petDetails.setPetBreed(checkPet.getPetBreed());
		petDetails.setPetAge(CalculateAge.petAge(checkPet.getDob()));
		petDetails.setPetDOB(checkPet.getDob());
		petDetails.setPetSize(determinePetSize(checkPet));
		petDetails.setPetProfile(checkPet.getImage());
		petDetails.setPetWeight(checkPet.getWeight());
		if (petDetails.getStartDate() != null) {
			LocalDate startDate = checkPet.getStartDate();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			petDetails.setStartDate(startDate.format(formatter));
		} else {
			petDetails.setStartDate(null);
		}
		petDetails.setEndDate(null);
//		petDetails.setStripeSubscriptionId(checkPet.getStripeSubscriptionId());
		petDetails.setStripeCustomerId(checkPet.getStripeCustomerId());
		if (checkPet.getPetType() != null && checkPet.getPetBreed() != null) {
			List<PetBreedAge> petBreedAges = petBreedAgeRepository.findByPetTypeAndBreed(checkPet.getPetType(),
					checkPet.getPetBreed());
			if (!petBreedAges.isEmpty()) {
				PetBreedAge petBreedAge = petBreedAges.get(0);
				petDetails.setAgeGroup(
						Agegroup.determineAgeCategory(CalculateAge.petAgeByMonth(checkPet.getDob()), petBreedAge));
			}
		}
	}

	private GetPetWellnessPlanDTO mapToGetPetWellnessPlanDTO(PetWellnessPlan wellnessPlan, PetDetails checkPet) {
		GetPetWellnessPlanDTO dto = new GetPetWellnessPlanDTO();

		dto.setPetId(checkPet.getId());
		dto.setPetWellnessPlanId(wellnessPlan.getId());
		dto.setClinicWellnessPlan(wellnessPlan.getClinicWellnessPlan().getId());
		dto.setClinicWellnessUpdate(wellnessPlan.getClinicWellnessUpdate().getId());
		dto.setStartDate(wellnessPlan.getManagePetWellnessPlan().getStartDate());
		dto.setEndDate(wellnessPlan.getManagePetWellnessPlan().getEndDate());
		dto.setManagePetWellnessPlan(wellnessPlan.getManagePetWellnessPlan().getId());
		dto.setStatus(wellnessPlan.getWorkFlowStatus().name());
		if (wellnessPlan.getScheduledDateAndTime() != null) {
			dto.setScheduledDateAndTime(wellnessPlan.getScheduledDateAndTime().toString());
		} else {
			dto.setScheduledDateAndTime(null);
		}

		List<PetBreedAge> petBreedAges = petBreedAgeRepository.findByPetTypeAndBreed(checkPet.getPetType(),
				checkPet.getPetBreed());
		if (!petBreedAges.isEmpty()) {
			PetBreedAge petBreedAge = petBreedAges.get(0);
			dto.setAgeGroup(Agegroup.determineAgeCategory(CalculateAge.petAgeByMonth(checkPet.getDob()), petBreedAge));
		}

		String petSize = determinePetSize(checkPet);
		if ("QTY".equalsIgnoreCase(wellnessPlan.getClinicWellnessUpdate().getDropDown().getPriceBased())) {
			dto.setDiscountPrice(wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForQuantity());
			dto.setUpdatedPrice(wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForQuantity());
		} else if ("WGT".equalsIgnoreCase(wellnessPlan.getClinicWellnessUpdate().getDropDown().getPriceBased())) {
			setPriceBasedOnPetSize(dto, wellnessPlan, petSize);
		}

		if (wellnessPlan.getFulfilledBy() != null) {
			DoctorDTO doctorDTO = new DoctorDTO();
			doctorDTO.setRegId(wellnessPlan.getFulfilledBy());
			Register getDoctorName = registerRepository.findById(wellnessPlan.getFulfilledBy()).orElse(null);
			if (getDoctorName != null) {
				doctorDTO.setDoctorName(getDoctorName.getFirstName() + " " + getDoctorName.getLastName());
			}
			dto.setFulfilledBy(doctorDTO);
		}

		DropdownList dropdown = wellnessPlan.getClinicWellnessUpdate().getDropDown();
		if (dropdown != null) {
			dto.setDropdownName(dropdown.getDropdown());
		}
		dto.setPetType(wellnessPlan.getPetId().getPetType());
		ServiceList service = wellnessPlan.getClinicWellnessPlan().getWellnessPlan().getService();
		if (service != null) {
			dto.setServiceName(service.getService());
		}
		dto.setWellnessPlanName(wellnessPlan.getClinicWellnessPlan().getWellnessPlan().getWellnessPlanName());

		return dto;
	}

	private String determinePetSize(PetDetails checkPet) {
		String petSize = null;
		if (checkPet.getWeight() != null && checkPet.getPetType() != null) {
			try {
				double weight = Double.parseDouble(checkPet.getWeight().replace("lb", "").trim());
				petSize = weightRangeRepository.findSizeByPetTypeAndWeight(checkPet.getPetType(), weight);
			} catch (NumberFormatException | NullPointerException e) {
				petSize = null;
			}
		}
		return petSize;
	}

	private void setPriceBasedOnPetSize(GetPetWellnessPlanDTO dto, PetWellnessPlan wellnessPlan, String petSize) {
		switch (petSize.toUpperCase()) {
		case "SMALL":
			dto.setDiscountPrice(wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForSmall());
			dto.setUpdatedPrice(wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForSmall());
			break;
		case "MEDIUM":
			dto.setDiscountPrice(wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForMedium());
			dto.setUpdatedPrice(wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForMedium());
			break;
		case "LARGE":
			dto.setDiscountPrice(wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForLarge());
			dto.setUpdatedPrice(wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForLarge());
			break;
		case "X-LARGE":
			dto.setDiscountPrice(wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForXLarge());
			dto.setUpdatedPrice(wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForXLarge());
			break;
		}
	}

	public String UpdateSalesRepInClinic(Long clinicId, Long regId) {
		ClinicDetails clinic = clinicDetailsRepository.findById(clinicId).get();
		Register register = registerRepository.findById(regId).get();
		clinic.setSalesRep(register);
		clinicDetailsRepository.save(clinic);
		return "updated";
	}

	public List<DoctorDTO> getDoctorsByClinicId(Long clinicId) {
		ClinicDetails clinicDetails = clinicDetailsRepository.findById(clinicId).get();
		List<DoctorDTO> doctorList = new ArrayList<>();

		if (clinicDetails == null) {
			return doctorList;
		}

		if (clinicDetails.getClinicOwner() != null && clinicDetails.getClinicOwner().isDoctor()) {
			DoctorDTO ownerDTO = new DoctorDTO();
			ownerDTO.setRegId(clinicDetails.getClinicOwner().getId());
			ownerDTO.setDoctorName(
					clinicDetails.getClinicOwner().getFirstName() + " " + clinicDetails.getClinicOwner().getLastName());
			doctorList.add(ownerDTO);
		}

		if (clinicDetails.getClinicAdmin() != null && clinicDetails.getClinicAdmin().isDoctor()) {
			DoctorDTO adminDTO = new DoctorDTO();
			adminDTO.setRegId(clinicDetails.getClinicAdmin().getId());
			adminDTO.setDoctorName(
					clinicDetails.getClinicAdmin().getFirstName() + " " + clinicDetails.getClinicAdmin().getLastName());
			doctorList.add(adminDTO);
		}

		doctorList.addAll(clinicDetails.getClinicAssociate().stream().filter(Register::isDoctor).map(associate -> {
			DoctorDTO associateDTO = new DoctorDTO();
			associateDTO.setRegId(associate.getId());
			associateDTO.setDoctorName(associate.getFirstName() + " " + associate.getLastName());
			return associateDTO;
		}).collect(Collectors.toList()));

		return doctorList;
	}

	public List<ClinicDetailsDTO> getSubClinics(Long clinicId) {
		ClinicDetails clinicDetails = clinicDetailsRepository.findById(clinicId).get();
		List<ClinicDetails> clinics = clinicDetailsRepository.findByHeadquaters(clinicDetails.getClinicName());
		List<ClinicDetailsDTO> subClinics = new ArrayList<ClinicDetailsDTO>();
		for (ClinicDetails clinic : clinics) {
			subClinics.add(getClinicDetails(clinic.getId()));
		}
		return subClinics;
	}

}
