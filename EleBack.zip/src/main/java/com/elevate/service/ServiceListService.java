package com.elevate.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.elevate.dto.DropdownDTO;
import com.elevate.dto.ServiceListDTO;
import com.elevate.dto.UpdateServiceStatus;
import com.elevate.entity.DropdownList;
import com.elevate.entity.ServiceList;
import com.elevate.repository.IDropdownListRepository;
import com.elevate.repository.IServiceListRepository;

@Service
public class ServiceListService {
	
	@Autowired
	private IServiceListRepository serviceListRepository;
	
	@Autowired
	private IDropdownListRepository dropdownListRepository;
	
	public String add(ServiceListDTO service) {
		
		ServiceList serviceList = new ServiceList();
		serviceList.setPetType(service.getPetType());
		serviceList.setService(service.getService());
        serviceList.setStatus(true);		
		serviceListRepository.save(serviceList);
		
		List<DropdownList> dropdowns = new ArrayList<>();
		for(DropdownDTO dropdown : service.getDropdown()) {
			DropdownList list = new DropdownList();
			list.setDropdown(dropdown.getDropdown());
			list.setPriceBased(dropdown.getPriceBased());
			list.setPriceForSmall(dropdown.getPriceForSmall());
			list.setPriceForMedium(dropdown.getPriceForMedium());
			list.setPriceForLarge(dropdown.getPriceForLarge());
			list.setPriceForXLarge(dropdown.getPriceForXLarge());
			list.setPriceForQuantity(dropdown.getPriceForQuantity());
			list.setIndustryStandardPrice(dropdown.getIndustryStandardPrice());
			list.setService(serviceList);
		    dropdowns.add(list);
		}
		dropdownListRepository.saveAll(dropdowns);
		return "Services Added";
	}

	public List<ServiceList> getAllServiceList(){
		return serviceListRepository.findAll();
	}
	
	public String update(ServiceList updateService) {
	    ServiceList service = serviceListRepository.findById(updateService.getId())
	            .orElseThrow(() -> new RuntimeException("Service Id not found"));

	    service.setPetType(updateService.getPetType());
	    service.setService(updateService.getService());

	    serviceListRepository.save(service);

	    if (updateService.getDropdowns() != null && !updateService.getDropdowns().isEmpty()) {
	        for (DropdownList updateDropdown : updateService.getDropdowns()) {
	            if (updateDropdown.getId() != null) {
	                DropdownList list = dropdownListRepository.findById(updateDropdown.getId())
	                        .orElseThrow(() -> new RuntimeException("Dropdown id not found"));

	                list.setDropdown(updateDropdown.getDropdown());
	                list.setPriceBased(updateDropdown.getPriceBased());
	                list.setPriceForSmall(updateDropdown.getPriceForSmall());
	                list.setPriceForMedium(updateDropdown.getPriceForMedium());
	                list.setPriceForLarge(updateDropdown.getPriceForLarge());
	                list.setPriceForXLarge(updateDropdown.getPriceForXLarge());
	                list.setPriceForQuantity(updateDropdown.getPriceForQuantity());
	                list.setIndustryStandardPrice(updateDropdown.getIndustryStandardPrice());
	                list.setService(service); 
	                dropdownListRepository.save(list);
	            }
	        }
	    } 
	    return "UPDATED";
	}
	
	public String updateStatus(UpdateServiceStatus update) {
		ServiceList service = serviceListRepository.findById(update.getId()).orElseThrow(() -> new RuntimeException("Service id not foynd to update"));
		if(update.isStatus()==false) {
			service.setStatus(false);
			serviceListRepository.save(service);
			return "Service is diabled";
		}else if(update.isStatus()==true) {
			service.setStatus(true);
			serviceListRepository.save(service);
			return "Service is enabled";
		}
		return null;
	}
			
	public ResponseEntity<String> deleteServiceList(Long id) {
	    ServiceList service = serviceListRepository.findById(id)
	        .orElseThrow(() -> new RuntimeException("Service ID not found"));

	    if(service != null) {
	    	try {
	    		serviceListRepository.deleteById(id);
	    		return ResponseEntity.ok("Service deleted successfully");
	    	} catch (DataIntegrityViolationException e) {
	    		return ResponseEntity.status(HttpStatus.CONFLICT)
	    				.body("Cannot delete this service because it is associated with a Wellness Plan or Recommendation");
	    	}
	    }
		return ResponseEntity.ok("Deleted Successfully");
	}
}