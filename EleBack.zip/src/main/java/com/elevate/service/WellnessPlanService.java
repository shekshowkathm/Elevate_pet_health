package com.elevate.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.elevate.dto.DropdownListResponseDTO;
import com.elevate.dto.RecommendationDTO;
import com.elevate.dto.ServiceListResponseDTO;
import com.elevate.dto.WellnessPlanDTO;
import com.elevate.dto.WellnessPlanResponseDTO;
import com.elevate.entity.ClinicDetails;
import com.elevate.entity.ClinicWellnessPlan;
import com.elevate.entity.ClinicWellnessUpdate;
import com.elevate.entity.DropdownList;
import com.elevate.entity.Recommendation;
import com.elevate.entity.ServiceList;
import com.elevate.entity.WellnessPlan;
import com.elevate.repository.IClinicDetailsRepository;
import com.elevate.repository.IClinicWellnessPlanRepository;
import com.elevate.repository.IClinicWellnessUpdateRepository;
import com.elevate.repository.IDropdownListRepository;
import com.elevate.repository.IRecommendationRepository;
import com.elevate.repository.IServiceListRepository;
import com.elevate.repository.IWellnessPlanRepository;

@Service
public class WellnessPlanService {

	@Autowired
	private IWellnessPlanRepository wellnessPlanRepository;

	@Autowired
	private IServiceListRepository serviceListRepository;

	@Autowired
	private IDropdownListRepository dropdownListRepository;

	@Autowired
	private IRecommendationRepository recommendationRepository;

	@Autowired
	private IClinicDetailsRepository clinicDetailsRepository;

	@Autowired
	private IClinicWellnessPlanRepository clinicWellnessPlanRepository;

	@Autowired
	private IClinicWellnessUpdateRepository clinicWellnessUpdateRepository;

	public String add(WellnessPlanDTO wellnessPlanDTO) {
		if (wellnessPlanRepository.existsByWellnessPlanNameAndService_Id(wellnessPlanDTO.getWellnessPlanName(),
				wellnessPlanDTO.getServiceId())) {
			return "Wellness plan Already Exists";
		} else {
			ServiceList serviceList = serviceListRepository.findById(wellnessPlanDTO.getServiceId())
					.orElseThrow(() -> new RuntimeException("ServiceList not found"));

			WellnessPlan wellnessPlan = new WellnessPlan();
			wellnessPlan.setPetType(wellnessPlanDTO.getPetType());
			wellnessPlan.setAgeGroup(wellnessPlanDTO.getAgeGroup());
			wellnessPlan.setWellnessPlanName(wellnessPlanDTO.getWellnessPlanName());
			wellnessPlan.setService(serviceList);
			wellnessPlan.setStatus(true);
			wellnessPlan = wellnessPlanRepository.save(wellnessPlan);

			List<Recommendation> recommendations = new ArrayList<>();
			for (RecommendationDTO recommendationDTO : wellnessPlanDTO.getRecommendation()) {
				DropdownList dropdownList = dropdownListRepository.findById(recommendationDTO.getDropdownId())
						.orElseThrow(() -> new RuntimeException("DropdownList not found"));

				Recommendation recommendation = new Recommendation();
				recommendation.setDropdownList(dropdownList);
				recommendation.setRecommendation(recommendationDTO.getRecommendation());
				recommendation.setWellnessPlan(wellnessPlan);

				recommendations.add(recommendation);
			}

			recommendationRepository.saveAll(recommendations);

			wellnessPlan.setRecommendation(recommendations);
			List<ClinicDetails> clinic = clinicDetailsRepository.findByClinicStatusIsTrue();
			for (ClinicDetails clinicDetails : clinic) {
				ClinicWellnessPlan clinicWellnessPlan = new ClinicWellnessPlan();
				clinicWellnessPlan.setClinic(clinicDetails);
				clinicWellnessPlan.setWellnessPlan(wellnessPlan);

				List<ClinicWellnessUpdate> wellnessUpdateList = new ArrayList<ClinicWellnessUpdate>();
				for (Recommendation recommendation : wellnessPlan.getRecommendation()) {
					Recommendation recommendationObj = recommendationRepository.findById(recommendation.getId()).get();
					ClinicWellnessUpdate wellnessUpdate = new ClinicWellnessUpdate();
					wellnessUpdate.setDropDown(recommendationObj.getDropdownList());
					clinicWellnessUpdateRepository.save(wellnessUpdate);
					wellnessUpdateList.add(wellnessUpdate);
				}
				clinicWellnessPlan.setWellnessUpdate(wellnessUpdateList);
				clinicWellnessPlanRepository.save(clinicWellnessPlan);
			}
			return "Wellness Plan Added";
		}

	}

	public WellnessPlanResponseDTO getWellnessPlanById(Long id) {
		WellnessPlan wellnessPlan = wellnessPlanRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Wellness Plan not found"));

		WellnessPlanResponseDTO wellnessPlanDTO = new WellnessPlanResponseDTO();
		wellnessPlanDTO.setId(wellnessPlan.getId());
		wellnessPlanDTO.setPetType(wellnessPlan.getPetType());
		wellnessPlanDTO.setAgeGroup(wellnessPlan.getAgeGroup());
		wellnessPlanDTO.setWellnessPlanName(wellnessPlan.getWellnessPlanName());
		wellnessPlanDTO.setStatus(true);

		List<ServiceListResponseDTO> serviceDTOList = new ArrayList<>();
		ServiceListResponseDTO serviceDTO = new ServiceListResponseDTO();
		serviceDTO.setId(wellnessPlan.getService().getId());
		serviceDTO.setPetType(wellnessPlan.getService().getPetType());
		serviceDTO.setService(wellnessPlan.getService().getService());

		List<DropdownListResponseDTO> dropdownDTOs = new ArrayList<>();
		for (Recommendation recommendation : wellnessPlan.getRecommendation()) {
			DropdownListResponseDTO dropdownDTO = new DropdownListResponseDTO();
			dropdownDTO.setId(recommendation.getDropdownList().getId());
			dropdownDTO.setDropdown(recommendation.getDropdownList().getDropdown());
			dropdownDTO.setPriceBased(recommendation.getDropdownList().getPriceBased());
			dropdownDTO.setIndustryStandardPrice(recommendation.getDropdownList().getIndustryStandardPrice());
			dropdownDTO.setRecommendation(recommendation.getRecommendation());

			dropdownDTOs.add(dropdownDTO);
		}

		serviceDTO.setDropdown(dropdownDTOs);
		serviceDTOList.add(serviceDTO);

		wellnessPlanDTO.setService(serviceDTOList);

		return wellnessPlanDTO;
	}

	public List<WellnessPlanResponseDTO> getAllWellnessPlans() {
		List<WellnessPlan> wellnessPlans = wellnessPlanRepository.findAll();

		List<WellnessPlanResponseDTO> wellnessPlanDTOs = new ArrayList<>();

		for (WellnessPlan wellnessPlan : wellnessPlans) {
			WellnessPlanResponseDTO wellnessPlanDTO = new WellnessPlanResponseDTO();
			wellnessPlanDTO.setId(wellnessPlan.getId());
			wellnessPlanDTO.setPetType(wellnessPlan.getPetType());
			wellnessPlanDTO.setAgeGroup(wellnessPlan.getAgeGroup());
			wellnessPlanDTO.setWellnessPlanName(wellnessPlan.getWellnessPlanName());
			wellnessPlanDTO.setStatus(true);

			List<ServiceListResponseDTO> serviceDTOList = new ArrayList<>();
			ServiceListResponseDTO serviceDTO = new ServiceListResponseDTO();
			serviceDTO.setId(wellnessPlan.getService().getId());
			serviceDTO.setPetType(wellnessPlan.getService().getPetType());
			serviceDTO.setService(wellnessPlan.getService().getService());

			List<DropdownListResponseDTO> dropdownDTOs = new ArrayList<>();
			for (Recommendation recommendation : wellnessPlan.getRecommendation()) {
				DropdownListResponseDTO dropdownDTO = new DropdownListResponseDTO();
				dropdownDTO.setId(recommendation.getDropdownList().getId());
				dropdownDTO.setDropdown(recommendation.getDropdownList().getDropdown());
				dropdownDTO.setPriceBased(recommendation.getDropdownList().getPriceBased());
				dropdownDTO.setIndustryStandardPrice(recommendation.getDropdownList().getIndustryStandardPrice());
				dropdownDTO.setRecommendation(recommendation.getRecommendation());
				dropdownDTO.setPriceForSmall(recommendation.getDropdownList().getPriceForSmall());
				dropdownDTO.setPriceForMedium(recommendation.getDropdownList().getPriceForMedium());
				dropdownDTO.setPriceForLarge(recommendation.getDropdownList().getPriceForLarge());
				dropdownDTO.setPriceForXLarge(recommendation.getDropdownList().getPriceForXLarge());
				dropdownDTO.setPriceForQuantity(recommendation.getDropdownList().getPriceForQuantity());

				dropdownDTOs.add(dropdownDTO);
			}

			serviceDTO.setDropdown(dropdownDTOs);
			serviceDTOList.add(serviceDTO);

			wellnessPlanDTO.setService(serviceDTOList);

			wellnessPlanDTOs.add(wellnessPlanDTO);
		}

		return wellnessPlanDTOs;
	}

	public String updateWellnessPlan(WellnessPlanResponseDTO responseDTO) {
		WellnessPlan wellnessPlan = wellnessPlanRepository.findById(responseDTO.getId())
				.orElseThrow(() -> new RuntimeException("Wellness Plan not found"));

		wellnessPlan.setPetType(responseDTO.getPetType());
		wellnessPlan.setAgeGroup(responseDTO.getAgeGroup());
		wellnessPlan.setWellnessPlanName(responseDTO.getWellnessPlanName());
		wellnessPlan.setStatus(responseDTO.isStatus());

		recommendationRepository.deleteAll(wellnessPlan.getRecommendation());

		List<Recommendation> recommendations = new ArrayList<>();
		for (DropdownListResponseDTO dropdownDTO : responseDTO.getService().get(0).getDropdown()) {
			DropdownList dropdownList = dropdownListRepository.findById(dropdownDTO.getId())
					.orElseThrow(() -> new RuntimeException("DropdownList not found for ID: " + dropdownDTO.getId()));

			Recommendation recommendation = new Recommendation();
			recommendation.setDropdownList(dropdownList);
			recommendation.setRecommendation(dropdownDTO.getRecommendation());
			recommendation.setWellnessPlan(wellnessPlan);
			recommendations.add(recommendation);
		}

		recommendationRepository.saveAll(recommendations);
		wellnessPlan.setRecommendation(recommendations);

		wellnessPlanRepository.save(wellnessPlan);

		return "Wellness Plan updated successfully";
	}

	public String deleteWellnessPlan(Long id) {
		WellnessPlan wellnessPlan = wellnessPlanRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Wellness Plan Id not found"));
		if (wellnessPlan != null) {
			List<Recommendation> recommendation = wellnessPlan.getRecommendation();
			for (Recommendation deleteRecommendation : recommendation) {
				recommendationRepository.deleteById(deleteRecommendation.getId());
			}
			wellnessPlanRepository.deleteById(id);
		}
		return "Wellness Plan Deleted Successfully";
	}
	
	
	public List<ServiceList> getAvailableServices(String wellnessPlanName) {
	    List<ServiceList> getAllServices = serviceListRepository.findAll();
	    
	    List<WellnessPlan> getPlans = wellnessPlanRepository.findByWellnessPlanName(wellnessPlanName);
	    System.out.println("Total plans size: " + getPlans.size());
	    
	    Set<Long> usedServiceIds = new HashSet<>();
	    
	    for (WellnessPlan plan : getPlans) {
	        usedServiceIds.add(plan.getService().getId());  
	    }
	    
	    getAllServices.removeIf(service -> usedServiceIds.contains(service.getId()));
	    
	    return getAllServices;
	}


}
