package com.elevate.service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.elevate.config.StripeConnect;
import com.elevate.dto.ClinicDetailsDTO;
import com.elevate.dto.PetDetailsDTO;
import com.elevate.dto.PriceDetails;
import com.elevate.dto.StripeDetails;
import com.elevate.entity.ClinicDetails;
import com.elevate.entity.ClinicWellnessUpdate;
import com.elevate.entity.PetDetails;
import com.elevate.entity.PetWellnessPlan;
import com.elevate.entity.PromotionDiscount;
import com.elevate.entity.Register;
import com.elevate.entity.TransactionDetails;
import com.elevate.repository.IClinicDetailsRepository;
import com.elevate.repository.IClinicWellnessUpdateRepository;
import com.elevate.repository.IPetDetailsRepository;
import com.elevate.repository.IPetWellnessPlanRepository;
import com.elevate.repository.IPromotionDiscountRepository;
import com.elevate.repository.IRegisterRepository;
import com.elevate.repository.ITransactionDetailsRepository;
import com.elevate.utils.EmailSender;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.Account;
import com.stripe.model.Balance;
import com.stripe.model.Coupon;
import com.stripe.model.Customer;
import com.stripe.model.CustomerCollection;
import com.stripe.model.Invoice;
import com.stripe.model.PaymentMethod;
import com.stripe.model.PaymentMethodCollection;
import com.stripe.model.Product;
import com.stripe.model.ProductCollection;
import com.stripe.model.PromotionCode;
import com.stripe.model.Subscription;
import com.stripe.model.SubscriptionSchedule;
import com.stripe.model.InvoiceCollection;
import com.stripe.param.CouponCreateParams;
import com.stripe.param.CustomerListParams;
import com.stripe.param.CustomerUpdateParams;
import com.stripe.param.InvoiceListParams;
import com.stripe.param.InvoiceUpcomingParams;
import com.stripe.param.PaymentMethodAttachParams;
import com.stripe.param.PaymentMethodListParams;
import com.stripe.param.ProductListParams;
import com.stripe.param.PromotionCodeCreateParams;
import com.stripe.param.SubscriptionCancelParams;
import com.stripe.param.SubscriptionListParams;
import com.stripe.param.SubscriptionScheduleListParams;
import com.stripe.param.SubscriptionUpdateParams;

@Service
public class StripeService {

    @Value("${Stripe.apiKey}")
    private String apiKey;

    @Autowired
    StripeConnect stripeConnect;

    @Autowired
    IClinicWellnessUpdateRepository clinicWellnessUpdateRepository;

    @Autowired
    IRegisterRepository registerRepository;

    @Autowired
    IPetDetailsRepository petDetailsRepository;

    @Autowired
    IClinicDetailsRepository clinicDetailsRepository;

    @Autowired
    private EmailSender emailSender;

    @Autowired
    ITransactionDetailsRepository transactionDetailsRepository;

    @Autowired
    IPetWellnessPlanRepository petWellnessPlanRepository;

    @Autowired
    IPromotionDiscountRepository promotionDiscountRepository;

    public String UpdateStripeStatus(Long regId, Register reg) throws Exception {
        Register register = registerRepository.findById(regId).get();
        if (register.getRole().equals("PET_OWNER")) {
            String fullName = register.getFirstName() + " " + register.getLastName();
            String connectedCustomer = stripeConnect.createConnectedCustomer(reg.getStripeAccountId(),
                    fullName, register.getEmail());
            register.setStripeCustomerId(connectedCustomer);
            PetDetails existingPetDetails = petDetailsRepository.findByPetOwnerId(regId);
            existingPetDetails.setStripeCustomerId(connectedCustomer);
            petDetailsRepository.save(existingPetDetails);
            registerRepository.save(register);
        } else {
            ClinicDetails clinic = clinicDetailsRepository.findByClinicOwner_IdAndEmail(regId, register.getEmail());
            Account account = stripeConnect.createConnectedAccount(register.getEmail());
            String accountLink = stripeConnect.createAccountLink(account.getId());
            emailSender.stripAccountCreationMail(register.getEmail(), clinic.getClinicName(), accountLink);
            clinic.setStripeAccountId(account.getId());
            clinicDetailsRepository.save(clinic);
            if (!register.isRegisterStatus()) {
                register.setStripeAccountId(account.getId());
                registerRepository.save(register);
            }
        }
        return "UPDATED";

    }

    public ResponseEntity<String> getStripeStatus(String accountId) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            Account account = Account.retrieve(accountId);
            ClinicDetails clinicAdmin = clinicDetailsRepository.findBystripeAccountId(accountId);
            if (account.getDetailsSubmitted()) {
                clinicAdmin.setStripeStatus(true);
                clinicDetailsRepository.save(clinicAdmin);
                return ResponseEntity.status(HttpStatus.CREATED).body("true");

            }
            return ResponseEntity.status(HttpStatus.CREATED).body("false");
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

    public ResponseEntity<?> createProductStripe(List<StripeDetails> stripeDetails) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            for (StripeDetails stripeDetails1 : stripeDetails) {
                if ("WGT".equals(stripeDetails1.getType())) {
                    long price = Math.round((double) stripeDetails1.getPrice() / 12);
                    if ("Large".equals(stripeDetails1.getSize())) {
                        String productName = stripeDetails1.getProductName();
                        String productDescription = stripeDetails1.getProductDescription();
                        String accountId = stripeDetails1.getAccountId();
                        String product = stripeConnect.createProduct(productName, productDescription);
                        String priceId = stripeConnect.createPrice(accountId, product, price);
                        ClinicWellnessUpdate existingWellnessUpdate = clinicWellnessUpdateRepository
                                .findById(stripeDetails1.getClinicWellnessUpdateId())
                                .orElseThrow(() -> new RuntimeException("Clinic Wellness details not found"));

                        existingWellnessUpdate.setStripeProductIdLarge(product);
                        existingWellnessUpdate.setStripePriceIdLarge(priceId);
                        existingWellnessUpdate.setStripeAccountId(stripeDetails1.getAccountId());
                        clinicWellnessUpdateRepository.save(existingWellnessUpdate);
                    } else if ("Medium".equals(stripeDetails1.getSize())) {
                        String productName = stripeDetails1.getProductName();
                        String productDescription = stripeDetails1.getProductDescription();
                        String accountId = stripeDetails1.getAccountId();
                        String product = stripeConnect.createProduct(productName, productDescription);
                        String priceId = stripeConnect.createPrice(accountId, product, price);
                        ClinicWellnessUpdate existingWellnessUpdate = clinicWellnessUpdateRepository
                                .findById(stripeDetails1.getClinicWellnessUpdateId())
                                .orElseThrow(() -> new RuntimeException("Clinic Wellness details not found"));

                        existingWellnessUpdate.setStripeProductIdMedium(product);
                        existingWellnessUpdate.setStripePriceIdMedium(priceId);
                        existingWellnessUpdate.setStripeAccountId(stripeDetails1.getAccountId());
                        clinicWellnessUpdateRepository.save(existingWellnessUpdate);
                    } else if ("Small".equals(stripeDetails1.getSize())) {
                        String productName = stripeDetails1.getProductName();
                        String productDescription = stripeDetails1.getProductDescription();
                        String accountId = stripeDetails1.getAccountId();
                        String product = stripeConnect.createProduct(productName, productDescription);
                        String priceId = stripeConnect.createPrice(accountId, product, price);
                        ClinicWellnessUpdate existingWellnessUpdate = clinicWellnessUpdateRepository
                                .findById(stripeDetails1.getClinicWellnessUpdateId())
                                .orElseThrow(() -> new RuntimeException("Clinic Wellness details not found"));

                        existingWellnessUpdate.setStripeProductIdSmall(product);
                        existingWellnessUpdate.setStripePriceIdSmall(priceId);
                        existingWellnessUpdate.setStripeAccountId(stripeDetails1.getAccountId());
                        clinicWellnessUpdateRepository.save(existingWellnessUpdate);
                    } else {
                        String productName = stripeDetails1.getProductName();
                        String productDescription = stripeDetails1.getProductDescription();
                        String accountId = stripeDetails1.getAccountId();
                        String product = stripeConnect.createProduct(productName, productDescription);
                        String priceId = stripeConnect.createPrice(accountId, product, price);
                        ClinicWellnessUpdate existingWellnessUpdate = clinicWellnessUpdateRepository
                                .findById(stripeDetails1.getClinicWellnessUpdateId())
                                .orElseThrow(() -> new RuntimeException("Clinic Wellness details not found"));

                        existingWellnessUpdate.setStripeProductIdXLarge(product);
                        existingWellnessUpdate.setStripePriceIdXLarge(priceId);
                        existingWellnessUpdate.setStripeAccountId(stripeDetails1.getAccountId());
                        clinicWellnessUpdateRepository.save(existingWellnessUpdate);
                    }
                    System.out.println("Type: " + stripeDetails1.getType());
                } else {
                    long monthlyPrice = Math.round((double) stripeDetails1.getPrice() / 12);
                    String product = stripeConnect.createProduct(stripeDetails1.getProductName(),
                            stripeDetails1.getProductDescription());
                    String priceId = stripeConnect.createPrice(stripeDetails1.getAccountId(), product, monthlyPrice);
                    ClinicWellnessUpdate existingWellnessUpdate = clinicWellnessUpdateRepository
                            .findById(stripeDetails1.getClinicWellnessUpdateId())
                            .orElseThrow(() -> new RuntimeException("Clinic Wellness details not found"));

                    existingWellnessUpdate.setStripeProductId(product);
                    existingWellnessUpdate.setStripePriceId(priceId);
                    existingWellnessUpdate.setStripeAccountId(stripeDetails1.getAccountId());
                    clinicWellnessUpdateRepository.save(existingWellnessUpdate);
                }
            }
            return ResponseEntity.status(HttpStatus.CREATED).body("Product created successfully");
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

    public ResponseEntity<String> updateStripePrice(List<StripeDetails> stripeDetails) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            for (StripeDetails stripeDetails1 : stripeDetails) {
                if ("WGT".equals(stripeDetails1.getType())) {
                    long newPrice = Math.round((double) stripeDetails1.getPrice() / 12);
                    if ("Large".equals(stripeDetails1.getSize())) {
                        String price = stripeConnect.updatePrice(stripeDetails1.getAccountId(),
                                stripeDetails1.getPriceId(), newPrice, stripeDetails1.getProductId());
                        ClinicWellnessUpdate existingWellnessUpdate = clinicWellnessUpdateRepository
                                .findById(stripeDetails1.getClinicWellnessUpdateId())
                                .orElseThrow(() -> new RuntimeException("Clinic Wellness details not found"));

                        existingWellnessUpdate.setStripePriceIdLarge(price);
                        clinicWellnessUpdateRepository.save(existingWellnessUpdate);
                    } else if ("Medium".equals(stripeDetails1.getSize())) {
                        String price = stripeConnect.updatePrice(stripeDetails1.getAccountId(),
                                stripeDetails1.getPriceId(), newPrice, stripeDetails1.getProductId());
                        ClinicWellnessUpdate existingWellnessUpdate = clinicWellnessUpdateRepository
                                .findById(stripeDetails1.getClinicWellnessUpdateId())
                                .orElseThrow(() -> new RuntimeException("Clinic Wellness details not found"));

                        existingWellnessUpdate.setStripePriceIdMedium(price);
                        clinicWellnessUpdateRepository.save(existingWellnessUpdate);
                    } else if ("Small".equals(stripeDetails1.getSize())) {
                        String price = stripeConnect.updatePrice(stripeDetails1.getAccountId(),
                                stripeDetails1.getPriceId(), newPrice, stripeDetails1.getProductId());
                        ClinicWellnessUpdate existingWellnessUpdate = clinicWellnessUpdateRepository
                                .findById(stripeDetails1.getClinicWellnessUpdateId())
                                .orElseThrow(() -> new RuntimeException("Clinic Wellness details not found"));

                        existingWellnessUpdate.setStripePriceIdSmall(price);
                        clinicWellnessUpdateRepository.save(existingWellnessUpdate);
                    } else {
                        String price = stripeConnect.updatePrice(stripeDetails1.getAccountId(),
                                stripeDetails1.getPriceId(), newPrice, stripeDetails1.getProductId());
                        ClinicWellnessUpdate existingWellnessUpdate = clinicWellnessUpdateRepository
                                .findById(stripeDetails1.getClinicWellnessUpdateId())
                                .orElseThrow(() -> new RuntimeException("Clinic Wellness details not found"));

                        existingWellnessUpdate.setStripePriceIdXLarge(price);
                        clinicWellnessUpdateRepository.save(existingWellnessUpdate);
                    }
                } else {
                    long newPrice = Math.round((double) stripeDetails1.getPrice() / 12);
                    String price = stripeConnect.updatePrice(stripeDetails1.getAccountId(), stripeDetails1.getPriceId(),
                            newPrice, stripeDetails1.getProductId());
                    ClinicWellnessUpdate existingWellnessUpdate = clinicWellnessUpdateRepository
                            .findById(stripeDetails1.getClinicWellnessUpdateId())
                            .orElseThrow(() -> new RuntimeException("Clinic Wellness details not found"));

                    existingWellnessUpdate.setStripePriceId(price);
                    clinicWellnessUpdateRepository.save(existingWellnessUpdate);
                }
            }
            return ResponseEntity.status(HttpStatus.CREATED).body("Price Updated successfully");
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

    public ResponseEntity<String> getAllStripeProducts() {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            ProductListParams params = ProductListParams.builder().setLimit(3L).build();
            ProductCollection products = Product.list(params);
            return ResponseEntity.status(HttpStatus.OK).body(products.toString());
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

    public ResponseEntity<?> checkCardDetails(String customerId) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            PaymentMethodListParams params = PaymentMethodListParams.builder()
                    .setType(PaymentMethodListParams.Type.CARD)
                    .setCustomer(customerId)
                    .build();
            PaymentMethodCollection paymentMethods = PaymentMethod.list(params);
            for (PaymentMethod paymentMethod : paymentMethods.getData()) {
                if (paymentMethod.getCard() != null) {
                    return ResponseEntity.status(HttpStatus.OK).body(true);
                }
            }
            return ResponseEntity.status(HttpStatus.OK).body(false);
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

    public ResponseEntity<?> handleSubscription(StripeDetails stripeDetails) throws Exception {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            LocalDate today = LocalDate.now();
            LocalDate startDate = stripeDetails.getStartDate();
            boolean hasOneTimePriceId = stripeDetails.getOneTimePriceId() != null;
            System.out.println(hasOneTimePriceId+"ooooooooo");
            if (startDate.isAfter(today)) {
                SubscriptionSchedule subscriptionSchedule =hasOneTimePriceId
                        ? stripeConnect.createScheduledSubscription(stripeDetails, startDate)
                        : stripeConnect.createScheduledSubscriptionWithoutOneTomeFee(stripeDetails, startDate);
                return ResponseEntity.status(HttpStatus.OK)
                        .body("wellness Plan Scheduled successfully");
            }
            Invoice subscription = hasOneTimePriceId
                    ? stripeConnect.createSubscription(stripeDetails)
                    : stripeConnect.createSubscriptionWithoutOneTimeFee(stripeDetails);
            System.out.println(subscription+"ddd");
            return ResponseEntity.status(HttpStatus.OK).body(subscription.getHostedInvoiceUrl());
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

    public ResponseEntity<String> attachCardDetails(StripeDetails stripeDetails) throws StripeException {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            PaymentMethodAttachParams attachParams = PaymentMethodAttachParams.builder()
                    .setCustomer(stripeDetails.getCustomerId())
                    .build();

            PaymentMethod paymentMethod = PaymentMethod.retrieve(stripeDetails.getPaymentMethodId());
            paymentMethod.attach(attachParams);

            if (stripeDetails.isDefaultPayment() == true) {
                CustomerUpdateParams customerUpdateParams = CustomerUpdateParams.builder()
                        .setInvoiceSettings(
                                CustomerUpdateParams.InvoiceSettings.builder()
                                        .setDefaultPaymentMethod(stripeDetails.getPaymentMethodId())
                                        .build())
                        .build();
                Customer customer = Customer.retrieve(stripeDetails.getCustomerId());
                customer.update(customerUpdateParams);
            } else {
                CustomerUpdateParams customerUpdateParams = CustomerUpdateParams.builder()
                        .setInvoiceSettings(
                                CustomerUpdateParams.InvoiceSettings.builder()
                                        .setDefaultPaymentMethod(stripeDetails.getPaymentMethodId())
                                        .build())
                        .build();
                Customer customer = Customer.retrieve(stripeDetails.getCustomerId());
                customer.update(customerUpdateParams);
            }
            return ResponseEntity.status(HttpStatus.OK).body("{\"message\": \"Card saved successfully\"}");
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

    public ResponseEntity<String> cancelSubscription(String subscriptionId) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            Subscription resource = Subscription.retrieve(subscriptionId);
            SubscriptionCancelParams params = SubscriptionCancelParams.builder().build();
            Subscription subscription = resource.cancel(params);
            return ResponseEntity.status(HttpStatus.OK).body("{\"message\": \"Subscription cancelled successfully\"}");
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

    public ResponseEntity<String> updateSubscription(StripeDetails stripeDetails) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            Subscription resource = Subscription.retrieve(stripeDetails.getSubscriptionId());
            SubscriptionUpdateParams.Builder paramsBuilder = SubscriptionUpdateParams.builder();
            List<PriceDetails> priceDetailsList = stripeDetails.getPriceIds();
            for (PriceDetails details : priceDetailsList) {
                paramsBuilder.addItem(
                        SubscriptionUpdateParams.Item.builder()
                                .setPrice(details.getPriceId())
                                .setQuantity(details.getQuantity())
                                .build());
            }
            Subscription subscription = resource.update(paramsBuilder.build());
//            PetDetails petDetails = petDetailsRepository.findById(stripeDetails.getPetDetailsId())
//                    .orElseThrow(() -> new RuntimeException("Pet details not found"));
            long[] petWellnessPlanIds=stripeDetails.getPetWellnessPlanId();
            for (long petWellnessPlanId : petWellnessPlanIds) {
                PetWellnessPlan petWellnessPlan=petWellnessPlanRepository.findById(petWellnessPlanId).orElseThrow(()->new RuntimeException("Pet wellness plan not found"));
                petWellnessPlan.setPlanStatus("paid");
                petWellnessPlan.setPaymentStatus("paid");
                petWellnessPlan.setStripeSubscriptionId(stripeDetails.getSubscriptionId());
                petWellnessPlanRepository.save(petWellnessPlan);
            }

            return ResponseEntity.status(HttpStatus.OK).body("{\"message\": \"Subscription Updated successfully\"}");
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

    public ResponseEntity<String> generateCouponCode(StripeDetails stripeDetails) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            System.out.println(stripeDetails.getProductId());
            String couponExpiryDate = stripeDetails.getCouponExpiryDate();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate date = LocalDate.parse(couponExpiryDate, formatter);
            long endDate = date.atStartOfDay(ZoneId.of("UTC")).toEpochSecond();
            CouponCreateParams params = CouponCreateParams.builder()
                    .setName(stripeDetails.getCouponName())
                    .setDuration(CouponCreateParams.Duration.ONCE)
                    .setRedeemBy(endDate)
                    .setAppliesTo(CouponCreateParams.AppliesTo.builder()
                            .addProduct(stripeDetails.getProductId())
                            .build())
                    .setAmountOff(stripeDetails.getDiscountAmount())
                    .setCurrency("USD")
                    .build();
            Coupon coupon = Coupon.create(params);
            PromotionCodeCreateParams promotionCodeCreateParams =
                    PromotionCodeCreateParams.builder()
                            .setCoupon(coupon.getId())
                            .setCode(stripeDetails.getCouponCode())
                            .setMaxRedemptions(stripeDetails.getMaxRedemptions())
                            .setRestrictions(PromotionCodeCreateParams.Restrictions.builder()
                                    .setFirstTimeTransaction(stripeDetails.getFirstTimeOnly())
                                    .build()
                            )
                            .build();
            PromotionCode promotionCode = PromotionCode.create(promotionCodeCreateParams);
            PromotionDiscount promotionDiscount = promotionDiscountRepository.findById(stripeDetails.getPromotionId()).get();
            promotionDiscount.setStripeCouponId(coupon.getId());
            promotionDiscountRepository.save(promotionDiscount);
            return ResponseEntity.status(HttpStatus.OK).body("Coupon created");
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

    public ResponseEntity<String> deleteCoupon(String couponId) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            Coupon resource = Coupon.retrieve(couponId);
            Coupon coupon = resource.delete();
            System.out.println(coupon + "Deleted coupon");
            return ResponseEntity.status(HttpStatus.OK).body("Coupon deleted Successfully");
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

    public ResponseEntity<String> validateCoupon(Long clinicId, String promotionType) {
        try {
            LocalDate today = LocalDate.now();

            PromotionDiscount promotionDiscount = promotionDiscountRepository.findByClinicIdAndPromotionType(clinicId, promotionType);
            if (promotionDiscount == null || promotionDiscount.getEndDate() == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Promotion not found or end date is missing.");
            }
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate endDate = LocalDate.parse(promotionDiscount.getEndDate(), formatter);

            if (today.isAfter(endDate)) {
                return ResponseEntity.status(HttpStatus.OK).body("Coupon Expired");
            }

            return ResponseEntity.status(HttpStatus.OK).body(promotionDiscount.getStripeCouponId());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

//    public ResponseEntity<?> getExpiryCardDetails() {
//        try {
//            if (apiKey == null || apiKey.isEmpty()) {
//                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
//            }
//            Stripe.apiKey = apiKey;
//            List<StripeDetails> expiringCards = new ArrayList<>();
//            String startingAfter = null;
//            String role="PET_OWNER";
//
////            do {
////                CustomerListParams.Builder paramsBuilder = CustomerListParams.builder().setLimit(10L);
////                if (startingAfter != null) {
////                    paramsBuilder.setStartingAfter(startingAfter);
////                }
////                CustomerListParams params = paramsBuilder.build();
////                CustomerCollection customers = Customer.list(params);
//                   List <Register> register=registerRepository.findByRole(role);
//                for (Register customers : register) {
//                    String customerId = customers.getStripeCustomerId();
//                    Customer customer = Customer.retrieve(customerId);
//                    try {
//                        String defaultPaymentMethodId = customer.getInvoiceSettings().getDefaultPaymentMethod();
//                        if (defaultPaymentMethodId != null) {
//                            PaymentMethod paymentMethod = PaymentMethod.retrieve(defaultPaymentMethodId);
//                            if ("card".equals(paymentMethod.getType()) && paymentMethod.getCard() != null) {
//                                int expMonth = paymentMethod.getCard().getExpMonth().intValue();
//                                int expYear = paymentMethod.getCard().getExpYear().intValue();
//                                LocalDate today = LocalDate.now();
//                                LocalDate endDate = LocalDate.of(expYear, expMonth, 1).withDayOfMonth(LocalDate.of(expYear, expMonth, 1).lengthOfMonth());
//                                Period period = Period.between(today, endDate);
//
//                                int years = period.getYears();
//                                int months = period.getMonths();
//
//                                int totalMonths = years * 12 + months;
//                                ClinicDetails clinicDetails = clinicDetailsRepository
//                                        .findByStripeAccountId(customer.getMetadata().get("connected_account_id")).orElseThrow(() -> new RuntimeException("Clinic details not found"));
//                                if (totalMonths == 0 || totalMonths == 1) {
//                                    expiringCards.add(new StripeDetails(
//                                            customer.getEmail(),
//                                            customer.getName(),
//                                            expMonth,
//                                            expYear,
//                                            paymentMethod.getCard().getLast4(),
//                                            paymentMethod.getCard().getBrand(),
//                                            clinicDetails.getClinicName()));
//                                }
//                            }
//                        }
//                    } catch (Exception e) {
//                        System.err.println("Error processing customer " + customerId + ": " + e.getMessage());
//                    }
//                }
////                startingAfter = customers.getData().isEmpty() ? null
////                        : customers.getData().get(customers.getData().size() - 1).getId();
////
////            } while (startingAfter != null);
//
////            if (expiringCards.isEmpty()) {
////                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No expiring cards found.");
////            }
//            return ResponseEntity.status(HttpStatus.OK).body(expiringCards);
//        } catch (StripeException e) {
//            System.err.println("Stripe error: " + e.getMessage());
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
//        } catch (RuntimeException e) {
//            System.err.println("Error: " + e.getMessage());
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
//        }
//    }
public ResponseEntity<?> getExpiryCardDetails() {
    try {
        if (apiKey == null || apiKey.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
        }
        Stripe.apiKey = apiKey;
        List<StripeDetails> expiringCards = new ArrayList<>();
        String role = "PET_OWNER";

        List<Register> register = registerRepository.findByRole(role);
        for (Register customers : register) {
            String customerId = customers.getStripeCustomerId();
            try {
                String defaultPaymentMethodId = Customer.retrieve(customerId).getInvoiceSettings().getDefaultPaymentMethod();
                if (defaultPaymentMethodId != null) {
                    PaymentMethod paymentMethod = PaymentMethod.retrieve(defaultPaymentMethodId);
                    if ("card".equals(paymentMethod.getType()) && paymentMethod.getCard() != null) {
                        int expMonth = paymentMethod.getCard().getExpMonth().intValue();
                        int expYear = paymentMethod.getCard().getExpYear().intValue();
                        int totalMonths = calculateRemainingMonths(expYear, expMonth);

                        if (totalMonths == 0 || totalMonths == 1) {
                            ClinicDetails clinicDetails = clinicDetailsRepository
                                    .findByStripeAccountId(Customer.retrieve(customerId).getMetadata().get("connected_account_id"))
                                    .orElseThrow(() -> new RuntimeException("Clinic details not found"));

                            expiringCards.add(new StripeDetails(
                                    Customer.retrieve(customerId).getEmail(),
                                    Customer.retrieve(customerId).getName(),
                                    expMonth,
                                    expYear,
                                    paymentMethod.getCard().getLast4(),
                                    paymentMethod.getCard().getBrand(),
                                    clinicDetails.getClinicName()
                            ));
                        }
                    }
                }
            } catch (Exception e) {
                System.err.println("Error processing customer " + customerId + ": " + e.getMessage());
            }
        }

        int length = expiringCards.size();
        System.out.println("Number of expiring cards: " + length);

        return expiringCards.isEmpty()
                ? ResponseEntity.status(HttpStatus.NO_CONTENT).body("No expiring cards found.")
                : ResponseEntity.ok(Map.of("count", length, "details", expiringCards));
    } catch (RuntimeException e) {
        System.err.println("Error: " + e.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
    }
}

    private int calculateRemainingMonths(int expYear, int expMonth) {
        LocalDate today = LocalDate.now();
        LocalDate endDate = LocalDate.of(expYear, expMonth, 1).withDayOfMonth(LocalDate.of(expYear, expMonth, 1).lengthOfMonth());
        Period period = Period.between(today, endDate);
        return period.getYears() * 12 + period.getMonths();
    }

    public ResponseEntity<?> getExpiryCardDetailsByClinic(String accountId) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;

            List<StripeDetails> expiringCards = new ArrayList<>();
            String startingAfter = null;
            do {
                CustomerListParams.Builder paramsBuilder = CustomerListParams.builder().setLimit(10L);
                if (startingAfter != null) {
                    paramsBuilder.setStartingAfter(startingAfter);
                }
                CustomerListParams params = paramsBuilder.build();
                CustomerCollection customers = Customer.list(params);
                for (Customer customer : customers.getData()) {
                    String connectedAccountId = customer.getMetadata().get("connected_account_id");
                    if (accountId.equals(connectedAccountId)) {
                        System.out.println(connectedAccountId + " Connected Account Id");
                        String customerId = customer.getId();
                        try {
                            String defaultPaymentMethodId = customer.getInvoiceSettings().getDefaultPaymentMethod();
                            if (defaultPaymentMethodId != null) {
                                PaymentMethod paymentMethod = PaymentMethod.retrieve(defaultPaymentMethodId);

                                if ("card".equals(paymentMethod.getType()) && paymentMethod.getCard() != null) {
                                    int expMonth = paymentMethod.getCard().getExpMonth().intValue();
                                    int expYear = paymentMethod.getCard().getExpYear().intValue();
                                    LocalDate today = LocalDate.now();
                                    LocalDate endDate = LocalDate.of(expYear, expMonth, 1)
                                            .withDayOfMonth(LocalDate.of(expYear, expMonth, 1).lengthOfMonth());
                                    Period period = Period.between(today, endDate);
                                    int years = period.getYears();
                                    int months = period.getMonths();
                                    int totalMonths = years * 12 + months;
                                    ClinicDetails clinicDetails = clinicDetailsRepository
                                            .findByStripeAccountId(customer.getMetadata().get("connected_account_id"))
                                            .orElseThrow(() -> new RuntimeException("Clinic details not found"));
                                    if (totalMonths <= 1) {
                                        expiringCards.add(new StripeDetails(
                                                customer.getEmail(),
                                                customer.getName(),
                                                expMonth,
                                                expYear,
                                                paymentMethod.getCard().getLast4(),
                                                paymentMethod.getCard().getBrand(),
                                                clinicDetails.getClinicName()));
                                    }
                                }
                            }
                        } catch (Exception e) {
                            System.err.println("Error processing customer " + customerId + ": " + e.getMessage());
                        }
                    }
                }
                startingAfter = customers.getData().isEmpty() ? null
                        : customers.getData().get(customers.getData().size() - 1).getId();
            } while (startingAfter != null);
            int length = expiringCards.size();
            if (expiringCards.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No expiring cards found.");
            }
            return ResponseEntity.status(HttpStatus.OK)
                    .body(Map.of("count", length, "expiringCards", expiringCards));
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

//    public ResponseEntity<?> getExpiryCardDetailsByClinic(String accountId) {
//        try {
//            if (apiKey == null || apiKey.isEmpty()) {
//                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
//            }
//            Stripe.apiKey = apiKey;
//            List<StripeDetails> expiringCards = new ArrayList<>();
//            String startingAfter = null;
//
//            do {
//                CustomerListParams.Builder paramsBuilder = CustomerListParams.builder().setLimit(10L);
//                if (startingAfter != null) {
//                    paramsBuilder.setStartingAfter(startingAfter);
//                }
//                CustomerListParams params = paramsBuilder.build();
//                CustomerCollection customers = Customer.list(params);
//
//                for (Customer customer : customers.getData()) {
//                    String connectedAccountId = customer.getMetadata().get("connected_account_id");
//                    if(accountId.equals(connectedAccountId)) {
//                        System.out.println(connectedAccountId+"Connecte Account Id");
//                        String customerId = customer.getId();
//                        try {
//                            String defaultPaymentMethodId = customer.getInvoiceSettings().getDefaultPaymentMethod();
//                            if (defaultPaymentMethodId != null) {
//                                PaymentMethod paymentMethod = PaymentMethod.retrieve(defaultPaymentMethodId);
//
//                                if ("card".equals(paymentMethod.getType()) && paymentMethod.getCard() != null) {
//                                    System.out.println("innnnnnnnnnn");
//                                    int expMonth = paymentMethod.getCard().getExpMonth().intValue();
//                                    int expYear = paymentMethod.getCard().getExpYear().intValue();
//                                    LocalDate today = LocalDate.now();
//                                    LocalDate endDate = LocalDate.of(expYear, expMonth, 1).withDayOfMonth(LocalDate.of(expYear, expMonth, 1).lengthOfMonth());
//                                    Period period = Period.between(today, endDate);
//
//                                    int years = period.getYears();
//                                    int months = period.getMonths();
//
//                                    int totalMonths = years * 12 + months;
//                                    System.out.println(totalMonths+"totalMonthss");
//                                    ClinicDetails clinicDetails = clinicDetailsRepository
//                                            .findByStripeAccountId(customer.getMetadata().get("connected_account_id")).orElseThrow(() -> new RuntimeException("Clinic details not found"));
//                                    if (totalMonths <= 1) {
//                                        expiringCards.add(new StripeDetails(
//                                                customer.getEmail(),
//                                                customer.getName(),
//                                                expMonth,
//                                                expYear,
//                                                paymentMethod.getCard().getLast4(),
//                                                paymentMethod.getCard().getBrand(),
//                                                clinicDetails.getClinicName()));
//                                        System.out.println(expiringCards+"expriring cards");
//                                    }
//                                }
//                            }
//                        } catch (Exception e) {
//                            System.err.println("Error processing customer " + customerId + ": " + e.getMessage());
//                        }
//                    }
//                }
//                startingAfter = customers.getData().isEmpty() ? null
//                        : customers.getData().get(customers.getData().size() - 1).getId();
//                System.out.println(startingAfter+"starting");
//            } while (startingAfter != null);
//
//            if (expiringCards.isEmpty()) {
//                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No expiring cards found.");
//            }
//            return ResponseEntity.status(HttpStatus.OK).body(expiringCards);
//        } catch (StripeException e) {
//            System.err.println("Stripe error: " + e.getMessage());
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
//        } catch (RuntimeException e) {
//            System.err.println("Error: " + e.getMessage());
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
//        }
//    }

    public ResponseEntity<?> getSalesExpDetails(Long salesRepId) {
        try {
            List<ClinicDetails> clinics = clinicDetailsRepository.findBySalesRepId(salesRepId);
            if (clinics.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No clinics found for the given salesRepId.");
            }

            List<String> clinicAccountIds = clinics.stream()
                    .map(ClinicDetails::getStripeAccountId)
                    .toList();

            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;

            List<StripeDetails> expiringCards = new ArrayList<>();
            String startingAfter = null;

            do {
                CustomerListParams.Builder paramsBuilder = CustomerListParams.builder().setLimit(10L);
                if (startingAfter != null) {
                    paramsBuilder.setStartingAfter(startingAfter);
                }
                CustomerListParams params = paramsBuilder.build();
                CustomerCollection customers = Customer.list(params);

                for (Customer customer : customers.getData()) {
                    String connectedAccountId = customer.getMetadata().get("connected_account_id");

                    if (clinicAccountIds.contains(connectedAccountId)) {
                        String customerId = customer.getId();
                        try {
                            String defaultPaymentMethodId = customer.getInvoiceSettings().getDefaultPaymentMethod();
                            if (defaultPaymentMethodId != null) {
                                PaymentMethod paymentMethod = PaymentMethod.retrieve(defaultPaymentMethodId);

                                if ("card".equals(paymentMethod.getType()) && paymentMethod.getCard() != null) {
                                    int expMonth = paymentMethod.getCard().getExpMonth().intValue();
                                    int expYear = paymentMethod.getCard().getExpYear().intValue();
                                    LocalDate today = LocalDate.now();
                                    LocalDate endDate = LocalDate.of(expYear, expMonth, 1)
                                            .withDayOfMonth(LocalDate.of(expYear, expMonth, 1).lengthOfMonth());
                                    Period period = Period.between(today, endDate);
                                    int totalMonths = period.getYears() * 12 + period.getMonths();

                                    if (totalMonths <= 1) {
                                        ClinicDetails clinicDetails = clinics.stream()
                                                .filter(c -> c.getStripeAccountId().equals(connectedAccountId))
                                                .findFirst()
                                                .orElseThrow(() -> new RuntimeException("Clinic details not found"));
                                        expiringCards.add(new StripeDetails(
                                                customer.getEmail(),
                                                customer.getName(),
                                                expMonth,
                                                expYear,
                                                paymentMethod.getCard().getLast4(),
                                                paymentMethod.getCard().getBrand(),
                                                clinicDetails.getClinicName()));
                                    }
                                }
                            }
                        } catch (Exception e) {
                            System.err.println("Error processing customer " + customerId + ": " + e.getMessage());
                        }
                    }
                }
                startingAfter = customers.getData().isEmpty() ? null
                        : customers.getData().get(customers.getData().size() - 1).getId();
            } while (startingAfter != null);

            int length = expiringCards.size();
            if (expiringCards.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No expiring cards found.");
            }
            return ResponseEntity.status(HttpStatus.OK)
                    .body(Map.of("count", length, "expiringCards", expiringCards));
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }


    public ResponseEntity<?> getCardDetailsByCustomer(String customerId) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            Map<String, Object> params = new HashMap<>();
            params.put("customer", customerId);
            params.put("type", "card");
            System.out.println("cus_RFdx1NxKstoJDM" + customerId);
            Customer customer = Customer.retrieve(customerId);
            String defaultPaymentMethodId = customer.getInvoiceSettings().getDefaultPaymentMethod();
            PaymentMethodCollection paymentMethods = PaymentMethod.list(params);
            List<Map<String, String>> cards = new ArrayList<>();
            for (PaymentMethod paymentMethod : paymentMethods.getData()) {
                Map<String, String> cardDetails = new HashMap<>();
                cardDetails.put("brand", paymentMethod.getCard().getBrand());
                cardDetails.put("last4", paymentMethod.getCard().getLast4());
                cardDetails.put("expMonth", String.valueOf(paymentMethod.getCard().getExpMonth()));
                cardDetails.put("expYear", String.valueOf(paymentMethod.getCard().getExpYear()));
                cardDetails.put("id", paymentMethod.getId());
                if (paymentMethod.getId().equals(defaultPaymentMethodId)) {
                    cardDetails.put("isDefault", "true");
                } else {
                    cardDetails.put("isDefault", "false");
                }
                cards.add(cardDetails);
            }
            return ResponseEntity.status(HttpStatus.OK).body(cards);
        } catch (RuntimeException | StripeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

    public ResponseEntity<?> removeCardDetailsCustomer(String customerId, StripeDetails stripeDetails) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            PaymentMethod paymentMethod = PaymentMethod.retrieve(stripeDetails.getPaymentMethodId());
            paymentMethod.detach();
            return ResponseEntity.status(HttpStatus.OK).body("{\"message\": \"Card Removed successfully\"}");
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        } catch (StripeException e) {
            throw new RuntimeException(e);
        }
    }

    public ResponseEntity<?> getsubscriptionDetails(String subscriptionId) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;

            InvoiceUpcomingParams params = InvoiceUpcomingParams.builder()
                    .setSubscription(subscriptionId)
                    .build();
            Invoice upcomingInvoice = Invoice.  upcoming(params);
            return ResponseEntity.status(HttpStatus.OK).body(upcomingInvoice.toJson());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        } catch (StripeException e) {
            throw new RuntimeException(e);
        }
    }

    public ResponseEntity<?> getSchsubscriptionIdDetails(String subscriptionId) {
        try {
            TransactionDetails transactionDetails = transactionDetailsRepository
                    .findByStripeSubscriptionId(subscriptionId);
            return ResponseEntity.status(HttpStatus.OK).body(transactionDetails);
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

    public ResponseEntity<?> getLastSixMonthsDetails() {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }

            Stripe.apiKey = apiKey;
            List<Map<String, Object>> monthTotals = new ArrayList<>();
            LocalDate sixMonthsAgo = LocalDate.now().minusMonths(6).with(TemporalAdjusters.firstDayOfMonth());
            LocalDate today = LocalDate.now().with(TemporalAdjusters.lastDayOfMonth());

            long startDate = sixMonthsAgo.atStartOfDay(ZoneId.systemDefault()).toEpochSecond();
            long endDate = today.atStartOfDay(ZoneId.systemDefault()).toEpochSecond();

            List<Invoice> allInvoices = new ArrayList<>();
            String startingAfter = null;

            do {
                InvoiceListParams.Builder paramsBuilder = InvoiceListParams.builder()
                        .setCreated(InvoiceListParams.Created.builder()
                                .setGte(startDate)
                                .setLte(endDate)
                                .build())
                        .setStatus(InvoiceListParams.Status.PAID)
                        .setLimit(100L);

                if (startingAfter != null) {
                    paramsBuilder.setStartingAfter(startingAfter);
                }

                List<Invoice> invoices = Invoice.list(paramsBuilder.build()).getData();
                if (invoices.isEmpty()) {
                    break;
                }
                allInvoices.addAll(invoices);
                startingAfter = invoices.get(invoices.size() - 1).getId();
            } while (startingAfter != null);

            Map<String, Double> totalsByMonth = new TreeMap<>();
            DateTimeFormatter customFormatter = DateTimeFormatter.ofPattern("MMM yyyy", Locale.ENGLISH);

            for (Invoice payment : allInvoices) {
                LocalDate paymentDate = Instant.ofEpochSecond(payment.getCreated())
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate();
                String formattedMonth = paymentDate.format(customFormatter);

                totalsByMonth.put(
                        formattedMonth,
                        totalsByMonth.getOrDefault(formattedMonth, 0.0) + payment.getAmountPaid() / 100.0
                );
            }

            for (Map.Entry<String, Double> entry : totalsByMonth.entrySet()) {
                Map<String, Object> monthData = new HashMap<>();
                monthData.put("month", entry.getKey());
                monthData.put("total", entry.getValue());
                monthTotals.add(monthData);
            }
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM yyyy", Locale.ENGLISH);
            monthTotals.sort((a, b) -> {
                YearMonth yearMonthA = YearMonth.parse(a.get("month").toString(), formatter);
                YearMonth yearMonthB = YearMonth.parse(b.get("month").toString(), formatter);
                return yearMonthB.compareTo(yearMonthA);
            });
            return ResponseEntity.status(HttpStatus.OK).body(monthTotals);
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        }

    }

    public ResponseEntity<?> getBalance() {
        try {

            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }

            Stripe.apiKey = apiKey;
            Balance balance = Balance.retrieve();
            return ResponseEntity.status(HttpStatus.OK).body(balance.getAvailable());

        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        }
    }

    public ResponseEntity<?> getUpcomingPayments() {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;

            String role = "PET_OWNER";

            List<Register> registers = registerRepository.findByRole(role);
            List<Map<String, Object>> upcomingPayments = new ArrayList<>();
            if (registers == null || registers.isEmpty()) {
                System.out.println("No registers found for role: " + role);
                return ResponseEntity.status(HttpStatus.OK).body("No upcoming payments found.");
            }


            for (Register register : registers) {
                try {
                    String stripeCustomerId = register.getStripeCustomerId();
                    if (stripeCustomerId == null || stripeCustomerId.isEmpty()) {
                        System.out.println("Skipping register with null or empty Stripe customer ID: " + register.getId());
                        continue;
                    }


                    InvoiceUpcomingParams params = InvoiceUpcomingParams.builder()
                            .setCustomer(stripeCustomerId)
                            .build();

                    Invoice upcomingInvoice = Invoice.upcoming(params);
                    if (upcomingInvoice != null) {
                        System.out.println("Upcoming invoice retrieved for customer: " + stripeCustomerId);

                                              Map<String, Object> paymentDetails = new HashMap<>();
                        paymentDetails.put("stripeCustomerId", stripeCustomerId);
                        paymentDetails.put("amountDue", upcomingInvoice.getAmountDue());
                        paymentDetails.put("customer", upcomingInvoice.getCustomerName());
                        paymentDetails.put("customerEmail", upcomingInvoice.getCustomerEmail());
                        paymentDetails.put("dueDate", upcomingInvoice.getPeriodEnd());

                        upcomingPayments.add(paymentDetails);
                    } else {
                        System.out.println("No upcoming invoice found for customer: " + stripeCustomerId);
                    }
                } catch (Exception e) {
                    
                    System.err.println("Error while processing customer " + register.getStripeCustomerId() + ": " + e.getMessage());
                    e.printStackTrace();
                }
            }

            if (upcomingPayments.isEmpty()) {
                return ResponseEntity.status(HttpStatus.OK).body("No upcoming payments found.");
            }

            return ResponseEntity.status(HttpStatus.OK).body(upcomingPayments);

        } catch (RuntimeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        }
    }

    public ResponseEntity<?> getSchedUpcomingPayments() {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            LocalDate today = LocalDate.now();
            LocalDate after2Days = today.plusDays(10);
            long startDate = today.atStartOfDay(ZoneId.of("UTC")).toEpochSecond();
            long endDate = after2Days.atStartOfDay(ZoneId.of("UTC")).toEpochSecond();
            List<SubscriptionSchedule> subscriptionsSchedule = new ArrayList<>();
            String startingAfter = null;
            do {
                SubscriptionScheduleListParams.Builder paramsBuilder = SubscriptionScheduleListParams.builder()
                        .setCreated(SubscriptionScheduleListParams.Created.builder()
                                .setGte(startDate)
                                .setLte(endDate)
                                .build())
                        .setLimit(100L);

                if (startingAfter != null) {
                    paramsBuilder.setStartingAfter(startingAfter);
                }

                List<SubscriptionSchedule> subscriptionScheduleBatch = SubscriptionSchedule.list(paramsBuilder.build()).getData();
                subscriptionsSchedule.addAll(subscriptionScheduleBatch);

                startingAfter = subscriptionScheduleBatch.isEmpty() ? null : subscriptionScheduleBatch.get(subscriptionScheduleBatch.size() - 1).getId();
            } while (startingAfter != null);

            List<Map<String, Object>> upcomingPayments = new ArrayList<>();

            for (SubscriptionSchedule subscriptionSchedule : subscriptionsSchedule) {
                try {
                    InvoiceUpcomingParams params = InvoiceUpcomingParams.builder()
                            .setCustomer(subscriptionSchedule.getCustomer())
                            .build();

                    Invoice upcomingInvoice = Invoice.upcoming(params);
                    long billingCycleAnchor = subscriptionSchedule.getPhases().getFirst().getStartDate();
                    LocalDate billingCycleDate = LocalDate.ofEpochDay(billingCycleAnchor / (24 * 60 * 60));
                    if (upcomingInvoice != null) {
                        Map<String, Object> paymentDetails = new HashMap<>();
                        Customer customer = Customer.retrieve(subscriptionSchedule.getCustomer());
                        paymentDetails.put("customer", customer.getName());
                        paymentDetails.put("subscription", subscriptionSchedule.getId());
                        paymentDetails.put("customerEmail", customer.getEmail());
                        paymentDetails.put("next_payment_amount", upcomingInvoice.getAmountDue() / 100.0);
                        paymentDetails.put("next_payment_date", billingCycleDate.toString());

                        upcomingPayments.add(paymentDetails);
                    }
                } catch (Exception e) {
                    System.err.println("Failed to fetch upcoming invoice for subscription schedule: " + subscriptionSchedule.getId());
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage());
                }
            }

            System.out.println(upcomingPayments + "upcomin payments");
            return ResponseEntity.status(HttpStatus.OK).body(upcomingPayments);
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        }
    }

    public ResponseEntity<?> getPetDetails(long petDetailsId){
        try{
            PetDetails petDetails = petDetailsRepository.findById(petDetailsId)
                    .orElseThrow(() -> new RuntimeException("Pet Details not found"));
            PetDetailsDTO dto = new PetDetailsDTO();
//            List<PetDetailsDTO> details = new ArrayList<>();
            dto.setPaymentStatus(petDetails.getPaymentStatus());
            dto.setId(petDetails.getId());
            dto.setPetName(petDetails.getPetName());
            dto.setPetAge(petDetails.getPetAge());
            dto.setPetType(petDetails.getPetType());
            dto.setAgeGroup(petDetails.getAgeGroup());
            dto.setPetBreed(petDetails.getPetBreed());
            dto.setGender(petDetails.getGender());
            dto.setWeight(petDetails.getWeight());
            dto.setDob(petDetails.getDob());
            return ResponseEntity.status(HttpStatus.OK).body(dto);
        } catch (Exception e) {
            System.err.println("Failed to fetch upcoming invoice for subscription schedule: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage());
        }
    }

    public ResponseEntity<?> getExpiryDetailscustomer(String customerId) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;

            Customer customer = Customer.retrieve(customerId);
            String defaultPaymentMethodId = customer.getInvoiceSettings().getDefaultPaymentMethod();

            if (defaultPaymentMethodId == null) {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No default payment method found for this customer.");
            }

            PaymentMethod paymentMethod = PaymentMethod.retrieve(defaultPaymentMethodId);

            if (!"card".equals(paymentMethod.getType()) || paymentMethod.getCard() == null) {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No card found for this customer.");
            }

            int expMonth = paymentMethod.getCard().getExpMonth().intValue();
            int expYear = paymentMethod.getCard().getExpYear().intValue();
            LocalDate today = LocalDate.now();
            LocalDate expiryDate = LocalDate.of(expYear, expMonth, 1).withDayOfMonth(
                    LocalDate.of(expYear, expMonth, 1).lengthOfMonth());
            Period period = Period.between(today, expiryDate);
            int totalMonths = period.getYears() * 12 + period.getMonths();
            if (totalMonths <= 1 && totalMonths >= 0) {
                return ResponseEntity.status(HttpStatus.OK).body(new StripeDetails(
                        customer.getEmail(),
                        customer.getName(),
                        expMonth,
                        expYear,
                        paymentMethod.getCard().getLast4(),
                        paymentMethod.getCard().getBrand(),
                        "Upcoming Expiry (within one month)"
                ));
            }

            if (totalMonths < 0 && totalMonths >= -1) {
                return ResponseEntity.status(HttpStatus.OK).body(new StripeDetails(
                        customer.getEmail(),
                        customer.getName(),
                        expMonth,
                        expYear,
                        paymentMethod.getCard().getLast4(),
                        paymentMethod.getCard().getBrand(),
                        "Past Expiry (within one month)"
                ));
            }

            return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No expiring or recently expired cards found.");

        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        }
    }

    public ResponseEntity<String> refreshAccountLink(String accountId) {
        try {
            String newAccountLink = stripeConnect.createAccountLink(accountId);
            return ResponseEntity.status(HttpStatus.OK).body(newAccountLink);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error while creating account link: " + e.getMessage());
        }
    }
    public ResponseEntity<String> reSendAccountLink(ClinicDetailsDTO clinicDetails) {
        try {
            String newAccountLink = stripeConnect.createAccountLink(clinicDetails.getStripeAccountId());
            emailSender.stripAccountCreationMail(clinicDetails.getClinicEmail(), clinicDetails.getClinicName(),
                    newAccountLink);
            return ResponseEntity.status(HttpStatus.OK).body("newAccountLink");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error while creating account link: " + e.getMessage());
        }
    }


    public ResponseEntity<String> retryPayment(StripeDetails stripeDetails) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            LocalDate today = LocalDate.now();
            LocalDate startDate = stripeDetails.getStartDate();
//            if (startDate.isAfter(today)) {
                SubscriptionSchedule subscriptionSchedule = stripeConnect.retryScheduledSubscription(stripeDetails,startDate);
                return ResponseEntity.status(HttpStatus.OK)
                        .body("wellnessplan Re-Scheduled successfully");
//            }
//            Invoice subscription = stripeConnect.retrySubscription(stripeDetails);
//            return ResponseEntity.status(HttpStatus.OK).body(subscription.getHostedInvoiceUrl());
        } catch (StripeException e) {
            System.err.println("Stripe error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Stripe error: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error: " + e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public ResponseEntity<?> getPaidMonthsForSubscription(String subscriptionId)  {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Stripe.apiKey = apiKey;
            Map<String, Object> params = new HashMap<>();
            params.put("subscription", subscriptionId);
            InvoiceListParams invoiceListParams = InvoiceListParams.builder()
                    .setSubscription(subscriptionId)
                    .build();
            InvoiceCollection invoices = Invoice.list(invoiceListParams);
            int monthsPaid = 0;

            for (Invoice invoice : invoices.getData()) {
                if ("paid".equals(invoice.getStatus())) {
                    monthsPaid++;
                }
            }
            return ResponseEntity.status(HttpStatus.OK).body(monthsPaid);
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error while creating account link: " + e.getMessage());
        }
    }

    public ResponseEntity<?> checkCardExpiration(String customerId) {
        try {
            if (apiKey == null || apiKey.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API Key");
            }
            Customer customer = Customer.retrieve(customerId);
            if (customer == null || customer.getInvoiceSettings() == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Customer not found or no invoice settings available");
            }
            PaymentMethod paymentMethod = PaymentMethod.retrieve(customer.getInvoiceSettings().getDefaultPaymentMethod());
            if (paymentMethod == null || paymentMethod.getCard() == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Payment method or card details not found");
            }

            int currentYear = LocalDate.now().getYear();
            int currentMonth = LocalDate.now().getMonthValue();

            boolean isExpired = paymentMethod.getCard().getExpYear() < currentYear ||
                    (paymentMethod.getCard().getExpYear() == currentYear &&
                            paymentMethod.getCard().getExpMonth() < currentMonth);

            return ResponseEntity.status(HttpStatus.OK).body(isExpired);

        } catch (Exception e) {

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error while checking card expiration: " + e.getMessage());
        }
    }




}
