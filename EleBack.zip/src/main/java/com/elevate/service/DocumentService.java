package com.elevate.service;

import com.elevate.dto.DocumentDto;
import com.elevate.entity.UploadDocument;
import com.elevate.repository.IDocumentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.elevate.utils.USDateFormat;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DocumentService {

	@Autowired
	private IDocumentRepository documentRepository;

	public UploadDocument uploadDocument(DocumentDto documentDto) {
		String date = USDateFormat.dateFormat();
		documentDto.setUploadDate(date);
		UploadDocument document = new UploadDocument(documentDto.getDocumentUrl(), documentDto.getUploadedByRole(),
				documentDto.getUploadedById(), documentDto.getTargetType(), documentDto.getTargetId(),
				documentDto.getClinicId(), documentDto.getDescription(), documentDto.getFileSize(),
				documentDto.getUploadDate());

		return documentRepository.save(document);
	}

	public List<DocumentDto> getDocumentsBySuperAdminForAllClinics() {
		List<UploadDocument> documents = documentRepository.findByUploadedByRoleAndTargetTypeAndTargetId("SUPER_ADMIN",
				"AllClinic", null);
		return documents.stream().map((doc) -> {
			DocumentDto dto = new DocumentDto();
			dto.setId(doc.getId());
			dto.setDocumentUrl(doc.getDocumentUrl());
			dto.setUploadDate(doc.getUploadDate());
			dto.setDescription(doc.getDescription());
			dto.setClinicId(doc.getClinicId());
			dto.setTargetId(doc.getTargetId());
			dto.setTargetType(doc.getTargetType());
			dto.setUploadedById(doc.getUploadedById());
			dto.setUploadedByRole(doc.getUploadedByRole());
			dto.setFileSize(doc.getFileSize());
			return dto;

		}).collect(Collectors.toList());
	}

	public List<DocumentDto> getDocumentsBySuperAdminForClinic(Long clinicId) {

		List<UploadDocument> documents = documentRepository
				.findDocumentsBySuperAdminAndClinicIdOrAllClinics("SUPER_ADMIN", clinicId, "AllClinic");

		return documents.stream().map((doc) -> {
			DocumentDto dto = new DocumentDto();
			dto.setId(doc.getId());
			dto.setDocumentUrl(doc.getDocumentUrl());
			dto.setDescription(doc.getDescription());
			dto.setClinicId(doc.getClinicId());
			dto.setTargetId(doc.getTargetId());
			dto.setTargetType(doc.getTargetType());
			dto.setUploadedById(doc.getUploadedById());
			dto.setUploadedByRole(doc.getUploadedByRole());
			dto.setUploadDate(doc.getUploadDate());
			dto.setFileSize(doc.getFileSize());
			return dto;

		}).collect(Collectors.toList());
	}

	public List<DocumentDto> getDocumentsSentBySuperAdminToClinic(Long clinicId) {
		List<UploadDocument> documents = documentRepository
				.findDocumentsBySuperAdminForClinicOrAllClinics("SUPER_ADMIN", clinicId, "clinic");

		return documents.stream().map((doc) -> {
			DocumentDto dto = new DocumentDto();
			dto.setId(doc.getId());
			dto.setDocumentUrl(doc.getDocumentUrl());
			dto.setDescription(doc.getDescription());
			dto.setClinicId(doc.getClinicId());
			dto.setTargetId(doc.getTargetId());
			dto.setTargetType(doc.getTargetType());
			dto.setUploadedById(doc.getUploadedById());
			dto.setUploadedByRole(doc.getUploadedByRole());
			dto.setUploadDate(doc.getUploadDate());
			dto.setFileSize(doc.getFileSize());

			return dto;

		}).collect(Collectors.toList());

	}

	public List<DocumentDto> getDocumentsUploadedByClinicToSuperAdmin(Long clinicId) {
		List<UploadDocument> documents = documentRepository.findDocumentsUploadedByClinicToSuperAdmin(clinicId);

		return documents.stream().map((doc) -> {
			DocumentDto dto = new DocumentDto();
			dto.setId(doc.getId());
			dto.setDocumentUrl(doc.getDocumentUrl());
			dto.setDescription(doc.getDescription());
			dto.setClinicId(doc.getClinicId());
			dto.setTargetId(doc.getTargetId());
			dto.setTargetType(doc.getTargetType());
			dto.setUploadedById(doc.getUploadedById());
			dto.setUploadedByRole(doc.getUploadedByRole());
			dto.setUploadDate(doc.getUploadDate());
			dto.setFileSize(doc.getFileSize());
			return dto;
		}).collect(Collectors.toList());
	}

	public List<DocumentDto> getDocumentsUploadedByPetOwnerToClinic(Long clinicId, Long uploadedById) {
		List<UploadDocument> documents = documentRepository.findDocumentsUploadedByPetOwnerToClinic(clinicId,
				uploadedById);

		return documents.stream().map(doc -> {
			DocumentDto dto = new DocumentDto();
			dto.setId(doc.getId());
			dto.setDocumentUrl(doc.getDocumentUrl());
			dto.setDescription(doc.getDescription());
			dto.setClinicId(doc.getClinicId());
			dto.setTargetId(doc.getTargetId());
			dto.setTargetType(doc.getTargetType());
			dto.setUploadedById(doc.getUploadedById());
			dto.setUploadedByRole(doc.getUploadedByRole());
			dto.setUploadDate(doc.getUploadDate());
			dto.setFileSize(doc.getFileSize());
			return dto;
		}).collect(Collectors.toList());
	}

	public List<DocumentDto> getDocumentsUploadedByClinicToAllPetOwners(Long clinicId) {
		List<UploadDocument> documents = documentRepository.findDocumentsUploadedByClinicToAllPetOwners(clinicId);

		return documents.stream().map((doc) -> {
			DocumentDto dto = new DocumentDto();
			dto.setId(doc.getId());
			dto.setDocumentUrl(doc.getDocumentUrl());
			dto.setDescription(doc.getDescription());
			dto.setClinicId(doc.getClinicId());
			dto.setTargetId(doc.getTargetId());
			dto.setTargetType(doc.getTargetType());
			dto.setUploadedById(doc.getUploadedById());
			dto.setUploadedByRole(doc.getUploadedByRole());
			dto.setUploadDate(doc.getUploadDate());
			dto.setFileSize(doc.getFileSize());
			return dto;
		}).collect(Collectors.toList());
	}

	public List<DocumentDto> getDocumentsUploadedByClinicToSpecificOrAllPetOwners(Long clinicId, Long petId) {
		List<UploadDocument> documents = documentRepository
				.findDocumentsByClinicAndTargetIdAndTargetTypeAndRolesExcludingInvoice(clinicId, petId);

		return documents.stream().map((doc) -> {
			DocumentDto dto = new DocumentDto();
			dto.setId(doc.getId());
			dto.setDocumentUrl(doc.getDocumentUrl());
			dto.setDescription(doc.getDescription());
			dto.setClinicId(doc.getClinicId());
			dto.setTargetId(doc.getTargetId());
			dto.setTargetType(doc.getTargetType());
			dto.setUploadedById(doc.getUploadedById());
			dto.setUploadedByRole(doc.getUploadedByRole());
			dto.setUploadDate(doc.getUploadDate());
			dto.setFileSize(doc.getFileSize());
			return dto;
		}).collect(Collectors.toList());
	}

	public List<DocumentDto> getInvoicesByPetOwnerId(Long petOwnerId) {
		List<UploadDocument> allInvoices = documentRepository.findByDocumentType("Invoice");

		List<UploadDocument> filteredInvoices = allInvoices.stream()
				.filter(document -> document.getTargetId() != null && document.getTargetId().equals(petOwnerId))
				.collect(Collectors.toList());

		List<DocumentDto> documentDtos = filteredInvoices.stream().map(document -> {
			DocumentDto dto = new DocumentDto();
			dto.setId(document.getId());
			dto.setDocumentUrl(document.getDocumentUrl());
			dto.setUploadedById(document.getUploadedById());
			dto.setUploadedByRole(document.getUploadedByRole());
			dto.setTargetType(document.getTargetType());
			dto.setTargetId(document.getTargetId());
			dto.setClinicId(document.getClinicId());
			dto.setDescription(document.getDescription());
			dto.setUploadDate(document.getUploadDate());
			dto.setFileSize(document.getFileSize());
			dto.setManagePlanId(document.getManagePetWellnessPlan().getId());
			return dto;
		}).collect(Collectors.toList());

		return documentDtos;
	}

}