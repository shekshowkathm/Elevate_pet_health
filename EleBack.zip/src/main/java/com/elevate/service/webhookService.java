package com.elevate.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.elevate.Enum.Status;
import com.elevate.utils.EmailSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.elevate.entity.ClinicDetails;
import com.elevate.entity.PetDetails;
import com.elevate.entity.PetWellnessPlan;
import com.elevate.entity.TransactionDetails;
import com.elevate.repository.IClinicDetailsRepository;
import com.elevate.repository.IPetDetailsRepository;
import com.elevate.repository.IPetWellnessPlanRepository;
import com.elevate.repository.ITransactionDetailsRepository;
import com.stripe.Stripe;
import com.stripe.exception.SignatureVerificationException;
import com.stripe.exception.StripeException;
import com.stripe.model.BalanceTransaction;
import com.stripe.model.Charge;
import com.stripe.model.Event;
import com.stripe.model.Invoice;
import com.stripe.model.InvoiceLineItem;
import com.stripe.model.PaymentIntent;
import com.stripe.model.Price;
import com.stripe.model.Subscription;
import com.stripe.model.SubscriptionSchedule;
import com.stripe.model.Transfer;
import com.stripe.net.Webhook;
import com.stripe.param.TransferCreateParams;

@Service
public class webhookService {
    @Value("${Stripe.apiKey}")
    private String apiKey;
    @Value("${endpointSecret}")
    private String endpointSecret;
    @Autowired
    IPetDetailsRepository petDetailsRepository;

    @Autowired
    PetDetailsService petDetailsService;

    @Autowired
    ITransactionDetailsRepository transactionDetailsRepository;

    @Autowired
    IPetWellnessPlanRepository petWellnessPlanRepository;

    @Autowired
    IClinicDetailsRepository clinicDetailsRepository;

    @Autowired
    private EmailSender emailSender;

    public ResponseEntity<String> getStripePaymentStatus(String payload, String sigHeader) {
        // secretKey=endpointSecret;
     String secretKey = "whsec_yiKg7UTmpT0yLdjObfGEyRjWeSAvSMhW";
        // String secretKey = "whsec_acf4d7ab4abd954f2251fd7694bdf1cf88cc674afdb1a24f5a9deb006d693d8d";
        if (sigHeader == null) {
            System.out.println("Signature header is null");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Signature is null failed");
        }
        try {
            Event event = Webhook.constructEvent(payload, sigHeader, secretKey);
            switch (event.getType()) {
                case "subscription_schedule.created":
                    handleScheduleCreated(event);
                    break;
                case "subscription_schedule.updated":
                    handleScheduleUpdate(event);
                    break;
                case "subscription_schedule.released":
                    handleScheduleReleased(event);
                    break;
                case "invoice.payment_succeeded":
                    handlePaymentSucceess(event);
                    break;
                    
                case "invoice.payment_failed":
                    handlePaymentFailure(event);
                    break;
                case "customer.subscription.updated":
                    handleSubscriptionUpdate(event);
                    break;
                case "customer.subscription.created":
                    handleSubscriptionCreated(event);
                    break;
                case "transfer.created":
                    handleTranferPayment(event);
                    break;
                case "customer.subscription.deleted":
                    handleSubscriptionDeleted(event);
                    break;
                case "payment_intent.payment_failed":
                    handlePaymentIntentFailed(event);
                    break;
                default:
                    System.out.println("Unhandled event type: " + event.getType());
            }
            return ResponseEntity.ok("Event handled");
        } catch (SignatureVerificationException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Signature verification failed");
        } catch (StripeException e) {
            throw new RuntimeException(e);
        }
    }

public  String handleSubscriptionCreated(Event event){
    Subscription subscription = (Subscription) event.getData().getObject();
    if ("subscription_schedule".equals(subscription.getObject())) {
        TransactionDetails transactionDetails = transactionDetailsRepository
                .findByStripeSubscriptionId(subscription.getId());
        transactionDetails.setPaymentStatus(subscription.getStatus());
//            transactionDetails.setStripeSubscriptionId(subscription.g());
        transactionDetailsRepository.save(transactionDetails);
    }else {
        TransactionDetails transactionDetails = transactionDetailsRepository
                .findByStripeSubscriptionId(subscription.getSchedule());
        transactionDetails.setPaymentStatus(subscription.getStatus());
            transactionDetails.setStripeSubscriptionId(subscription.getId());
        transactionDetailsRepository.save(transactionDetails);
    }
    return "Success";
}
    public String handleScheduleUpdate(Event event) {
System.out.println(event+"handleScheduleUpdate");

        SubscriptionSchedule subscriptionSchedule = (SubscriptionSchedule) event.getData().getObject();
        if ("subscription_schedule".equals(subscriptionSchedule.getObject())) {
            TransactionDetails transactionDetails = transactionDetailsRepository
                    .findByStripeSubscriptionId(subscriptionSchedule.getId());

            System.out.println("Transaction Details: " + transactionDetails);
            if (transactionDetails != null) {
                transactionDetails.setPaymentStatus(subscriptionSchedule.getStatus());
                transactionDetails.setStripeSubscriptionId(subscriptionSchedule.getSubscription()); // Use correct subscription ID
                transactionDetailsRepository.save(transactionDetails);
            } else {
                System.out.println("No transaction details found for Subscription Schedule ID: " + subscriptionSchedule.getId());
            }

            List<PetWellnessPlan> existingPetWellnessDetails = petWellnessPlanRepository
                    .findByStripeSubscriptionId(subscriptionSchedule.getId());


            if (existingPetWellnessDetails != null && !existingPetWellnessDetails.isEmpty()) {
                for (PetWellnessPlan plan : existingPetWellnessDetails) {
                    plan.setPaymentStatus(subscriptionSchedule.getStatus());
                    plan.setStripeSubscriptionId(subscriptionSchedule.getSubscription()); // Use correct subscription ID
                    plan.setPlanStatus("scheduled");
                    plan.setWorkFlowStatus(Status.ACTIVE);
                    petWellnessPlanRepository.save(plan);
                }
            } else {
                System.out.println("No Pet Wellness Plans found for Subscription Schedule ID: " + subscriptionSchedule.getId());
            }
        }

        return "Success";
    }
  public String handleScheduleReleased(Event event){
      System.out.println(event+"handleScheduleReleased");

      SubscriptionSchedule subscriptionSchedule = (SubscriptionSchedule) event.getData().getObject();
      if ("subscription_schedule".equals(subscriptionSchedule.getObject())) {
          if(Objects.equals(subscriptionSchedule.getStatus(), "released")){
              List<PetWellnessPlan> existingPetWellnessDetails = petWellnessPlanRepository
                      .findByStripeSubscriptionId(subscriptionSchedule.getSubscription());
              if (existingPetWellnessDetails != null && !existingPetWellnessDetails.isEmpty()) {
                  for (PetWellnessPlan plan : existingPetWellnessDetails) {
                      plan.setPaymentStatus(subscriptionSchedule.getStatus());
                      plan.setPlanStatus("completed");
                      plan.setWorkFlowStatus(Status.COMPLETED);
                      petWellnessPlanRepository.save(plan);
                  }
              } else {
                  System.out.println("No Pet Wellness Plans found for Subscription Schedule ID: " + subscriptionSchedule.getId());
              }

          }
      }
      return "Success";
  }

    public String handlePaymentIntentFailed(Event event){
        System.out.println(event+"handlePaymentIntentFailed");
        PaymentIntent paymentIntent=(PaymentIntent) event.getData().getObject();
        System.out.println(paymentIntent+"Payment intent event Failed");
        TransactionDetails transactionDetails=new TransactionDetails();
        transactionDetails.setPaymentStatus(paymentIntent.getStatus());
        transactionDetails.setStripeInvoiceId(paymentIntent.getInvoice());
        transactionDetails.setStripeCustomerId(paymentIntent.getCustomer());
        transactionDetails.setStripePaymentId(paymentIntent.getId());
        transactionDetails.setPaymentFailedMsg(paymentIntent.getLastPaymentError().getMessage());
        TransactionDetails transactionDetails1=transactionDetailsRepository.save(transactionDetails);
        System.out.println(transactionDetails1+"transaction details card expired");
        return "Failed";
    }

    public String handlePaymentFailure(Event event) {
        System.out.println(event+"InvoiceInvoiceInvoice");
        try {
            Invoice invoice = (Invoice) event.getData().getObject();

            if (invoice == null) {
                System.err.println("Invoice data is null!");
                return "Failed";
            }

            Map<String, String> subscriptionMetadata = invoice.getSubscriptionDetails() != null
                    ? invoice.getSubscriptionDetails().getMetadata()
                    : new HashMap<>();

            String connectedAccountId = subscriptionMetadata.getOrDefault("connected_account_id", null);
            String invoiceNumber = invoice.getNumber();
            System.out.println(connectedAccountId);


            if (invoiceNumber == null || invoiceNumber.trim().isEmpty()) {
                System.err.println("Invoice number is null or empty!");
                return "Failed";
            }


            TransactionDetails existingTransactionDetails = transactionDetailsRepository.findByInvoiceNumber(invoiceNumber);



            if (existingTransactionDetails == null) {
                TransactionDetails transactionDetails = new TransactionDetails();
                transactionDetails.setInvoiceNumber(invoiceNumber);
                transactionDetails.setStripeSubscriptionId(invoice.getSubscription());
                transactionDetails.setStripeCustomerId(invoice.getCustomer());
                transactionDetails.setUrl(invoice.getHostedInvoiceUrl());
                transactionDetails.setPaymentStatus(invoice.getStatus());
                transactionDetails.setTotalAmount(invoice.getAmountDue() != null ? (double) invoice.getAmountDue() / 100 : 0.0);
                transactionDetails.setStripeConnectedAccountId(connectedAccountId);
                transactionDetails.setCustomerPaidDate(invoice.getEffectiveAt());
                TransactionDetails savedTransaction = transactionDetailsRepository.save(transactionDetails);
                System.out.println("New Transaction Saved: " + savedTransaction);

                if (invoice.getCustomerEmail() != null) {
                    emailSender.paymentFail(invoice.getCustomerEmail(), invoice.getCustomerName(), invoice.getAmountDue());
                }

            } else {
                if (!existingTransactionDetails.getInvoiceNumber().equals(invoiceNumber)) {
                    System.err.println("Mismatched invoice numbers! Investigate potential duplication.");
                    return "Failed";
                }

                existingTransactionDetails.setPaymentStatus(invoice.getStatus());
                existingTransactionDetails.setUrl(invoice.getHostedInvoiceUrl());
                TransactionDetails updatedTransaction = transactionDetailsRepository.save(existingTransactionDetails);
                System.out.println("Existing Transaction Updated: " + updatedTransaction);

                if (invoice.getCustomerEmail() != null) {
                    emailSender.paymentFail(invoice.getCustomerEmail(), invoice.getCustomerName(), invoice.getAmountDue());
                }
            }

        } catch (Exception e) {
            System.err.println("Error handling payment failure: " + e.getMessage());
            System.out.println(e.getMessage()+"InvoiceInvoiceInvoice");
            e.printStackTrace();
            return "Failed";
        }

        return "Success";
    }



    public String handlePaymentSucceess(Event event) {
        double platformAmount = 0;
        double amount = 0;
        double stripePercent;
        double platformDeduct;
        double amountStripeFee = 0.0;
        double platformStripeFee = 0.0;
        double fixamount = 0.0;
        double stripeFixfee = 0.0;
        double StripeFeeclinic =0.0;
        double StripeFeeelevate =0.0;
        Invoice invoice = (Invoice) event.getData().getObject();
        Map<String, String> subscriptionMetadata = invoice.getSubscriptionDetails().getMetadata();
        String connectedAccountId = subscriptionMetadata.get("connected_account_id");
        if (connectedAccountId == null || connectedAccountId.isEmpty()) {
            List<TransactionDetails> transactions = transactionDetailsRepository.findTransactions(invoice.getSubscription());
            if (!transactions.isEmpty()) {
                TransactionDetails latestTransaction = transactions.get(0);
                connectedAccountId = latestTransaction.getStripeConnectedAccountId();
            }
        }else {

        }
        List<InvoiceLineItem> lineItems = invoice.getLines().getData();
        for (InvoiceLineItem lineItem : lineItems) {
            String lineItemConnectedAccountId = lineItem.getPrice().getMetadata().get("connected_account_id");
            if (lineItemConnectedAccountId != null) {
                amount = amount + lineItem.getAmount();
            } else {
                platformAmount = platformAmount + lineItem.getAmount();
            }
        }
        double stripeFee = calculateStripeFee(invoice, platformAmount);
        System.out.println(amount+"clinicAmount");
        System.out.println(platformAmount + "elevateAmount");
        System.out.println(stripeFee+"stripeFee");
        stripePercent = (stripeFee / invoice.getAmountPaid()) * 100;
        if (invoice.getDiscount() != null) {
            double discount = invoice.getDiscount().getCoupon().getAmountOff();
            double discountedAmount=platformAmount-discount;
            platformDeduct = (stripePercent * discountedAmount) / 100;
            platformAmount = platformAmount - platformDeduct ;
        }
        platformDeduct = (stripePercent * platformAmount) / 100;

//        platformAmount = platformAmount - platformDeduct;
        System.out.println(amount+"amount");
        System.out.println(platformAmount+"platformAmount");
        double totalRevenue = amount + platformAmount;
         stripeFixfee = ((stripeFee)/100) -0.3;
        System.out.println(stripeFixfee+"stripeFixfeestripeFixfee");
        fixamount = stripeFixfee/((totalRevenue)/100);
        double roundedValue = Math.round(fixamount * 1000.0) / 1000.0;
        System.out.println(roundedValue+"roundedValueroundedValue");
        System.out.println(totalRevenue+"totalRevenue");
        if (totalRevenue > 0) {
            amountStripeFee = amount/100;
            platformStripeFee = platformAmount /100;
        }
        StripeFeeclinic = Math.round((amountStripeFee * roundedValue + 0.3) * 1000.0) / 1000.0;
        StripeFeeelevate = Math.round((platformStripeFee * roundedValue) * 1000.0) / 1000.0;
        amount = amountStripeFee -StripeFeeclinic;
        platformAmount =platformStripeFee -StripeFeeelevate;
        System.out.println("Amount (Connected Accounts) after Stripe Fee: " + amount);
        System.out.println("Amount Stripe Fee: " + StripeFeeclinic);
        System.out.println("Platform Amount after Stripe Fee: " + platformAmount);
        System.out.println("Platform Stripe Fee: " + StripeFeeelevate);
        System.out.println(platformAmount+"platformAmountplatformAmount");
        String updatedPetWellnessDetails = updatePetWellnessDetailsByStripe(invoice);
        long updatedTransactionDetails = updateTransactionDetails(invoice, connectedAccountId, amount, stripeFee,
                platformAmount,StripeFeeclinic,StripeFeeelevate);
        Transfer transferedData = transferToConnectedAccount(connectedAccountId, amount, stripeFee, invoice,
                platformAmount, updatedTransactionDetails);
        emailSender.paymentConfirm(invoice.getCustomerEmail(), invoice.getCustomerName(), invoice.getAmountPaid());

        return "Success";
    }

    public String handleScheduleCreated(Event event) throws StripeException {
        System.out.println("subscriptionSchedule"+event);
        SubscriptionSchedule subscriptionSchedule = (SubscriptionSchedule) event.getData().getObject();
        System.out.println(subscriptionSchedule.getStatus()+"subscriptionSchedule.getStatus()");

            Map<String, String> subscriptionMetadata = subscriptionSchedule.getMetadata();
            String connectedAccountId = subscriptionMetadata.get("connected_account_id");
            System.out.println(connectedAccountId+"connectedAccountIdNotStarted");
            List<SubscriptionSchedule.Phase> lineItems = subscriptionSchedule.getPhases();
            long startDate = 0;
            double toatlPrice = 0;
            for (SubscriptionSchedule.Phase phase : lineItems) {
                List<SubscriptionSchedule.Phase.AddInvoiceItem> invoiceItem = phase.getAddInvoiceItems();
                List<SubscriptionSchedule.Phase.Item> items = phase.getItems();
                startDate = phase.getStartDate();
                for (SubscriptionSchedule.Phase.AddInvoiceItem invoice : invoiceItem) {
                    String priceId = invoice.getPrice();
                    Price price = Price.retrieve(priceId);
                    toatlPrice = toatlPrice + price.getUnitAmount();
                }
                for (SubscriptionSchedule.Phase.Item item : items) {
                    String priceId = item.getPrice();
                    Price price = Price.retrieve(priceId);
                    toatlPrice = toatlPrice + price.getUnitAmount();
                }
            }
            TransactionDetails transactionDetails = new TransactionDetails();
            transactionDetails.setStripeCustomerId(subscriptionSchedule.getCustomer());
            transactionDetails.setStripeSubscriptionId(subscriptionSchedule.getId());
            transactionDetails.setPaymentStatus(subscriptionSchedule.getStatus());
            transactionDetails.setStripeConnectedAccountId(connectedAccountId);
            transactionDetails.setCustomerPaidDate(startDate);
            transactionDetails.setTotalAmount(toatlPrice / 100);
            TransactionDetails transactionObj = transactionDetailsRepository.save(transactionDetails);
            List<PetWellnessPlan> existingPetWellnessDetails = petWellnessPlanRepository
                    .findByStripeSubscriptionId(subscriptionSchedule.getId());
            for (PetWellnessPlan plan : existingPetWellnessDetails) {
                plan.setPaymentStatus(subscriptionSchedule.getStatus());
                plan.setPlanStatus("scheduled");
                plan.setWorkFlowStatus(Status.ACTIVE);
                petWellnessPlanRepository.save(plan);
            }

        return "Success";
    }

    public String handleSubscriptionUpdate(Event event) {
        System.out.println(event+"handleSubscriptionUpdatehandleSubscriptionUpdate");
        Subscription subscription = (Subscription) event.getData().getObject();
        if ("subscription_schedule".equals(subscription.getObject())) {
            TransactionDetails transactionDetails = transactionDetailsRepository
                    .findByStripeSubscriptionId(subscription.getSchedule());
            transactionDetails.setPaymentStatus(subscription.getStatus());
            transactionDetails.setStripeSubscriptionId(subscription.getId());
            transactionDetailsRepository.save(transactionDetails);
        }else {
//            TransactionDetails transactionDetails = transactionDetailsRepository
//                    .findByStripeSubscriptionId(subscription.getId());
//            transactionDetails.setPaymentStatus(subscription.getStatus());
//            transactionDetails.setStripeSubscriptionId(subscription.getSchedule());
//            transactionDetailsRepository.save(transactionDetails);
        }
        return "Success";
    }

    public String handleTranferPayment(Event event) {

        Transfer transfer = (Transfer) event.getData().getObject();
        System.out.println(transfer+"transfertransfer");
        Map<String, String> transferMetaData = transfer.getMetadata();
        TransactionDetails transactionDetails = transactionDetailsRepository
                .findById(Long.valueOf(transferMetaData.get("transactionId")))
                .orElseThrow(() -> new RuntimeException("Transaction details not found"));
        transactionDetails.setConnectedAccountReceived((double) (transfer.getAmount()) /100 );
        transactionDetails.setStripeTransferId(transfer.getId());
        transactionDetails.setClinicName(transfer.getDescription());
        transactionDetailsRepository.save(transactionDetails);

        return "Success";
    }

        public String handleSubscriptionDeleted(Event event) {
            System.out.println(event + " handleSubscriptionDeleted");
            try {
                Subscription subscription = (Subscription) event.getData().getObject();
                if (subscription == null) {
                    System.err.println("Subscription data is null!");
                    return "Failed";
                }

//                TransactionDetails transactionDetails = transactionDetailsRepository.findByStripeSubscriptionId(subscription.getId());

                List<TransactionDetails> transactions = transactionDetailsRepository.findTransactions(subscription.getId());

                if (!transactions.isEmpty()) {
                    TransactionDetails latestTransaction = transactions.get(0); // Fetch the latest record
                    latestTransaction.setPaymentStatus(subscription.getStatus());
                    transactionDetailsRepository.save(latestTransaction);
                    System.out.println("TransactionDetails updated successfully: " + latestTransaction);
                } else {
                    System.err.println("No TransactionDetails found for Subscription ID: " + subscription.getId());
                }

                List<PetWellnessPlan> petWellnessPlans = petWellnessPlanRepository.findByStripeSubscriptionId(subscription.getId());
                if (petWellnessPlans != null && !petWellnessPlans.isEmpty()) {
                    for (PetWellnessPlan petWellnessPlan : petWellnessPlans) {
                        petWellnessPlan.setPaymentStatus(subscription.getStatus());
                        petWellnessPlan.setPlanStatus(subscription.getStatus());
                        petWellnessPlan.setWorkFlowStatus(Status.CANCEL);
                        petWellnessPlanRepository.save(petWellnessPlan);
                    }
                    System.out.println("PetWellnessPlans updated successfully.");
                } else {
                    System.err.println("No PetWellnessPlans found for Subscription ID: " + subscription.getId());
                }

            } catch (Exception e) {
                System.err.println("Error handling subscription deletion: " + e.getMessage());
                e.printStackTrace();
                return "Failed";
            }

            return "Success";
        }


        public double calculateStripeFee(Invoice invoice, double platformAmount) {
        double stripeFee = 0;
        try {
            Stripe.apiKey = apiKey;
            String chargeId = invoice.getCharge();
            Charge charge = Charge.retrieve(chargeId);
            String balanceTransactionId = charge.getBalanceTransaction();
            BalanceTransaction balanceTransaction = BalanceTransaction.retrieve(balanceTransactionId);

            stripeFee = balanceTransaction.getFee();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return stripeFee;
    }

    public Transfer transferToConnectedAccount(String connectedAccountId, double amount, double stripeFee,
            Invoice invoice, double platformDeduct, long transactionId) {
        PetDetails existingPetDetails = petDetailsRepository
                .findByStripeCustomerId(invoice.getCustomer())
                .orElseThrow(() -> new RuntimeException("Pet details not found"));
        ClinicDetails clinicDetails = clinicDetailsRepository
                .findById(existingPetDetails.getClinic().getId()).get();
        Transfer transfer = null;
        System.out.println(amount + "amount");
        System.out.println(stripeFee + "stripeFee");
        System.out.println(platformDeduct + "platform deduct");
//        long calcAmount = (long) (amount - (stripeFee - platformDeduct));
        long calcAmount =(int) Math.round(amount * 100);
        System.out.println(amount + "calcAmount");
        System.out.println(connectedAccountId+"connectedAccountIdconnectedAccountId");
        try {
            TransferCreateParams transferParams = TransferCreateParams.builder()
                    .setAmount(calcAmount)
                    .setCurrency("usd")
                    .setDestination(connectedAccountId)
                    .putMetadata("transactionId", String.valueOf(transactionId))
                    .setDescription(clinicDetails.getClinicName())
                    .build();

            transfer = Transfer.create(transferParams);
        } catch (StripeException e) {
            System.err.println("Transfer failed: " + e.getMessage());
        }
        return transfer;
    }

    public Long updateTransactionDetails(Invoice invoice, String connectedAccountId, double amount, double stripeFee,
            double platformAmount,double StripeFeeclinic ,double StripeFeeelevate) {
        TransactionDetails existingTransactionDetails = transactionDetailsRepository.findByInvoiceNumber(invoice.getNumber());

        if (existingTransactionDetails == null || existingTransactionDetails.getInvoiceNumber() == null || existingTransactionDetails.getInvoiceNumber().isEmpty()) {
            TransactionDetails transactionDetails = new TransactionDetails();
            transactionDetails.setStripeCustomerId(invoice.getCustomer());
            transactionDetails.setStripeSubscriptionId(invoice.getSubscription());
            transactionDetails.setStripeConnectedAccountId(connectedAccountId);
            transactionDetails.setStripePaymentId(invoice.getPaymentIntent());
            transactionDetails.setStripeInvoiceId(invoice.getId());
            transactionDetails.setInvoiceNumber(invoice.getNumber());
            transactionDetails.setTotalAmount((double) invoice.getAmountPaid() / 100);
            transactionDetails.setUrl(invoice.getHostedInvoiceUrl());
            transactionDetails.setPetOwnerName(invoice.getCustomerName());
            transactionDetails.setPlatformReceivedAmount(platformAmount );
            transactionDetails.setStripeFeeClinic(StripeFeeclinic);
            transactionDetails.setStripeFeeElevate(StripeFeeelevate);
            transactionDetails.setStripeFee(stripeFee / 100);
            transactionDetails.setDiscountAmount(
                    invoice.getDiscount() != null && invoice.getDiscount().getCoupon() != null && invoice.getDiscount().getCoupon().getAmountOff() != null
                            ? (double) invoice.getDiscount().getCoupon().getAmountOff() / 100
                            : 0.0
            );

            if (invoice.getLines() != null) {
                transactionDetails.setReccuringCount(invoice.getLines().getObject());
            }
            transactionDetails.setPaymentStatus(invoice.getStatus());
            if (invoice.getStatusTransitions() != null) {
                transactionDetails.setCustomerPaidDate(invoice.getStatusTransitions().getPaidAt());
            }

            TransactionDetails transactionObj = transactionDetailsRepository.save(transactionDetails);
            return transactionObj.getId();
        } else {
            existingTransactionDetails.setPaymentStatus(invoice.getStatus());
            existingTransactionDetails.setUrl(invoice.getHostedInvoiceUrl());
            existingTransactionDetails.setStripeInvoiceId(invoice.getId());
            existingTransactionDetails.setStripePaymentId(invoice.getPaymentIntent());
            existingTransactionDetails.setTotalAmount((double) invoice.getAmountPaid() / 100);
            existingTransactionDetails.setPlatformReceivedAmount(platformAmount);
            existingTransactionDetails.setStripeFee(stripeFee / 100);
            existingTransactionDetails.setStripeFeeClinic(StripeFeeclinic);
            existingTransactionDetails.setStripeFeeElevate(StripeFeeelevate);
            existingTransactionDetails.setPetOwnerName(invoice.getCustomerName());
            if (invoice.getStatusTransitions() != null) {
                existingTransactionDetails.setCustomerPaidDate(invoice.getStatusTransitions().getPaidAt());
            }
            TransactionDetails transactionDetails = transactionDetailsRepository.save(existingTransactionDetails);
            return transactionDetails.getId();
        }

    }

    public String updatePetWellnessDetailsByStripe(Invoice invoice) {
//        List<PetWellnessPlan> existingPetDetails = petWellnessPlanRepository
//                .findByStripeSubscriptionIdAndStripeCustomerId(invoice.getSubscription(), invoice.getCustomer())
//                .orElseThrow(() -> new RuntimeException("Pet details not found"));

        List<PetWellnessPlan> existingWellnessPlan = petWellnessPlanRepository
                .findByStripeSubscriptionId(invoice.getSubscription());
        for (PetWellnessPlan plan : existingWellnessPlan) {
            plan.setPlanStatus(invoice.getStatus());
            plan.setStripeInvoiceId(invoice.getNumber());
            plan.setPaymentStatus(invoice.getStatus());
            plan.setStripePaymentId(invoice.getPaymentIntent());
            petWellnessPlanRepository.save(plan);
        }
        PetDetails  petDetails=petDetailsRepository.findByStripeCustomerId(invoice.getCustomer()).get();
        petDetails.setPaymentStatus(invoice.getStatus());
        petDetailsRepository.save(petDetails);
        return "UPDATED";
    }



}
