package com.elevate.service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.elevate.Enum.Status;
import com.elevate.dto.PlanConfirmNotificationDTO;
import com.elevate.entity.ClinicDetails;
import com.elevate.entity.PetDetails;
import com.elevate.entity.PetWellnessPlan;
import com.elevate.entity.Register;
import com.elevate.repository.IClinicDetailsRepository;
import com.elevate.repository.IPetDetailsRepository;
import com.elevate.repository.IPetWellnessPlanRepository;
import com.elevate.repository.IRegisterRepository;

@Service
public class AlertService {
	
	@Autowired
	private IPetWellnessPlanRepository petWellnessPlanRepository;
	
	@Autowired
	private IClinicDetailsRepository clinicDetailsRepository;
	
	@Autowired
	private IPetDetailsRepository petDetailsRepository;
	
	@Autowired
	private IRegisterRepository registerRepository;
			
	public List<PlanConfirmNotificationDTO> getPlansForConfirmation(Long clinicId) {
	    ClinicDetails clinicDetails = clinicDetailsRepository.findById(clinicId)
	            .orElseThrow(() -> new RuntimeException("Clinic ID not found"));
	    
	    if(clinicDetails == null) {
	    	throw new RuntimeException("Clinic Id is not found");
	    }

	    List<Status> statuses = List.of(
	            Status.SENT_TO_CLINIC,
	            Status.UPDATED_PLANS_TO_CLINIC,
	            Status.NEW_SET_TO_CLINIC
	    );

	    List<PetWellnessPlan> plans = petWellnessPlanRepository.findPlansByClinicIdAndStatuses(clinicId, statuses);

	    Map<String, PetWellnessPlan> uniquePlans = plans.stream()
	            .collect(Collectors.toMap(
	                    plan -> {
	                        return "KEY_" + plan.getPetId().getId() + "_" +
	                               plan.getPetOwnerId().getId() + "_" +
	                               plan.getWorkFlowStatus().name();
	                    },
	                    plan -> plan,
	                    (existing, replacement) -> existing 
	            ));

	    List<PlanConfirmNotificationDTO> listNotification = new ArrayList<>();
	    for (PetWellnessPlan dto : uniquePlans.values()) {
	        PlanConfirmNotificationDTO notification = new PlanConfirmNotificationDTO();

	        notification.setName(dto.getPetOwnerId().getFirstName() + " " + dto.getPetOwnerId().getLastName());
	        notification.setPhoneNumber(dto.getPetOwnerId().getContactNumber());
	        notification.setStatus(dto.getWorkFlowStatus().name());
	        notification.setPetId(dto.getPetId().getId());
	        notification.setPetOwnerId(dto.getPetOwnerId().getId());
            notification.setImage(dto.getPetOwnerId().getProfile());
	        
	        if (dto.getWorkFlowStatus().equals(Status.SENT_TO_CLINIC)) {
	            notification.setMessage("You need to confirm the plan for " + dto.getPetId().getPetName() +
	                    ". The pet owner, " + dto.getPetOwnerId().getFirstName() + " " +
	                    dto.getPetOwnerId().getLastName() + ", has chosen the plan, and it is now your turn to make it active.");
	        } else if (dto.getWorkFlowStatus().equals(Status.UPDATED_PLANS_TO_CLINIC)) {
	            notification.setMessage("The updated plan for " + dto.getPetId().getPetName() +
	                    " has been confirmed by the pet owner, " + dto.getPetOwnerId().getFirstName() +
	                    " " + dto.getPetOwnerId().getLastName() + ". It is now your turn to make it active.");
	        } else if (dto.getWorkFlowStatus().equals(Status.NEW_SET_TO_CLINIC)) {
	            notification.setMessage("The pet owner, " + dto.getPetOwnerId().getFirstName() +
	                    " " + dto.getPetOwnerId().getLastName() +
	                    ", has selected a plan from the new set for " + dto.getPetId().getPetName() +
	                    ". Please confirm and make it active.");
	        }

	        listNotification.add(notification);
	    }

	    return listNotification;
	}
	

	public List<PlanConfirmNotificationDTO> getPlansForPetOwnerNotification(Long petOwnerId) {
	    Register petOwnerCheck = registerRepository.findByIdAndRegisterStatusIsTrue(petOwnerId);
	    
	    if (petOwnerCheck == null) {
	        throw new RuntimeException("Pet owner not found or is inactive.");
	    }

	    List<PetDetails> pets = petDetailsRepository.findByPetOwner_IdAndStatusIsTrue(petOwnerId);
	    if (pets.isEmpty()) {
	        throw new RuntimeException("No pets found for the given pet owner.");
	    }

	    List<Status> statuses = List.of(
	            Status.NEW_SET_TO_PET_OWNER,
	            Status.UPDATED_PLANS_TO_OWNER,
	            Status.SENT_TO_PET_OWNER
	    );

	    List<PetWellnessPlan> plans = petWellnessPlanRepository.findPlansByPetIdsAndStatuses(
	            pets.stream().map(PetDetails::getId).collect(Collectors.toList()), statuses);

	    Map<String, PetWellnessPlan> uniquePlans = plans.stream()
	            .collect(Collectors.toMap(
	                    plan -> "KEY_" + plan.getPetId().getId() + "_" +
	                            plan.getPetOwnerId().getId() + "_" +
	                            plan.getWorkFlowStatus().name(),
	                    plan -> plan,
	                    (existing, replacement) -> existing 
	            ));
	    

	    List<PlanConfirmNotificationDTO> ownerNotifications = new ArrayList<>();
	    for (PetWellnessPlan plan : uniquePlans.values()) {
	        PlanConfirmNotificationDTO notification = new PlanConfirmNotificationDTO();

	        notification.setName(plan.getPetId().getPetName());
	        notification.setStatus(plan.getWorkFlowStatus().name());
	        notification.setPhoneNumber(plan.getClinicWellnessPlan().getClinic().getContactNumber());
	        notification.setPetId(plan.getPetId().getId());
	        notification.setPetOwnerId(plan.getPetOwnerId().getId());
            notification.setImage(plan.getClinicWellnessPlan().getClinic().getClinicImage());
            
	        if (plan.getWorkFlowStatus().equals(Status.NEW_SET_TO_PET_OWNER)) {
	            notification.setMessage("A new set of plans has been created for your pet, " +
	                    plan.getPetId().getPetName() + " from " +
	                    plan.getClinicWellnessPlan().getClinic().getClinicName() + ". Please review and choose a plan.");
	        } else if (plan.getWorkFlowStatus().equals(Status.UPDATED_PLANS_TO_OWNER)) {
	            notification.setMessage("There is an updated plan for your pet, " + plan.getPetId().getPetName() +
	                    " from " + plan.getClinicWellnessPlan().getClinic().getClinicName() +
	                    ". Please review the changes and confirm your choice.");
	        } else if (plan.getWorkFlowStatus().equals(Status.SENT_TO_PET_OWNER)) {
	            notification.setMessage("The plan for your pet, " + plan.getPetId().getPetName() +
	                    " from " + plan.getClinicWellnessPlan().getClinic().getClinicName() +
	                    ", has been finalized. Please confirm the selection to proceed.");
	        }

	        ownerNotifications.add(notification);
	    }

	    return ownerNotifications;
	}
	
	
	public List<PlanConfirmNotificationDTO> getPlanExpiryAlertsForClinic(Long clinicId) {
	    Instant thirtyDaysFromNow = Instant.now().plus(30, ChronoUnit.DAYS);

	    List<PetWellnessPlan> plans = petWellnessPlanRepository.findPlansByClinicAndStatus(Status.ACTIVE, clinicId);

	    List<PlanConfirmNotificationDTO> notifications = new ArrayList<>();
	    Set<Long> processedPlanIds = new HashSet<>(); 

	    for (PetWellnessPlan plan : plans) {
	        if (plan.getPetOwnerId() != null && plan.getManagePetWellnessPlan() != null) {
	            Long managePetWellnessPlanId = plan.getManagePetWellnessPlan().getId();

	            if (processedPlanIds.contains(managePetWellnessPlanId)) {
	                continue;
	            }

	            String endDateString = plan.getManagePetWellnessPlan().getEndDate();

	            try {
	                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	                LocalDate endDate = LocalDate.parse(endDateString, formatter);

	                Instant endDateInstant = endDate.atStartOfDay(ZoneId.systemDefault()).toInstant();

	                if (endDateInstant.isBefore(thirtyDaysFromNow) && endDateInstant.isAfter(Instant.now())) {
	                    long daysToExpire = ChronoUnit.DAYS.between(LocalDate.now(), endDate);

	                    PlanConfirmNotificationDTO notification = new PlanConfirmNotificationDTO();
	                    notification.setImage(plan.getPetId().getImage());
	                    notification.setName(plan.getPetId().getPetName());
	                    notification.setPetId(plan.getPetId().getId());
	                    notification.setPetOwnerId(plan.getPetOwnerId().getId());
	                    notification.setPhoneNumber(plan.getPetOwnerId().getContactNumber());
	                    notification.setStatus("PLAN_EXPIRING");
	                    notification.setMessage("The plan for " + plan.getPetId().getPetName() +
	                            " is going to end within " + daysToExpire + " days.");
	                    notifications.add(notification);

	                    processedPlanIds.add(managePetWellnessPlanId);
	                } 
	            } catch (DateTimeParseException e) {
	                System.err.println("Invalid endDate format for plan ID: " + plan.getId() + ", value: " + endDateString);
	            }
	        }
	    }

	    return notifications;
	}

	
	public List<PlanConfirmNotificationDTO> getPlanExpiryAlertsForPetOwner(Long petOwnerId) {
	    Optional<Register> petOwner = registerRepository.findById(petOwnerId);

	    if (petOwner.isPresent()) {
	        Instant thirtyDaysFromNow = Instant.now().plus(30, ChronoUnit.DAYS);

	        List<PetWellnessPlan> plans = petWellnessPlanRepository.findByPetOwnerIdAndWorkFlowStatus(petOwner.get(), Status.ACTIVE);

	        List<PlanConfirmNotificationDTO> notifications = new ArrayList<>();
	        Set<Long> processedPlanIds = new HashSet<>(); // To track processed plans

	        for (PetWellnessPlan plan : plans) {
	            if (plan.getPetOwnerId() != null && plan.getManagePetWellnessPlan() != null) {
	                Long managePetWellnessPlanId = plan.getManagePetWellnessPlan().getId();

	                if (processedPlanIds.contains(managePetWellnessPlanId)) {
	                    continue;
	                }

	                String endDateString = plan.getManagePetWellnessPlan().getEndDate();

	                try {
	                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	                    LocalDate endDate = LocalDate.parse(endDateString, formatter);

	                    Instant endDateInstant = endDate.atStartOfDay(ZoneId.systemDefault()).toInstant();

	                    if (endDateInstant.isBefore(thirtyDaysFromNow) && endDateInstant.isAfter(Instant.now())) {
	                        long daysToExpire = ChronoUnit.DAYS.between(LocalDate.now(), endDate);

	                        PlanConfirmNotificationDTO notification = new PlanConfirmNotificationDTO();
	                        notification.setImage(plan.getPetId().getImage());
	                        notification.setName(plan.getPetId().getPetName());
	                        notification.setPetId(plan.getPetId().getId());
	                        notification.setPetOwnerId(plan.getPetOwnerId().getId());
	                        notification.setPhoneNumber(plan.getPetOwnerId().getContactNumber());
	                        notification.setStatus("PLAN_EXPIRING");
	                        notification.setMessage("The plan for " + plan.getPetId().getPetName() +
	                                " is going to end within " + daysToExpire + " days.");
	                        notifications.add(notification);

	                        processedPlanIds.add(managePetWellnessPlanId);
	                    }
	                } catch (DateTimeParseException e) {
	                    System.err.println("Invalid endDate format for plan ID: " + plan.getId() + ", value: " + endDateString);
	                }
	            }
	        }

	        return notifications;
	    } else {
	        return Collections.emptyList();
	    }
	}
	
	
	 public List<PlanConfirmNotificationDTO> getScheduledAppointmentsAlertsForClinic(Long clinicId) {
	        Instant now = Instant.now();
	        Instant startOfDay = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant();
	        Instant endOfDay = LocalDate.now().atTime(23, 59, 59).atZone(ZoneId.systemDefault()).toInstant();

	        List<PetWellnessPlan> todaysAppointments = petWellnessPlanRepository.findByClinicWellnessPlan_ClinicIdAndScheduledDateAndTimeBetween(clinicId, startOfDay, endOfDay);

	        List<PetWellnessPlan> missedAppointments = petWellnessPlanRepository.findByClinicWellnessPlan_ClinicIdAndScheduledDateAndTimeBeforeAndWorkFlowStatus(clinicId, now, Status.ACTIVE);

	        List<PlanConfirmNotificationDTO> notifications = new ArrayList<>();

	        for (PetWellnessPlan plan : todaysAppointments) {
	            PlanConfirmNotificationDTO dto = new PlanConfirmNotificationDTO();
	            dto.setPetId(plan.getPetId().getId());
	            dto.setPetOwnerId(plan.getPetOwnerId().getId());
	            dto.setName(plan.getPetId().getPetName());
	            dto.setPhoneNumber(plan.getPetOwnerId().getContactNumber());
	            dto.setStatus("TODAYS_APPOINTMENTS");
	            dto.setMessage("The appointment for " + plan.getPetId().getPetName() 
	                    + " is scheduled for today for the service: " 
	                    + plan.getClinicWellnessPlan().getWellnessPlan().getService().getService() 
	                    + " - " + plan.getClinicWellnessUpdate().getDropDown().getDropdown() 
	                    + " at " + formatDateTime(plan.getScheduledDateAndTime()) + ".");
	            dto.setImage(plan.getPetId().getImage());
	            notifications.add(dto);
	        }

	        for (PetWellnessPlan plan : missedAppointments) {
	            PlanConfirmNotificationDTO dto = new PlanConfirmNotificationDTO();
	            dto.setPetId(plan.getPetId().getId());
	            dto.setPetOwnerId(plan.getPetOwnerId().getId());
	            dto.setName(plan.getPetId().getPetName());
	            dto.setPhoneNumber(plan.getPetOwnerId().getContactNumber());
	            dto.setStatus("MISSED_APPOINTMENTS");
	            dto.setMessage("The appointment for " + plan.getPetId().getPetName() 
	                    + " is scheduled for today for the service: " 
	                    + plan.getClinicWellnessPlan().getWellnessPlan().getService().getService() 
	                    + " - " + plan.getClinicWellnessUpdate().getDropDown().getDropdown() 
	                    + " at " + formatDateTime(plan.getScheduledDateAndTime()) + ".");
	            dto.setImage(plan.getPetId().getImage());
	            notifications.add(dto);
	        }

	        return notifications;
	    }


	 public String formatDateTime(Instant scheduledDateAndTime) {
		    ZonedDateTime zonedDateTime = scheduledDateAndTime.atZone(ZoneId.systemDefault()); 
		    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"); 
		    return zonedDateTime.format(formatter); 
		}
	 
	 public List<PlanConfirmNotificationDTO> getScheduledAppointmentsAlertsForPetOwner(Long petOwnerId) {
		    Instant now = Instant.now();
		    Instant startOfDay = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant();
		    Instant endOfDay = LocalDate.now().atTime(23, 59, 59).atZone(ZoneId.systemDefault()).toInstant();

		    List<PetWellnessPlan> todaysAppointments = petWellnessPlanRepository
		            .findTodaysAppointmentsForPetOwner(petOwnerId, startOfDay, endOfDay);
		    List<PetWellnessPlan> missedAppointments = petWellnessPlanRepository
		            .findMissedAppointmentsForPetOwner(petOwnerId, now, Status.ACTIVE);

		    List<PlanConfirmNotificationDTO> notifications = new ArrayList<>();

		    for (PetWellnessPlan plan : todaysAppointments) {
		        PlanConfirmNotificationDTO dto = new PlanConfirmNotificationDTO();
		        dto.setPetId(plan.getPetId().getId());
		        dto.setPetOwnerId(plan.getPetOwnerId().getId());
		        dto.setName(plan.getPetId().getPetName());
		        dto.setPhoneNumber(plan.getPetOwnerId().getContactNumber());
		        dto.setStatus("TODAYS_APPOINTMENTS");
		        dto.setMessage("The appointment for " + plan.getPetId().getPetName()
		                + " is scheduled for today for the service: "
		                + plan.getClinicWellnessPlan().getWellnessPlan().getService().getService()
		                + " - " + plan.getClinicWellnessUpdate().getDropDown().getDropdown()
		                + " at " + formatDateTime(plan.getScheduledDateAndTime()) + ".");
		        dto.setImage(plan.getPetId().getImage());
		        notifications.add(dto);
		    }

		    for (PetWellnessPlan plan : missedAppointments) {
		        PlanConfirmNotificationDTO dto = new PlanConfirmNotificationDTO();
		        dto.setPetId(plan.getPetId().getId());
		        dto.setPetOwnerId(plan.getPetOwnerId().getId());
		        dto.setName(plan.getPetId().getPetName());
		        dto.setPhoneNumber(plan.getPetOwnerId().getContactNumber());
		        dto.setStatus("MISSED_APPOINTMENTS");
		        dto.setMessage("The appointment for " + plan.getPetId().getPetName()
		                + " was missed for the service: "
		                + plan.getClinicWellnessPlan().getWellnessPlan().getService().getService()
		                + " - " + plan.getClinicWellnessUpdate().getDropDown().getDropdown()
		                + " at " + formatDateTime(plan.getScheduledDateAndTime()) + ".");
		        dto.setImage(plan.getPetId().getImage());
		        notifications.add(dto);
		    }

		    return notifications;
		}
	 
	 public Map<String, Long> getNotificationCounts(Long petOwnerId) {
		    Map<String, Long> notificationCounts = new HashMap<>();

		    Instant now = Instant.now();
		    Instant startOfDay = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant();
		    Instant endOfDay = LocalDate.now().atTime(23, 59, 59).atZone(ZoneId.systemDefault()).toInstant();
		    long scheduledAppointmentsCount = petWellnessPlanRepository
		            .findTodaysAppointmentsForPetOwner(petOwnerId, startOfDay, endOfDay)
		            .size();
		    notificationCounts.put("ScheduledAppointments", scheduledAppointmentsCount);

		    long missedAppointmentsCount = petWellnessPlanRepository
		            .findMissedAppointmentsForPetOwner(petOwnerId, now, Status.ACTIVE)
		            .size();
		    notificationCounts.put("MissedAppointments", missedAppointmentsCount);

		    Optional<Register> petOwner = registerRepository.findById(petOwnerId);
		    long planExpiryCount = 0;
		    if (petOwner.isPresent()) {
		        Instant thirtyDaysFromNow = Instant.now().plus(30, ChronoUnit.DAYS);
		        List<PetWellnessPlan> plans = petWellnessPlanRepository
		                .findByPetOwnerIdAndWorkFlowStatus(petOwner.get(), Status.ACTIVE);
		        planExpiryCount = plans.stream()
		                .filter(plan -> {
		                    String endDateString = plan.getManagePetWellnessPlan().getEndDate();
		                    try {
		                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		                        LocalDate endDate = LocalDate.parse(endDateString, formatter);
		                        Instant endDateInstant = endDate.atStartOfDay(ZoneId.systemDefault()).toInstant();
		                        return endDateInstant.isBefore(thirtyDaysFromNow) && endDateInstant.isAfter(Instant.now());
		                    } catch (DateTimeParseException e) {
		                        System.err.println("Invalid endDate format for plan ID: " + plan.getId() + ", value: " + endDateString);
		                        return false;
		                    }
		                })
		                .count();
		    }
		    notificationCounts.put("PlanExpiry", planExpiryCount);

		    Register petOwnerCheck = registerRepository.findByIdAndRegisterStatusIsTrue(petOwnerId);
		    long plansForPetOwnerCount = 0;
		    if (petOwnerCheck != null) {
		        List<PetDetails> pets = petDetailsRepository.findByPetOwner_IdAndStatusIsTrue(petOwnerId);
		        if (!pets.isEmpty()) {
		            List<Status> statuses = List.of(
		                    Status.NEW_SET_TO_PET_OWNER,
		                    Status.UPDATED_PLANS_TO_OWNER,
		                    Status.SENT_TO_PET_OWNER
		            );
		            plansForPetOwnerCount = petWellnessPlanRepository
		                    .findPlansByPetIdsAndStatuses(
		                            pets.stream().map(PetDetails::getId).collect(Collectors.toList()), statuses)
		                    .stream()
		                    .map(plan -> "KEY_" + plan.getPetId().getId() + "_" +
		                            plan.getPetOwnerId().getId() + "_" +
		                            plan.getWorkFlowStatus().name())
		                    .distinct()
		                    .count();
		        }
		    }
		    notificationCounts.put("PlansForPetOwner", plansForPetOwnerCount);

		    long totalNotifications = scheduledAppointmentsCount + missedAppointmentsCount + planExpiryCount + plansForPetOwnerCount;
		    notificationCounts.put("TotalNotifications", totalNotifications);

		    return notificationCounts;
		}

}