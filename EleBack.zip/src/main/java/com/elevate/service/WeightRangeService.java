package com.elevate.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.elevate.dto.UpdateServiceStatus;
import com.elevate.entity.ClinicDetails;
import com.elevate.entity.ClinicWeightRange;
import com.elevate.entity.WeightRange;
import com.elevate.repository.IClinicDetailsRepository;
import com.elevate.repository.IClinicWeightRangeRepository;
import com.elevate.repository.IWeightRangeRepository;

@Service
public class WeightRangeService {

	@Autowired
	private IWeightRangeRepository weightRangeRepository;

	@Autowired
	private IClinicDetailsRepository clinicRepository;

	@Autowired
	private IClinicWeightRangeRepository clinicWeightRangeRepository;

	public ResponseEntity<String> add(WeightRange weight) {
	    String[] weightBounds = weight.getWeight().replace("lb", "").split("-");
	    double newMinWeight = Double.parseDouble(weightBounds[0].trim());
	    double newMaxWeight = Double.parseDouble(weightBounds[1].trim());

	    List<WeightRange> existingRanges = weightRangeRepository.findByPetTypeAndStatusTrue(weight.getPetType());

	    if (existingRanges.isEmpty()) {
	        weight.setStatus(true);
	        WeightRange weightRange = weightRangeRepository.save(weight);
	        addWeightRangeToClinics(weightRange);
	        return ResponseEntity.ok("Weight range added successfully!");
	    }

	    existingRanges.sort((range1, range2) -> {
	        double range1Min = Double.parseDouble(range1.getWeight().replace("lb", "").split("-")[0].trim());
	        double range2Min = Double.parseDouble(range2.getWeight().replace("lb", "").split("-")[0].trim());
	        return Double.compare(range1Min, range2Min);
	    });

	    WeightRange lastRange = existingRanges.get(existingRanges.size() - 1);
	    String[] lastBounds = lastRange.getWeight().replace("lb", "").split("-");
	    double lastMinWeight = Double.parseDouble(lastBounds[0].trim());
	    double lastMaxWeight = Double.parseDouble(lastBounds[1].trim());

	    if (newMinWeight == lastMinWeight && newMaxWeight == lastMaxWeight) {
	        return ResponseEntity.status(HttpStatus.CONFLICT)
	                .body("Duplicate Entry: This weight range already exists.");
	    }

	    if (newMinWeight <= lastMaxWeight && newMaxWeight >= lastMinWeight) {
	        return ResponseEntity.status(HttpStatus.CONFLICT)
	                .body("Weight range overlaps with an existing range for the same pet type.");
	    }

	    double epsilon = 0.01;

	    if (Math.abs(newMinWeight - (lastMaxWeight + epsilon)) > epsilon) {
	        return ResponseEntity.status(HttpStatus.CONFLICT)
	                .body("Weight range does not connect to the last existing range.");
	    }

	    weight.setStatus(true);
	    WeightRange weightRange = weightRangeRepository.save(weight);
	    addWeightRangeToClinics(weightRange);

	    return ResponseEntity.ok("Weight range added successfully!");
	}



	private void addWeightRangeToClinics(WeightRange weightRange) {
		List<ClinicDetails> clinics = clinicRepository.findByClinicStatusIsTrue();
		if (clinics != null && !clinics.isEmpty()) {
			for (ClinicDetails clinicDetails : clinics) {
				ClinicWeightRange clinicWeightRange = new ClinicWeightRange();
				clinicWeightRange.setClinic(clinicDetails);
				clinicWeightRange.setWeightRange(weightRange);
				clinicWeightRangeRepository.save(clinicWeightRange);
			}
		}
	}

	public List<WeightRange> getAllData() {
		return weightRangeRepository.findAll();
	}

	public ResponseEntity<String> update(WeightRange weight) {
		String[] weightBounds = weight.getWeight().replace("lb", "").split("-");
		int newMinWeight = Integer.parseInt(weightBounds[0].trim());
		int newMaxWeight = Integer.parseInt(weightBounds[1].trim());

		WeightRange weightDetails = weightRangeRepository.findById(weight.getId()).orElse(null);
		if (weightDetails == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Weight range not found.");
		}

		List<WeightRange> existingRanges = weightRangeRepository.findByPetTypeAndStatusTrue(weight.getPetType());
		for (WeightRange existing : existingRanges) {
			if (!existing.getId().equals(weight.getId())) { // Exclude the current range from validation
				String[] existingBounds = existing.getWeight().replace("lb", "").split("-");
				int existingMinWeight = Integer.parseInt(existingBounds[0].trim());
				int existingMaxWeight = Integer.parseInt(existingBounds[1].trim());

				if ((newMinWeight <= existingMaxWeight && newMaxWeight >= existingMinWeight)) {
					return ResponseEntity.status(HttpStatus.CONFLICT)
							.body("Weight range overlaps with an existing range for the same pet type.");
				}

				if (newMinWeight == existingMinWeight && newMaxWeight == existingMaxWeight) {
					return ResponseEntity.status(HttpStatus.CONFLICT)
							.body("Duplicate Entry: This weight range already exists.");
				}
			}
		}

		weightDetails.setPetType(weight.getPetType());
		weightDetails.setWeight(weight.getWeight());
		weightDetails.setSize(weight.getSize());
		weightRangeRepository.save(weightDetails);

		return ResponseEntity.ok("Weight range updated successfully!");
	}

	public String deleteWeightRange(Long id) {
		WeightRange checkId = weightRangeRepository.findById(id).get();
		if (checkId != null) {
			weightRangeRepository.deleteById(id);
			return "Deleted";
		} else {
			return "Weight Range id not found";
		}
	}

	public String updateStatus(UpdateServiceStatus status) {
		WeightRange weightStaus = weightRangeRepository.findById(status.getId())
				.orElseThrow(() -> new RuntimeException("Weight Range Id not found"));
		if (weightStaus != null) {
			weightStaus.setStatus(status.isStatus());
		}
		return "Weight Range Status Updated";
	}

}
