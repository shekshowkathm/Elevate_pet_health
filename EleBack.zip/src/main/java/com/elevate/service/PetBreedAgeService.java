package com.elevate.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.elevate.dto.UpdateServiceStatus;
import com.elevate.entity.PetBreedAge;
import com.elevate.repository.IPetBreedAgeRepository;

@Service
public class PetBreedAgeService {
	
	@Autowired
	private IPetBreedAgeRepository ageRepository;
	
	
	public ResponseEntity<String> add(PetBreedAge breedAge) {
	    List<PetBreedAge> existingBreeds = ageRepository.findByPetTypeAndStatusTrue(breedAge.getPetType());
	    for (PetBreedAge existing : existingBreeds) {
	        if (existing.getBreed().equalsIgnoreCase(breedAge.getBreed())) {
	            return ResponseEntity.status(HttpStatus.CONFLICT)
	                    .body("Duplicate Entry: Breed already exists for the given pet type.");
	        }
	    }

	    List<String> newRanges = List.of(
	            breedAge.getAgeForPuppy(),
	            breedAge.getAgeForKitten(),
	            breedAge.getAgeForAdult(),
	            breedAge.getAgeForSenior()
	    );

	    if (!isContinuous(newRanges)) {
	        return ResponseEntity.status(HttpStatus.CONFLICT)
	                .body("Invalid age range: Gaps or overlaps detected between age ranges.");
	    }

	    breedAge.setStatus(true);
	    ageRepository.save(breedAge);
	    return ResponseEntity.ok("Pet breed and age added successfully!");
	}


	private boolean isContinuous(List<String> ageRanges) {
	    int lastMax = -1;

	    for (String range : ageRanges) {
	        if (range == null || range.isBlank()) {
	            continue; 
	        }

	        String[] bounds = range.replace("months", "").trim().split("-");
	        int min = Integer.parseInt(bounds[0].trim());
	        int max = Integer.parseInt(bounds[1].trim());

	        if (lastMax != -1 && min != lastMax + 1) {
	            return false; 
	        }

	        lastMax = max; 
	    }
	    return true; 
	}

	
	public List<PetBreedAge> getAllAgeAndBreed(){
		return ageRepository.findAll();
	}
	
//	public PetBreedAge updateData(PetBreedAge update) {
//		PetBreedAge age = ageRepository.findById(update.getId()).get();
//		if(age!=null) {
//			age.setPetType(update.getPetType());
//			age.setBreed(update.getBreed());
//			age.setBreedType(update.getBreedType());
//			age.setAgeForPuppy(update.getAgeForPuppy());
//			age.setAgeForKitten(update.getAgeForKitten());
//			age.setAgeForAdult(update.getAgeForAdult());
//			age.setAgeForSenior(update.getAgeForSenior());
//			ageRepository.save(age);
//		}
//		return age;
//	}
	
	
	public ResponseEntity<String> updateData(PetBreedAge update) {
	    Optional<PetBreedAge> existingRecord = ageRepository.findById(update.getId());
	    if (existingRecord.isEmpty()) {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                .body("Error: Breed data not found for the given ID.");
	    }

	    PetBreedAge age = existingRecord.get();
	    List<PetBreedAge> breedsWithSamePetType = ageRepository.findByPetTypeAndStatusTrue(update.getPetType());
	    for (PetBreedAge breed : breedsWithSamePetType) {
	        if (!breed.getId().equals(update.getId()) && breed.getBreed().equalsIgnoreCase(update.getBreed())) {
	            return ResponseEntity.status(HttpStatus.CONFLICT)
	                    .body("Error: Breed name already exists for the given pet type.");
	        }
	    }

	    List<String> newRanges = List.of(
	            update.getAgeForPuppy(),
	            update.getAgeForKitten(),
	            update.getAgeForAdult(),
	            update.getAgeForSenior()
	    );

	    if (!isContinuous(newRanges)) {
	        return ResponseEntity.status(HttpStatus.CONFLICT)
	                .body("Error: Overlapping or invalid age ranges detected.");
	    }

	    age.setPetType(update.getPetType());
	    age.setBreed(update.getBreed());
	    age.setBreedType(update.getBreedType());
	    age.setAgeForPuppy(update.getAgeForPuppy());
	    age.setAgeForKitten(update.getAgeForKitten());
	    age.setAgeForAdult(update.getAgeForAdult());
	    age.setAgeForSenior(update.getAgeForSenior());

	    ageRepository.save(age);
	    return ResponseEntity.ok("Breed updated successfully!");
	}

	
	public String deleteBreed(Long id) {
		PetBreedAge petBreed = ageRepository.findById(id).get();
		if(petBreed!=null) {
			ageRepository.deleteById(id);
			return "Updated";
		}else {
			return "Id not found";
		}
	}
	
	public String updateStatus(UpdateServiceStatus status) {
		PetBreedAge petBreedStatus = ageRepository.findById(status.getId()).orElseThrow(() -> new RuntimeException("Breed Id not found"));
		if(petBreedStatus!= null) {
            petBreedStatus.setStatus(status.isStatus());
            ageRepository.save(petBreedStatus);
		}
		return "Updated";
	}
	
	public List<String> getBreedName(String petType) {
	    List<PetBreedAge> getPetBreedData = ageRepository.findByPetType(petType);
	    List<String> breedNames = new ArrayList<>();

	    if (getPetBreedData != null) {
	        for (PetBreedAge pet : getPetBreedData) {
	            breedNames.add(pet.getBreed());
	        }
	    }

	    return breedNames;
	}
	
}
