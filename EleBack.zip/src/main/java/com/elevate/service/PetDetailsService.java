package com.elevate.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import com.elevate.Enum.Status;
import com.elevate.config.StripeConnect;
import com.elevate.dto.*;
import com.elevate.entity.*;
import com.elevate.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import com.elevate.dto.AddPetOwnerDTO;
import com.elevate.dto.ClinicDTO;
import com.elevate.dto.ClinicWellnessPlanDTO;
import com.elevate.dto.ClinicWellnessPlanUpdateDTO;
import com.elevate.dto.DoctorDTO;
import com.elevate.dto.GetPetWellnessPlanDTO;
import com.elevate.dto.PetDTO;
import com.elevate.dto.PetDetailsDTO;
import com.elevate.dto.PetImageList;
import com.elevate.dto.PetOwnerClinics;
import com.elevate.dto.PetOwnerPetDetails;
import com.elevate.dto.PetOwnerPlanDTO;
import com.elevate.dto.PetOwnerRegisterDTO;
import com.elevate.dto.PetPlansDTO;
import com.elevate.utils.Agegroup;
import com.elevate.utils.CalculateAge;
import com.elevate.utils.USDateFormat;

@Service
public class PetDetailsService {

	@Autowired
	private IPetDetailsRepository petDetailsRepository;

	@Autowired
	private IRegisterRepository registerRepository;

	@Autowired
	private IClinicDetailsRepository clinicDetailsRepository;

	@Autowired
	private IPetBreedAgeRepository petBreedAgeRepository;

	@Autowired
	private IPetWellnessPlanRepository petWellnessPlanRepository;

	@Autowired
	private IClinicWellnessPlanRepository clinicWellnessPlanRepository;

	@Autowired
	private IClinicWellnessUpdateRepository clincWellnessUpdateRepository;

	@Autowired
	private StripeConnect stripeConnect;

	@Autowired
	private IWeightRangeRepository weightRangeRepository;

	@Autowired
	private IPromotionDiscountRepository promotionDiscountRepository;

	@Autowired
	private IManagePetWellnessPlansRepository managePetWellnessPlanRepository;

	public ResponseEntity<String> registerPetOwner(PetOwnerRegisterDTO petOwner) {
		if (registerRepository.existsByEmail(petOwner.getEmail())) {
			return new ResponseEntity<>("Email ALready Exists", HttpStatus.CONFLICT);
		}
		Register register = new Register();
		register.setEmail(petOwner.getEmail());
		register.setCreated_On(USDateFormat.dateFormat());
		register.setContactNumber(petOwner.getContact());
		register.setRole(petOwner.getRole());
		register.setFirstName(petOwner.getFirstName());
		register.setLastName(petOwner.getLastName());
		register.setTimezone(petOwner.getTimezone());
		register.setProfile("https://elevatepethealth-imagestorage.s3.us-east-1.amazonaws.com/media/profile-user.png");
		Register registerObj = registerRepository.save(register);

		PetDetails petDetails = new PetDetails();
		ClinicDetails clinic = clinicDetailsRepository.findById(petOwner.getClinicId())
				.orElseThrow(() -> new RuntimeException("Clinic Not found"));
		petDetails.setClinic(clinic);
		petDetails.setPetOwner(registerObj);
		petDetails.setImage(
				"https://elevatepethealth-imagestorage.s3.us-east-1.amazonaws.com/media/Static%20images%20dog%20and%20cat.jpg");
		petDetailsRepository.save(petDetails);

		return new ResponseEntity<>("Pet Owner Added", HttpStatus.CREATED);
	}

	public String addPet(PetDetails petDetails) {
		PetDetails petDetail = petDetailsRepository.findByPetTypeIsNullAndPetOwner_IdAndClinic_Id(
				petDetails.getPetOwner().getId(), petDetails.getClinic().getId());
		if (petDetail != null) {
			petDetail.setDob(petDetails.getDob());
			petDetail.setGender(petDetails.getGender());
			petDetail.setStatus(true);
			petDetail.setPetName(petDetails.getPetName());
			petDetail.setPetBreed(petDetails.getPetBreed());
			petDetail.setWeight(petDetails.getWeight());
			if (petDetails.getImage() == null || petDetails.getImage() == " ") {
				petDetail.setImage(
						"https://elevatepethealth-imagestorage.s3.us-east-1.amazonaws.com/media/Static%20images%20dog%20and%20cat.jpg");
			} else {
				petDetail.setImage(petDetails.getImage());
			}
			petDetail.setPetType(petDetails.getPetType());
			if (petDetail.getPetType() != null && petDetail.getPetBreed() != null) {
				PetBreedAge petBreedAge = petBreedAgeRepository
						.findByPetTypeAndBreed(petDetail.getPetType(), petDetail.getPetBreed()).get(0);
				petDetail.setAgeGroup(
						Agegroup.determineAgeCategory(CalculateAge.petAgeByMonth(petDetail.getDob()), petBreedAge));
			}
			petDetailsRepository.save(petDetail);
		} else {
			petDetails.setStatus(true);
			petDetailsRepository.save(petDetails);
		}

		return "Pet added";
	}

	public String addClinic(Long petOwnerId, Long clinicId) {
		List<PetDetails> petDetails = petDetailsRepository.findByClinicIdAndPetOwner_Id(clinicId, petOwnerId);
		if (petDetails.isEmpty()) {
			PetDetails pet = new PetDetails();
			ClinicDetails clinic = clinicDetailsRepository.findById(clinicId).get();
			Register register = registerRepository.findById(petOwnerId).get();
			pet.setClinic(clinic);
			pet.setPetOwner(register);
			pet.setImage(
					"https://elevatepethealth-imagestorage.s3.us-east-1.amazonaws.com/media/Static%20images%20dog%20and%20cat.jpg");
			petDetailsRepository.save(pet);
			return "Clinic added";
		} else {
			return "Already exist";
		}
	}

	public String updatePetStatus(Long petId) {
		PetDetails petDetails = petDetailsRepository.findById(petId).get();
		petDetails.setStatus(true);
		petDetailsRepository.save(petDetails);
		ClinicDetails clinicDetails = clinicDetailsRepository.findById(petDetails.getClinic().getId()).get();
		List<PetDetails> pets = clinicDetails.getPetDetails();
		pets.add(petDetails);
		clinicDetails.setPetDetails(pets);
		clinicDetailsRepository.save(clinicDetails);
		return "Updated";
	}

	public List<PetOwnerRegisterDTO> notRegisteredPetOwners(Long clinicId) {
		List<PetOwnerRegisterDTO> petOwnersDTO = new ArrayList<>();

		List<PetDetails> petOwner = petDetailsRepository.findByClinicIdAndStatusIsFalse(clinicId);
		if (!petOwner.isEmpty()) {
			for (PetDetails petDetails : petOwner) {
				Register register = registerRepository.findById(petDetails.getPetOwner().getId()).get();
				PetOwnerRegisterDTO dto = new PetOwnerRegisterDTO();
				dto.setEmail(register.getEmail());
				dto.setContact(register.getContactNumber());
				dto.setFirstName(register.getFirstName());
				dto.setLastName(register.getLastName());
				dto.setId(register.getId());
				dto.setPetId(petDetails.getId());
				petOwnersDTO.add(dto);
			}
		}
		return petOwnersDTO;
	}

	public List<PetDetailsDTO> getAllPetOwners() {
		List<Register> registeredUser = registerRepository.findByRegisterStatusIsTrueAndRole("PET_OWNER");
		List<PetDetailsDTO> petOwners = new ArrayList<>();

		for (Register register : registeredUser) {
			List<PetDetails> users = petDetailsRepository.findByPetOwner_IdAndStatusIsTrue(register.getId());
			for (PetDetails pet : users) {
				PetDetailsDTO dto = new PetDetailsDTO();
				dto.setId(register.getId());
				dto.setEmail(register.getEmail());
				dto.setProfile(register.getProfile());
				dto.setContact(register.getContactNumber());

				dto.setOwnerFirstName(register.getFirstName());
				dto.setOwnerLastName(register.getLastName());

				dto.setPetName(pet.getPetName());
				dto.setPetType(pet.getPetType());
				dto.setImage(pet.getImage());
				dto.setPetId(pet.getId());
				ClinicDetails clinicDetails = clinicDetailsRepository.findById(pet.getClinic().getId()).get();
				dto.setClinicEmail(clinicDetails.getEmail());
				dto.setClinicName(clinicDetails.getClinicName());
				dto.setClinicState(clinicDetails.getState());
				dto.setClinicCity(clinicDetails.getCity());
				petOwners.add(dto);
			}
		}
		return petOwners;
	}

	public PetOwnerRegisterDTO getRegisterById(Long id) {

		Register register = registerRepository.findById(id).get();

		Long clinicId = petDetailsRepository.findFirstByPetOwner_IdOrderByIdAsc(id).getClinic().getId();

		PetOwnerRegisterDTO dto = new PetOwnerRegisterDTO();
		dto.setId(register.getId());
		dto.setProfile(register.getProfile());
		dto.setFirstName(register.getFirstName());
		dto.setLastName(register.getLastName());
		dto.setContact(register.getContactNumber());
		dto.setEmail(register.getEmail());
		dto.setClinicId(clinicId);
		dto.setCity(register.getCity());
		dto.setState(register.getState());
		dto.setAddress(register.getAddress());
		dto.setZipcode(register.getZipcode());

		return dto;
	}

	public List<PetOwnerPetDetails> getPetOwnersPetDetails(Long id) {

		List<PetOwnerPetDetails> petDetails = new ArrayList<PetOwnerPetDetails>();
		List<PetDetails> pets = petDetailsRepository.findByPetOwner_IdAndStatusIsTrue(id);
		for (PetDetails pet : pets) {
			PetOwnerPetDetails petDetail = new PetOwnerPetDetails();
			petDetail.setPetName(pet.getPetName());
			petDetail.setPetType(pet.getPetType());
			petDetail.setGender(pet.getGender());
			petDetail.setPetBreed(pet.getPetBreed());
			petDetail.setPetAge(pet.getPetAge());
			petDetail.setImage(pet.getImage());
			petDetail.setDob(pet.getDob());
			petDetails.add(petDetail);
		}
		return petDetails;
	}

	public List<PetOwnerClinics> getPetOwnerClinics(Long id) {
		List<PetDetails> petDetails = petDetailsRepository.findByPetOwner_IdAndStatusIsTrue(id);
		List<PetOwnerClinics> clinics = new ArrayList<>();
		Set<Long> clinicIds = new HashSet<>();
		for (PetDetails petDetail : petDetails) {
			Long clinicId = petDetail.getClinic().getId();

			if (!clinicIds.contains(clinicId)) {
				PetOwnerClinics clinic = new PetOwnerClinics();
				clinic.setClinicId(clinicId);
				clinic.setStatus(petDetail.isStatus());

				ClinicDetails clinicDetails = clinicDetailsRepository.findById(clinicId).get();
				clinic.setClinicName(clinicDetails.getClinicName());

				clinics.add(clinic);
				clinicIds.add(clinicId);
			}
		}

		return clinics;
	}

	public List<PetImageList> getPetImageList(Long id) {
		List<PetDetails> petDetails = petDetailsRepository.findByPetOwner_IdAndStatusIsTrue(id);
		List<PetImageList> result = new ArrayList<PetImageList>();

		for (PetDetails petDetail : petDetails) {
			PetImageList petImage = new PetImageList();
			petImage.setPetImage(petDetail.getImage());
			petImage.setPetId(petDetail.getId());
			result.add(petImage);
		}
		return result;
	}

	public PetDTO getMyPetDetails(Long id) {
		PetDTO pet = new PetDTO();
		PetDetails petDetails = petDetailsRepository.findById(id)
				.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Pet not found"));
		pet.setId(petDetails.getId());
		pet.setPetName(petDetails.getPetName());
		pet.setPetType(petDetails.getPetType());
		pet.setGender(petDetails.getGender());
		pet.setPetBreed(petDetails.getPetBreed());
		pet.setStripeCustomerId(petDetails.getStripeCustomerId());
		pet.setPaymentStatus(petDetails.getPaymentStatus());
		if (petDetails.getDob() != null) {
			pet.setPetAge(CalculateAge.petAge(petDetails.getDob()));
		}
		pet.setWeight(petDetails.getWeight());
		pet.setStatus(petDetails.isStatus());
		if(petDetails.getAgeGroup()!=null) {
			pet.setAgeGroup(petDetails.getAgeGroup());
		}

		pet.setImage(petDetails.getImage());
		pet.setDob(petDetails.getDob());
		ClinicDetails clinic = clinicDetailsRepository.findById(petDetails.getClinic().getId())
				.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Clinic not found"));
		pet.setClinicName(clinic.getClinicName());
		ClinicDTO clinicDTO = new ClinicDTO();
		clinicDTO.setClinicId(clinic.getId());
		clinicDTO.setClinicName(clinic.getClinicName());
		clinicDTO.setAddress(clinic.getAddress());
		clinicDTO.setZipCode(clinic.getZipCode());
		clinicDTO.setCity(clinic.getCity());
		clinicDTO.setState(clinic.getState());
		clinicDTO.setContactNumber(clinic.getContactNumber());
		clinicDTO.setEmail(clinic.getEmail());
		clinicDTO.setQrCode(clinic.getQrCode());
		clinicDTO.setClinicImage(clinic.getClinicImage());
		clinicDTO.setClinicLogo(clinic.getClinicLogo());
		clinicDTO.setSocialLinkOne(clinic.getSocialLinkOne());
		clinicDTO.setSocialLinkTwo(clinic.getSocialLinkTwo());
		clinicDTO.setSocialLinkThree(clinic.getSocialLinkThree());
		clinicDTO.setSocialLinkFour(clinic.getSocialLinkFour());

		pet.setClinic(clinicDTO);

		List<PromotionDiscount> activePromotions = promotionDiscountRepository
				.findByClinic_IdAndStatusIsTrue(clinic.getId());
		List<SetPromotionReminder> promotionList = new ArrayList<>();
		for (PromotionDiscount promotion : activePromotions) {
			SetPromotionReminder reminder = new SetPromotionReminder();
			reminder.setPromotion(promotion.getPromotionType());
			reminder.setExpiryDate(promotion.getEndDate());

			if (promotion.getEndDate() != null) {
				String currentDate = USDateFormat.dateFormat();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
				LocalDate currentLocalDate = LocalDate.parse(currentDate, formatter);
				LocalDate expiryDate = LocalDate.parse(promotion.getEndDate(), formatter);
				long pendingDays = ChronoUnit.DAYS.between(currentLocalDate, expiryDate);
				reminder.setPendingDays((int) pendingDays);
			} else {
				reminder.setPendingDays(0);
			}

			promotionList.add(reminder);
		}
		pet.setActivePromotions(promotionList);

		LocalDate currentDate = LocalDate.now();

		List<Status> statuses = Arrays.asList(Status.ACTIVE, Status.FULFILLED,Status.CANCEL);
		List<PetWellnessPlan> petWellnessPlans = petWellnessPlanRepository
				.findByPetIdAndWorkFlowStatusIn(petDetails.getId(), statuses);

		List<PetOwnerPlanDTO> ongoingPlans = new ArrayList<>();
		List<PetOwnerPlanDTO> futurePlans = new ArrayList<>();

		for (PetWellnessPlan plan : petWellnessPlans) {
			PetOwnerPlanDTO planDTO = mapToPetOwnerPlanDTO(plan);
			LocalDate startDate = LocalDate.parse(planDTO.getStartDate());
			LocalDate endDate = LocalDate.parse(planDTO.getEndDate());

			if (startDate.isBefore(currentDate) && endDate.isAfter(currentDate) || startDate.isEqual(currentDate)) {
				ongoingPlans.add(planDTO);
			} else if (startDate.isAfter(currentDate)) {
				futurePlans.add(planDTO);
			}
		}

		pet.setOngoingPlans(categorizePlansForProfile(ongoingPlans));
		pet.setFuturePlans(categorizePlansForProfile(futurePlans));

		return pet;
	}

	private PetOwnerPlanDTO mapToPetOwnerPlanDTO(PetWellnessPlan plan) {
		PetOwnerPlanDTO dto = new PetOwnerPlanDTO();
		dto.setPetWellnessPlanId(plan.getId());
		dto.setStartDate(plan.getManagePetWellnessPlan().getStartDate());
		dto.setEndDate(plan.getManagePetWellnessPlan().getEndDate());
		dto.setScheduledDate(plan.getScheduledDateAndTime() != null ? plan.getScheduledDateAndTime().toString() : null);
		dto.setPlanStatus(plan.getPlanStatus());
		dto.setPaymentStatus(plan.getPaymentStatus());
		dto.setStripeSubscriptionId(plan.getStripeSubscriptionId());
		dto.setManagepetWellnessPlanId(plan.getManagePetWellnessPlan().getId());
		dto.setInitialAmount(plan.getManagePetWellnessPlan().getTotalAmount());
		dto.setUpdatedAmount(plan.getManagePetWellnessPlan().getUpdatedAmount());

		ClinicWellnessPlan clinicWellnessPlan = clinicWellnessPlanRepository
				.findById(plan.getClinicWellnessPlan().getId()).get();
		ClinicWellnessPlanDTO clinicWellnessPlanDTO = new ClinicWellnessPlanDTO();
		clinicWellnessPlanDTO.setAgeGroup(clinicWellnessPlan.getWellnessPlan().getAgeGroup());
		clinicWellnessPlanDTO.setClinicWellnessPlanId(clinicWellnessPlan.getId());
		clinicWellnessPlanDTO.setPetType(clinicWellnessPlan.getWellnessPlan().getPetType());
		clinicWellnessPlanDTO.setServiceName(clinicWellnessPlan.getWellnessPlan().getService().getService());
		clinicWellnessPlanDTO.setWellnessPlanName(clinicWellnessPlan.getWellnessPlan().getWellnessPlanName());
		dto.setClinicWellnessPlan(clinicWellnessPlanDTO);

		ClinicWellnessPlan clinicWellnessPlan1 = clinicWellnessPlanRepository
				.findById(plan.getClinicWellnessPlan().getId()).get();

		ClinicWellnessPlanDTO clinicWellnessPlanDTO1 = new ClinicWellnessPlanDTO();
		clinicWellnessPlanDTO1.setAgeGroup(clinicWellnessPlan1.getWellnessPlan().getAgeGroup());
		clinicWellnessPlanDTO1.setClinicWellnessPlanId(clinicWellnessPlan1.getId());
		clinicWellnessPlanDTO1.setPetType(clinicWellnessPlan1.getWellnessPlan().getPetType());
		clinicWellnessPlanDTO1.setServiceName(clinicWellnessPlan1.getWellnessPlan().getService().getService());
		clinicWellnessPlanDTO1.setWellnessPlanName(clinicWellnessPlan1.getWellnessPlan().getWellnessPlanName());

		dto.setClinicWellnessPlan(clinicWellnessPlanDTO1);

		ClinicWellnessUpdate clinicWellnessUpdate = clincWellnessUpdateRepository
				.findById(plan.getClinicWellnessUpdate().getId()).get();

		ClinicWellnessPlanUpdateDTO clinicWellnessUpdateDTO = new ClinicWellnessPlanUpdateDTO();
		clinicWellnessUpdateDTO.setDiscountPercentage(clinicWellnessUpdate.getDiscountPercentage());
		clinicWellnessUpdateDTO.setUpdateRecommendation(clinicWellnessUpdate.getUpdateRecommendation());
		clinicWellnessUpdateDTO.setWellnessUpdateId(clinicWellnessUpdate.getId());
		clinicWellnessUpdateDTO.setStipeAccountId(clinicWellnessUpdate.getStripeAccountId());
		clinicWellnessUpdateDTO.setStripeProductId(clinicWellnessUpdate.getStripeProductId());
		clinicWellnessUpdateDTO.setStripePriceId(clinicWellnessUpdate.getStripePriceId());
		clinicWellnessUpdateDTO.setPriceBased(clinicWellnessUpdate.getDropDown().getPriceBased());

		setWellnessPricing(clinicWellnessUpdateDTO, clinicWellnessUpdate, plan.getPetId());

		dto.setWellnessPlanUpdate(clinicWellnessUpdateDTO);

		return dto;
	}

	private Map<Integer, List<PetOwnerPlanDTO>> categorizePlansForProfile(List<PetOwnerPlanDTO> plans) {

		for (PetOwnerPlanDTO plan : plans) {
			Long manageId = plan.getManagepetWellnessPlanId();
			ManagePetWellnessPlans managePetWellnessPlans = managePetWellnessPlanRepository.findById(manageId).get();
			List<String> promotions = new ArrayList<String>();
			for (PromotionDiscount promotionDiscount : managePetWellnessPlans.getPromotionDiscounts()) {
				promotions.add(promotionDiscount.getPromotionType());
			}
			plan.setPromotions(promotions);
		}

		Map<Long, List<PetOwnerPlanDTO>> groupedPlans = plans.stream()
				.collect(Collectors.groupingBy(PetOwnerPlanDTO::getManagepetWellnessPlanId));

		List<Map.Entry<Long, List<PetOwnerPlanDTO>>> sortedEntries = groupedPlans.entrySet().stream()
				.sorted(Map.Entry.comparingByKey()).collect(Collectors.toList());

		Map<Integer, List<PetOwnerPlanDTO>> dynamicSets = new HashMap<>();
		for (int i = 0; i < sortedEntries.size(); i++) {
			dynamicSets.put(i + 1, sortedEntries.get(i).getValue());
		}

		return dynamicSets;
	}

	private void setAgeGroup(PetDTO pet, PetDetails petDetails) {
		PetBreedAge petBreedAge = petBreedAgeRepository
				.findByPetTypeAndBreed(petDetails.getPetType(), petDetails.getPetBreed()).get(0);
		pet.setAgeGroup(Agegroup.determineAgeCategory(CalculateAge.petAgeByMonth(petDetails.getDob()), petBreedAge));
	}
	
	private void setWellnessPricing(ClinicWellnessPlanUpdateDTO dto, ClinicWellnessUpdate update,
			PetDetails petDetails) {
		String size = null;
		if (petDetails.getWeight() != null && petDetails.getPetType() != null) {
			try {
				double weight = Double.parseDouble(petDetails.getWeight().replace("lb", "").trim());
				size = weightRangeRepository.findSizeByPetTypeAndWeight(petDetails.getPetType(), weight);
			} catch (NumberFormatException | NullPointerException e) {
				size = null;
			}
		}

		if ("QTY".equalsIgnoreCase(update.getDropDown().getPriceBased())) {
			dto.setDiscountPriceForQuantity(update.getDiscountPriceForQuantity());
			dto.setUpdatedPriceForQuantity(update.getUpdatedPriceForQuantity());
		} else if ("WGT".equalsIgnoreCase(update.getDropDown().getPriceBased()) && size != null) {
			switch (size.toUpperCase()) {
			case "SMALL":
				dto.setDiscountPriceForSmall(update.getDiscountPriceForSmall());
				dto.setUpdatedPriceForSmall(update.getUpdatedPriceForSmall());
				dto.setStripePriceIdSmall(update.getStripePriceIdSmall());
				dto.setStripeProductIdSmall(update.getStripeProductIdSmall());
				break;
			case "MEDIUM":
				dto.setDiscountPriceForMedium(update.getDiscountPriceForMedium());
				dto.setUpdatedPriceForMedium(update.getUpdatedPriceForMedium());
				dto.setStripePriceIdMedium(update.getStripePriceIdMedium());
				dto.setStripeProductIdMedium(update.getStripeProductIdMedium());
				break;
			case "LARGE":
				dto.setDiscountPriceForLarge(update.getDiscountPriceForLarge());
				dto.setUpdatedPriceForLarge(update.getUpdatedPriceForLarge());
				dto.setStripePriceIdLarge(update.getStripePriceIdLarge());
				dto.setStripeProductIdXLarge(update.getStripeProductIdXLarge());
				break;
			case "X-LARGE":
				dto.setDiscountPriceForXLarge(update.getDiscountPriceForXLarge());
				dto.setUpdatedPriceForXLarge(update.getUpdatedPriceForXLarge());
				dto.setStripeProductIdXLarge(update.getStripeProductIdXLarge());
				dto.setStripePriceIdXLarge(update.getStripePriceIdXLarge());
				break;
			}
		}
	}

	public ResponseEntity<String> registerPetOwnerByClinic(AddPetOwnerDTO petOwnerDTO) {

		if (registerRepository.existsByEmail(petOwnerDTO.getEmail())) {
			return new ResponseEntity<>("Email Already Exists", HttpStatus.CONFLICT);
		}
		Register register = new Register();
		register.setEmail(petOwnerDTO.getEmail());
		register.setCreated_On(USDateFormat.dateFormat());
		register.setContactNumber(petOwnerDTO.getContact());
		register.setRole("PET_OWNER");
		register.setFirstName(petOwnerDTO.getFirstName());
		register.setLastName(petOwnerDTO.getLastName());
		register.setCreated_By(petOwnerDTO.getCreatedById());
		register.setProfile("https://elevatepethealth-imagestorage.s3.us-east-1.amazonaws.com/media/profile-user.png");
		register.setTimezone(petOwnerDTO.getTimezone());
		PetDetails petDetails = new PetDetails();
		ClinicDetails clinic = clinicDetailsRepository.findById(petOwnerDTO.getClinicId())
				.orElseThrow(() -> new RuntimeException("Clinic Not found"));
		petDetails.setPetName(petOwnerDTO.getPetName());
		petDetails.setClinic(clinic);
		petDetails.setImage(
				"https://elevatepethealth-imagestorage.s3.us-east-1.amazonaws.com/media/Static%20images%20dog%20and%20cat.jpg");

//		try {
//            String fullName = petOwnerDTO.getFirstName() + " " + petOwnerDTO.getLastName();
//			String connectedCustomer = stripeConnect.createConnectedCustomer(petOwnerDTO.getStripeAccountId(),
//					fullName, petOwnerDTO.getEmail());
//			register.setStripeCustomerId(connectedCustomer);
//			petDetails.setStripeCustomerId(connectedCustomer);
//		} catch (Exception e) {
//			throw new RuntimeException(e);
//		}
		Register registerObj = registerRepository.save(register);
		petDetails.setPetOwner(registerObj);
		petDetailsRepository.save(petDetails);

		return new ResponseEntity<>("Pet Owner Added", HttpStatus.CREATED);
	}

	public String updatePetDetails(Long petId, PetDetailsDTO petDetailsDTO) {
		PetDetails existingPetDetails = petDetailsRepository.findById(petId).get();

		existingPetDetails.setPetName(petDetailsDTO.getPetName());
		existingPetDetails.setGender(petDetailsDTO.getGender());
		existingPetDetails.setPetBreed(petDetailsDTO.getPetBreed());
		existingPetDetails.setDob(petDetailsDTO.getDob());
		existingPetDetails.setPetType(petDetailsDTO.getPetType());
		if (petDetailsDTO.getDob() != null) {
			existingPetDetails.setPetAge(CalculateAge.petAge(petDetailsDTO.getDob()));

		}
		if (petDetailsDTO.getPetType() != null && petDetailsDTO.getPetBreed() != null) {
			PetBreedAge petBreedAge = petBreedAgeRepository
					.findByPetTypeAndBreed(petDetailsDTO.getPetType(), petDetailsDTO.getPetBreed()).get(0);
			existingPetDetails.setAgeGroup(
					Agegroup.determineAgeCategory(CalculateAge.petAgeByMonth(petDetailsDTO.getDob()), petBreedAge));
		}
		existingPetDetails.setWeight(petDetailsDTO.getWeight());
		existingPetDetails.setImage(petDetailsDTO.getImage());

		petDetailsRepository.save(existingPetDetails);
		return "Profile updated";
	}

	public List<PetDetailsDTO> getPetDetails(long petDetailsId) {
		List<PetDetailsDTO> details = new ArrayList<>();
		PetDetails petDetails = petDetailsRepository.findById(petDetailsId)
				.orElseThrow(() -> new RuntimeException("Pet Details not found"));
		PetDetailsDTO dto = new PetDetailsDTO();
		dto.setId(petDetails.getId());
		dto.setPetName(petDetails.getPetName());
		dto.setPetAge(petDetails.getPetAge());
		dto.setPetType(petDetails.getPetType());
		dto.setAgeGroup(petDetails.getAgeGroup());
		dto.setPetBreed(petDetails.getPetBreed());
		dto.setGender(petDetails.getGender());
		dto.setWeight(petDetails.getWeight());
		dto.setDob(petDetails.getDob());
		dto.setPaymentStatus(petDetails.getPaymentStatus());
		dto.setImage(petDetails.getImage());

		LocalDate currentDate = LocalDate.now();
		List<PetWellnessPlan> plans = petWellnessPlanRepository.findByPetId_IdAndWorkFlowStatus(petDetailsId, Status.ACTIVE);

		if (plans == null || plans.isEmpty()) {
			dto.setHistoryPlans(Map.of());
			dto.setOngoingPlans(Map.of());
			dto.setFuturePlans(Map.of());
			return (List<PetDetailsDTO>) dto;
		}

		List<GetPetWellnessPlanDTO> historical = new ArrayList<>();
		List<GetPetWellnessPlanDTO> ongoing = new ArrayList<>();
		List<GetPetWellnessPlanDTO> future = new ArrayList<>();

		for (PetWellnessPlan plan : plans) {
			GetPetWellnessPlanDTO planDTO = mapToWellnessPlanDTO(plan);

			LocalDate startDate = LocalDate.parse(planDTO.getStartDate());
			LocalDate endDate = LocalDate.parse(planDTO.getEndDate());

			if ((startDate.isBefore(currentDate) || startDate.isEqual(currentDate))
					&& (endDate.isAfter(currentDate) || endDate.isEqual(currentDate))) {
				ongoing.add(planDTO);
			} else if (endDate.isBefore(currentDate)) {
				historical.add(planDTO);
			} else if (startDate.isAfter(currentDate)) {
				future.add(planDTO);
			}

		}

		dto.setHistoryPlans(categorizePlans(historical));
		dto.setOngoingPlans(categorizePlans(ongoing));
		dto.setFuturePlans(categorizePlans(future));

		details.add(dto);

		return details;

	}

	public PetPlansDTO getPetPlans(Long petId) {
		PetDetails petDetails = petDetailsRepository.findById(petId).orElse(null);

		if (petDetails == null) {
			return null;
		}

		PetPlansDTO petPlansDTO = new PetPlansDTO();
		PetImageList petSummary = new PetImageList();
		petSummary.setPetId(petDetails.getId());
		petSummary.setPetImage(petDetails.getImage());
		petPlansDTO.setPetSummary(petSummary);

		LocalDate currentDate = LocalDate.now();
		List<PetWellnessPlan> plans = petWellnessPlanRepository.findByPetId_IdAndWorkFlowStatus(petId, Status.ACTIVE);

		if (plans == null || plans.isEmpty()) {
			petPlansDTO.setHistoryPlans(Map.of());
			petPlansDTO.setOngoingPlans(Map.of());
			petPlansDTO.setFuturePlans(Map.of());
			return petPlansDTO;
		}

		List<GetPetWellnessPlanDTO> historical = new ArrayList<>();
		List<GetPetWellnessPlanDTO> ongoing = new ArrayList<>();
		List<GetPetWellnessPlanDTO> future = new ArrayList<>();

		for (PetWellnessPlan plan : plans) {
			GetPetWellnessPlanDTO planDTO = mapToWellnessPlanDTO(plan);

			LocalDate startDate = LocalDate.parse(planDTO.getStartDate());
			LocalDate endDate = LocalDate.parse(planDTO.getEndDate());

			if ((startDate.isBefore(currentDate) || startDate.isEqual(currentDate))
					&& (endDate.isAfter(currentDate) || endDate.isEqual(currentDate))) {
				ongoing.add(planDTO);
			} else if (endDate.isBefore(currentDate)) {
				historical.add(planDTO);
			} else if (startDate.isAfter(currentDate)) {
				future.add(planDTO);
			}

		}

		petPlansDTO.setHistoryPlans(categorizePlans(historical));
		petPlansDTO.setOngoingPlans(categorizePlans(ongoing));
		petPlansDTO.setFuturePlans(categorizePlans(future));

		return petPlansDTO;
	}

	private Map<Integer, List<GetPetWellnessPlanDTO>> categorizePlans(List<GetPetWellnessPlanDTO> plans) {
		Map<Long, List<GetPetWellnessPlanDTO>> groupedPlans = new HashMap<>();

		for (GetPetWellnessPlanDTO plan : plans) {
			Long manageId = plan.getManagePetWellnessPlan();
			ManagePetWellnessPlans managePetWellnessPlans = managePetWellnessPlanRepository.findById(manageId).get();
			List<String> promotions = new ArrayList<String>();
			for (PromotionDiscount promotionDiscount : managePetWellnessPlans.getPromotionDiscounts()) {
				promotions.add(promotionDiscount.getPromotionType());
			}
			plan.setPromotions(promotions);
			groupedPlans.computeIfAbsent(manageId, k -> new ArrayList<>()).add(plan);
		}

		Map<Integer, List<GetPetWellnessPlanDTO>> dynamicSets = new HashMap<>();

		List<Map.Entry<Long, List<GetPetWellnessPlanDTO>>> sortedEntries = new ArrayList<>(groupedPlans.entrySet());
		sortedEntries.sort(Map.Entry.comparingByKey());

		for (int i = 0; i < sortedEntries.size() && i < 4; i++) {
			dynamicSets.put(i + 1, sortedEntries.get(i).getValue());
		}

		return dynamicSets;
	}

	private GetPetWellnessPlanDTO mapToWellnessPlanDTO(PetWellnessPlan plan) {
		GetPetWellnessPlanDTO dto = new GetPetWellnessPlanDTO();
		dto.setPetWellnessPlanId(plan.getId());
		dto.setPetId(plan.getPetId().getId());
		dto.setClinicWellnessPlan(plan.getClinicWellnessPlan().getId());
		dto.setClinicWellnessUpdate(plan.getClinicWellnessUpdate().getId());
		dto.setManagePetWellnessPlan(plan.getManagePetWellnessPlan().getId());
		dto.setStartDate(plan.getManagePetWellnessPlan().getStartDate());
		dto.setEndDate(plan.getManagePetWellnessPlan().getEndDate());
		dto.setPaymentStatus(plan.getPaymentStatus());
		dto.setPlanStatus(plan.getPlanStatus());
		dto.setWellnessPlanName(plan.getClinicWellnessPlan().getWellnessPlan().getWellnessPlanName());
		dto.setServiceName(plan.getClinicWellnessPlan().getWellnessPlan().getService().getService());
		dto.setStatus(plan.getWorkFlowStatus().name());
		dto.setScheduledDateAndTime(
				plan.getScheduledDateAndTime() != null ? plan.getScheduledDateAndTime().toString() : null);
		List<PetBreedAge> petBreedAges = petBreedAgeRepository.findByPetTypeAndBreed(plan.getPetId().getPetType(),
				plan.getPetId().getPetBreed());
		if (!petBreedAges.isEmpty()) {
			PetBreedAge petBreedAge = petBreedAges.get(0);
			dto.setAgeGroup(
					Agegroup.determineAgeCategory(CalculateAge.petAgeByMonth(plan.getPetId().getDob()), petBreedAge));
		}
		String petSize = determinePetSize(plan.getPetId());
		if ("QTY".equalsIgnoreCase(plan.getClinicWellnessUpdate().getDropDown().getPriceBased())) {
			dto.setDiscountPrice(plan.getClinicWellnessUpdate().getDiscountPriceForQuantity());
			dto.setUpdatedPrice(plan.getClinicWellnessUpdate().getUpdatedPriceForQuantity());
		} else if ("WGT".equalsIgnoreCase(plan.getClinicWellnessUpdate().getDropDown().getPriceBased())) {
			setPriceBasedOnPetSize(dto, plan, petSize);
		}

		if (plan.getFulfilledBy() != null) {
			DoctorDTO doctorDTO = new DoctorDTO();
			doctorDTO.setRegId(plan.getFulfilledBy());
			Register getDoctorName = registerRepository.findById(plan.getFulfilledBy()).orElse(null);
			if (getDoctorName != null) {
				doctorDTO.setDoctorName(getDoctorName.getFirstName() + " " + getDoctorName.getLastName());
			}
			dto.setFulfilledBy(doctorDTO);
		}

		DropdownList dropdown = plan.getClinicWellnessUpdate().getDropDown();
		if (dropdown != null) {
			dto.setDropdownName(dropdown.getDropdown());
		}
		dto.setPetType(plan.getPetId().getPetType());
		ServiceList service = plan.getClinicWellnessPlan().getWellnessPlan().getService();
		if (service != null) {
			dto.setServiceName(service.getService());
		}
		dto.setWellnessPlanName(plan.getClinicWellnessPlan().getWellnessPlan().getWellnessPlanName());

		return dto;
	}

	private String determinePetSize(PetDetails checkPet) {
		String petSize = null;
		if (checkPet.getWeight() != null && checkPet.getPetType() != null) {
			try {
				double weight = Double.parseDouble(checkPet.getWeight().replace("lb", "").trim());
				petSize = weightRangeRepository.findSizeByPetTypeAndWeight(checkPet.getPetType(), weight);
			} catch (NumberFormatException | NullPointerException e) {
				petSize = null;
			}
		}
		return petSize;
	}

	private void setPriceBasedOnPetSize(GetPetWellnessPlanDTO dto, PetWellnessPlan wellnessPlan, String petSize) {
		switch (petSize.toUpperCase()) {
		case "SMALL":
			dto.setDiscountPrice(wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForSmall());
			dto.setUpdatedPrice(wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForSmall());
			break;
		case "MEDIUM":
			dto.setDiscountPrice(wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForMedium());
			dto.setUpdatedPrice(wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForMedium());
			break;
		case "LARGE":
			dto.setDiscountPrice(wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForLarge());
			dto.setUpdatedPrice(wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForLarge());
			break;
		case "X-LARGE":
			dto.setDiscountPrice(wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForXLarge());
			dto.setUpdatedPrice(wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForXLarge());
			break;
		}
	}
}