package com.elevate.service;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import com.elevate.dto.*;
import com.elevate.entity.*;
import com.elevate.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.elevate.Enum.Status;
import com.elevate.utils.EmailSender;
import com.elevate.utils.S3Service;
import com.elevate.utils.USDateFormat;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import io.jsonwebtoken.io.IOException;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

@Service
public class ClinicWellnessPlanService {

	@Autowired
	private IClinicWellnessPlanRepository clinicWellnessPlanRepository;

	@Autowired
	private IDropdownListRepository dropDownRepository;

	@Autowired
	private IRecommendationRepository recommendationRepository;

	@Autowired
	private IClinicWellnessUpdateRepository clinicWellnessUpdateRepository;

	@Autowired
	private IPetDetailsRepository petDetailsRepository;

	@Autowired
	private IRegisterRepository registerRepository;

	@Autowired
	private IPetWellnessPlanRepository petWellnessPlanRepository;

	@Autowired
	private IManagePetWellnessPlansRepository managePetWellnessPlanRepository;

	@Autowired
	private EmailSender emailSender;

	@Autowired
	private IPromotionDiscountRepository promotionDiscountRepository;
	
	@Autowired
	private S3Service s3Service;
	
	@Autowired
	private IDocumentRepository documentRepository;
	
	@Autowired
	private IWeightRangeRepository weightRangeRepository;

	public List<ClinicWellnessPlanDTO> getClinicWellnessPlans(Long id) {
		List<ClinicWellnessPlan> clinicWellnessPlan = clinicWellnessPlanRepository.findByClinicId(id);
		List<ClinicWellnessPlanDTO> result = new ArrayList<ClinicWellnessPlanDTO>();
		for (ClinicWellnessPlan ClinicWellnessPlan : clinicWellnessPlan) {
			ClinicWellnessPlanDTO clinicWellnessPlanDTO = new ClinicWellnessPlanDTO();
			clinicWellnessPlanDTO.setClinicWellnessPlanId(ClinicWellnessPlan.getId());
			clinicWellnessPlanDTO.setWellnessPlanName(ClinicWellnessPlan.getWellnessPlan().getWellnessPlanName());
			clinicWellnessPlanDTO.setServiceName(ClinicWellnessPlan.getWellnessPlan().getService().getService());
			clinicWellnessPlanDTO.setPetType(ClinicWellnessPlan.getWellnessPlan().getPetType());
			clinicWellnessPlanDTO.setAgeGroup(ClinicWellnessPlan.getWellnessPlan().getAgeGroup());
			clinicWellnessPlanDTO.setClinicDropDowns(dropDownDetails(ClinicWellnessPlan.getWellnessUpdate(),
					ClinicWellnessPlan.getWellnessPlan().getId()));

			result.add(clinicWellnessPlanDTO);
		}
		return result;
	}

	private List<DropdownListResponseDTO> dropDownDetails(List<ClinicWellnessUpdate> wellnessUpdate,
														  Long wellnessPlanId) {
		List<DropdownListResponseDTO> dropDowns = new ArrayList<DropdownListResponseDTO>();

		for (ClinicWellnessUpdate clinicWellnessUpdate : wellnessUpdate) {
			DropdownListResponseDTO dropDown = new DropdownListResponseDTO();
			DropdownList dropDownList = dropDownRepository.findById(clinicWellnessUpdate.getDropDown().getId()).get();
			dropDown.setIndustryStandardPrice(dropDownList.getIndustryStandardPrice());
			Recommendation recommendation = recommendationRepository
					.findByDropdownListIdAndWellnessPlanId(dropDownList.getId(), wellnessPlanId);
			dropDown.setRecommendation(recommendation.getRecommendation());
			dropDown.setDropdown(dropDownList.getDropdown());
			dropDown.setPriceBased(dropDownList.getPriceBased());
			dropDown.setPriceForSmall(dropDownList.getPriceForSmall());
			dropDown.setPriceForMedium(dropDownList.getPriceForMedium());
			dropDown.setPriceForLarge(dropDownList.getPriceForLarge());
			dropDown.setPriceForXLarge(dropDownList.getPriceForXLarge());
			dropDown.setPriceForQuantity(dropDownList.getPriceForQuantity());

			ClinicWellnessPlanUpdateDTO updateWellness = new ClinicWellnessPlanUpdateDTO();
			updateWellness.setUpdateRecommendation(clinicWellnessUpdate.getUpdateRecommendation());
			updateWellness.setDiscountPercentage(clinicWellnessUpdate.getDiscountPercentage());
			updateWellness.setDiscountPriceForQuantity(clinicWellnessUpdate.getDiscountPriceForQuantity());
			updateWellness.setDiscountPriceForSmall(clinicWellnessUpdate.getDiscountPriceForSmall());
			updateWellness.setDiscountPriceForMedium(clinicWellnessUpdate.getDiscountPriceForMedium());
			updateWellness.setDiscountPriceForLarge(clinicWellnessUpdate.getDiscountPriceForLarge());
			updateWellness.setDiscountPriceForXLarge(clinicWellnessUpdate.getDiscountPriceForXLarge());
			updateWellness.setUpdatedPriceForSmall(clinicWellnessUpdate.getUpdatedPriceForSmall());
			updateWellness.setUpdatedPriceForMedium(clinicWellnessUpdate.getUpdatedPriceForMedium());
			updateWellness.setUpdatedPriceForLarge(clinicWellnessUpdate.getUpdatedPriceForLarge());
			updateWellness.setUpdatedPriceForXLarge(clinicWellnessUpdate.getUpdatedPriceForXLarge());
			updateWellness.setUpdatedPriceForQuantity(clinicWellnessUpdate.getUpdatedPriceForQuantity());
			updateWellness.setDoctorPercentage(clinicWellnessUpdate.getDoctorPercentage());
			updateWellness.setStatus(clinicWellnessUpdate.isStatus());
			updateWellness.setWellnessUpdateId(clinicWellnessUpdate.getId());
			updateWellness.setStripeProductIdSmall(clinicWellnessUpdate.getStripeProductIdSmall());
			updateWellness.setStripeProductIdMedium(clinicWellnessUpdate.getStripeProductIdMedium());
			updateWellness.setStripeProductIdLarge(clinicWellnessUpdate.getStripeProductIdLarge());
			updateWellness.setStripeProductIdXLarge(clinicWellnessUpdate.getStripeProductIdXLarge());
			updateWellness.setStripePriceIdSmall(clinicWellnessUpdate.getStripePriceIdSmall());
			updateWellness.setStripePriceIdMedium(clinicWellnessUpdate.getStripePriceIdMedium());
			updateWellness.setStripePriceIdLarge(clinicWellnessUpdate.getStripePriceIdLarge());
			updateWellness.setStripePriceIdXLarge(clinicWellnessUpdate.getStripePriceIdXLarge());
			updateWellness.setStripeProductId(clinicWellnessUpdate.getStripeProductId());
			updateWellness.setStipeAccountId(clinicWellnessUpdate.getStripeAccountId());
			updateWellness.setStripePriceId(clinicWellnessUpdate.getStripePriceId());
			updateWellness.setPriceBased(dropDownList.getPriceBased());
			dropDown.setWellnessUpdate(updateWellness);

			dropDowns.add(dropDown);
		}
		return dropDowns;
	}

	public ClinicWellnessUpdate updateClinicWellnessPlan(ClinicWellnessPlanUpdateDTO clinicWellnessPlanUpdate) {
		ClinicWellnessUpdate clinicWellnessUpdate = clinicWellnessUpdateRepository
				.findById(clinicWellnessPlanUpdate.getWellnessUpdateId())
				.orElseThrow(() -> new IllegalArgumentException("Wellness update not found"));

		clinicWellnessUpdate.setDiscountPercentage(clinicWellnessPlanUpdate.getDiscountPercentage());

		String discountPercentageStr = clinicWellnessPlanUpdate.getDiscountPercentage();
		double discountPercentage = 0.0;

		if (discountPercentageStr != null && !discountPercentageStr.trim().isEmpty()) {
			discountPercentage = Double.parseDouble(discountPercentageStr);
		}

		if (clinicWellnessPlanUpdate.getUpdatedPriceForSmall() != null
				&& !clinicWellnessPlanUpdate.getUpdatedPriceForSmall().trim().isEmpty()) {
			double priceForSmall = Double.parseDouble(clinicWellnessPlanUpdate.getUpdatedPriceForSmall());
			double discountedPrice = priceForSmall - (priceForSmall * (discountPercentage / 100));
			clinicWellnessUpdate.setUpdatedPriceForSmall(String.valueOf(priceForSmall));
			clinicWellnessUpdate.setDiscountPriceForSmall(String.valueOf(discountedPrice));
		} else {
			clinicWellnessUpdate.setUpdatedPriceForSmall(null);
			clinicWellnessUpdate.setDiscountPriceForSmall(null);
		}

		if (clinicWellnessPlanUpdate.getUpdatedPriceForMedium() != null
				&& !clinicWellnessPlanUpdate.getUpdatedPriceForMedium().trim().isEmpty()) {
			double priceForMedium = Double.parseDouble(clinicWellnessPlanUpdate.getUpdatedPriceForMedium());
			double discountedPrice = priceForMedium - (priceForMedium * (discountPercentage / 100));
			clinicWellnessUpdate.setUpdatedPriceForMedium(String.valueOf(priceForMedium));
			clinicWellnessUpdate.setDiscountPriceForMedium(String.valueOf(discountedPrice));
		} else {
			clinicWellnessUpdate.setUpdatedPriceForMedium(null);
			clinicWellnessUpdate.setDiscountPriceForMedium(null);
		}

		if (clinicWellnessPlanUpdate.getUpdatedPriceForLarge() != null
				&& !clinicWellnessPlanUpdate.getUpdatedPriceForLarge().trim().isEmpty()) {
			double priceForLarge = Double.parseDouble(clinicWellnessPlanUpdate.getUpdatedPriceForLarge());
			double discountedPrice = priceForLarge - (priceForLarge * (discountPercentage / 100));
			clinicWellnessUpdate.setUpdatedPriceForLarge(String.valueOf(priceForLarge));
			clinicWellnessUpdate.setDiscountPriceForLarge(String.valueOf(discountedPrice));
		} else {
			clinicWellnessUpdate.setUpdatedPriceForLarge(null);
			clinicWellnessUpdate.setDiscountPriceForLarge(null);
		}

		if (clinicWellnessPlanUpdate.getUpdatedPriceForXLarge() != null
				&& !clinicWellnessPlanUpdate.getUpdatedPriceForXLarge().trim().isEmpty()) {
			double priceForXLarge = Double.parseDouble(clinicWellnessPlanUpdate.getUpdatedPriceForXLarge());
			double discountedPrice = priceForXLarge - (priceForXLarge * (discountPercentage / 100));
			clinicWellnessUpdate.setUpdatedPriceForXLarge(String.valueOf(priceForXLarge));
			clinicWellnessUpdate.setDiscountPriceForXLarge(String.valueOf(discountedPrice));
		} else {
			clinicWellnessUpdate.setUpdatedPriceForXLarge(null);
			clinicWellnessUpdate.setDiscountPriceForXLarge(null);
		}

		if (clinicWellnessPlanUpdate.getUpdatedPriceForQuantity() != null
				&& !clinicWellnessPlanUpdate.getUpdatedPriceForQuantity().trim().isEmpty()) {
			double priceForQuantity = Double.parseDouble(clinicWellnessPlanUpdate.getUpdatedPriceForQuantity());
			double discountedPrice = priceForQuantity - (priceForQuantity * (discountPercentage / 100));
			clinicWellnessUpdate.setUpdatedPriceForQuantity(String.valueOf(priceForQuantity));
			clinicWellnessUpdate.setDiscountPriceForQuantity(String.valueOf(discountedPrice));
		} else {
			clinicWellnessUpdate.setUpdatedPriceForQuantity(null);
			clinicWellnessUpdate.setDiscountPriceForQuantity(null);
		}

		clinicWellnessUpdate.setUpdatedPriceForSmall(clinicWellnessPlanUpdate.getUpdatedPriceForSmall());
		clinicWellnessUpdate.setUpdatedPriceForMedium(clinicWellnessPlanUpdate.getUpdatedPriceForMedium());
		clinicWellnessUpdate.setUpdatedPriceForLarge(clinicWellnessPlanUpdate.getUpdatedPriceForLarge());
		clinicWellnessUpdate.setUpdatedPriceForXLarge(clinicWellnessPlanUpdate.getUpdatedPriceForXLarge());
		clinicWellnessUpdate.setUpdatedPriceForQuantity(clinicWellnessPlanUpdate.getUpdatedPriceForQuantity());
		clinicWellnessUpdate.setDoctorPercentage(clinicWellnessPlanUpdate.getDoctorPercentage());
		clinicWellnessUpdate.setStatus(clinicWellnessPlanUpdate.isStatus());
		clinicWellnessUpdate.setUpdateRecommendation(clinicWellnessPlanUpdate.getUpdateRecommendation());

		return clinicWellnessUpdateRepository.save(clinicWellnessUpdate);
	}

	public List<ClinicWellnessPlanDTO> getWellnessPlan(Long clinicId, String wellness, String petSize) {
		List<ClinicWellnessPlan> clinicWellnessPlans = clinicWellnessPlanRepository
				.findClinicWellnessPlansByClinicIdAndWellnessPlanName(clinicId, wellness);
		List<ClinicWellnessPlanDTO> result = new ArrayList<>();

		for (ClinicWellnessPlan clinicWellnessPlan : clinicWellnessPlans) {
			List<DropdownListResponseDTO> dropDowns = dropDownDetailsPet(clinicWellnessPlan.getWellnessUpdate(),
					clinicWellnessPlan.getWellnessPlan().getId(), petSize);

			for (DropdownListResponseDTO dropdown : dropDowns) {
				ClinicWellnessPlanDTO clinicWellnessPlanDTO = new ClinicWellnessPlanDTO();
				clinicWellnessPlanDTO.setClinicWellnessPlanId(clinicWellnessPlan.getId());
				clinicWellnessPlanDTO.setWellnessPlanName(clinicWellnessPlan.getWellnessPlan().getWellnessPlanName());
				clinicWellnessPlanDTO.setServiceName(clinicWellnessPlan.getWellnessPlan().getService().getService());
				clinicWellnessPlanDTO.setPetType(clinicWellnessPlan.getWellnessPlan().getPetType());
				clinicWellnessPlanDTO.setAgeGroup(clinicWellnessPlan.getWellnessPlan().getAgeGroup());
				List<DropdownListResponseDTO> singleDropDownList = new ArrayList<>();
				singleDropDownList.add(dropdown);
				clinicWellnessPlanDTO.setClinicDropDowns(singleDropDownList);

				result.add(clinicWellnessPlanDTO);
			}
		}

		return result;
	}

	public ClinicWellnessPlansWithPromotionStatusDTO getPetWellnessPlanWithPromotionStatusForPet(
			Long clinicId, String wellness, String petSize, Long petId) {

		ClinicWellnessPlansWithPromotionStatusDTO responseDTO = new ClinicWellnessPlansWithPromotionStatusDTO();
		List<ClinicWellnessPlansWithPromotionStatusDTO.PromotionStatusDTO> promotions = new ArrayList<>();


		List<PromotionDiscount> promotionDiscounts = promotionDiscountRepository.findByClinic_IdAndStatusTrue(clinicId);

		if (!promotionDiscounts.isEmpty()) {
			for (PromotionDiscount promotion : promotionDiscounts) {
				Long promotionId = promotion.getId();
				String promotionName = promotion.getPromotionType();
				boolean status = false;

				switch (promotionName) {
					case "30-60-90 Days":
						status = true;
						break;

					case "Multi Pet":
						var petinfo = petDetailsRepository.findById(petId);
						List<PetDetails> petDetails = petDetailsRepository.findByPetOwner_IdAndStatusIsTrue(petinfo.get().getPetOwner().getId());
						if (petDetails.size() > 1) {
							for (PetDetails pet : petDetails) {
								List<PetWellnessPlan> plans = petWellnessPlanRepository.findByPetId_Id(pet.getId());
								if (plans.stream().anyMatch(p -> p.getWorkFlowStatus().equals(Status.ACTIVE))) {
									status = true;
									break;
								}
							}
						}
						break;

					case "Multi Years":
						List<PetWellnessPlan> multiYearPlans = petWellnessPlanRepository.findByPetId_Id(petId);
						for (PetWellnessPlan plan : multiYearPlans) {
							if (plan.getWorkFlowStatus().equals(Status.FULFILLED)) {
								LocalDate endDate = LocalDate.parse(plan.getManagePetWellnessPlan().getEndDate(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
								LocalDate today = LocalDate.now();
								LocalDate minDate = today.minusDays(90);

								if ((endDate.isEqual(today) || endDate.isBefore(today)) &&
										(endDate.isEqual(minDate) || endDate.isAfter(minDate))) {
									status = true;
								}
							}
						}
						break;

					default:
						LocalDate elevateEndDate = LocalDate.parse(promotion.getEndDate(), DateTimeFormatter.ofPattern("MM/dd/yyyy"));
						status = elevateEndDate.isAfter(LocalDate.now());
						break;
				}

				// Add the promotion status to the list
				promotions.add(new ClinicWellnessPlansWithPromotionStatusDTO.PromotionStatusDTO(
						promotionId, promotionName, status));
			}
		}

		responseDTO.setPromotions(promotions);
		responseDTO.setWellnessPlans(getWellnessPlan(clinicId, wellness, petSize));

		return responseDTO;
	}




	private List<DropdownListResponseDTO> dropDownDetailsPet(List<ClinicWellnessUpdate> wellnessUpdate, Long wellnessPlanId, String petSize) {
	    List<DropdownListResponseDTO> dropDowns = new ArrayList<>();

	    for (ClinicWellnessUpdate clinicWellnessUpdate : wellnessUpdate) {
	        if (clinicWellnessUpdate.isStatus()) {
	            DropdownList dropDownList = dropDownRepository.findById(clinicWellnessUpdate.getDropDown().getId()).get();

	            Recommendation recommendation = recommendationRepository
	                    .findByDropdownListIdAndWellnessPlanId(dropDownList.getId(), wellnessPlanId);

	            if (recommendation != null && 
	               (recommendation.getRecommendation().equals("Required") || 
	                recommendation.getRecommendation().equals("Recommended"))) {
	                
	                DropdownListResponseDTO dropDown = new DropdownListResponseDTO();
	                dropDown.setIndustryStandardPrice(dropDownList.getIndustryStandardPrice());
	                dropDown.setDropdown(dropDownList.getDropdown());
	                dropDown.setPriceBased(dropDownList.getPriceBased());

	                ClinicWellnessPlanUpdateDTO updateWellness = new ClinicWellnessPlanUpdateDTO();
	                updateWellness.setUpdateRecommendation(clinicWellnessUpdate.getUpdateRecommendation());
	                updateWellness.setDiscountPercentage(clinicWellnessUpdate.getDiscountPercentage());
	                updateWellness.setDoctorPercentage(clinicWellnessUpdate.getDoctorPercentage());
	                updateWellness.setStatus(clinicWellnessUpdate.isStatus());
	                updateWellness.setStripeProductId(clinicWellnessUpdate.getStripeProductId());
	                updateWellness.setStripePriceId(clinicWellnessUpdate.getStripePriceId());
	                updateWellness.setWellnessUpdateId(clinicWellnessUpdate.getId());
                    updateWellness.setPriceBased(dropDownList.getPriceBased());
	                String price = null;
	                if ("QTY".equalsIgnoreCase(dropDownList.getPriceBased())) {
	                    price = clinicWellnessUpdate.getDiscountPriceForQuantity();
	                    updateWellness.setUpdatedPriceForQuantity(clinicWellnessUpdate.getUpdatedPriceForQuantity());
	                } else if ("WGT".equalsIgnoreCase(dropDownList.getPriceBased())) {
	                    switch (petSize.toUpperCase()) {
	                        case "SMALL":
	                            price = clinicWellnessUpdate.getDiscountPriceForSmall();
	                            updateWellness.setUpdatedPriceForSmall(clinicWellnessUpdate.getUpdatedPriceForSmall());
	                            break;
	                        case "MEDIUM":
	                            price = clinicWellnessUpdate.getDiscountPriceForMedium();
	                            updateWellness.setUpdatedPriceForMedium(clinicWellnessUpdate.getUpdatedPriceForMedium());
	                            break;
	                        case "LARGE":
	                            price = clinicWellnessUpdate.getDiscountPriceForLarge();
	                            updateWellness.setUpdatedPriceForLarge(clinicWellnessUpdate.getUpdatedPriceForLarge());
	                            break;
	                        case "X-LARGE":
	                            price = clinicWellnessUpdate.getDiscountPriceForXLarge();
	                            updateWellness.setUpdatedPriceForXLarge(clinicWellnessUpdate.getUpdatedPriceForXLarge());
	                            break;
	                        default:
	                            price = null; 
	                    }
	                }

	                updateWellness.setPrice(price); 

	                dropDown.setWellnessUpdate(updateWellness);
	                dropDowns.add(dropDown);
	            }
	        }
	    }

	    return dropDowns;
	}

	
	public String sendPlansToPetOwner(ChoosePlanWithPromotionsDTO choosePlanWithPromotionsDTO) {
	    List<PetWellnessPlan> sendPetPlans = new ArrayList<>();

	    String petOwnerEmail = null;
	    String petOwnerName = null;
	    String petName = null;
	    String clinicName = null;

		ManagePetWellnessPlans newPlans = null;
		if(choosePlanWithPromotionsDTO.getChoosePlans().get(0).getManagePetWellnessPlanId() == null) {
			newPlans = new ManagePetWellnessPlans();
			newPlans.setPromotionDiscounts(choosePlanWithPromotionsDTO.getPromotionDiscounts());
			managePetWellnessPlanRepository.save(newPlans);
		}

	    for (ChoosePlanDTO petPlan : choosePlanWithPromotionsDTO.getChoosePlans()) {
	        PetDetails checkPet = petDetailsRepository.findById(petPlan.getPetId())
	                .orElseThrow(() -> new RuntimeException("Pet Id is not found"));
	        	        
	        Register checkSentBy = registerRepository.findById(petPlan.getSentBy())
	                .orElseThrow(() -> new RuntimeException("Sent By Id is not found"));
	        
	        ClinicWellnessPlan checkClinicWellnessPlan = clinicWellnessPlanRepository
	                .findById(petPlan.getClinicWellnessPlan())
	                .orElseThrow(() -> new RuntimeException("Clinic Wellness Plan Not found"));
	        
	        ClinicWellnessUpdate checkClinicWellnessUpdate = clinicWellnessUpdateRepository
	                .findById(petPlan.getClinicWellnessUpdate())
	                .orElseThrow(() -> new RuntimeException("Clinic Wellness Update id not found"));
	        
	        ManagePetWellnessPlans checkManagePetWellnessPlan = null;
	        if (petPlan.getManagePetWellnessPlanId() != null) {
	            checkManagePetWellnessPlan = managePetWellnessPlanRepository
	                    .findById(petPlan.getManagePetWellnessPlanId())
	                    .orElseThrow(() -> new RuntimeException("Manage Pet Wellness Plan Id not Found"));
	        }

	        Long serviceFrequency = petPlan.getServiceFrequency();

	        for (int i = 0; i < serviceFrequency; i++) {
	            PetWellnessPlan plan = new PetWellnessPlan();
	            plan.setPetId(checkPet);
	            plan.setPetOwnerId(checkPet.getPetOwner());
	            plan.setAssignedBy(checkSentBy);
	            plan.setClinicWellnessPlan(checkClinicWellnessPlan);
	            plan.setClinicWellnessUpdate(checkClinicWellnessUpdate);
	            if(checkManagePetWellnessPlan!=null) {
	            	plan.setManagePetWellnessPlan(checkManagePetWellnessPlan);
	            }else if(newPlans!=null) {
	            	plan.setManagePetWellnessPlan(newPlans);
	            }
	            
	            plan.setWorkFlowStatus(Status.SENT_TO_PET_OWNER);
	            sendPetPlans.add(plan);
	            petWellnessPlanRepository.save(plan);
	        }

	        if (petOwnerEmail == null) {
	            petOwnerEmail = checkPet.getPetOwner().getEmail();
	            petOwnerName = checkPet.getPetOwner().getFirstName() + " " + checkPet.getPetOwner().getLastName();
	            petName = checkPet.getPetName();
	            clinicName = checkClinicWellnessPlan.getClinic().getClinicName();
	        }
	    }

	    if (petOwnerEmail != null) {
	        emailSender.sendWellnessPlanNotification(petOwnerEmail, petOwnerName, petName, clinicName);
	    }
//		Long managePetWellnessPlanId = choosePlanWithPromotionsDTO.getChoosePlans().getFirst().getManagePetWellnessPlanId();

	    return "Plans Sent";
	}
	
	public String sendUpdatedPlansToPetOwner(ChoosePlanWithPromotionsDTO choosePlanWithPromotionsDTO , String action) {
	    List<PetWellnessPlan> sendPetPlans = new ArrayList<>();

	    String petOwnerEmail = null;
	    String petOwnerName = null;
	    String petName = null;
	    String clinicName = null;

		ManagePetWellnessPlans newPlans = null;
		if(action.equals("add")){
			if(choosePlanWithPromotionsDTO.getChoosePlans().getFirst().getManagePetWellnessPlanId() == null) {
				newPlans = new ManagePetWellnessPlans();
				newPlans.setPromotionDiscounts(choosePlanWithPromotionsDTO.getPromotionDiscounts());
				managePetWellnessPlanRepository.save(newPlans);
			}
		}

	    for (ChoosePlanDTO petPlan : choosePlanWithPromotionsDTO.getChoosePlans()) {
	        PetDetails checkPet = petDetailsRepository.findById(petPlan.getPetId())
	                .orElseThrow(() -> new RuntimeException("Pet Id is not found"));

	        Register checkSentBy = registerRepository.findById(petPlan.getSentBy())
	                .orElseThrow(() -> new RuntimeException("Sent By Id is not found"));

	        ClinicWellnessPlan checkClinicWellnessPlan = clinicWellnessPlanRepository
	                .findById(petPlan.getClinicWellnessPlan())
	                .orElseThrow(() -> new RuntimeException("Clinic Wellness Plan Not found"));

	        ClinicWellnessUpdate checkClinicWellnessUpdate = clinicWellnessUpdateRepository
	                .findById(petPlan.getClinicWellnessUpdate())
	                .orElseThrow(() -> new RuntimeException("Clinic Wellness Update id not found"));

	        ManagePetWellnessPlans checkManagePetWellnessPlan = null;
	        if (petPlan.getManagePetWellnessPlanId() != null) {
	            checkManagePetWellnessPlan = managePetWellnessPlanRepository
	                    .findById(petPlan.getManagePetWellnessPlanId())
	                    .orElseThrow(() -> new RuntimeException("Manage Pet Wellness Plan Id not Found"));
	        }

	        Long serviceFrequency = petPlan.getServiceFrequency();

	        for (int i = 0; i < serviceFrequency; i++) {
	            PetWellnessPlan plan = new PetWellnessPlan();
	            plan.setPetId(checkPet);
	            plan.setPetOwnerId(checkPet.getPetOwner());
	            plan.setAssignedBy(checkSentBy);
	            plan.setClinicWellnessPlan(checkClinicWellnessPlan);
	            plan.setClinicWellnessUpdate(checkClinicWellnessUpdate);
	            if(checkManagePetWellnessPlan!=null) {
	            	plan.setManagePetWellnessPlan(checkManagePetWellnessPlan);
	            }else {
	            	plan.setManagePetWellnessPlan(null);
	            }
	            if(action.equals("add")) {
	            	plan.setWorkFlowStatus(Status.NEW_SET_TO_PET_OWNER);
					plan.setManagePetWellnessPlan(newPlans);
	            }else if (action.equals("update")){
	            	plan.setWorkFlowStatus(Status.UPDATED_PLANS_TO_OWNER);
	            }
	            sendPetPlans.add(plan);
				if(action.equals("update")) {
					Long managePetWellnessPlanId = choosePlanWithPromotionsDTO.getChoosePlans().getFirst().getManagePetWellnessPlanId();
					Optional<ManagePetWellnessPlans> managePetWellnessPlan = managePetWellnessPlanRepository.findById(managePetWellnessPlanId);
					if (managePetWellnessPlan.isPresent()) {
						managePetWellnessPlan.ifPresent(managePetWellnessPlans -> managePetWellnessPlans.setPromotionDiscounts(choosePlanWithPromotionsDTO.getPromotionDiscounts()));
						managePetWellnessPlanRepository.save(managePetWellnessPlan.get());
					}
				}
	            petWellnessPlanRepository.save(plan);
	        }

	        if (petOwnerEmail == null) {
	            petOwnerEmail = checkPet.getPetOwner().getEmail();
	            petOwnerName = checkPet.getPetOwner().getFirstName() + " " + checkPet.getPetOwner().getLastName();
	            petName = checkPet.getPetName();
	            clinicName = checkClinicWellnessPlan.getClinic().getClinicName();
	        }
	    }

	    if (petOwnerEmail != null) {
	        emailSender.sendUpdatedWellnessPlanNotification(petOwnerEmail, petOwnerName, petName, clinicName);
	    }
	    return "Plans Sent";
	}

	public String confirmChoosenPlans(ConfirmPlanRequestDTO request) {
	    List<PetWellnessPlan> selectedPlans = petWellnessPlanRepository.findAllById(request.getPetWellnessPlanIds());
	    if (selectedPlans == null || selectedPlans.isEmpty()) {
	        return "NOT UPDATED";
	    }

	    if (request.getManagePetWellnessPlanId() == null) {
	        throw new IllegalArgumentException("ManagePetWellnessPlanId must be provided for updates.");
	    }

	    ManagePetWellnessPlans managePlan = managePetWellnessPlanRepository
	            .findById(request.getManagePetWellnessPlanId())
	            .orElseThrow(() -> new IllegalArgumentException("ManagePetWellnessPlan not found with ID: " + request.getManagePetWellnessPlanId()));

	    if (request.getUpdatedAmount() != null) {
	        managePlan.setUpdatedAmount(request.getUpdatedAmount());
	    }
	    if (request.getStartDate() != null) {
	        managePlan.setStartDate(request.getStartDate());
	    }
	    if (request.getEndDate() != null) {
	        managePlan.setEndDate(request.getEndDate());
	    }
	    if (request.getTotalAmount() != null) {
	        managePlan.setTotalAmount(request.getTotalAmount());
	    }

	    managePlan = managePetWellnessPlanRepository.save(managePlan);

	    for (PetWellnessPlan plan : selectedPlans) {
	        plan.setManagePetWellnessPlan(managePlan);
	        plan.setWorkFlowStatus(Status.ACTIVE);
	        plan.setCreatedOn(USDateFormat.dateFormat());
	    }
	    petWellnessPlanRepository.saveAll(selectedPlans);

	    try {
	        byte[] pdfBytes = generateInvoicePDF(selectedPlans, managePlan.getTotalAmount());
	        String pdfPath = saveInvoiceToS3(pdfBytes);
	        saveInvoiceMetadata(pdfPath, "Generated invoice for wellness plans", managePlan,
	                selectedPlans.get(0).getClinicWellnessPlan().getClinic().getId());

	        String fromEmail = managePlan.getPetWellnessPlans().get(0).getClinicWellnessPlan().getClinic().getEmail();
	        String toEmail = managePlan.getPetWellnessPlans().get(0).getPetOwnerId().getEmail();
	        String petOwnerName = managePlan.getPetWellnessPlans().get(0).getPetOwnerId().getFirstName() + " "
	                + managePlan.getPetWellnessPlans().get(0).getPetOwnerId().getLastName();
	        String petName = managePlan.getPetWellnessPlans().get(0).getPetId().getPetName();
	        String clinicName = selectedPlans.get(0).getClinicWellnessPlan().getClinic().getClinicName();
	        String planName = selectedPlans.get(0).getClinicWellnessPlan().getWellnessPlan().getService().getService() + " - "
	                + selectedPlans.get(0).getClinicWellnessUpdate().getDropDown().getDropdown();
	        String startDate = managePlan.getStartDate().toString();
	        String endDate = managePlan.getEndDate().toString();

	        emailSender.sendPlanConfirmationEmail(fromEmail , toEmail, petOwnerName, petName , planName, startDate, endDate, clinicName, pdfBytes);

	    } catch (IOException e) {
	        throw new RuntimeException("Error while generating or saving PDF invoice", e);
	    }

	    return "UPDATED";
	}

	
	private byte[] generateInvoicePDF(List<PetWellnessPlan> plans, String totalAmount) throws IOException {
	    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
	    Document document = new Document(PageSize.A4);

	    try {
	        PdfWriter.getInstance(document, byteArrayOutputStream);
	        document.open();

	        String logoUrl = plans.get(0).getClinicWellnessPlan().getClinic().getClinicLogo(); // Fetch logo URL
	        if (logoUrl != null && !logoUrl.isEmpty()) {
	            OkHttpClient client = new OkHttpClient();
	            Request request = new Request.Builder().url(logoUrl).build();

	            try (Response response = client.newCall(request).execute()) {
	                if (response.isSuccessful() && response.body() != null) {
	                    InputStream logoStream = response.body().byteStream();
	                    Image logo = Image.getInstance(logoStream.readAllBytes());
	                    logo.scaleToFit(150, 150); // Scale logo size
	                    logo.setAlignment(Image.ALIGN_CENTER); // Center the logo
	                    document.add(logo);
	                } else {
	                    document.add(new Paragraph("Failed to load clinic logo (Error code: " + response.code() + ")"));
	                }
	            } catch (Exception e) {
	                document.add(new Paragraph("Error fetching clinic logo: " + e.getMessage()));
	            }
	        } else {
	            document.add(new Paragraph("No clinic logo provided."));
	        }

	        document.add(new Paragraph(" "));


	        document.add(new Paragraph("Invoice for Pet Wellness Plans", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18)));
	        document.add(new Paragraph("Invoice ID: " + (plans.isEmpty() ? "N/A" : plans.get(0).getManagePetWellnessPlan().getId())));
	        document.add(new Paragraph("Date: " + LocalDate.now(), FontFactory.getFont(FontFactory.HELVETICA, 12)));
	        document.add(new Paragraph(" "));

	        String clinicName = plans.isEmpty() ? "N/A" : plans.get(0).getClinicWellnessPlan().getClinic().getClinicName();
	        String clinicPhone = plans.isEmpty() ? "N/A" : plans.get(0).getClinicWellnessPlan().getClinic().getContactNumber();
	        String clinicAddress = plans.isEmpty() ? "N/A" : plans.get(0).getClinicWellnessPlan().getClinic().getAddress();
	        String clinicStateAndCity = plans.isEmpty() ? "N/A" : plans.get(0).getClinicWellnessPlan().getClinic().getCity() + ", " + plans.get(0).getClinicWellnessPlan().getClinic().getState();

	        Paragraph clinicDetails = new Paragraph(
	            "Clinic Name: " + clinicName + "\n" +
	            "Phone: " + clinicPhone + "\n" +
	            "Address: " + clinicAddress + "\n" +
	            "City & State: " + clinicStateAndCity + "\n",
	            FontFactory.getFont(FontFactory.HELVETICA, 12)
	        );
	        document.add(clinicDetails);
	        document.add(new Paragraph(" "));

	        String petName = plans.isEmpty() ? "N/A" : plans.get(0).getPetId().getPetName();
	        String petType = plans.isEmpty() ? "N/A" : plans.get(0).getPetId().getPetType();

	        Paragraph petDetails = new Paragraph(
	            "Pet Name: " + petName + "\n" +
	            "Pet Type: " + petType + "\n",
	            FontFactory.getFont(FontFactory.HELVETICA, 12)
	        );
	        document.add(petDetails);
	        document.add(new Paragraph(" "));

	        PdfPTable table = new PdfPTable(5);
	        table.setWidthPercentage(100);
	        table.setSpacingBefore(10f);
	        table.setSpacingAfter(10f);

	        float[] columnWidths = {2f, 2f, 4f, 2f, 2f};
	        table.setWidths(columnWidths);

	        Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 11);
	        addHeaderCell(table, "Service Name", headerFont);
	        addHeaderCell(table, "Pet Type", headerFont);
	        addHeaderCell(table, "Recommendations", headerFont);
	        addHeaderCell(table, "Discounted Price", headerFont);
	        addHeaderCell(table, "Clinic Price", headerFont);

	        Font cellFont = FontFactory.getFont(FontFactory.HELVETICA, 10);
	        for (PetWellnessPlan plan : plans) {
	            String petSize = determinePetSize(plan.getPetId());

	            GetPetWellnessPlanDTO dto = new GetPetWellnessPlanDTO();
	            setPriceBasedOnPetSize(dto, plan, petSize);

	            addCell(table, plan.getClinicWellnessPlan().getWellnessPlan().getService().getService() + " " + "-" + plan.getClinicWellnessUpdate().getDropDown().getDropdown(), cellFont);
	            addCell(table, plan.getPetId().getPetType(), cellFont);
	            addCell(table, plan.getClinicWellnessUpdate().getUpdateRecommendation(), cellFont);
	            addCell(table, dto.getDiscountPrice() != null ? dto.getDiscountPrice() : "N/A", cellFont);
	            addCell(table, dto.getUpdatedPrice() != null ? dto.getUpdatedPrice() : "N/A", cellFont);
	        }

	        document.add(table);

	        document.add(new Paragraph(" "));
	        document.add(new Paragraph("Total Payment: " + totalAmount, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14)));

	        document.close();
	    } catch (DocumentException e) {
	        throw new IOException("Error while generating PDF", e);
	    }

	    return byteArrayOutputStream.toByteArray();
	}
 
	private void addHeaderCell(PdfPTable table, String text, Font font) {
	    PdfPCell cell = new PdfPCell(new Phrase(text, font));
	    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	    cell.setPadding(8f);
	    cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
	    table.addCell(cell);
	}
 
	private void addCell(PdfPTable table, String text, Font font) {
	    PdfPCell cell = new PdfPCell(new Phrase(text, font));
	    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
	    cell.setPadding(5f);
	    table.addCell(cell);
	}
 
 
	private String saveInvoiceToS3(byte[] pdfBytes) throws IOException {
	    String filename = "invoice-" + System.currentTimeMillis() + ".pdf";
	    return s3Service.uploadPDFToS3(pdfBytes, filename);
	}
 
	
	private void saveInvoiceMetadata(String pdfPath, String description, ManagePetWellnessPlans managePlan, Long clinicId) {
	    UploadDocument document = new UploadDocument();
	    document.setDocumentUrl(pdfPath);
	    document.setUploadedByRole(managePlan.getPetWellnessPlans().get(0).getAssignedBy().getRole());
	    document.setUploadedById(managePlan.getPetWellnessPlans().get(0).getAssignedBy().getId());
	    document.setTargetType("INVOICE");
	    document.setUploadDate(LocalDate.now().toString());
	    document.setDescription(description);
	    document.setManagePetWellnessPlan(managePlan);
	    document.setClinicId(clinicId);
	    document.setDocumentType("Invoice");
	    document.setTargetId(managePlan.getPetWellnessPlans().get(0).getPetOwnerId().getId());
	    document.setTargetType("PetOwner");
	    documentRepository.save(document);
	}
 
	private String determinePetSize(PetDetails checkPet) {
		String petSize = null;
		if (checkPet.getWeight() != null && checkPet.getPetType() != null) {
			try {
				double weight = Double.parseDouble(checkPet.getWeight().replace("lb", "").trim());
				petSize = weightRangeRepository.findSizeByPetTypeAndWeight(checkPet.getPetType(), weight);
			} catch (NumberFormatException | NullPointerException e) {
				petSize = null;
			}
		}
		return petSize;
	}
 
	
	private void setPriceBasedOnPetSize(GetPetWellnessPlanDTO dto, PetWellnessPlan wellnessPlan, String petSize) {
	    if ("QTY".equalsIgnoreCase(wellnessPlan.getClinicWellnessUpdate().getDropDown().getPriceBased())) {
	        dto.setDiscountPrice(wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForQuantity());
	        dto.setUpdatedPrice(wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForQuantity());
	        System.out.println("QTY PRICE OF UPDATED : " + wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForQuantity());
	        System.out.println("QTY PRICE OF DISCOUNTED : " + wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForQuantity() );
	    } else if ("WGT".equalsIgnoreCase(wellnessPlan.getClinicWellnessUpdate().getDropDown().getPriceBased())) {
	        switch (petSize.toUpperCase()) {
	            case "SMALL":
	                dto.setDiscountPrice(wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForSmall());
	                dto.setUpdatedPrice(wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForSmall());
	                System.out.println("Discount Price for Small: " + wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForSmall());
	                System.out.println("Updated Price for Small: " + wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForSmall());
	                break;
	            case "MEDIUM":
	                dto.setDiscountPrice(wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForMedium());
	                dto.setUpdatedPrice(wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForMedium());
	                System.out.println("Discount Price for Medium: " + wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForMedium());
	                System.out.println("Updated Price for Medium: " + wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForMedium());
	                break;
	            case "LARGE":
	                dto.setDiscountPrice(wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForLarge());
	                dto.setUpdatedPrice(wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForLarge());
	                System.out.println("Discount Price for Large: " + wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForLarge());
	                System.out.println("Updated Price for Large: " + wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForLarge());
	                break;
	            case "X-LARGE":
	                dto.setDiscountPrice(wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForXLarge());
	                dto.setUpdatedPrice(wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForXLarge());
	                System.out.println("Discount Price for X-Large: " + wellnessPlan.getClinicWellnessUpdate().getDiscountPriceForXLarge());
	                System.out.println("Updated Price for X-Large: " + wellnessPlan.getClinicWellnessUpdate().getUpdatedPriceForXLarge());
	                break;
	            default:
	                dto.setDiscountPrice("N/A");
	                dto.setUpdatedPrice("N/A");
	                break;
	        }
	    } else {
	        dto.setDiscountPrice("N/A");
	        dto.setUpdatedPrice("N/A");
	    }
	}

	 
	public String updateFullfilledStatus(Long petWellnessPlanId, Long regId) {
		PetWellnessPlan checkPetWellnessPlan = petWellnessPlanRepository.findByIdAndWorkFlowStatus(petWellnessPlanId , Status.ACTIVE);
		if (checkPetWellnessPlan != null) {
			Register checkRegister = registerRepository.findById(regId).get();
			checkPetWellnessPlan.setWorkFlowStatus(Status.FULFILLED);
			checkPetWellnessPlan.setFulfilledBy(checkRegister.getId());
			petWellnessPlanRepository.save(checkPetWellnessPlan);
		} else {
			return "Pet Wellness Plan not found or not confirmed";
		}
		return "Updated";
	}
}
