package com.elevate.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.elevate.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.elevate.dto.AddNewSetPlansDRTO;
import com.elevate.dto.ClinicWellnessPlanUpdateDTO;
import com.elevate.dto.DropdownListResponseDTO;
import com.elevate.dto.GetUpdateWellnessPlansDTO;
import com.elevate.dto.UpdateNewSetPlansDTO;
import com.elevate.repository.IClinicWellnessPlanRepository;
import com.elevate.repository.IClinicWellnessUpdateRepository;
import com.elevate.repository.IManagePetWellnessPlansRepository;
import com.elevate.repository.IPetDetailsRepository;
import com.elevate.repository.IPetWellnessPlanRepository;
import com.elevate.repository.IRegisterRepository;
import jakarta.persistence.EntityNotFoundException;

@Service
public class ManagePetWellnessPlanService {
		
	@Autowired 
	private IPetWellnessPlanRepository petWellnessPlanRepository;
	
	@Autowired
	private IClinicWellnessPlanRepository clinicWellnessPlanRepository;
	
	@Autowired
	private IManagePetWellnessPlansRepository managePetWellnessPlansRepository;
	
    @Autowired
    private IPetDetailsRepository petDetailsRepository;

    @Autowired
    private IClinicWellnessUpdateRepository clinicWellnessUpdateRepository;

    @Autowired
    private IRegisterRepository registerRepository;
    
    public Map<String, Object> getPlansToUpdate(Long clinicId, String wellnessPlanName, Long managePetWellnessPlanId) {
        List<ClinicWellnessPlan> clinicWellnessPlans = clinicWellnessPlanRepository
                .findClinicWellnessPlansByClinicIdAndWellnessPlanName(clinicId, wellnessPlanName);
        List<PetWellnessPlan> usedPetWellnessPlans = petWellnessPlanRepository
                .findByManagePetWellnessPlanId(managePetWellnessPlanId);

        Map<String, Integer> serviceFrequencyMap = new HashMap<>();
        List<GetUpdateWellnessPlansDTO> result = new ArrayList<>();

        List<String> promotions = managePetWellnessPlansRepository.findById(managePetWellnessPlanId)
                .map(ManagePetWellnessPlans::getPromotionDiscounts)
                .map(discounts -> discounts.stream()
                        .map(PromotionDiscount::getPromotionType)
                        .collect(Collectors.toList()))
                .orElse(Collections.emptyList());

        String startDate = null;
        String endDate = null;
        String totalAmount = null;
        String monthlyAmount = null;

        for (ClinicWellnessPlan clinicWellnessPlan : clinicWellnessPlans) {
            if (clinicWellnessPlan == null || clinicWellnessPlan.getWellnessPlan() == null) {
                continue;
            }

            List<DropdownListResponseDTO> dropDowns = dropDownDetailsPet(
                    clinicWellnessPlan.getWellnessUpdate(),
                    clinicWellnessPlan.getWellnessPlan().getId()
            );

            for (DropdownListResponseDTO dropdown : dropDowns) {
                if (dropdown == null || !dropdown.getWellnessUpdate().isStatus()) {
                    continue;
                }

                String serviceName = clinicWellnessPlan.getWellnessPlan().getService().getService();
                String dropdownName = dropdown.getDropdown();

                long frequencyCount = usedPetWellnessPlans.stream()
                        .filter(petWellnessPlan -> petWellnessPlan.getClinicWellnessPlan() != null &&
                                petWellnessPlan.getClinicWellnessUpdate() != null &&
                                petWellnessPlan.getClinicWellnessPlan().getId().equals(clinicWellnessPlan.getId()) &&
                                dropdownName.equals(petWellnessPlan.getClinicWellnessUpdate().getDropDown().getDropdown()))
                        .count();

                int serviceFrequency = frequencyCount > 0 ? (int) frequencyCount : 1;

                String uniqueKey = clinicWellnessPlan.getId() + "-" + dropdownName + "-" + managePetWellnessPlanId;
                serviceFrequencyMap.put(uniqueKey, serviceFrequency);

                GetUpdateWellnessPlansDTO wellnessPlanDTO = new GetUpdateWellnessPlansDTO();
                wellnessPlanDTO.setClinicWellnessPlanId(clinicWellnessPlan.getId());
                wellnessPlanDTO.setPetType(clinicWellnessPlan.getWellnessPlan().getPetType());
                wellnessPlanDTO.setAgeGroup(clinicWellnessPlan.getWellnessPlan().getAgeGroup());
                wellnessPlanDTO.setWellnessPlanName(clinicWellnessPlan.getWellnessPlan().getWellnessPlanName());
                wellnessPlanDTO.setServiceName(serviceName);
                wellnessPlanDTO.setClinicDropDowns(Collections.singletonList(dropdown));
                wellnessPlanDTO.setPetId(usedPetWellnessPlans.get(0).getPetId().getId());
                wellnessPlanDTO.setPetOwnerId(usedPetWellnessPlans.get(0).getPetOwnerId().getId());
                wellnessPlanDTO.setPromotions(promotions);

                PetWellnessPlan matchedPlan = usedPetWellnessPlans.stream()
                        .filter(petWellnessPlan -> petWellnessPlan.getClinicWellnessPlan() != null &&
                                petWellnessPlan.getClinicWellnessUpdate() != null &&
                                petWellnessPlan.getClinicWellnessPlan().getId().equals(clinicWellnessPlan.getId()) &&
                                dropdownName.equals(petWellnessPlan.getClinicWellnessUpdate().getDropDown().getDropdown()))
                        .findFirst()
                        .orElse(null);

                if (matchedPlan != null) {
                    wellnessPlanDTO.setPlanStatus(matchedPlan.getWorkFlowStatus().name());
                    startDate = matchedPlan.getManagePetWellnessPlan().getStartDate();
                    endDate = matchedPlan.getManagePetWellnessPlan().getEndDate();

                    totalAmount = matchedPlan.getManagePetWellnessPlan().getTotalAmount();
                    try {
                        double totalAmountNumeric = Double.parseDouble(totalAmount);
                        monthlyAmount = String.valueOf(totalAmountNumeric / 12);
                    } catch (NumberFormatException e) {
                        totalAmount = "0";
                        monthlyAmount = "0";
                    }
                } else {
                    wellnessPlanDTO.setPlanStatus("INACTIVE");
                }

                wellnessPlanDTO.setServiceFrequency(serviceFrequency);
                result.add(wellnessPlanDTO);
            }
        }

        Map<String, Object> response = new HashMap<>();
        response.put("startDate", startDate);
        response.put("endDate", endDate);
        response.put("totalAmount", totalAmount);
        response.put("monthlyAmount", monthlyAmount);
        response.put("plans", result);

        return response;
    }


    public List<GetUpdateWellnessPlansDTO> getPlansToAddNewSet(Long clinicId, String wellnessPlanName) {
        List<PetWellnessPlan> existingPetWellnessPlans = petWellnessPlanRepository.findExistingPlansForClinicAndWellnessPlan(clinicId, wellnessPlanName);

        Set<String> existingPlanCombinations = existingPetWellnessPlans.stream()
                .map(pwp -> pwp.getClinicWellnessPlan().getId() + "-" + pwp.getClinicWellnessUpdate().getId())
                .collect(Collectors.toSet());

        List<ClinicWellnessPlan> clinicWellnessPlans = clinicWellnessPlanRepository.findClinicWellnessPlansByClinicIdAndWellnessPlanName(clinicId, wellnessPlanName);

        List<GetUpdateWellnessPlansDTO> result = new ArrayList<>();

        for (ClinicWellnessPlan clinicWellnessPlan : clinicWellnessPlans) {
            List<DropdownListResponseDTO> dropDowns = dropDownDetailsPet(
                    clinicWellnessPlan.getWellnessUpdate(), clinicWellnessPlan.getWellnessPlan().getId());

            for (DropdownListResponseDTO dropdown : dropDowns) {
                if (dropdown.getWellnessUpdate().isStatus()) {
                    GetUpdateWellnessPlansDTO wellnessPlanDTO = new GetUpdateWellnessPlansDTO();
                    wellnessPlanDTO.setClinicWellnessPlanId(clinicWellnessPlan.getId());
                    wellnessPlanDTO.setPetType(clinicWellnessPlan.getWellnessPlan().getPetType());
                    wellnessPlanDTO.setAgeGroup(clinicWellnessPlan.getWellnessPlan().getAgeGroup());
                    wellnessPlanDTO.setWellnessPlanName(clinicWellnessPlan.getWellnessPlan().getWellnessPlanName());
                    wellnessPlanDTO.setServiceName(clinicWellnessPlan.getWellnessPlan().getService().getService());
                    wellnessPlanDTO.setClinicDropDowns(Collections.singletonList(dropdown));
//                    wellnessPlanDTO.setPetPlanStatus(false);
                    wellnessPlanDTO.setPetId(existingPetWellnessPlans.getFirst().getPetId().getId());
                    wellnessPlanDTO.setPetOwnerId(existingPetWellnessPlans.getFirst().getPetOwnerId().getId());

                    String planKey = clinicWellnessPlan.getId() + "-" + dropdown.getWellnessUpdate().getWellnessUpdateId();

                    if (!existingPlanCombinations.contains(planKey)) {
                        result.add(wellnessPlanDTO);
                    }
                }
            }
        }

        return result;
    }

    
    private List<DropdownListResponseDTO> dropDownDetailsPet(List<ClinicWellnessUpdate> wellnessUpdates, Long wellnessPlanId) {
        List<DropdownListResponseDTO> dropDowns = new ArrayList<>();

        for (ClinicWellnessUpdate wellnessUpdate : wellnessUpdates) {
            if ("Not Offered".equals(wellnessUpdate.getUpdateRecommendation())) {
                continue; 
            }

            DropdownListResponseDTO responseDTO = new DropdownListResponseDTO();
            responseDTO.setId(wellnessUpdate.getDropDown().getId());
            responseDTO.setDropdown(wellnessUpdate.getDropDown().getDropdown());
            responseDTO.setIndustryStandardPrice(wellnessUpdate.getDropDown().getIndustryStandardPrice());

            ClinicWellnessPlanUpdateDTO updateDTO = new ClinicWellnessPlanUpdateDTO();
            updateDTO.setWellnessUpdateId(wellnessUpdate.getId());
            updateDTO.setUpdateRecommendation(wellnessUpdate.getUpdateRecommendation());
            updateDTO.setUpdatedPriceForQuantity(wellnessUpdate.getUpdatedPriceForQuantity());
            updateDTO.setUpdatedPriceForSmall(wellnessUpdate.getUpdatedPriceForSmall());
            updateDTO.setUpdatedPriceForMedium(wellnessUpdate.getUpdatedPriceForMedium());
            updateDTO.setUpdatedPriceForLarge(wellnessUpdate.getUpdatedPriceForLarge());
            updateDTO.setUpdatedPriceForXLarge(wellnessUpdate.getUpdatedPriceForXLarge());
            updateDTO.setDiscountPriceForQuantity(wellnessUpdate.getDiscountPriceForQuantity());
            updateDTO.setDiscountPriceForSmall(wellnessUpdate.getDiscountPriceForSmall());
            updateDTO.setDiscountPriceForMedium(wellnessUpdate.getDiscountPriceForMedium());
            updateDTO.setDiscountPriceForLarge(wellnessUpdate.getDiscountPriceForLarge());
            updateDTO.setDiscountPriceForXLarge(wellnessUpdate.getDiscountPriceForXLarge());
            updateDTO.setDiscountPercentage(wellnessUpdate.getDiscountPercentage());
            updateDTO.setDoctorPercentage(wellnessUpdate.getDoctorPercentage());
            updateDTO.setPriceBased(wellnessUpdate.getDropDown().getPriceBased());
            updateDTO.setStatus(wellnessUpdate.isStatus());
            responseDTO.setWellnessUpdate(updateDTO);

            dropDowns.add(responseDTO);
        }

        return dropDowns;
    }
    
    public String updateWellnessPlan(List<UpdateNewSetPlansDTO> dtoList) {
        List<PetWellnessPlan> savedPlans = new ArrayList<>();

        for (UpdateNewSetPlansDTO dto : dtoList) {
            int frequency = dto.getServiceFrequency(); 
            for (int i = 0; i < frequency; i++) {
                PetWellnessPlan petWellnessPlan = new PetWellnessPlan();

                PetDetails petDetails = petDetailsRepository.findById(dto.getPetId())
                        .orElseThrow(() -> new EntityNotFoundException("Pet not found with ID: " + dto.getPetId()));
                petWellnessPlan.setPetId(petDetails);
                petWellnessPlan.setPetOwnerId(petDetails.getPetOwner());

                petWellnessPlan.setClinicWellnessPlan(clinicWellnessPlanRepository.findById(dto.getClinicWellnessPlanId())
                        .orElseThrow(() -> new EntityNotFoundException("Clinic Wellness Plan not found with ID: " + dto.getClinicWellnessPlanId())));

                petWellnessPlan.setClinicWellnessUpdate(clinicWellnessUpdateRepository.findById(dto.getClinicWellnessUpdateId())
                        .orElseThrow(() -> new EntityNotFoundException("Clinic Wellness Update not found with ID: " + dto.getClinicWellnessUpdateId())));

                petWellnessPlan.setAssignedBy(registerRepository.findById(dto.getAssignedById())
                        .orElseThrow(() -> new EntityNotFoundException("Assigned By not found with ID: " + dto.getAssignedById())));

//                petWellnessPlan.setPending(true);
//                petWellnessPlan.setStatus(Status.ACTIVE);
//                petWellnessPlan.setConfirmed(true);

                if (dto.getManagePetWellnessPlanId() != null) {
                    ManagePetWellnessPlans managePlan = managePetWellnessPlansRepository.findById(dto.getManagePetWellnessPlanId())
                            .orElseThrow(() -> new EntityNotFoundException("Manage Pet Wellness Plan not found with ID: " + dto.getManagePetWellnessPlanId()));
                    petWellnessPlan.setManagePetWellnessPlan(managePlan);
                }

                savedPlans.add(petWellnessPlanRepository.save(petWellnessPlan));
            }
        }

        return "Pet Wellness Plans created successfully.";
    }

    
    public String addNewPlansSet(List<AddNewSetPlansDRTO> wellnessPlansDTO) {
        ManagePetWellnessPlans managePetWellnessPlan = new ManagePetWellnessPlans();
        managePetWellnessPlan.setStartDate(wellnessPlansDTO.get(0).getStartDate());
        managePetWellnessPlan.setEndDate(wellnessPlansDTO.get(0).getEndDate());
        managePetWellnessPlan = managePetWellnessPlansRepository.save(managePetWellnessPlan);

        for (AddNewSetPlansDRTO wellnessPlanDTO : wellnessPlansDTO) {
            int frequency = wellnessPlanDTO.getServiceFrequency();

            for (int i = 0; i < frequency; i++) {
                PetWellnessPlan petWellnessPlan = new PetWellnessPlan();

                petWellnessPlan.setManagePetWellnessPlan(managePetWellnessPlan);

                petWellnessPlan.setAssignedBy(registerRepository.findById(wellnessPlanDTO.getAssignedById())
                        .orElseThrow(() -> new EntityNotFoundException("Assigned By not found with ID: " + wellnessPlanDTO.getAssignedById())));

//                petWellnessPlan.setPending(true);
//                petWellnessPlan.setStatus(Status.ACTIVE);
//                petWellnessPlan.setConfirmed(true);

                PetDetails checkPet = petDetailsRepository.findById(wellnessPlanDTO.getPetId())
                        .orElseThrow(() -> new RuntimeException("Pet Id Not found"));
                petWellnessPlan.setPetId(checkPet);
                petWellnessPlan.setPetOwnerId(checkPet.getPetOwner());

                ClinicWellnessPlan checkClinicWellnessPlan = clinicWellnessPlanRepository.findById(wellnessPlanDTO.getClinicWellnessPlanId())
                        .orElseThrow(() -> new EntityNotFoundException("Clinic Wellness Plan not found with ID: " + wellnessPlanDTO.getClinicWellnessPlanId()));
                ClinicWellnessUpdate checkClinicWellnessUpdate = clinicWellnessUpdateRepository.findById(wellnessPlanDTO.getClinicWellnessUpdateId())
                        .orElseThrow(() -> new EntityNotFoundException("Clinic Wellness Update not found with ID: " + wellnessPlanDTO.getClinicWellnessUpdateId()));

                petWellnessPlan.setClinicWellnessPlan(checkClinicWellnessPlan);
                petWellnessPlan.setClinicWellnessUpdate(checkClinicWellnessUpdate);

                petWellnessPlanRepository.save(petWellnessPlan);
            }
        }
        return "Wellness plans created successfully";
    }

}
