package com.elevate.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import com.elevate.entity.NewsLetter;
import com.elevate.entity.Subscribers;
import com.elevate.repository.INewsLetterRepository;
import com.elevate.repository.ISubscribeRepository;
import com.elevate.utils.EmailSender;
import com.elevate.utils.USDateFormat;

@Service
public class SubscibersService {
	
	@Autowired
	private ISubscribeRepository subscriberRepository;
	
	@Autowired
	private INewsLetterRepository newsLetterRepository;
	
	@Autowired
	private EmailSender emailSender;
	
	public String addSubscriber(Subscribers subscriber) {
	   subscriber.setStatus("SUBSCRIBED");
	   subscriber.setSubscribed_on(USDateFormat.dateFormat());
	   subscriberRepository.save(subscriber);
	   return "Added";	
	}
	
	public List<Subscribers> getAllSubscribers(){
		List<Subscribers> allUsers = subscriberRepository.findByStatus("SUBSCRIBED");
		return allUsers;
	}
	
	public String unscubscribe(String email) {
		Subscribers getSubscriber = subscriberRepository.findByEmail(email);
		if(getSubscriber == null) {
			return "Emal is not found";
		}else {
			getSubscriber.setStatus("UNSUBSCRIBED");
			subscriberRepository.save(getSubscriber);
			return "Unsubscribed";
		}
	}
	
	public String addImagesForEmails(NewsLetter newsLetter) {
		newsLetter.setUploadedOn(USDateFormat.dateFormat());
		newsLetterRepository.save(newsLetter);
		return "Scheduled the image to the date";
	}
	
	public List<NewsLetter> getAllNewsLetters(){
		List<NewsLetter> allNewsLetters = newsLetterRepository.findAll();
		return allNewsLetters;
	}
	
	@Scheduled(cron = "0 54 15 * * ?")
	public void sendOffersAndNewsLetters() {
		String currentDate = USDateFormat.dateFormat();
		NewsLetter newsLetter = newsLetterRepository.findByScheduledAt(currentDate);
		if(newsLetter != null) {
			List<String> subscribers = subscriberRepository.findSubscribedEmails();
			if (!subscribers.isEmpty()) {
               emailSender.sendNewslettersAndOffers(subscribers, newsLetter.getImage());
            } 
		}
	}

}
