package com.elevate.utils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.io.IOException;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.S3Exception;

@Service
public class S3Service {
    
    @Autowired
    private S3Client s3Client;

    @Value("${aws.bucketName}")
    private String bucketName;

    public String uploadQRCodeToS3(byte[] qrCode, String filename) throws IOException {
        try (ByteArrayInputStream inputStream = new ByteArrayInputStream(qrCode)) {
            PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                    .bucket(bucketName)
                    .key(filename)
                    .contentType("image/png")
                    .build();

            s3Client.putObject(putObjectRequest, RequestBody.fromInputStream(inputStream, qrCode.length));

            return "https://" + bucketName + ".s3.amazonaws.com/" + filename;
//            return filename;

        } catch (S3Exception e) {
            throw new RuntimeException("Failed to upload QR code to S3", e);
        } catch (java.io.IOException e1) {
			e1.printStackTrace();
		}
		return filename;
    }
    
    public String uploadPDFToS3(byte[] pdfBytes, String filename) throws IOException {
        try (ByteArrayInputStream inputStream = new ByteArrayInputStream(pdfBytes)) {
            PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                    .bucket(bucketName)
                    .key(filename)
                    .contentType("application/pdf")
                    .build();

            s3Client.putObject(putObjectRequest, RequestBody.fromInputStream(inputStream, pdfBytes.length));

            return generateS3Url(filename);
        } catch (S3Exception e) {
            throw new RuntimeException("Failed to upload PDF to S3", e);
        } catch (java.io.IOException e1) {
			e1.printStackTrace();
		}
		return filename;
    }

    
    private String generateS3Url(String filename) {
        return "https://" + bucketName + ".s3.amazonaws.com/" + filename;
    }
    
    public File downloadImageFromS3(String imageUrl) {
        File tempFile = null;
        try {
            System.out.println("Starting image download from S3...");

            String encodedUrl = imageUrl.replace(" ", "%20");

            URI uri = new URI(encodedUrl);
            String path = uri.getPath();
            String key = path.substring(1);

            System.out.println("Extracted S3 key: " + key);

            tempFile = File.createTempFile("newsletter_image", ".jpg");
            tempFile.deleteOnExit();

            GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .build();

            ResponseInputStream<GetObjectResponse> responseStream = s3Client.getObject(getObjectRequest);
            
            Files.copy(responseStream, tempFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            
            if (tempFile.exists()) {
                System.out.println("Image downloaded successfully: " + tempFile.getAbsolutePath());
            } else {
                System.out.println("Failed to download image or save to temp file.");
            }

            return tempFile;

        } catch (Exception e) {
            System.err.println("Error downloading image: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

}





