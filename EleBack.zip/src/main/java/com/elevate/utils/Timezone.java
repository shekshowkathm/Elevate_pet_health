package com.elevate.utils;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class Timezone {

	public static Instant convertToUTC(String scheduledDateAndTime, String clientTimeZoneAbbreviation) {
		// Get the ZoneId based on the abbreviation
		ZoneId clientZoneId = getZoneIdFromAbbreviation(clientTimeZoneAbbreviation);

		// Parse the scheduledDateAndTime as LocalDateTime (no time zone)
		LocalDateTime localDateTime = LocalDateTime.parse(scheduledDateAndTime, DateTimeFormatter.ISO_LOCAL_DATE_TIME);

		// Convert LocalDateTime to ZonedDateTime in the client's time zone
		ZonedDateTime zonedDateTime = localDateTime.atZone(clientZoneId);

		// Convert the ZonedDateTime to UTC
		Instant utcTime = zonedDateTime.withZoneSameInstant(ZoneId.of("UTC")).toInstant();
		return utcTime;
	}

	private static ZoneId getZoneIdFromAbbreviation(String timeZoneAbbreviation) {
		switch (timeZoneAbbreviation) {
		case "EST":
			return ZoneId.of("America/New_York");
		case "PST":
			return ZoneId.of("America/Los_Angeles");
		case "CST":
			return ZoneId.of("America/Chicago");
		case "MST":
			return ZoneId.of("America/Denver");
		case "AKST":
			return ZoneId.of("America/Anchorage");
		case "HST":
			return ZoneId.of("Pacific/Honolulu");
		default:
			throw new IllegalArgumentException("Invalid Time Zone Abbreviation: " + timeZoneAbbreviation);
		}
	}

	public static String convertToTimeZone(Instant storedUtcTime, String petOwnersTimeZoneAbbreviation) {
		ZoneId petOwnerZoneId = getZoneIdFromAbbreviation(petOwnersTimeZoneAbbreviation);

		ZonedDateTime patientLocalTime = storedUtcTime.atZone(ZoneId.of("UTC")).withZoneSameInstant(petOwnerZoneId);

		return patientLocalTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
	}
}
