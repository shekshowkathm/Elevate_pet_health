package com.elevate.utils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.elevate.dto.ClinicRegister;
import com.elevate.dto.Email;
import com.elevate.dto.GetClinicInfoDTO;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.FileSystemResource;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@Component
public class EmailSender {
	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	private Configuration config;

	@Value("${spring.mail.username}")
	private String sender;
	
	 @Autowired
	 private S3Service s3Service;

	@Async
	public void sendEmail(String to, Email welcomeEmail) {
		MimeMessage message = javaMailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_RELATED,
					StandardCharsets.UTF_8.name());

			Template template = config.getTemplate("welcomeEmail-template.ftl");
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, welcomeEmail);

			helper.setTo(to);
			helper.setText(html, true);
			helper.setSubject("Welcome to Elevate Pet Health");
			helper.setFrom(sender);

			javaMailSender.send(message);
		} catch (MessagingException | IOException | TemplateException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Sending alert email to the super admin
	 * 
	 * @param to
	 * @param clinicRequest
	 */

	@Async
	public void sendAlertEmail(String to, ClinicRegister clinicRequest) {
		MimeMessage message = javaMailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_RELATED,
					StandardCharsets.UTF_8.name());

			// Encode the image
//			String base64Image = ImageUtils.encodeImageToBase64("src/main/resources/static/images/helo.svg");
//			welcomeEmail.setBase64Image(base64Image);

			Template template = config.getTemplate("alert-email-template.ftl");
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, clinicRequest);

			helper.setTo(to);
			helper.setText(html, true);
			helper.setSubject("Clinic Registration Request");
			helper.setFrom(sender);

			javaMailSender.send(message);
		} catch (MessagingException | IOException | TemplateException e) {
			e.printStackTrace();
		}
	}
	
	 @Async
	 public void sendOtpMail(String toEmail, String otpNumber) {
	        MimeMessage message = javaMailSender.createMimeMessage();

	        try {
	            MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_RELATED, StandardCharsets.UTF_8.name());

	            Template template = config.getTemplate("otpTemplate.ftl");

	            Map<String, Object> model = new HashMap<>();
	            model.put("otpNumber", otpNumber);

	            String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);

	            helper.setTo(toEmail);
	            helper.setSubject("OTP VERIFICATION FOR PASSWORD RESET");
	            helper.setFrom(sender);
	            helper.setText(html, true);  

	            javaMailSender.send(message);
	        } catch (MessagingException | IOException | TemplateException e) {
	            e.printStackTrace();
	        }
	    }
	
	@Async
	public void stripAccountCreationMail(String toEmail,String name,String verificationLink) {
		MimeMessage message = javaMailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message,true,
					StandardCharsets.UTF_8.name());

			Map<String, Object> model = new HashMap<>();
			model.put("name", name);
			model.put("activationLink", verificationLink);

			Template template = config.getTemplate("account_creation.ftl");
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);


			helper.setTo(toEmail);
			helper.setText(html, true);
			helper.setSubject("Stripe Account Creation");
			helper.setFrom(sender);

			javaMailSender.send(message);
		} catch (MessagingException | IOException | TemplateException e) {
			e.printStackTrace();
		}
	}
	
	@Async
	public void sendWellnessPlanNotification(String toEmail, String petOwnerName, String petName, String clinicName) {
	    MimeMessage message = javaMailSender.createMimeMessage();
	    try {
	        MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_RELATED,
	                StandardCharsets.UTF_8.name());

	        Map<String, Object> model = new HashMap<>();
	        model.put("petOwnerName", petOwnerName);
	        model.put("petName", petName);
	        model.put("clinicName", clinicName);

	        Template template = config.getTemplate("notifyWellnessPlanTemplate.ftl");
	        String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);

	        helper.setTo(toEmail);
	        helper.setText(html, true);
	        helper.setSubject("New Wellness Plans Available from " + clinicName);
	        helper.setFrom(sender);

	        javaMailSender.send(message);
	    } catch (MessagingException | IOException | TemplateException e) {
	        e.printStackTrace();
	    }
	}
	
	@Async
	public void sendUpdatedWellnessPlanNotification(String toEmail, String petOwnerName, String petName, String clinicName) {
	    MimeMessage message = javaMailSender.createMimeMessage();
	    try {
	        MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_RELATED,
	                StandardCharsets.UTF_8.name());

	        Map<String, Object> model = new HashMap<>();
	        model.put("petOwnerName", petOwnerName);
	        model.put("petName", petName);
	        model.put("clinicName", clinicName);

	        Template template = config.getTemplate("updatePlansNotifyMail.ftl");
	        String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);

	        helper.setTo(toEmail);
	        helper.setText(html, true);
	        helper.setSubject("New Wellness Plans Available from " + clinicName);
	        helper.setFrom(sender);

	        javaMailSender.send(message);
	    } catch (MessagingException | IOException | TemplateException e) {
	        e.printStackTrace();
	    }
	}
	
	@Async
	public void sendClinicInfoEmail(GetClinicInfoDTO clinicInfo) {
	    MimeMessage message = javaMailSender.createMimeMessage();
	    try {
	        MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_RELATED,
	                StandardCharsets.UTF_8.name());

	        Template template = config.getTemplate("clinicInfoTemplate.ftl");

	        Map<String, Object> model = new HashMap<>();
	        model.put("userMail", clinicInfo.getFromMail());
	        model.put("clinicName", clinicInfo.getClinicName());
	        model.put("state", clinicInfo.getState());
	        model.put("city", clinicInfo.getCity());
	        model.put("zipCode", clinicInfo.getZipCode());

	        String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);

	        helper.setTo("dharanidhas@datapattern.ai");

	        helper.setFrom(clinicInfo.getFromMail());

	        helper.setSubject("Clinic Information");
	        helper.setText(html, true);

	        javaMailSender.send(message);
	    } catch (MessagingException | IOException | TemplateException e) {
	        e.printStackTrace();
	    }
	}

	@Async
	public void sendScheduledAppointmentEmail(String toEmail, String petName, String scheduledDateTime, String clinicName, String clinicAddress, String petOwnerName, String fromEmail) {
	    MimeMessage message = javaMailSender.createMimeMessage();
	    try {
	        MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_RELATED, StandardCharsets.UTF_8.name());

	        Template template = config.getTemplate("appointmentTemplate.ftl");

	        Map<String, Object> model = new HashMap<>();
	        model.put("petOwnerName", petOwnerName);
	        model.put("petName", petName);
	        model.put("scheduledDateTime", scheduledDateTime);
	        model.put("clinicName", clinicName);
	        model.put("clinicAddress", clinicAddress);

	        String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);

	        helper.setTo(toEmail); 
	        helper.setSubject("Wellness Appointment Scheduled");
	        helper.setText(html, true); 
	        helper.setFrom(fromEmail); 

	        javaMailSender.send(message);
	        System.out.println("Scheduled appointment email sent to: " + toEmail);

	    } catch (MessagingException | IOException | TemplateException e) {
	        e.printStackTrace();
	        System.err.println("Failed to send scheduled appointment email: " + e.getMessage());
	    }
	}
	
	@Async
	public void sendReplyEmail(String toEmail, String petOwnerName, String issueDescription, String replyMessage, String clinicName, String fromEmail) {
	    MimeMessage message = javaMailSender.createMimeMessage();
	    try {
	        MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_RELATED, StandardCharsets.UTF_8.name());

	        // Load the FreeMarker template
	        Template template = config.getTemplate("supportReplyMail.ftl");

	        Map<String, Object> model = new HashMap<>();
	        model.put("petOwnerName", petOwnerName);
	        model.put("issueDescription", issueDescription);
	        model.put("replyMessage", replyMessage);
	        model.put("clinicName", clinicName);

	        String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);

	        helper.setTo(toEmail);
	        helper.setSubject("Response to Your Query: " + issueDescription);
	        helper.setText(html, true); 
	        helper.setFrom(fromEmail);

	        javaMailSender.send(message);

	    } catch (MessagingException | IOException | TemplateException e) {
	        e.printStackTrace();
	        System.err.println("Failed to send reply email: " + e.getMessage());
	    }
	}
	
	@Async
	public void sendPlanConfirmationEmail(String fromEmail ,String toEmail, String petOwnerName, String petName ,String planName, String startDate, 
	                                      String endDate, String clinicName, byte[] pdfBytes) {
	    MimeMessage message = javaMailSender.createMimeMessage();
	    try {
	        MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, 
	                                                         StandardCharsets.UTF_8.name());

	        Template template = config.getTemplate("confirmPlan.ftl");

	        Map<String, Object> model = new HashMap<>();
	        model.put("petOwnerName", petOwnerName);
	        model.put("petName", petName);
	        model.put("clinicName", clinicName);

	        String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);

	        helper.setTo(toEmail);
	        helper.setSubject("Wellness Plan Confirmation for " + petName);
	        helper.setText(html, true);
	        helper.setFrom(fromEmail);

	        if (pdfBytes != null && pdfBytes.length > 0) {
	            helper.addAttachment("Invoice.pdf", new ByteArrayResource(pdfBytes));
	        }

	        javaMailSender.send(message);
	        System.out.println("Plan confirmation email sent to: " + toEmail);

	    } catch (MessagingException | IOException | TemplateException e) {
	        e.printStackTrace();
	        System.err.println("Failed to send plan confirmation email: " + e.getMessage());
	    }

	}

	@Async
	public void paymentFail(String toEmail,String name,double verificationLink) {
		MimeMessage message = javaMailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message,true,
					StandardCharsets.UTF_8.name());

			Map<String, Object> model = new HashMap<>();
			model.put("name", name);
			model.put("activationLink", (verificationLink)/100);

			Template template = config.getTemplate("paymentFaileds.ftl");
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);


			helper.setTo(toEmail);
			helper.setText(html, true);
			helper.setSubject("Payment Failed");
			helper.setFrom(sender);

			javaMailSender.send(message);
		} catch (MessagingException | IOException | TemplateException e) {
			e.printStackTrace();
		}
	}
	@Async
	public void paymentConfirm(String toEmail,String name,double verificationLink) {
		MimeMessage message = javaMailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message,true,
					StandardCharsets.UTF_8.name());

			Map<String, Object> model = new HashMap<>();
			model.put("name", name);
			model.put("amount", (verificationLink)/100);

			Template template = config.getTemplate("paymentConfirm.ftl");
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);


			helper.setTo(toEmail);
			helper.setText(html, true);
			helper.setSubject("Payment Confirmation");
			helper.setFrom(sender);

			javaMailSender.send(message);
		} catch (MessagingException | IOException | TemplateException e) {
			e.printStackTrace();
		}
	}
	
	@Async
	public void sendNewslettersAndOffers(List<String> emails, String imageUrl) {
	    File imageFile = null;
	    try {
	        System.out.println("Starting to send newsletters...");
	        MimeMessage message = javaMailSender.createMimeMessage();
	        MimeMessageHelper helper = new MimeMessageHelper(message, true);

	        helper.setFrom(sender);
	        helper.setTo(emails.toArray(new String[0]));
	        helper.setSubject("This Week's Newsletter");

	        String htmlContent = "<h1>Welcome to This Week's Newsletter</h1>"
	                + "<p>Check out our latest updates:</p>"
	                + "<img src='cid:newsletterImage' width='500px'/>";

	        helper.setText(htmlContent, true);
	        System.out.println("Email body set successfully.");

	        imageFile = s3Service.downloadImageFromS3(imageUrl);
	        if (imageFile != null && imageFile.exists()) {
	            System.out.println("Image downloaded successfully: " + imageFile.getAbsolutePath());

	            FileSystemResource imageResource = new FileSystemResource(imageFile);
	            helper.addInline("newsletterImage", imageResource);
	            System.out.println("Image attached to email.");
	        } else {
	            System.out.println("Failed to download image from S3.");
	        }

	        javaMailSender.send(message);
	        System.out.println("Newsletter sent successfully!");

	    } catch (Exception e) {
	        System.out.println("Error sending newsletter: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        if (imageFile != null && imageFile.exists()) {
	            scheduleFileDeletion(imageFile);
	        }
	    }
	}

	private void scheduleFileDeletion(File file) {
	    Executors.newSingleThreadScheduledExecutor().schedule(() -> {
	        if (file.delete()) {
	            System.out.println("Temporary file deleted: " + file.getAbsolutePath());
	        } else {
	            System.out.println("Failed to delete temporary file: " + file.getAbsolutePath());
	        }
	    }, 10, TimeUnit.SECONDS);
	}







}