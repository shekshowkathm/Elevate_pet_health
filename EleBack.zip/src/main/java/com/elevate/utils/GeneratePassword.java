package com.elevate.utils;

import java.security.SecureRandom;
import java.util.Random;

public class GeneratePassword {
	
	public static  String generateRandomPassword(int length) {
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%&*";
		SecureRandom random = new SecureRandom();
		StringBuilder password = new StringBuilder(length);

		for (int i = 0; i < length; i++) {
			password.append(characters.charAt(random.nextInt(characters.length())));
		}
		return password.toString();
	}
	
	public String createOtp() {
		Random randomotp = new Random();
		int otp = 100000 + randomotp.nextInt(900000);
		return Integer.toString(otp);
	}
}
