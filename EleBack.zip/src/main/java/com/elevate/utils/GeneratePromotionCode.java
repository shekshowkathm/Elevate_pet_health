package com.elevate.utils;

import java.security.SecureRandom;

public class GeneratePromotionCode {
	
	public static  String generatePromotionCode(int length) {
		    String prefix = "Elevate";
	        SecureRandom random = new SecureRandom();
	        StringBuilder promotionCode = new StringBuilder(prefix);
	        for (int i = 0; i < 3; i++) {
	            promotionCode.append(random.nextInt(10));
	        }
	        return promotionCode.toString();
	}
	

}
