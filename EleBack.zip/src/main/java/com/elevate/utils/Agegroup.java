package com.elevate.utils;

import com.elevate.entity.PetBreedAge;

public class Agegroup {
	
	public static int[] parseAgeRange(String ageRange) {
        if (ageRange == null || ageRange.trim().isEmpty()) {
            return new int[] { 0, Integer.MAX_VALUE };
        }

        String[] parts = ageRange.split(" ");
        if (parts.length != 3) {
            return new int[] { 0, Integer.MAX_VALUE }; 
        }

        try {
            int lowerBound = Integer.parseInt(parts[0]);
            int upperBound = Integer.parseInt(parts[2]);
            return new int[] { lowerBound, upperBound };
        } catch (NumberFormatException e) {
            return new int[] { 0, Integer.MAX_VALUE }; 
        }
    }

	public static String determineAgeCategory(int totalMonths, PetBreedAge petBreedAge) {
		int[] puppyRange = parseAgeRange(petBreedAge.getAgeForPuppy());
		int[] kittenRange = parseAgeRange(petBreedAge.getAgeForKitten());
		int[] adultRange = parseAgeRange(petBreedAge.getAgeForAdult());
		int[] seniorRange = parseAgeRange(petBreedAge.getAgeForSenior());

		if (petBreedAge.getPetType().equalsIgnoreCase("Dog")) {
	        if (totalMonths >= puppyRange[0] && totalMonths <= puppyRange[1]) {
	            return "Puppy";
	        }
	    } else if (petBreedAge.getPetType().equalsIgnoreCase("Cat")) {
	        if (totalMonths >= kittenRange[0] && totalMonths <= kittenRange[1]) {
	            return "Kitten";
	        }
	    }
		if (totalMonths >= adultRange[0] && totalMonths <= adultRange[1]) {
	        return "Adult";
	    }
		if (totalMonths >= seniorRange[0]) {
	        return "Senior";
	    }
		return "Unknown Age Category";
	}
}
