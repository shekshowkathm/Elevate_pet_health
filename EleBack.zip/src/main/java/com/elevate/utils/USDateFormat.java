package com.elevate.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class USDateFormat {

	public static String dateFormat() {
		DateTimeFormatter usFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		String formattedDate = LocalDate.now().format(usFormatter);
		return formattedDate;
	}
}
