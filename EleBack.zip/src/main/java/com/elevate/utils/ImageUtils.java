package com.elevate.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Base64;

public class ImageUtils {
	public static String encodeImageToBase64(String imagePath) throws IOException {
		File file = new File(imagePath);
		FileInputStream imageInFile = new FileInputStream(file);
		byte[] imageBytes = new byte[(int) file.length()];
		imageInFile.read(imageBytes);
		imageInFile.close();
		return Base64.getEncoder().encodeToString(imageBytes);
	}
}
