package com.elevate.utils;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeParseException;

public class CalculateAge {

	public static String petAge(String dob) {		
	 if (dob == null || dob.isEmpty()) {
            return "DOB not provided";
        }
        try {
            LocalDate birthDate = LocalDate.parse(dob);
            Period age = Period.between(birthDate, LocalDate.now());
            return age.getYears() + " year(s) " + age.getMonths() + " month(s)";
        } catch (DateTimeParseException e) {
            return "Invalid DOB format";
        }
	}

	public static int petAgeByMonth(String dob) {
		if (dob == null || dob.isEmpty()) {
            return 0; 
        }
        try {
            LocalDate birthDate = LocalDate.parse(dob);
            Period age = Period.between(birthDate, LocalDate.now());
            return age.getYears() * 12 + age.getMonths();
        } catch (DateTimeParseException e) {
            return 0;
        }
	}
}
