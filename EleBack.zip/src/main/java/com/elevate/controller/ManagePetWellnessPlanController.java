package com.elevate.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.dto.AddNewSetPlansDRTO;
import com.elevate.dto.GetUpdateWellnessPlansDTO;
import com.elevate.dto.UpdateNewSetPlansDTO;
import com.elevate.service.ManagePetWellnessPlanService;

@RestController
@RequestMapping("/updatePlans")
@CrossOrigin
public class ManagePetWellnessPlanController {
	
	@Autowired
	private ManagePetWellnessPlanService managePetWellnessPlanService;
		 
	 @GetMapping("/available/{clinicId}/{wellnessPlanName}/{managePetWellnessPlanId}")
	 @PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	 public Map<String , Object> getAvailableClinicWellnessPlans(@PathVariable Long clinicId, @PathVariable String wellnessPlanName, @PathVariable Long managePetWellnessPlanId) {
	     return managePetWellnessPlanService.getPlansToUpdate(clinicId, wellnessPlanName, managePetWellnessPlanId);
	 }
	 
	 @GetMapping("getPlans/{clinicId}/{wellnessPlanName}")
	 @PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	 public List<GetUpdateWellnessPlansDTO> getPlansToAdd(@PathVariable Long clinicId , @PathVariable String wellnessPlanName){
		return managePetWellnessPlanService.getPlansToAddNewSet(clinicId, wellnessPlanName); 
	 }
	 
	 @PostMapping("/updateExistingPlans")
	 @PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	 public String updateExistingPlans(@RequestBody List<UpdateNewSetPlansDTO> plans){
		 return managePetWellnessPlanService.updateWellnessPlan(plans);
	 }
	 
	 @PostMapping("/addNewPlans")
	 @PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	 public String addNewPlans(@RequestBody List<AddNewSetPlansDRTO> newPlans){
		 return managePetWellnessPlanService.addNewPlansSet(newPlans);
	 }
}
