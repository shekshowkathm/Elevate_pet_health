package com.elevate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.dto.ClinicDetailsDTO;
import com.elevate.dto.StripeDetails;
import com.elevate.entity.Register;
import com.elevate.service.StripeService;

@RestController
@RequestMapping("/stripe")
@CrossOrigin("*")
public class StripeController {
    @Autowired
    StripeService stripeService;

    @PutMapping("/UpdateStripeStatus/{regId}")
    @PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'SUPER_ADMIN')")
    public String UpdateStripeStatus(@PathVariable Long regId, @RequestBody Register register) throws Exception {
        return stripeService.UpdateStripeStatus(regId, register);
    }

    @GetMapping("/stripe-account-status/{accountId}")
    public ResponseEntity<String> stripeAccountStatus(@PathVariable String accountId) {
        return stripeService.getStripeStatus(accountId);
    }

    @PutMapping("/createProduct")
    public ResponseEntity<?> createProduct(@RequestBody List<StripeDetails> stripeDetails) {
        return stripeService.createProductStripe(stripeDetails);
    }

    @PutMapping("/update-stripe-price")
    public ResponseEntity<String> updateStripePrice(@RequestBody List<StripeDetails> stripeDetails) {
        return stripeService.updateStripePrice(stripeDetails);
    }

    @GetMapping("/get-all-stripe-product")
    public ResponseEntity<String> getAllStripeProducts() {
        return stripeService.getAllStripeProducts();
    }

    @GetMapping("/getCardDetails/{customerId}")
    public ResponseEntity<?> checkCardDetails(@PathVariable String customerId) {
        return stripeService.checkCardDetails(customerId);
    }

    @PostMapping("/createSubscription")
    public ResponseEntity<?> createSubscription(@RequestBody StripeDetails stripeDetails) throws Exception {
        return stripeService.handleSubscription(stripeDetails);
    }

    @GetMapping("/cancelSubscription/{subscriptionId}")
    public ResponseEntity<String> cancelSubscription(@PathVariable String subscriptionId) {
        return stripeService.cancelSubscription(subscriptionId);
    }

    @PostMapping("/attach-card")
    public ResponseEntity<?> attachCardDetails(@RequestBody StripeDetails stripeDetails) throws Exception {
        return stripeService.attachCardDetails(stripeDetails);
    }

    @PutMapping("/updateSubscription")
    public ResponseEntity<String> updateSubscription(@RequestBody StripeDetails stripeDetails) {
        return stripeService.updateSubscription(stripeDetails);
    }

    @PostMapping("/generateCoupon")
    public ResponseEntity<String> generateCoupon(@RequestBody StripeDetails stripeDetails) {
        return stripeService.generateCouponCode(stripeDetails);
    }

    @PutMapping("/deleteCoupon/{couponId}")
    public ResponseEntity<String> deleteCoupon(@PathVariable String couponId){
        return stripeService.deleteCoupon(couponId);
    }

    @GetMapping("/getExpiringCard")
    public ResponseEntity<?> getExpiringCardDetails() {
        return stripeService.getExpiryCardDetails();
    }

    @GetMapping("/upcomingPayments")
    public ResponseEntity<?> getUpcomingPayments(){
        return stripeService.getUpcomingPayments();
    }

    @GetMapping("/upcomingSchedPayments")
    public ResponseEntity<?> getSchedUpcomingPayments(){
        return stripeService.getSchedUpcomingPayments();
    }

    @GetMapping("/getcard/{customerId}")
    public ResponseEntity<?> getCardDetailsByCustomer(@PathVariable String customerId) {
        return stripeService.getCardDetailsByCustomer(customerId);
    }

    @PutMapping("/removeCard/{customerId}")
    public ResponseEntity<?> removeCardDetailsCustomer(@PathVariable String customerId,
            @RequestBody StripeDetails stripeDetails) {
        return stripeService.removeCardDetailsCustomer(customerId, stripeDetails);
    }

    @GetMapping("/getSubscriptionId/{subscriptionId}")
    public ResponseEntity<?> getsubscriptionDetails(@PathVariable String subscriptionId) {
        return stripeService.getsubscriptionDetails(subscriptionId);
    }

    @GetMapping("/getSchSubscriptionId/{subscriptionId}")
    public ResponseEntity<?> getSchsubscriptionIdDetails(@PathVariable String subscriptionId) {
        return stripeService.getSchsubscriptionIdDetails(subscriptionId);
    }

    @PutMapping("/validateCoupon/{clinicId}/{promotionType}")
    public ResponseEntity<String> validateCoupon(@PathVariable Long clinicId,@PathVariable String promotionType){
        return stripeService.validateCoupon(clinicId,promotionType);
    }

    @GetMapping("/last-six-months")
    public  ResponseEntity<?> getLastSixMonthsDetails(){
        return stripeService.getLastSixMonthsDetails();
    }

    @GetMapping("/balance")
    public  ResponseEntity<?> getBalance(){
        return stripeService.getBalance();
    }

    @GetMapping("/getPetDetails/{petDetailId}")
    public ResponseEntity<?> getPetDetails(@PathVariable long petDetailId){
        return stripeService.getPetDetails(petDetailId);
    }

    @GetMapping("getExpiryDetailsByClinic/{accountId}")
    public ResponseEntity<?> getExpiryCardDetailsByClinic(@PathVariable String accountId){
        return stripeService.getExpiryCardDetailsByClinic(accountId);
    }

    @GetMapping("getSalesExpDetails/{salesRepId}")
        public ResponseEntity<?> getSalesExpDetails(@PathVariable Long salesRepId){
            return stripeService.getSalesExpDetails(salesRepId);
    }

    @GetMapping("getExpiryDetailscustomer/{customerId}")
    public ResponseEntity<?> getExpiryDetailscustomer(@PathVariable String customerId){
        return stripeService.getExpiryDetailscustomer(customerId);
    }

    @PostMapping("/refreshAccountLink")
    public  ResponseEntity<String> refreshAccountLink(@RequestBody String accountId){
        if (accountId == null || accountId.trim().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error: Account ID cannot be null or empty.");
        }
        return stripeService.refreshAccountLink(accountId);
    }

    @PostMapping("/reSendAccountLink")
    public  ResponseEntity<String> reSendAccountLink(@RequestBody ClinicDetailsDTO clinicDetails){
        return stripeService.reSendAccountLink(clinicDetails);
    }

    @GetMapping("/getPaidMonthsForSubscription/{subscriptionId}")
    public  ResponseEntity<?> getPaidMonthsForSubscription(@PathVariable String subscriptionId){
        return stripeService.getPaidMonthsForSubscription(subscriptionId);
    }


    @PostMapping("/reActiveSubscription")
    public ResponseEntity<String> retryPayment(@RequestBody StripeDetails stripeDetails){
        return stripeService.retryPayment(stripeDetails);
    }

    @GetMapping("/checkCardExpiration/{customerId}")
    public  ResponseEntity<?> checkCardExpiration(@PathVariable String customerId){
        return  stripeService.checkCardExpiration(customerId);
    }

}
