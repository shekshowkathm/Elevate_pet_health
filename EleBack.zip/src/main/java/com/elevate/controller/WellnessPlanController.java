package com.elevate.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.elevate.dto.WellnessPlanDTO;
import com.elevate.dto.WellnessPlanResponseDTO;
import com.elevate.entity.ServiceList;
import com.elevate.service.WellnessPlanService;


@RestController
@RequestMapping("/wellnessPlan")
@CrossOrigin
public class WellnessPlanController {
	
	@Autowired
	private WellnessPlanService wellnessPlanService;
	
	@PostMapping("/add")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String add(@RequestBody WellnessPlanDTO wellnessPlan) {
		return wellnessPlanService.add(wellnessPlan);
	}
	
	@GetMapping("getAll")
	@PreAuthorize("hasAnyAuthority('SUPER_ADMIN' , 'CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE' , 'SALES_REP')")
	public List<WellnessPlanResponseDTO> getAll(){
		return wellnessPlanService.getAllWellnessPlans();
	}
	
	@PutMapping("/updateWellnessPlan")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
    public ResponseEntity<String> updateWellnessPlan(@RequestBody WellnessPlanResponseDTO responseDTO) {
        try {
            String response = wellnessPlanService.updateWellnessPlan(responseDTO);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
	
	@DeleteMapping("/delete/{id}")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String delete(@PathVariable Long id) {
		return wellnessPlanService.deleteWellnessPlan(id);
	}
	
	@GetMapping("/availableServices/{wellnessPlanName}")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public List<ServiceList> getAvailableServices(@PathVariable String wellnessPlanName){
		return wellnessPlanService.getAvailableServices(wellnessPlanName);
	}

}
