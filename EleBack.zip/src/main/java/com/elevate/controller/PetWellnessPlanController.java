package com.elevate.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.elevate.dto.AppoinmentDTO;
import com.elevate.dto.CalenderDTO;
import com.elevate.dto.GetChooseWellnessPlansDTO;
import com.elevate.service.PetWellnessPlanService;

@RestController
@RequestMapping("/petWellnessPlan")
@CrossOrigin("*")
public class PetWellnessPlanController {

	@Autowired
	private PetWellnessPlanService petWellnessPlanService;

	@PutMapping("/updateScheduledAppointment/{petWellnessPlanId}/{scheduledDateAndTime}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	public String updateScheduledDate(@PathVariable Long petWellnessPlanId, @PathVariable String scheduledDateAndTime) {
		return petWellnessPlanService.updateWellnessPlanScheduledDate(petWellnessPlanId, scheduledDateAndTime);
	}

	@GetMapping("/getPlanToChoose/{petId}/{role}")
	@PreAuthorize("hasAnyAuthority('PET_OWNER' , 'CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	public List<GetChooseWellnessPlansDTO> getChoosePlans(@PathVariable Long petId , @PathVariable String role) {
		return petWellnessPlanService.getSentPlans(petId , role);
	}
	
	@GetMapping("/getUpdatedPlans/{petId}/{role}")
	@PreAuthorize("hasAnyAuthority('PET_OWNER' , 'CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	public List<GetChooseWellnessPlansDTO> getUpdatedSentPlans(@PathVariable Long petId ,@PathVariable String role) {
		return petWellnessPlanService.getUpdatedSentPlans(petId , role);
	}
	
	@GetMapping("/getNewSetPlans/{petId}/{role}")
	@PreAuthorize("hasAnyAuthority('PET_OWNER' , 'CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	public List<GetChooseWellnessPlansDTO> getNewSetPlans(@PathVariable Long petId ,@PathVariable String role) {
		return petWellnessPlanService.getNewSetPlans(petId , role);
	}
	
	@PutMapping("/updateStatus/{petWellnessPlanId}/{status}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public String updatePlanStatus(@PathVariable Long petWellnessPlanId, @PathVariable String status) {
		return petWellnessPlanService.singlePlanStatus(petWellnessPlanId, status);
	}
	
	@PutMapping("/acceptPlan/{status}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public ResponseEntity<String> acceptPlanStatus(@RequestBody List<Long> petWellnessPlanIds, @PathVariable String status) {
		return petWellnessPlanService.acceptPlans(petWellnessPlanIds, status);
	}

	@GetMapping("/appoinments/{clinicId}/{timezone}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	public List<AppoinmentDTO> getAppoinments(@PathVariable Long clinicId, @PathVariable String timezone) {
		return petWellnessPlanService.getAppoinments(clinicId, timezone);
	}

	@GetMapping("/calender/{clinicId}/{timezone}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	public List<CalenderDTO> getCalendar(@PathVariable Long clinicId, @PathVariable String timezone) {
		return petWellnessPlanService.getCalendar(clinicId, timezone);
	}

	@GetMapping("/pet-Owner_calender/{petOwnerId}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public List<CalenderDTO> getPetOwnerCalender(@PathVariable Long petOwnerId) {
		return petWellnessPlanService.getPetOwnerCalender(petOwnerId);
	}

	@GetMapping("/appoinment-status/{clinicId}/{timezone}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	public List<AppoinmentDTO> getAppoinmentsStatus(@PathVariable Long clinicId, @PathVariable String timezone) {
		return petWellnessPlanService.getAppointmentsStatus(clinicId, timezone);
	}
	
	@PutMapping("/acceptPlanTermsAndConditions/{managePetWellnessPlanId}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public String acceptPlanTermsAndConditions(@PathVariable Long managePetWellnessPlanId) {
		return petWellnessPlanService.acceptPlanTermsAndConditions(managePetWellnessPlanId);
	}
}
