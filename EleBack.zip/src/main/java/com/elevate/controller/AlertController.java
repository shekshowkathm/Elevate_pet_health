package com.elevate.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.dto.PlanConfirmNotificationDTO;
import com.elevate.service.AlertService;

@RestController
@RequestMapping("/alert")
@CrossOrigin
public class AlertController {
	
	@Autowired
	private AlertService alertService;
	
	@GetMapping("/plans-to-confirm/{clinicId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	public List<PlanConfirmNotificationDTO> getAlertsForPlanActivation(@PathVariable Long clinicId){
		return alertService.getPlansForConfirmation(clinicId);
	}
	
	@GetMapping("/pet-plans-choosen/{petOwnerId}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public List<PlanConfirmNotificationDTO> getAlertsForPetPlans(@PathVariable Long petOwnerId){
		return alertService.getPlansForPetOwnerNotification(petOwnerId);
	}
	
	@GetMapping("/expiry-plans/{clinicId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	public List<PlanConfirmNotificationDTO> getExpiryAlertsForClinic(@PathVariable Long clinicId){
		return alertService.getPlanExpiryAlertsForClinic(clinicId);
	}
	
	@GetMapping("/expiry-plans-for-pets/{petOwnerId}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public List<PlanConfirmNotificationDTO> getExpiryAlertsForPetOwners(@PathVariable Long petOwnerId){
		return alertService.getPlanExpiryAlertsForPetOwner(petOwnerId);
	}

	@GetMapping("/appointments/{clinicId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
    public List<PlanConfirmNotificationDTO> getAppointmentsAlertsForClinic(@PathVariable Long clinicId) {
	    return alertService.getScheduledAppointmentsAlertsForClinic(clinicId);
	}
	
	@GetMapping("/pets-appointments/{petOwnerId}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
    public List<PlanConfirmNotificationDTO> getAppointmentsAlertsForPetOwners(@PathVariable Long petOwnerId) {
	    return alertService.getScheduledAppointmentsAlertsForPetOwner(petOwnerId);
	}
	
	@GetMapping("/notificationsCount/{petOwnerId}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public ResponseEntity<Map<String, Long>> getNotificationCounts(@PathVariable Long petOwnerId) {
	    Map<String, Long> notificationCounts = alertService.getNotificationCounts(petOwnerId);
	    return ResponseEntity.ok(notificationCounts);
	}
}