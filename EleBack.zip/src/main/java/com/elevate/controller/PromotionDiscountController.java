package com.elevate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.dto.GenerateCodeRequestDTO;
import com.elevate.dto.PromotionClinics;
import com.elevate.dto.PromotionDiscountDTO;
import com.elevate.entity.PromotionDiscount;
import com.elevate.service.PromotionDiscountService;

@RestController
@RequestMapping("/promotion")
@CrossOrigin("*")
public class PromotionDiscountController {

	@Autowired
	private PromotionDiscountService promotionDiscountService;

	@PostMapping("/add-promotion")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String addPromotions(@RequestBody PromotionDiscount promotionDiscount) {
		return promotionDiscountService.addPromotion(promotionDiscount);
	}

	@GetMapping("/getPromotions/{clinicId}")
	@PreAuthorize("hasAnyAuthority('SUPER_ADMIN','SALES_REP')")
	public List<PromotionDiscountDTO> getPromotions(@PathVariable Long clinicId) {
		return promotionDiscountService.getAllPromotion(clinicId);
	}

	@PostMapping("/generateCode")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String generateCode(@RequestBody GenerateCodeRequestDTO code) {
		return promotionDiscountService.generateCode(code);
	}

	@PutMapping("/updatePromotion")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String updatePromtion(@RequestBody PromotionDiscount promotionDiscount) {
		return promotionDiscountService.updatePromotionDiscount(promotionDiscount);
	}

	@GetMapping("/count/{clinicId}/{monthYear}")
	public String getWellnessPlanCount(@PathVariable("clinicId") Long clinicId,
			@PathVariable("monthYear") String monthYear) {
		return promotionDiscountService.countUniqueWellnessPlansByClinicAndMonth(clinicId, monthYear);
	}

	@GetMapping("/get-clinic-promotion")
	@PreAuthorize("hasAnyAuthority('SUPER_ADMIN','SALES_REP')")
	public List<PromotionClinics> getClinicDetailsInPromotions(@RequestParam String role, @RequestParam(required = false) Long salesRepId) {
		return promotionDiscountService.getClinicDetailsInPromotions(role,salesRepId);
	}
}
