package com.elevate.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.config.StripeConnect;
import com.elevate.service.TransactionDetailsService;
import com.stripe.exception.StripeException;


@RestController
@RequestMapping("/transaction")
@CrossOrigin("*")
public class TransactionDetailsController {

    @Autowired
    TransactionDetailsService transactionDetailsService;

    @Autowired
    StripeConnect stripeConnect;


    @GetMapping("/getTransaction/{customerId}")
    public ResponseEntity<?> getTransactionDetails(@PathVariable String customerId){
        return transactionDetailsService.getTransactionDetails(customerId);
    }

    @PutMapping("/loginLink/{connectedAccountId}")
    public ResponseEntity<String> createLoginLink(@PathVariable String connectedAccountId) throws StripeException {
        return stripeConnect.createLoginLink(connectedAccountId);
    }

    @GetMapping("/getByStatus")
    public ResponseEntity<?> getTransactionDetailsByStatus(){
        return transactionDetailsService.getTransactionDetailsByStatus();
    }

    @GetMapping("/todayEarningByClinic/{accountId}")
    public ResponseEntity<?> getTotalByConnectedAcc(@PathVariable String accountId){
        return transactionDetailsService.getTotalByConnectedAcc(accountId);
    }

    @GetMapping("/todayEarningByAdmin")
    public ResponseEntity<?> getTotalByPlatform(){
        return transactionDetailsService.getTotalByPlatform();
    }

    @PutMapping("/getByAccountId/{accountId}")
    public ResponseEntity<?> getTransactionDetailsByAccId(@PathVariable String accountId,  @RequestBody Map<String, String> requestBody){
        try {
            if (requestBody == null || !requestBody.containsKey("paymentStatus")) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Payment status is required in the request body.");
            }

            String paymentStatus = requestBody.get("paymentStatus");
            return transactionDetailsService.getTransactionDetailsByAccId(accountId, paymentStatus);
        } catch (Exception e) {
            System.err.println("Failed to fetch transaction details: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage());
        }
    }



    @GetMapping("/getAll")
    public ResponseEntity<?> getAllTransactions() {
        try {
            return transactionDetailsService.getAllTransactions();
        } catch (Exception e) {
            System.err.println("Error fetching all transactions: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while retrieving transactions.");
        }
    }
    @GetMapping("/getcutomerDetails/{customerId}")
    public ResponseEntity<?>getCustomerDetails(@PathVariable String customerId){
    return  transactionDetailsService.getCustomerDetails(customerId);
    }

    @GetMapping("/getclinicPaymentsDetails/{salesRepId}")
    public ResponseEntity<?>getclinicPaymentsDetails(@PathVariable Long salesRepId){
        return  transactionDetailsService.getclinicPaymentsDetails(salesRepId);
    }

    @GetMapping("/getPaymentStatus/{id}")
    public ResponseEntity<?>getPaymentStatus(@PathVariable Long id){
        return  transactionDetailsService.getPaymentStatus(id);
    }


}
