package com.elevate.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.dto.SupportDTO;
import com.elevate.dto.SupportResponseDTO;
import com.elevate.entity.Support;
import com.elevate.service.SupportService;

@RestController
@RequestMapping("/support")
@CrossOrigin("*")
public class SupportController {

	@Autowired
	private SupportService supportService;

	@PostMapping("/add")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public String addSupport(@RequestBody Support support) {
		return supportService.addSupport(support);
	}

	@GetMapping("/get/{email}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	public List<SupportDTO> getDetails(@PathVariable String email) {
		return supportService.getDetails(email);
	}

	@GetMapping("/get-Clinic/{petOwnerId}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public Set<String> getClinicEmails(@PathVariable Long petOwnerId) {
		return supportService.getCliniEmails(petOwnerId);
	}
	
	@PostMapping("/sendSupportReply")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE')")
	public void sendReplyMail(@RequestBody SupportResponseDTO supportResponse){
		supportService.replyMessage(supportResponse);
	}
}
