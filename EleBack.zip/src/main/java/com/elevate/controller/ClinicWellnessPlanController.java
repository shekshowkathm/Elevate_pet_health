package com.elevate.controller;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.util.List;

import com.elevate.dto.*;
import com.elevate.entity.UploadDocument;
import com.elevate.repository.IDocumentRepository;

import com.elevate.entity.ClinicWellnessUpdate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.elevate.service.ClinicWellnessPlanService;
import com.elevate.utils.S3Service;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;


import io.jsonwebtoken.io.IOException;

@RestController
@RequestMapping("/clinic-wellness-plan")
@CrossOrigin("*")
public class ClinicWellnessPlanController {

	@Autowired
	private ClinicWellnessPlanService clinicWellnessPlanService;
	
	@Autowired
	private S3Service s3Service;
	
	@Autowired
	private IDocumentRepository documentRepository;

	@GetMapping("/get/{id}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'CLINIC_ADMIN', 'CLINIC_ASSOCIATE')")
	public List<ClinicWellnessPlanDTO> getClinicWellnessPlan(@PathVariable Long id) {
		return clinicWellnessPlanService.getClinicWellnessPlans(id);
	}
	
	@PutMapping("/update-clinic-wellness")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'CLINIC_ADMIN')")
	public ClinicWellnessUpdate updateClinicWellnessPlan(@RequestBody ClinicWellnessPlanUpdateDTO clinicWellnessPlanUpdate) {
		return clinicWellnessPlanService.updateClinicWellnessPlan(clinicWellnessPlanUpdate);
	}
	
	@GetMapping("/get-pet-wellness-plan/{clinicId}/{wellness}/{petSize}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'CLINIC_ADMIN', 'CLINIC_ASSOCIATE')")
	public List<ClinicWellnessPlanDTO> getPetWellnessPlan(@PathVariable Long clinicId,@PathVariable String wellness, @PathVariable String petSize){
		return clinicWellnessPlanService.getWellnessPlan(clinicId,wellness,petSize);
	}

	@GetMapping("/get-pet-wellness-plan/{clinicId}/{wellness}/{petSize}/{petId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'CLINIC_ADMIN', 'CLINIC_ASSOCIATE')")
	public ClinicWellnessPlansWithPromotionStatusDTO getPetWellnessPlanWithPromotionStatusForPet(@PathVariable Long clinicId, @PathVariable String wellness, @PathVariable String petSize, @PathVariable Long petId){
		return clinicWellnessPlanService.getPetWellnessPlanWithPromotionStatusForPet(clinicId,wellness,petSize,petId);
	}

	
	@PostMapping("/sendPlans")
	@PreAuthorize("hasAnyAuthority('CLINIC_ASSOCIATE' , 'CLINIC_OWNER' , 'CLINIC_ADMIN')")
	public String add(@RequestBody ChoosePlanWithPromotionsDTO choosePlanWithPromotionsDTO) {
		return clinicWellnessPlanService.sendPlansToPetOwner(choosePlanWithPromotionsDTO);
	}
	
	@PostMapping("/sendUpdatedPlans/{action}")
	@PreAuthorize("hasAnyAuthority('CLINIC_ASSOCIATE' , 'CLINIC_OWNER' , 'CLINIC_ADMIN')")
	public String addUpdatedPlans(@RequestBody ChoosePlanWithPromotionsDTO choosePlanWithPromotionsDTO ,@PathVariable String action) {
		return clinicWellnessPlanService.sendUpdatedPlansToPetOwner(choosePlanWithPromotionsDTO , action);
	}
	
	@PutMapping("/updateConfirmPlans")
	@PreAuthorize("hasAnyAuthority('CLINIC_ASSOCIATE' , 'CLINIC_OWNER' , 'CLINIC_ADMIN')")
	public String updateConfirmChoosenPlans(@RequestBody ConfirmPlanRequestDTO request) {
		return clinicWellnessPlanService.confirmChoosenPlans(request);
	}
	
	@PutMapping("/updateFulfilledStatus/{petWellnessPlanId}/{regId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_ASSOCIATE' , 'CLINIC_OWNER' , 'CLINIC_ADMIN')")
	public String updateFulfilledStatus(@PathVariable Long petWellnessPlanId ,@PathVariable Long regId) {
		return clinicWellnessPlanService.updateFullfilledStatus(petWellnessPlanId, regId);
	}
	
	@PostMapping("/generateInvoice")
	@PreAuthorize("hasAnyAuthority('CLINIC_ASSOCIATE' , 'CLINIC_OWNER' , 'CLINIC_ADMIN')")
	public ResponseEntity<String> generateInvoiceAndUpload() {
	        try {
	            byte[] pdfBytes = generateSampleInvoicePDF(); 
	            String filename = "invoice-" + System.currentTimeMillis() + ".pdf";
	            String s3Url = s3Service.uploadPDFToS3(pdfBytes, filename);

	            // Save the S3 URL to the document entity
	            UploadDocument document = new UploadDocument();
	            document.setDocumentUrl(s3Url);
	            document.setUploadedByRole("ADMIN");
	            document.setUploadedById(1L);
	            document.setTargetType("INVOICE");
	            document.setUploadDate(LocalDate.now().toString());
	            document.setDescription("Generated invoice for pet wellness plan");
	            documentRepository.save(document);

	            return ResponseEntity.ok("Invoice generated and uploaded to S3. URL: " + s3Url);
	        } catch (IOException e) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to generate or upload invoice: " + e.getMessage());
	        }
	  }

	    /**
	     * A method to generate a sample PDF for testing.
	     * You can replace this with your actual invoice generation logic.
	     */
	   public byte[] generateSampleInvoicePDF() throws IOException {
	        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

	        Document document = new Document();
	        
	        try {
	            PdfWriter.getInstance(document, byteArrayOutputStream);
	            document.open();
	            document.add(new Paragraph("Invoice for Pet Wellness Plan"));
	            document.add(new Paragraph("Date: " + LocalDate.now()));
	            document.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	            throw new IOException("Error generating PDF", e);
	        }

	        return byteArrayOutputStream.toByteArray();
	    }
}
