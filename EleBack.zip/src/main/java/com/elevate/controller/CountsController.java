package com.elevate.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.dto.CountsDTO;
import com.elevate.service.CountsService;

@RequestMapping("/counts")
@RestController
@CrossOrigin("*")
public class CountsController {
	
	@Autowired
	private CountsService countsService;
	
	@GetMapping("/clinic/{clinicId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATES')")
	public CountsDTO getCountsForClinic(@PathVariable Long clinicId) {
		return countsService.getCountsForClinic(clinicId);
	}
	
	@GetMapping("/superAdmin")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public CountsDTO getCountsForSuperAdmin() {
		return countsService.getCountsForSuperAdmin();
	}
	
	@GetMapping("/salesRep/{regId}")
	@PreAuthorize("hasAuthority('SALES_REP')")
	public CountsDTO getCountsForSalesRep(@PathVariable Long regId) {
		return countsService.getCountsForSalesRep(regId);
	}
}
