package com.elevate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.dto.ServiceListDTO;
import com.elevate.dto.UpdateServiceStatus;
import com.elevate.entity.ServiceList;
import com.elevate.service.ServiceListService;

@RestController
@RequestMapping("/service")
@CrossOrigin
public class ServiceController {
	
	@Autowired
	private ServiceListService serviceListService;
	
	@PostMapping("/add")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String addd(@RequestBody ServiceListDTO dto) {
		return serviceListService.add(dto);
	}
	
	@GetMapping("/getAllServices")
	@PreAuthorize("hasAnyAuthority('SUPER_ADMIN' , 'CLINIC_ADMIN' , 'CLINIC_OWNER' , 'CLINIC_ASSOCIATE' , 'SALES_REP')")
	public List<ServiceList> getAllService(){
		return serviceListService.getAllServiceList();
	}
	
	@PutMapping("/update")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String update(@RequestBody ServiceList update) {
		return serviceListService.update(update);
	}

	@PutMapping("/deactivateStatus")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String deactivateService(@RequestBody UpdateServiceStatus update) {
		return serviceListService.updateStatus(update);
	}
	
	@DeleteMapping("/deleteService/{id}")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public ResponseEntity<String> deleteServiceList(@PathVariable Long id) {
		return serviceListService.deleteServiceList(id);
	}
}
