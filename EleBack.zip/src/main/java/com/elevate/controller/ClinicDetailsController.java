package com.elevate.controller;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.elevate.dto.*;
import com.elevate.entity.ClinicDetails;
import com.elevate.repository.IClinicDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.elevate.service.ClinicDetailsService;
import com.elevate.utils.GenerateQRCode;
import com.elevate.utils.S3Service;

@RestController
@RequestMapping("/clinic-details")
@CrossOrigin("*")
public class ClinicDetailsController {

	@Autowired
	private ClinicDetailsService clinicDetailsService;

	@Autowired
	private S3Service s3Service;

	@Value("${aws.bucketName}")
	private String bucketName;

	@Autowired
	private IClinicDetailsRepository clinicDetailsRepository;

	@PostMapping("/clinicRegisterRequest")
	public ResponseEntity<String> clinicRegister(@RequestBody ClinicRegister clinicRegister) {
		return clinicDetailsService.clinicRegister(clinicRegister);
	}

	@PostMapping("/add-clinic")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'CLINIC_ADMIN')")
	public ResponseEntity<String> addClinic(@RequestBody ClinicDetailsDTO clinicDetailsDTO) {
		return clinicDetailsService.addClinic(clinicDetailsDTO);
	}

	@PutMapping("/updateClinicStatus/{id}/{regId}")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String updateClinicStatus(@PathVariable Long id, @PathVariable Long regId) {
		return clinicDetailsService.updateStatus(id, regId);
	}

	// Get List of clinic Based on role
	@GetMapping("/clinicDetails/{regId}/{role}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN','CLINIC_ASSOCIATE','SUPER_ADMIN')")
	public List<ClinicDetailsDTO> getClinicDetailsByRole(@PathVariable Long regId, @PathVariable String role) {
		return clinicDetailsService.getClinicdetailsByRole(regId, role);
	}

	@GetMapping("/get-Clinic/{clinicId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER','CLINIC_ADMIN','CLINIC_ASSOCIATE','PET_OWNER','SUPER_ADMIN','SALES_REP')")
	public ClinicDetailsDTO getClinicDetails(@PathVariable Long clinicId) {
		return clinicDetailsService.getClinicDetails(clinicId);
	}

	@PutMapping("/add-clinic-members/{clinicId}/{regId}/{role}")
	@PreAuthorize("hasAuthority('CLINIC_OWNER')")
	public String updateClinicMembers(@PathVariable Long clinicId, @PathVariable Long regId,
			@PathVariable String role) {
		return clinicDetailsService.updateClinicMembers(clinicId, regId, role);
	}

	@PutMapping("/update")
	public ResponseEntity<String> updateClinicDetails(@RequestBody ClinicDetailsDTO clinicDetailsDto) {
		return clinicDetailsService.updateClinicDetails(clinicDetailsDto);
	}

	// Active Clinic List
	@GetMapping("/active")
	public ResponseEntity<?> getAllActiveClinics() {
		List<ClinicDetailsDTO> activeClinics = clinicDetailsService.findAllByClinicStatusTrue();
		if (activeClinics.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No active clinics available.");
		} else {
			return ResponseEntity.ok(activeClinics);
		}
	}

	@GetMapping("/get-Clinic-associates/{clinicId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER','CLINIC_ADMIN')")
	public List<ClinicAssociatesDTO> getAssociates(@PathVariable Long clinicId) {
		return clinicDetailsService.getAssociates(clinicId);
	}

	@GetMapping("/get-Clinic-admin/{clinicId}")
	@PreAuthorize("hasAuthority('CLINIC_OWNER')")
	public ClinicAdminDTO getClinicAdmins(@PathVariable Long clinicId) {
		return clinicDetailsService.getClinicAdmins(clinicId);
	}

	@GetMapping("/get-pet-details/{clinicId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER','CLINIC_ADMIN','CLINIC_ASSOCIATE')")
	public List<PetDetailsDTO> getPetDetails(@PathVariable Long clinicId) {
		return clinicDetailsService.getPetDetails(clinicId);
	}

	@PostMapping("/addClinicAdminAndAssociate")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN')")
	public ResponseEntity<String> addAdminAndAssociate(
			@RequestBody ClinicAdminRegisterDTO clinicAdminAssociateRegister) {
		return clinicDetailsService.addClinicAdminAndAssociate(clinicAdminAssociateRegister);
	}

	@GetMapping("/getAllClinicMembers/{role}")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public List<ClinicAdminDTO> getAllClinicMembersByRole(@PathVariable String role) {
		return clinicDetailsService.getAllClinicMembersByRole(role);
	}

	@GetMapping("/getAllAssociates")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public List<ClinicAssociatesDTO> getAllClinicAssociates() {
		return clinicDetailsService.getAllClinicAssociate();
	}

	// Get a Details By Id (All role)
	@GetMapping("get-profile/{id}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'SUPER_ADMIN','CLINIC_ADMIN','CLINIC_ASSOCIATE','SALES_REP')")
	public ClinicRollDTO getRegisterById(@PathVariable Long id) {
		return clinicDetailsService.getRegisterById(id);
	}

	// Get List of Clinic Details for Super Admin
	@GetMapping("clinic-list-details")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public List<ClinicListDTO> getClinicList() {
		return clinicDetailsService.getClinicList();
	}

	@PostMapping("/add-clinic-super-admin")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public ResponseEntity<String> addClinicBySuperAdmin(@RequestBody ClinicDetailsDTO clinicDetails) {
		return clinicDetailsService.addClinicBySuperAdmin(clinicDetails);
	}

	@PostMapping("/generateQRCode/{clinicId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN')")
	public ResponseEntity<String> generateQRCodeAndUpload(@PathVariable Long clinicId) throws IOException {
		Optional<ClinicDetails> optionalClinicDetails = clinicDetailsRepository.findById(clinicId);
		if (!optionalClinicDetails.isPresent()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Clinic not found with id: " + clinicId);
		}
		ClinicDetails clinicDetails = optionalClinicDetails.get();
		String text = clinicDetails.getClinicName();
		int width = 300;
		int height = 300;
		byte[] qrCodeImage = new GenerateQRCode().generateQrCodeImage(text, width, height);
		String filename = "qr-" + clinicDetails.getId() + "-" + System.currentTimeMillis() + ".png";
		String s3Url = s3Service.uploadQRCodeToS3(qrCodeImage, filename);
		clinicDetails.setQrCode(s3Url);
		clinicDetailsRepository.save(clinicDetails);
		return ResponseEntity.ok("QR Code generated and uploaded to S3. URL: " + s3Url);
	}

	@GetMapping("/clinic-list-owner/{clinicOwnerId}")
	@PreAuthorize("hasAnyAuthority('SUPER_ADMIN','SALES_REP')")
	public List<ClinicListDTO> getClinicsByClinicOwnerId(@PathVariable Long clinicOwnerId) {
		return clinicDetailsService.getClinicsByClinicOwnerId(clinicOwnerId);
	}

	@GetMapping("/elevate-rep-clinic-list/{salesRepId}")
	@PreAuthorize("hasAnyAuthority('SUPER_ADMIN','SALES_REP')")
	public List<ClinicListDTO> getClinicBySalesRep(@PathVariable Long salesRepId) {
		return clinicDetailsService.getClinicBySalesRep(salesRepId);
	}

	@GetMapping("/list-clinic-members/{clinicId}")
	@PreAuthorize("hasAnyAuthority('SUPER_ADMIN')")
	public ClinicUser getClinicmemberslist(@PathVariable Long clinicId) {
		return clinicDetailsService.getClinicmemberslist(clinicId);
	}

	@PutMapping("/updateAdminAccess")
	@PreAuthorize("hasAuthority('CLINIC_OWNER')")
	public String adminAccess(@RequestBody AdminAccessDTO adminAccessDTO) {
		return clinicDetailsService.adminAccess(adminAccessDTO);
	}

	@GetMapping("/getAdminAccess/{clinicAdminId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_ADMIN', 'CLINIC_OWNER')")
	public AdminAccessDTO getAdminAccess(@PathVariable Long clinicAdminId) {
		return clinicDetailsService.getAccessOfAdmin(clinicAdminId);
	}

	// get a list of user under sales-rep
	@GetMapping("/sales-rep/{id}/users/{role}")
	@PreAuthorize("hasAuthority('SALES_REP')")
	public Set<ClinicAdminDTO> getUsersByRoleUnderSalesRep(@PathVariable String role, @PathVariable Long id) {
		return clinicDetailsService.getUsersByRoleUnderSalesRep(id, role);
	}

	@GetMapping("/get-headquaters")
	public Set<String> getHeadquaters() {
		return clinicDetailsService.getHeadquaterClinics();
	}

	@GetMapping("/getHeadquaters")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public Set<String> getHeadquatersSuperAdmin() {
		return clinicDetailsService.getHeadquaterClinics();
	}

	@GetMapping("getPetById/{petId}/{petOwnerId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_ADMIN', 'CLINIC_OWNER' , 'CLINIC_ASSOCIATE' , 'SUPER_ADMIN' , 'SALES_REP')")
	public PetDetailsWithOwnersDTO getPetById(@PathVariable Long petId, @PathVariable Long petOwnerId) {
		return clinicDetailsService.getSinglePetDetailsWithOwner(petId, petOwnerId);
	}

	@PutMapping("/update-salesRep/{clinicId}/{regId}")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String updateSalesRep(@PathVariable Long clinicId, @PathVariable Long regId) {
		return clinicDetailsService.UpdateSalesRepInClinic(clinicId, regId);
	}

	@GetMapping("/getDoctorsByClinic/{clinicId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_ADMIN', 'CLINIC_OWNER' , 'CLINIC_ASSOCIATE')")
	public List<DoctorDTO> getDoctorNames(@PathVariable Long clinicId) {
		return clinicDetailsService.getDoctorsByClinicId(clinicId);
	}
	
	@GetMapping("/sub-clinics/{clinicId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_ADMIN', 'CLINIC_OWNER' , 'CLINIC_ASSOCIATE' , 'SUPER_ADMIN' , 'SALES_REP')")
	public List<ClinicDetailsDTO> getSubClinics(@PathVariable Long clinicId){
		return clinicDetailsService.getSubClinics(clinicId);
	}
}