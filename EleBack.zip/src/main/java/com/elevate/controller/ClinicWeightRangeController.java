package com.elevate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.dto.ClinicWeightRangeDTO;
import com.elevate.service.ClinicWeightRangeService;

@RestController
@RequestMapping("/clinic-weight-range")
@CrossOrigin("*")
public class ClinicWeightRangeController {

	@Autowired
	private ClinicWeightRangeService clinicWeightRangeService;

	@GetMapping("/get/{id}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'CLINIC_ADMIN', 'CLINIC_ASSOCIATE')")
	public List<ClinicWeightRangeDTO> getClinicWeightRange(@PathVariable Long id) {
		return clinicWeightRangeService.getClinicWeightRange(id);
	}

	@PutMapping("/update")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'CLINIC_ADMIN')")
	public String updateWeightRange(@RequestParam Long id, @RequestParam String updateWeightRange) {
		return clinicWeightRangeService.updateClinicWeightRange(id, updateWeightRange);
	}

}
