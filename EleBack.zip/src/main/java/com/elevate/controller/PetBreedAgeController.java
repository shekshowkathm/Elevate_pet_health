package com.elevate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.dto.UpdateServiceStatus;
import com.elevate.entity.PetBreedAge;
import com.elevate.service.PetBreedAgeService;

@RestController
@RequestMapping("/breed")
@CrossOrigin
public class PetBreedAgeController {
	
	@Autowired
	private PetBreedAgeService ageService;
	
	@PostMapping("/add")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public ResponseEntity<String> add(@RequestBody PetBreedAge age) {
		return ageService.add(age);
	}
	
	@GetMapping("/getAll")
	@PreAuthorize("hasAnyAuthority('SUPER_ADMIN' , 'CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE' , 'SALES_REP')")
	public List<PetBreedAge> getAll(){
		return ageService.getAllAgeAndBreed();
	}
	
	@PutMapping("/update")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public ResponseEntity<String> update(@RequestBody PetBreedAge ageGroup) {
		return ageService.updateData(ageGroup);
	}
	
	@DeleteMapping("/delete/{id}")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String delete(@PathVariable Long id) {
		 return ageService.deleteBreed(id);
	}
	
	@PutMapping("/updateStatus")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String updateStatus(UpdateServiceStatus status) {
		return ageService.updateStatus(status);
	}
	
	@GetMapping("/getBreedName/{petType}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public List<String> getAllBreedName(@PathVariable String petType){
		return ageService.getBreedName(petType);
	}

}
