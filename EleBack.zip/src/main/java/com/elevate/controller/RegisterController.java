package com.elevate.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.dto.AuthRequest;
import com.elevate.dto.AuthResponse;
import com.elevate.dto.ClinicRegister;
import com.elevate.dto.ForgetPassword;
import com.elevate.dto.GetClinicInfoDTO;
import com.elevate.dto.SalesRepDTO;
import com.elevate.dto.UpdatePassword;
import com.elevate.dto.UpdateRegister;
import com.elevate.entity.Register;
import com.elevate.repository.IRegisterRepository;
import com.elevate.service.JwtService;
import com.elevate.service.RegisterService;

@RestController
@RequestMapping("/register")
@CrossOrigin("*")
public class RegisterController {

	@Autowired
	private RegisterService registerService;

	@Autowired
	private IRegisterRepository registerRepository;

	@Autowired
	public AuthenticationManager authenticationManager;

	@Autowired
	private JwtService jwtService;

	@PostMapping("/addSuperAdmin")
	public Register addElevateAdmin(@RequestBody Register register) {
		return registerService.addSuperAdmin(register);
	}

	@PostMapping("/add")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'SUPER_ADMIN')")
	public ResponseEntity<String> add(@RequestBody Register register) {
		return registerService.add(register);
	}

	@PutMapping("/updateRegisterStatus/{regId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'SUPER_ADMIN')")
	public String updateRegisterStatus(@PathVariable Long regId) {
		return registerService.updateRegStatus(regId);
	}


	@GetMapping("/not-verified-clinic-owners")
	@PreAuthorize("hasAnyAuthority('SUPER_ADMIN')")
	public List<ClinicRegister> retrieveNotVerifedRegisters() {
		return registerService.notVerifiedRegisters();
	}

	@PutMapping("/updatePassword")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'SUPER_ADMIN','CLINIC_ADMIN','CLINIC_ASSOCIATE','PET_OWNER','SALES_REP')")
	public String updatePassword(@RequestBody UpdatePassword updatePassword) {
		return registerService.updatePassword(updatePassword);
	}

	@PutMapping("/terms-and-conditions/{regId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'SUPER_ADMIN','CLINIC_ADMIN','CLINIC_ASSOCIATE','PET_OWNER','SALES_REP')")
	public String updateTermsAndCondition(@PathVariable long regId) {
		return registerService.updateTermsAndConditiond(regId);
	}

	@PutMapping("/update-profile")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'SUPER_ADMIN','CLINIC_ADMIN','CLINIC_ASSOCIATE','PET_OWNER','SALES_REP')")
	public String updateProfile(@RequestBody UpdateRegister updateRegister) {
		return registerService.updateProfile(updateRegister);
	}

	@GetMapping("/get-sales-rep")
	@PreAuthorize("hasAnyAuthority('SUPER_ADMIN')")
	public List<SalesRepDTO> getSalesRep() {
		return registerService.getSalesRep();
	}

	// Sales-Rep Details get By Id
	@GetMapping("sales-rep/{id}")
	@PreAuthorize("hasAnyAuthority('SUPER_ADMIN','SALES_REP')")
	public SalesRepDTO getSalesRepById(@PathVariable Long id) {
		return registerService.getSalesRepById(id);
	}

	@PostMapping("/generateOtp/{email}")
	public String checkEmail(@PathVariable String email) {
		return registerService.checkEmailForPasswordChange(email);
	}

	@PostMapping("/verify-otp/{email}/{otp}")
	public String verifyOtp(@PathVariable String email, @PathVariable String otp) {
		return registerService.verifyOtp(email, otp);
	}

	@PostMapping("/forgetPassword")
	public String forgetPassword(@RequestBody ForgetPassword forgetPassword) {
		return registerService.forgetPassword(forgetPassword);
	}

	@GetMapping("/get-all-rep-list")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public List<SalesRepDTO> getActiveSalesRep() {
		return registerService.getActiveSalesRep();
	}

	@GetMapping("/getAllDoctors")
	@PreAuthorize("hasAnyAuthority('CLINIC_ADMIN' , 'CLINIC_OWNER' , 'CLINIC_ASSOCIATE')")
	public List<String> getAllDoctorsName() {
		return registerService.getAllDoctors();
	}

	
	@PostMapping("/login")
    public ResponseEntity<?> authentication(@RequestBody AuthRequest authRequest) {
		AuthResponse response = new AuthResponse();
		Optional<Register> registerOpt = registerRepository.findByEmail(authRequest.getUsername());
 
		if (registerOpt.isPresent() && registerOpt.get().getPassword() != null
				&& registerOpt.get().isRegisterStatus() == true) {
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
			Register register = registerOpt.get();
			if (authentication.isAuthenticated()) {
				response.setId(register.getId());
				response.setUsername(register.getEmail());
				response.setRole(register.getRole());
				response.setToken(jwtService.generateToken(authRequest.getUsername()));
				response.setResponse("Login Successfully");
				response.setTermsAndConditions(register.isTermsAndConditions());
				if ("PET_OWNER".equals(register.getRole())) {
					response.setStripeCustomerId(register.getStripeCustomerId());
				}
				response.setTimezone(register.getTimezone());
				return ResponseEntity.ok(response);
			} else {
				response.setResponse("Invalid Login");
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
			}
		}
		response.setResponse("No username found");
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	}

	@PutMapping("/status-update/{regId}")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String statusUpdate(@PathVariable Long regId) {
		return registerService.updateStatus(regId);
	}
	
	@PostMapping("/sendInfoEmail")
    public String sendClinicInfoEmail(@RequestBody GetClinicInfoDTO clinicInfo) {
        registerService.sendClinicInfoEmail(clinicInfo);       
        return "Clinic information email sent successfully!";
    }
}