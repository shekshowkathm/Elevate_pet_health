package com.elevate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.dto.AddPetOwnerDTO;
import com.elevate.dto.PetDTO;
import com.elevate.dto.PetDetailsDTO;
import com.elevate.dto.PetImageList;
import com.elevate.dto.PetOwnerClinics;
import com.elevate.dto.PetOwnerPetDetails;
import com.elevate.dto.PetOwnerRegisterDTO;
import com.elevate.dto.PetPlansDTO;
import com.elevate.entity.PetDetails;
import com.elevate.service.PetDetailsService;

@RestController
@RequestMapping("/pet-detials")
@CrossOrigin("*")
public class PetDetailsController {

	@Autowired
	private PetDetailsService petDetailsService;

	@PostMapping("/addPetOwner")
	public ResponseEntity<String> addPetOwner(@RequestBody PetOwnerRegisterDTO petOwnerDTO) {
		return petDetailsService.registerPetOwner(petOwnerDTO);
	}

	@PostMapping("/add-pet")
	@PreAuthorize("hasAnyAuthority('PET_OWNER')")
	public String addPet(@RequestBody PetDetails petDetails) {
		return petDetailsService.addPet(petDetails);
	}

	@PostMapping("/add-new-clinic/{petOwnerId}/{clinicId}")
	@PreAuthorize("hasAnyAuthority('PET_OWNER')")
	public String addNewClinic(@PathVariable Long petOwnerId, @PathVariable Long clinicId) {
		return petDetailsService.addClinic(petOwnerId, clinicId);
	}

	@PutMapping("/update-status/{petId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER', 'CLINIC_ADMIN')")
	public String updatePetStatus(@PathVariable Long petId) {
		return petDetailsService.updatePetStatus(petId);
	}

	@GetMapping("/notVerifiedPetOwners/{clinicId}")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER' , 'CLINIC_ADMIN')")
	public List<PetOwnerRegisterDTO> notVerifiedPetOwners(@PathVariable Long clinicId) {
		return petDetailsService.notRegisteredPetOwners(clinicId);
	}

	// List Of Pet Owners
	@GetMapping("/getAllPetOwners")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public List<PetDetailsDTO> getAllPetOwners() {
		return petDetailsService.getAllPetOwners();
	}

	// Get PetOwner Details By Id (For Profile)
	@GetMapping("get-profile/{id}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public PetOwnerRegisterDTO getRegisterById(@PathVariable Long id) {
		return petDetailsService.getRegisterById(id);
	}

	@GetMapping("/get-pets/{id}") // Pet Owner Register Id
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER','CLINIC_ADMIN','CLINIC_ASSOCIATE')")
	public List<PetOwnerPetDetails> getPetDetailsByPetOwnerID(@PathVariable Long id) {
		return petDetailsService.getPetOwnersPetDetails(id);
	}

	@GetMapping("/get-clinics/{id}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public List<PetOwnerClinics> getPetOwnerClinics(@PathVariable Long id) {
		return petDetailsService.getPetOwnerClinics(id);
	}

	@GetMapping("/get-pet-image/{id}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public List<PetImageList> getPetImageList(@PathVariable Long id) {
		return petDetailsService.getPetImageList(id);
	}

	@GetMapping("/get-my-pet/{id}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public PetDTO getMyPet(@PathVariable Long id) {
		return petDetailsService.getMyPetDetails(id);
	}

	@PostMapping("/add-New-Pet-Owner")
	@PreAuthorize("hasAnyAuthority('CLINIC_OWNER','CLINIC_ADMIN','CLINIC_ASSOCIATE')")
	public ResponseEntity<String> addPetOwnerByClinic(@RequestBody AddPetOwnerDTO addPetOwnerDTO) {
		return petDetailsService.registerPetOwnerByClinic(addPetOwnerDTO);
	}

	@PutMapping("/update-pet/{petId}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public String updatePet(@PathVariable Long petId, @RequestBody PetDetailsDTO petDetailsDTO) {
		return petDetailsService.updatePetDetails(petId, petDetailsDTO);
	}

	@GetMapping("/getPetDetails/{petDetailsId}")
	public ResponseEntity <List<PetDetailsDTO>> getPetDetails(@PathVariable Long petDetailsId){
		return ResponseEntity.status(HttpStatus.OK).body(petDetailsService.getPetDetails(petDetailsId));}
	
	@GetMapping("get-Pet-Plans/{petId}")
	@PreAuthorize("hasAuthority('PET_OWNER')")
	public PetPlansDTO getPetPlans(@PathVariable Long petId) {
		return petDetailsService.getPetPlans(petId);
	}

	

}
