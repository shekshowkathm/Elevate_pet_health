package com.elevate.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.entity.NewsLetter;
import com.elevate.entity.Subscribers;
import com.elevate.service.SubscibersService;

@RestController
@RequestMapping("/subscribe")
@CrossOrigin
public class SubscribersController {

	@Autowired
	private SubscibersService subscriberService;
	
	@PostMapping("/add")
	public String add(@RequestBody Subscribers subscribe) {
		return subscriberService.addSubscriber(subscribe);
	}
	
	@GetMapping("/getAllSubscribers")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public List<Subscribers> getAllSubscribers(){
		return subscriberService.getAllSubscribers();
	}
	
	@PutMapping("/unsubscribe/{email}")
	public String unsubscribeStatus(@PathVariable String email) {
		return subscriberService.unscubscribe(email);
	}
	
	@PostMapping("/addImages")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String addImages(@RequestBody NewsLetter newsLetter) {
		return subscriberService.addImagesForEmails(newsLetter);
	}
	
	@GetMapping("/getAllNewsLetters")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public List<NewsLetter> getAllNewsLetter(){
		return subscriberService.getAllNewsLetters();
	}
	
	 @PostMapping("/send-newsletter")
	 @PreAuthorize("hasAuthority('SUPER_ADMIN')")
	 public ResponseEntity<String> sendNewsletterNow() {
	        try {
	        	subscriberService.sendOffersAndNewsLetters();  
	            return ResponseEntity.ok("Newsletter sent successfully!");
	        } catch (Exception e) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                                 .body("Error sending newsletter: " + e.getMessage());
	        }
	  }
}
