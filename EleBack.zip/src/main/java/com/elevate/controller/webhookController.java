package com.elevate.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.service.webhookService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/webhooks")
public class webhookController {

    @Autowired
    webhookService webhookService;

    @PostMapping("/paymentStatus")
    public ResponseEntity<String> getStripePaymentStatus(@RequestBody String payload, HttpServletRequest request){
        String sigHeader = request.getHeader("Stripe-Signature");
        return webhookService.getStripePaymentStatus(payload,sigHeader);
    }

}
