package com.elevate.controller;

import com.elevate.dto.DocumentDto;
import com.elevate.entity.UploadDocument;
import com.elevate.service.DocumentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/documents")
@CrossOrigin("*")
public class DocumentController {

    @Autowired
    private DocumentService documentService;

    @PostMapping("/upload")
    @PreAuthorize("hasAnyAuthority('CLINIC_OWNER','CLINIC_ADMIN','CLINIC_ASSOCIATE','PET_OWNER','SUPER_ADMIN')")
    public ResponseEntity<UploadDocument> uploadDocument(@RequestBody DocumentDto documentDto) {
        UploadDocument document = documentService.uploadDocument(documentDto);
        return ResponseEntity.ok(document);
    }

    // GET method to retrieve all documents uploaded by SuperAdmin to all clinics (A)
    @GetMapping("/superadmin/allclinics")
    @PreAuthorize("hasAuthority('SUPER_ADMIN')")
    public ResponseEntity<List<DocumentDto>> getDocumentsBySuperAdminForAllClinics() {
        List<DocumentDto> documents = documentService.getDocumentsBySuperAdminForAllClinics();
        return new ResponseEntity<>(documents, HttpStatus.OK);
    }

    //Get method By Clinic Id (For Clinic)(A1)
    @GetMapping("/superadmin/clinic/{clinicId}")
    @PreAuthorize("hasAnyAuthority('CLINIC_OWNER','CLINIC_ADMIN','CLINIC_ASSOCIATE','SUPER_ADMIN','SALES_REP')")
    public ResponseEntity<List<DocumentDto>> getDocumentsBySuperAdminForClinic(@PathVariable Long clinicId) {
        List<DocumentDto> documents = documentService.getDocumentsBySuperAdminForClinic(clinicId);
        return new ResponseEntity<>(documents, HttpStatus.OK);
    }

    // Get documents uploaded by the clinic to the Super Admin(A2)
    @GetMapping("/clinic/{clinicId}/superadmin")
    @PreAuthorize("hasAnyAuthority('CLINIC_OWNER','CLINIC_ADMIN','CLINIC_ASSOCIATE','SUPER_ADMIN','SALES_REP')")
    public ResponseEntity<List<DocumentDto>> getDocumentsUploadedByClinicToSuperAdmin(@PathVariable Long clinicId) {
        List<DocumentDto> documents = documentService.getDocumentsUploadedByClinicToSuperAdmin(clinicId);
        return new ResponseEntity<>(documents, HttpStatus.OK);
    }
    //PetOwner to the Clinic (B2)
    @GetMapping("/clinic/{clinicId}/from-petowner/{uploadedById}")
    @PreAuthorize("hasAnyAuthority('CLINIC_OWNER','CLINIC_ADMIN','CLINIC_ASSOCIATE','PET_OWNER','SUPER_ADMIN')")
    public ResponseEntity<List<DocumentDto>> getDocumentsUploadedByPetOwnerToClinic(
            @PathVariable Long clinicId, @PathVariable Long uploadedById) {
        List<DocumentDto> documents = documentService.getDocumentsUploadedByPetOwnerToClinic(clinicId, uploadedById);
        return new ResponseEntity<>(documents, HttpStatus.OK);
    }

    //   Clinic To All Pet Owners(B)
    @GetMapping("/clinic/{clinicId}/petowners/all")
    @PreAuthorize("hasAnyAuthority('CLINIC_OWNER','CLINIC_ADMIN','CLINIC_ASSOCIATE','PET_OWNER','SUPER_ADMIN')")
    public ResponseEntity<List<DocumentDto>> getDocumentsUploadedByClinicToAllPetOwners(@PathVariable Long clinicId) {
        List<DocumentDto> documents = documentService.getDocumentsUploadedByClinicToAllPetOwners(clinicId);
        return ResponseEntity.ok(documents);
    }
    //Clinic To petOwner (B1)
    @GetMapping("/clinic/{clinicId}/to-petowner/{petId}")
    @PreAuthorize("hasAnyAuthority('CLINIC_OWNER','CLINIC_ADMIN','CLINIC_ASSOCIATE','PET_OWNER','SUPER_ADMIN')")
    public ResponseEntity<List<DocumentDto>> getDocumentsUploadedByClinicToSpecificOrAllPetOwners(@PathVariable Long clinicId, @PathVariable Long petId) {
        List<DocumentDto> documents = documentService.getDocumentsUploadedByClinicToSpecificOrAllPetOwners(clinicId, petId);
        return ResponseEntity.ok(documents);
    }
    
    @GetMapping("/invoices/{petOwnerId}")
    @PreAuthorize("hasAuthority('PET_OWNER')")
    public List<DocumentDto> getInvoices(@PathVariable Long petOwnerId) {
        return documentService.getInvoicesByPetOwnerId(petOwnerId);
    }
}