package com.elevate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elevate.dto.UpdateServiceStatus;
import com.elevate.entity.WeightRange;
import com.elevate.service.WeightRangeService;

@RestController
@RequestMapping("/weightRange")
@CrossOrigin("*")
public class WeightRangeController {
	
	@Autowired
	private WeightRangeService weightRangeService;

	@PostMapping("/add")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public ResponseEntity<String> add(@RequestBody WeightRange weight) {
		return weightRangeService.add(weight);
		
	}
	
	@GetMapping("/getAll")
	@PreAuthorize("hasAnyAuthority('SUPER_ADMIN' , 'CLINIC_OWNER' , 'CLINIC_ADMIN' , 'CLINIC_ASSOCIATE' , 'SALES_REP')")
	public List<WeightRange> getAllWightRange(){
		return weightRangeService.getAllData();
	}
	
	@PutMapping("/update")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public ResponseEntity<String> update(@RequestBody WeightRange weightRange) {
		return weightRangeService.update(weightRange);
	}
	
	@DeleteMapping("/delete/{id}")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String delete(@PathVariable Long id) {
		return weightRangeService.deleteWeightRange(id);
	}
	
	@PutMapping("/updateStatus")
	@PreAuthorize("hasAuthority('SUPER_ADMIN')")
	public String updateStatus(UpdateServiceStatus status) {
		return weightRangeService.updateStatus(status);
	}
}
