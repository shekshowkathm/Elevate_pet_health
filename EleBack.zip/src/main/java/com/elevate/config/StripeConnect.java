package com.elevate.config;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.elevate.dto.PriceDetails;
import com.elevate.dto.StripeDetails;
import com.elevate.entity.PetWellnessPlan;
//import com.elevate.repository.IPetDetailsRepository;
import com.elevate.repository.IPetWellnessPlanRepository;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.Account;
import com.stripe.model.AccountLink;
import com.stripe.model.Customer;
import com.stripe.model.Invoice;
import com.stripe.model.LoginLink;
import com.stripe.model.Price;
import com.stripe.model.Product;
import com.stripe.model.Subscription;
import com.stripe.model.SubscriptionSchedule;
import com.stripe.param.AccountCreateParams;
import com.stripe.param.AccountLinkCreateParams;
import com.stripe.param.CustomerCreateParams;
import com.stripe.param.LoginLinkCreateOnAccountParams;
import com.stripe.param.PriceCreateParams;
import com.stripe.param.PriceUpdateParams;
import com.stripe.param.ProductCreateParams;
import com.stripe.param.SubscriptionCreateParams;
import com.stripe.param.SubscriptionScheduleCreateParams;


@Service
public class StripeConnect {
    @Value("${Stripe.apiKey}")
    private String apiKey;

//    @Autowired
//    IPetDetailsRepository petDetailsRepository;

    @Autowired
    IPetWellnessPlanRepository petWellnessPlanRepository;

    public Account createConnectedAccount(String email) throws Exception {
        System.out.println(email);
        Stripe.apiKey = apiKey;
        AccountCreateParams params = AccountCreateParams.builder()
                        .setCountry("US")
                        .setEmail(email)
                        // .setType(AccountCreateParams.Type.EXPRESS)
                       .setController(
                               AccountCreateParams.Controller.builder()
                                       .setLosses(
                                               AccountCreateParams.Controller.Losses.builder()
                                                       .setPayments(AccountCreateParams.Controller.Losses.Payments.STRIPE)
                                                       .build()
                                       )
                                       .build()
                       )
                        .build();
        return Account.create(params);
    }

    public String createAccountLink(String accountId) throws Exception {
        Stripe.apiKey = apiKey;
        if (accountId == null) {
            throw new IllegalArgumentException("Account type must not be null");
        }
        AccountLinkCreateParams params =
                AccountLinkCreateParams.builder()
                        .setAccount(accountId)
                        .setRefreshUrl("https://demo.elevatepethealth.com/stripe/refresh/"+accountId)
                        .setReturnUrl("https://demo.elevatepethealth.com/login")
                        .setType(AccountLinkCreateParams.Type.ACCOUNT_ONBOARDING)
                        .build();

        AccountLink accountLink = AccountLink.create(params);
        return accountLink.getUrl();
    }


    public  String createConnectedCustomer(String accountId,String customerName, String customerEmail) throws Exception {
        Stripe.apiKey = apiKey;
        System.out.println(accountId+"Account Ids");
//        RequestOptions requestOptions = RequestOptions.builder()
//                .setStripeAccount(accountId)
//                .build();
        CustomerCreateParams params = CustomerCreateParams.builder()
                .setName(customerName)
                .setEmail(customerEmail)
                .putMetadata("connected_account_id", accountId)
                .build();
        Customer platformCustomer = Customer.create(params);

        return platformCustomer.getId();
    }

    public ResponseEntity<String> createLoginLink(String connectedAccountId) throws StripeException {
        Stripe.apiKey=apiKey;
        LoginLinkCreateOnAccountParams params =
                LoginLinkCreateOnAccountParams.builder().build();
        LoginLink loginLink = LoginLink.createOnAccount(connectedAccountId, params);
        return ResponseEntity.status(HttpStatus.CREATED).body(loginLink.getUrl());

    }

    public SubscriptionSchedule createScheduledSubscription(StripeDetails stripeDetails, LocalDate startDate)throws Exception{
        long formatStartDate = startDate.atStartOfDay(ZoneId.systemDefault()).toInstant().getEpochSecond();
        SubscriptionScheduleCreateParams.Builder paramsBuilder =
                SubscriptionScheduleCreateParams.builder()
                        .setCustomer(stripeDetails.getCustomerId())
                        .setStartDate(formatStartDate)
                        .putMetadata("connected_account_id", stripeDetails.getAccountId());
//                        .setEndBehavior(SubscriptionScheduleCreateParams.EndBehavior.RELEASE);
        SubscriptionScheduleCreateParams.Phase.Builder phaseBuilder = SubscriptionScheduleCreateParams.Phase.builder()
                .setCoupon(stripeDetails.getStripeCouponId())
//                .addDiscount(SubscriptionScheduleCreateParams.Phase.Discount.builder().setDiscount(stripeDetails.getStripeCouponId()).build())
                .addAddInvoiceItem(SubscriptionScheduleCreateParams.Phase.AddInvoiceItem.builder().setPrice(stripeDetails.getOneTimePriceId()).build())
                .setIterations(12L);
        List<PriceDetails> priceDetailsList = stripeDetails.getPriceIds();
        for (PriceDetails details : priceDetailsList) {
            phaseBuilder.addItem(
                    SubscriptionScheduleCreateParams.Phase.Item.builder()
                            .setPrice(details.getPriceId())
                            .setQuantity(details.getQuantity())
                            .build()
            );
        }
        paramsBuilder.addPhase(phaseBuilder.build());

        SubscriptionSchedule subscriptionSchedule = SubscriptionSchedule.create(paramsBuilder.build());
        long[] petWellnessPlanIds= stripeDetails.getPetWellnessPlanId();
System.out.println(subscriptionSchedule+"subscriptionSchedulesubscriptionSchedule");
        for(long petWellnessPlanId:petWellnessPlanIds){
            PetWellnessPlan existingPetWellnessDetails = petWellnessPlanRepository
                    .findById(petWellnessPlanId)
                    .orElseThrow(() -> new RuntimeException("Pet details not found"));
            existingPetWellnessDetails.setPaymentStatus(subscriptionSchedule.getStatus());
            existingPetWellnessDetails.setPlanStatus("scheduled");
            existingPetWellnessDetails.setStripeSubscriptionId(subscriptionSchedule.getId());
            petWellnessPlanRepository.save(existingPetWellnessDetails);
        }

        return subscriptionSchedule;
    }

    public SubscriptionSchedule createScheduledSubscriptionWithoutOneTomeFee(StripeDetails stripeDetails, LocalDate startDate)throws Exception{
        long formatStartDate = startDate.atStartOfDay(ZoneId.systemDefault()).toInstant().getEpochSecond();
        SubscriptionScheduleCreateParams.Builder paramsBuilder =
                SubscriptionScheduleCreateParams.builder()
                        .setCustomer(stripeDetails.getCustomerId())
                        .setStartDate(formatStartDate)
                        .putMetadata("connected_account_id", stripeDetails.getAccountId());
        SubscriptionScheduleCreateParams.Phase.Builder phaseBuilder = SubscriptionScheduleCreateParams.Phase.builder()
                .setCoupon(stripeDetails.getStripeCouponId())
                .setIterations(12L);
        List<PriceDetails> priceDetailsList = stripeDetails.getPriceIds();
        for (PriceDetails details : priceDetailsList) {
            phaseBuilder.addItem(
                    SubscriptionScheduleCreateParams.Phase.Item.builder()
                            .setPrice(details.getPriceId())
                            .setQuantity(details.getQuantity())
                            .build()
            );
        }
        paramsBuilder.addPhase(phaseBuilder.build());

        SubscriptionSchedule subscriptionSchedule = SubscriptionSchedule.create(paramsBuilder.build());
        long[] petWellnessPlanIds= stripeDetails.getPetWellnessPlanId();

        for(long petWellnessPlanId:petWellnessPlanIds){
            PetWellnessPlan existingPetWellnessDetails = petWellnessPlanRepository
                    .findById(petWellnessPlanId)
                    .orElseThrow(() -> new RuntimeException("Pet details not found"));
            existingPetWellnessDetails.setStripeSubscriptionId(subscriptionSchedule.getId());
            petWellnessPlanRepository.save(existingPetWellnessDetails);
        }

        return subscriptionSchedule;
    }


    public Invoice createSubscription(StripeDetails stripeDetails) throws Exception {
        System.out.println(stripeDetails.getStripeCouponId()+"llllllllllllllllll");
        if(stripeDetails.getOneTimePriceId() == null){

        }
        SubscriptionCreateParams.Builder paramsBuilder = SubscriptionCreateParams.builder()
                .setCustomer(stripeDetails.getCustomerId())
                .putMetadata("connected_account_id", stripeDetails.getAccountId())
                .setCoupon(stripeDetails.getStripeCouponId())
//                .addDiscount(SubscriptionCreateParams.Discount.builder().setDiscount(stripeDetails.getStripeCouponId()).build())
                .addAddInvoiceItem(
                        SubscriptionCreateParams.AddInvoiceItem.builder().setPrice(stripeDetails.getOneTimePriceId()).build()
                )
//					.setCancelAt(cancelAt)
                .setPaymentBehavior(SubscriptionCreateParams.PaymentBehavior.DEFAULT_INCOMPLETE);
        List<PriceDetails> priceDetailsList = stripeDetails.getPriceIds();
        for (PriceDetails details : priceDetailsList) {
            paramsBuilder.addItem(
                    SubscriptionCreateParams.Item.builder()
                            .setPrice(details.getPriceId())
                            .setQuantity(details.getQuantity())
                            .build());
        }

        Subscription subscription = Subscription.create(paramsBuilder.build());

        long[] petWellnessPlanIds= stripeDetails.getPetWellnessPlanId();

        for(long petWellnessPlanId:petWellnessPlanIds){
            PetWellnessPlan existingPetWellnessDetails = petWellnessPlanRepository
                    .findById(petWellnessPlanId)
                    .orElseThrow(() -> new RuntimeException("Pet details not found"));
            existingPetWellnessDetails.setStripeSubscriptionId(subscription.getId());
            petWellnessPlanRepository.save(existingPetWellnessDetails);
        }


        return Invoice.retrieve(subscription.getLatestInvoice());
    }

    public Invoice createSubscriptionWithoutOneTimeFee(StripeDetails stripeDetails) throws Exception {
        System.out.println(stripeDetails.getStripeCouponId()+"llllllllllllllllll");
        SubscriptionCreateParams.Builder paramsBuilder = SubscriptionCreateParams.builder()
                .setCustomer(stripeDetails.getCustomerId())
                .putMetadata("connected_account_id", stripeDetails.getAccountId())
                .setCoupon(stripeDetails.getStripeCouponId())
                .setPaymentBehavior(SubscriptionCreateParams.PaymentBehavior.DEFAULT_INCOMPLETE);
        List<PriceDetails> priceDetailsList = stripeDetails.getPriceIds();
        for (PriceDetails details : priceDetailsList) {
            paramsBuilder.addItem(
                    SubscriptionCreateParams.Item.builder()
                            .setPrice(details.getPriceId())
                            .setQuantity(details.getQuantity())
                            .build());
        }

        Subscription subscription = Subscription.create(paramsBuilder.build());
        
        long[] petWellnessPlanIds= stripeDetails.getPetWellnessPlanId();

        for(long petWellnessPlanId:petWellnessPlanIds){ 
            PetWellnessPlan existingPetWellnessDetails = petWellnessPlanRepository
                    .findById(petWellnessPlanId)
                    .orElseThrow(() -> new RuntimeException("Pet details not found"));
            existingPetWellnessDetails.setStripeSubscriptionId(subscription.getId());
            petWellnessPlanRepository.save(existingPetWellnessDetails);
        }


        return Invoice.retrieve(subscription.getLatestInvoice());
    }

    public String createProduct(String productName,String description) throws StripeException {
        ProductCreateParams params = ProductCreateParams.builder().setName(productName)
                .setDescription(description).build();
        Product product = Product.create(params);
        return product.getId();
    }

    public String createPrice(String accountId,String productId,long monthlyPrice) throws StripeException {
        PriceCreateParams priceParams = PriceCreateParams.builder()
                .setUnitAmount(monthlyPrice)
                .setCurrency("usd")
                .setRecurring(PriceCreateParams.Recurring.builder()
                        .setInterval(PriceCreateParams.Recurring.Interval.MONTH)
                        .build())
                .setProduct(productId)
                .putMetadata("connected_account_id", accountId)
                .build();
        Price price = Price.create(priceParams);
        return price.getId();
    }

    public String updatePrice(String accountId,String priceId,long newPrice,String productId) throws StripeException {
        Price oldPrice = Price.retrieve(priceId);
        PriceUpdateParams params = PriceUpdateParams.builder()
                .setActive(false)
                .build();
        oldPrice.update(params);
        PriceCreateParams priceParams = PriceCreateParams.builder()
                .setUnitAmount(newPrice)
                .setCurrency("usd")
                .setRecurring(PriceCreateParams.Recurring.builder()
                        .setInterval(PriceCreateParams.Recurring.Interval.MONTH)
                        .build())
                .setProduct(productId)
                .putMetadata("connected_account_id", accountId)
                .build();
        Price price = Price.create(priceParams);
        return price.getId();
    }

    @RequestMapping("/stripe/refresh/{accountId}")
    public String handleStripeRefresh(@PathVariable String accountId) {
        try {
            String accountLinkUrl = createAccountLink(accountId);
            System.out.println(accountLinkUrl);
            return "redirect:" + accountLinkUrl;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

 public SubscriptionSchedule retryScheduledSubscription(StripeDetails stripeDetails, LocalDate startDate)throws Exception{
     long formatStartDate = startDate.atStartOfDay(ZoneId.systemDefault()).toInstant().getEpochSecond();
     SubscriptionScheduleCreateParams.Builder paramsBuilder =
             SubscriptionScheduleCreateParams.builder()
                     .setCustomer(stripeDetails.getCustomerId())
                     .setStartDate(formatStartDate)
                     .putMetadata("connected_account_id", stripeDetails.getAccountId());
     SubscriptionScheduleCreateParams.Phase.Builder phaseBuilder = SubscriptionScheduleCreateParams.Phase.builder()
             .setIterations(stripeDetails.getBillingCycle());
     List<PriceDetails> priceDetailsList = stripeDetails.getPriceIds();
     for (PriceDetails details : priceDetailsList) {
         phaseBuilder.addItem(
                 SubscriptionScheduleCreateParams.Phase.Item.builder()
                         .setPrice(details.getPriceId())
                         .setQuantity(details.getQuantity())
                         .build()
         );
     }
     paramsBuilder.addPhase(phaseBuilder.build());

     SubscriptionSchedule subscriptionSchedule = SubscriptionSchedule.create(paramsBuilder.build());
     long[] petWellnessPlanIds= stripeDetails.getPetWellnessPlanId();

     for(long petWellnessPlanId:petWellnessPlanIds){
         PetWellnessPlan existingPetWellnessDetails = petWellnessPlanRepository
                 .findById(petWellnessPlanId)
                 .orElseThrow(() -> new RuntimeException("Pet details not found"));
         existingPetWellnessDetails.setStripeSubscriptionId(subscriptionSchedule.getId());
         petWellnessPlanRepository.save(existingPetWellnessDetails);
     }

     return subscriptionSchedule;
 }
    public Invoice retrySubscription(StripeDetails stripeDetails) throws Exception {

    SubscriptionCreateParams.Builder paramsBuilder = SubscriptionCreateParams.builder()
            .setCustomer(stripeDetails.getCustomerId())
            .putMetadata("connected_account_id", stripeDetails.getAccountId())
            .setPaymentBehavior(SubscriptionCreateParams.PaymentBehavior.DEFAULT_INCOMPLETE);

    List<PriceDetails> priceDetailsList = stripeDetails.getPriceIds();
        for (PriceDetails details : priceDetailsList) {
        paramsBuilder.addItem(
                SubscriptionCreateParams.Item.builder()
                        .setPrice(details.getPriceId())
                        .setQuantity(details.getQuantity())
                        .build());
    }
    Subscription subscription = Subscription.create(paramsBuilder.build());
    long[] petWellnessPlanIds= stripeDetails.getPetWellnessPlanId();
        for(long petWellnessPlanId:petWellnessPlanIds){
        PetWellnessPlan existingPetWellnessDetails = petWellnessPlanRepository
                .findById(petWellnessPlanId)
                .orElseThrow(() -> new RuntimeException("Pet details not found"));
        existingPetWellnessDetails.setStripeSubscriptionId(subscription.getId());
        petWellnessPlanRepository.save(existingPetWellnessDetails);
    }


        return Invoice.retrieve(subscription.getLatestInvoice());
    }
}