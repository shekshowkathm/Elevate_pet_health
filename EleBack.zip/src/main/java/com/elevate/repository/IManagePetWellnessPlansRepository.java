package com.elevate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.elevate.entity.ManagePetWellnessPlans;

@Repository
public interface IManagePetWellnessPlansRepository extends JpaRepository<ManagePetWellnessPlans, Long> {

}
