package com.elevate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.elevate.entity.Recommendation;

@Repository
public interface IRecommendationRepository extends JpaRepository<Recommendation, Long> {

	Recommendation findByDropdownListIdAndWellnessPlanId(Long dropdownListId, Long wellnessPlanId);

}
