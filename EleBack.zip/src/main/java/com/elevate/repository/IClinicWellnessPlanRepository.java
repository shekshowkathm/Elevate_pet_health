package com.elevate.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.elevate.entity.ClinicWellnessPlan;

@Repository
public interface IClinicWellnessPlanRepository extends JpaRepository<ClinicWellnessPlan, Long> {

	List<ClinicWellnessPlan> findByClinicId(Long id);

	@Query("SELECT cwp FROM ClinicWellnessPlan cwp WHERE cwp.clinic.id = :clinicId AND cwp.wellnessPlan.wellnessPlanName = :wellnessPlanName ORDER BY id")
	List<ClinicWellnessPlan> findClinicWellnessPlansByClinicIdAndWellnessPlanName(@Param("clinicId") Long clinicId,
			@Param("wellnessPlanName") String wellnessPlanName);

	long countByClinic_IdAndWellnessUpdate_StatusTrue(Long id);
}
