package com.elevate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.elevate.entity.DropdownList;

@Repository
public interface IDropdownListRepository extends JpaRepository<DropdownList, Long> {

}
