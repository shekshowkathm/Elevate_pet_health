package com.elevate.repository;

import java.time.Instant;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.elevate.Enum.Status;
import com.elevate.entity.PetDetails;
import com.elevate.entity.PetWellnessPlan;
import com.elevate.entity.Register;

@Repository
public interface IPetWellnessPlanRepository extends JpaRepository<PetWellnessPlan, Long> {

	List<PetWellnessPlan> findByPetId(PetDetails petDetails);

	List<PetWellnessPlan> findByPetIdOrderByIdAsc(PetDetails petId);

	List<PetWellnessPlan> findByPetId_Id(Long petId);

	List<PetWellnessPlan> findByManagePetWellnessPlanId(Long managePetWellnessPlanId);

	List<PetWellnessPlan> findByPetOwnerId_Id(Long petOwnerId);

	List<PetWellnessPlan> findByStripeSubscriptionIdAndStripeCustomerId(String stripeSubscriptionId,
			String stripeCustomerId);

	List<PetWellnessPlan> findByStripeSubscriptionId(String subscriptionId);

	@Query("SELECT p FROM PetWellnessPlan p WHERE p.clinicWellnessPlan.clinic.id = :clinicId AND p.clinicWellnessPlan.wellnessPlan.wellnessPlanName = :wellnessPlanName")
	List<PetWellnessPlan> findExistingPlansForClinicAndWellnessPlan(@Param("clinicId") Long clinicId,
			@Param("wellnessPlanName") String wellnessPlanName);

	@Query("SELECT COUNT(DISTINCT p.petOwnerId, p.managePetWellnessPlan) " + "FROM PetWellnessPlan p "
			+ "JOIN p.clinicWellnessPlan cwp " + "WHERE cwp.clinic.id = :clinicId "
			+ "AND CONCAT(TRIM(SUBSTRING(p.createdOn, 7, 4)), '-', TRIM(SUBSTRING(p.createdOn, 1, 2))) = :monthYear")
	Long countUniquePlansByClinicAndMonth(@Param("clinicId") Long clinicId, @Param("monthYear") String monthYear);

	@Query("SELECT COUNT(p) FROM PetWellnessPlan p " + "WHERE p.createdOn BETWEEN :startDate AND :currentDate "
			+ "AND p.clinicWellnessPlan.clinic.id = :clinicId")
	Long countByDateRangeAndClinicId(@Param("startDate") String startDate, @Param("currentDate") String currentDate,
			@Param("clinicId") Long clinicId);

	@Query("SELECT COUNT(p) FROM PetWellnessPlan p " + "WHERE p.createdOn >= :startDate AND p.createdOn <= :endDate "
			+ "AND p.clinicWellnessPlan.clinic.id = :clinicId")
	int countByCreatedOnBetweenAndClinicId(@Param("startDate") String startDate, @Param("endDate") String endDate,
			@Param("clinicId") Long clinicId);

	List<PetWellnessPlan> findByPetId_IdAndWorkFlowStatus(Long petId, Status workFlowStatus);

	PetWellnessPlan findByIdAndWorkFlowStatus(Long petWellnessPlanId, Status status);

	@Query("SELECT p FROM PetWellnessPlan p WHERE p.petId.id = :petId AND p.workFlowStatus IN :statuses")
	List<PetWellnessPlan> findByPetIdAndWorkFlowStatusIn(@Param("petId") Long petId,
			@Param("statuses") List<Status> statuses);

	@Query("SELECT p FROM PetWellnessPlan p WHERE p.petId.clinic.id = :clinicId AND p.workFlowStatus = 'ACTIVE'")
	List<PetWellnessPlan> findActivePlansByClinicId(@Param("clinicId") Long clinicId);

	@Query("SELECT p FROM PetWellnessPlan p WHERE p.petOwnerId.id = :petOwnerId AND p.workFlowStatus = 'ACTIVE'")
	List<PetWellnessPlan> findByPetOwnerIdAndActiveWorkFlowStatus(@Param("petOwnerId") Long petOwnerId);

	@Query("SELECT p FROM PetWellnessPlan p WHERE p.clinicWellnessPlan.clinic.id = :clinicId AND p.workFlowStatus = 'ACTIVE'")
	List<PetWellnessPlan> findByClinicWellnessPlan_ClinicIdAndActiveWorkFlowStatus(@Param("clinicId") Long clinicId);

	List<PetWellnessPlan> findByPetIdClinicIdAndWorkFlowStatus(Long clinicId, Status workFlowStatus);

	@Query("SELECT p FROM PetWellnessPlan p " + "JOIN p.managePetWellnessPlan mp " + "WHERE p.workFlowStatus = :status "
			+ "AND mp.endDate IS NOT NULL "
			+ "AND CAST(mp.endDate AS Instant) BETWEEN CURRENT_TIMESTAMP AND :expiryDate")
	List<PetWellnessPlan> findExpiringActivePlans(@Param("status") Status status,
			@Param("expiryDate") Instant expiryDate);

	@Query("SELECT p FROM PetWellnessPlan p WHERE p.workFlowStatus = :status")
	List<PetWellnessPlan> findAllActivePlans(@Param("status") Status status);

	List<PetWellnessPlan> findByPetId_IdAndWorkFlowStatusIn(Long petId, List<Status> statuses);

	List<PetWellnessPlan> findByWorkFlowStatusAndFulfilledBy(Status workFlowStatus, Long fulfilledBy);

	@Query("SELECT p FROM PetWellnessPlan p " + "WHERE p.clinicWellnessPlan.clinic.id = :clinicId "
			+ "AND p.workFlowStatus IN :statuses")
	List<PetWellnessPlan> findPlansByClinicIdAndStatuses(@Param("clinicId") Long clinicId,
			@Param("statuses") List<Status> statuses);

	@Query("SELECT p FROM PetWellnessPlan p WHERE p.petId.id IN :petIds AND p.workFlowStatus IN :statuses")
	List<PetWellnessPlan> findPlansByPetIdsAndStatuses(@Param("petIds") List<Long> petIds,
			@Param("statuses") List<Status> statuses);

	@Query("SELECT p FROM PetWellnessPlan p " + "JOIN p.managePetWellnessPlan mp " + "WHERE p.workFlowStatus = :status "
			+ "AND p.clinicWellnessPlan.clinic.id = :clinicId " + "AND mp.endDate IS NOT NULL")
	List<PetWellnessPlan> findPlansByClinicAndStatus(@Param("status") Status status, @Param("clinicId") Long clinicId);

	List<PetWellnessPlan> findByPetOwnerIdAndWorkFlowStatus(Register petOwnerId, Status workFlowStatus);

	@Query("SELECT p FROM PetWellnessPlan p " + "WHERE p.clinicWellnessPlan.clinic.id = :clinicId "
			+ "AND p.scheduledDateAndTime BETWEEN :startOfDay AND :endOfDay")
	List<PetWellnessPlan> findByClinicWellnessPlan_ClinicIdAndScheduledDateAndTimeBetween(
			@Param("clinicId") Long clinicId, @Param("startOfDay") Instant startOfDay,
			@Param("endOfDay") Instant endOfDay);

	@Query("SELECT p FROM PetWellnessPlan p " + "WHERE p.clinicWellnessPlan.clinic.id = :clinicId "
			+ "AND p.scheduledDateAndTime <= :currentTime " + "AND p.workFlowStatus = :workFlowStatus")
	List<PetWellnessPlan> findByClinicWellnessPlan_ClinicIdAndScheduledDateAndTimeBeforeAndWorkFlowStatus(
			@Param("clinicId") Long clinicId, @Param("currentTime") Instant currentTime,
			@Param("workFlowStatus") Status workFlowStatus);

	@Query("SELECT pwp FROM PetWellnessPlan pwp WHERE pwp.petOwnerId.id = :petOwnerId "
			+ "AND pwp.scheduledDateAndTime < :currentTime AND pwp.workFlowStatus = :workFlowStatus")
	List<PetWellnessPlan> findMissedAppointmentsForPetOwner(@Param("petOwnerId") Long petOwnerId,
			@Param("currentTime") Instant currentTime, @Param("workFlowStatus") Status workFlowStatus);

	@Query("SELECT pwp FROM PetWellnessPlan pwp WHERE pwp.petOwnerId.id = :petOwnerId "
			+ "AND pwp.scheduledDateAndTime BETWEEN :startOfDay AND :endOfDay")
	List<PetWellnessPlan> findTodaysAppointmentsForPetOwner(@Param("petOwnerId") Long petOwnerId,
			@Param("startOfDay") Instant startOfDay, @Param("endOfDay") Instant endOfDay);

}
