package com.elevate.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.elevate.entity.PetDetails;
import com.elevate.entity.Register;

@Repository
public interface IPetDetailsRepository extends JpaRepository<PetDetails, Long> {

	List<PetDetails> findByClinicIdAndPetOwner_Id(Long clinicId, Long regId);

	PetDetails findByClinicId(Long clinicId);

	List<PetDetails> findByPetOwner_IdAndStatusIsTrue(Long id);

	List<PetDetails> findByClinic_Id(Long id);

	PetDetails findFirstByPetOwner_IdOrderByIdAsc(Long id);

	List<PetDetails> findByClinicIdAndStatusIsFalse(Long clinicId);

	PetDetails findByPetTypeIsNullAndPetOwner_IdAndClinic_Id(Long petOwnerId,Long clinic_Id);

	Optional<PetDetails> findByStripeCustomerId(String stripeCustomerId);

	PetDetails findByPetOwnerId(Long petOwner);

	List<PetDetails> findByClinic_IdAndStatusTrue(Long clinicId);
	
	@Query("SELECT p FROM PetDetails p WHERE p.status = true")
	List<PetDetails> findAllActivePets();
	
	@Query("SELECT DISTINCT p.petOwner FROM PetDetails p WHERE p.clinic.id = :clinicId AND p.status = true")
	List<Register> findDistinctPetOwnersByClinicId(@Param("clinicId") Long clinicId);



}
