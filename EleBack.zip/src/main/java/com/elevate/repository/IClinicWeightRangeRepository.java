package com.elevate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.elevate.entity.ClinicWeightRange;

@Repository
public interface IClinicWeightRangeRepository extends JpaRepository<ClinicWeightRange, Long> {

	@Query("SELECT cwr FROM ClinicWeightRange cwr WHERE cwr.clinic.id = :clinicId ORDER BY id")
	List<ClinicWeightRange> findAllByClinicId(Long clinicId);

}
