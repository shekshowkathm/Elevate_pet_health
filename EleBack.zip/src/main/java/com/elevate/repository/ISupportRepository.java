package com.elevate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.elevate.entity.Support;

@Repository
public interface ISupportRepository extends JpaRepository<Support, Long> {

	List<Support> findByReceiver(String receiver);

}
