package com.elevate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.elevate.entity.PromotionDiscount;

@Repository
public interface IPromotionDiscountRepository extends JpaRepository<PromotionDiscount, Long> {

	List<PromotionDiscount> findByClinic_IdAndStatusIsTrue(Long clinicId);

	List<PromotionDiscount> findByClinic_IdAndStatusIsTrueAndPromotionType(Long clinicId, String promotionType);

	List<PromotionDiscount> findByClinic_Id(Long ClinicId);

	List<PromotionDiscount> findByStatusIsTrue();

	PromotionDiscount findByClinicIdAndPromotionType(Long clinicId,String promotionType);

	@Query("SELECT p FROM PromotionDiscount p WHERE p.clinic.id = :clinicId AND p.status = true AND p.promotionType NOT IN :excludedPromotionTypes")
	List<PromotionDiscount> findByClinic_IdAndStatusIsTrueAndPromotionTypeNotIn(@Param("clinicId") Long clinicId,
			@Param("excludedPromotionTypes") List<String> excludedPromotionTypes);

	List<PromotionDiscount> findByClinic_IdAndStatusTrue(Long id);
}
