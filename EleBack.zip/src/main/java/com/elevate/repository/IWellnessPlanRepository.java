package com.elevate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.elevate.entity.WellnessPlan;

@Repository
public interface IWellnessPlanRepository extends JpaRepository<WellnessPlan, Long> {

	 List<WellnessPlan> findByStatusIsTrue();
	 
	 boolean existsByWellnessPlanNameAndService_Id(String wellnessPlanName, Long serviceId);
	 
	 List<WellnessPlan> findByWellnessPlanName(String wellnessPlanName);

}
