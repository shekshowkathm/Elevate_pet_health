package com.elevate.repository;

import com.elevate.entity.UploadDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface IDocumentRepository extends JpaRepository<UploadDocument, Long> {

	List<UploadDocument> findByUploadedByRoleAndTargetTypeAndTargetId(String superAdmin, String clinic, Long o);

	@Query("SELECT d FROM UploadDocument d WHERE d.uploadedByRole = :uploadedByRole AND "
			+ "((:clinicId IS NULL OR d.clinicId = :clinicId) OR d.targetType = :targetType)")
	List<UploadDocument> findDocumentsBySuperAdminAndClinicIdOrAllClinics(
			@Param("uploadedByRole") String uploadedByRole, @Param("clinicId") Long clinicId,
			@Param("targetType") String targetType);

	@Query("SELECT d FROM UploadDocument d WHERE d.uploadedByRole = :uploadedByRole AND "
			+ "(d.clinicId = :clinicId OR d.targetType = :targetType)")
	List<UploadDocument> findDocumentsBySuperAdminForClinicOrAllClinics(@Param("uploadedByRole") String uploadedByRole,
			@Param("clinicId") Long clinicId, @Param("targetType") String targetType);

	@Query("SELECT d FROM UploadDocument d WHERE d.clinicId = :clinicId AND d.targetType = 'SuperAdmin' AND "
			+ "d.uploadedByRole IN ('CLINIC_OWNER', 'CLINIC_ADMIN', 'CLINIC_ASSOCIATE')")
	List<UploadDocument> findDocumentsUploadedByClinicToSuperAdmin(@Param("clinicId") Long clinicId);

	@Query("SELECT d FROM UploadDocument d WHERE d.clinicId = :clinicId AND d.targetType = 'AllPetOwners' AND "
			+ "d.uploadedByRole IN ('CLINIC_OWNER', 'CLINIC_ADMIN', 'CLINIC_ASSOCIATE')")
	List<UploadDocument> findDocumentsUploadedByClinicToAllPetOwners(@Param("clinicId") Long clinicId);

	@Query("SELECT d FROM UploadDocument d WHERE d.clinicId = :clinicId " + "AND d.targetId = :targetId "
			+ "AND d.targetType = 'PetOwner' " + "AND (d.documentType IS NULL OR d.documentType != 'Invoice') "
			+ "AND d.uploadedByRole IN ('CLINIC_OWNER', 'CLINIC_ADMIN', 'CLINIC_ASSOCIATE')")
	List<UploadDocument> findDocumentsByClinicAndTargetIdAndTargetTypeAndRolesExcludingInvoice(
			@Param("clinicId") Long clinicId, @Param("targetId") Long targetId);

	@Query("SELECT d FROM UploadDocument d WHERE d.clinicId = :clinicId AND "
			+ "d.uploadedById = :uploadedById AND d.uploadedByRole = 'PET_OWNER' AND d.targetType = 'Clinic'")
	List<UploadDocument> findDocumentsUploadedByPetOwnerToClinic(@Param("clinicId") Long clinicId,
			@Param("uploadedById") Long uploadedById);

	List<UploadDocument> findByDocumentType(String string);

}
