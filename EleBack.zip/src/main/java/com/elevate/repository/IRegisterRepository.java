package com.elevate.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.elevate.entity.Register;

@Repository
public interface IRegisterRepository extends JpaRepository<Register, Long> {

	boolean existsByEmail(String email);

	Optional<Register> findByEmail(String username);

	Register findByStripeCustomerId(String stripeCustomerId);

	List<Register> findByRegisterStatusIsFalse();

	List<Register> findByRole(String role);
	
	List<Register> findByRegisterStatusIsFalseAndRole(String role);
	
	List<Register> findByRegisterStatusIsTrueAndRole(String role);
	
	List<Register> findByRoleAndRegisterStatusIsTrue(String role);
	
	List<Register> findByDoctorTrue();
	
	Optional<Register> findByDoctorTrueAndId(Long regId);

	Register findByIdAndRegisterStatusIsTrue(Long petOwnerId);

}
