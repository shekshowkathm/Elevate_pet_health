package com.elevate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.elevate.entity.NewsLetter;

@Repository
public interface INewsLetterRepository extends JpaRepository<NewsLetter, Long> {
	
	NewsLetter findByScheduledAt(String scheduledDate);

}
