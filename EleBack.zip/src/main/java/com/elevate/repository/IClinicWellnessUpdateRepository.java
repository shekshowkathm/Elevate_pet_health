package com.elevate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.elevate.entity.ClinicWellnessUpdate;

@Repository
public interface IClinicWellnessUpdateRepository extends JpaRepository<ClinicWellnessUpdate, Long> {

}
