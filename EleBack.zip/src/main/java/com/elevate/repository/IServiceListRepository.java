package com.elevate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.elevate.entity.ServiceList;

@Repository
public interface IServiceListRepository extends JpaRepository<ServiceList, Long>{

}
