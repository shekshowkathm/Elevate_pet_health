package com.elevate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.elevate.entity.ClinicDetails;
import java.util.List;
import java.util.Optional;

@Repository
public interface IClinicDetailsRepository extends JpaRepository<ClinicDetails, Long> {

	public ClinicDetails findByEmail(String email);

	List<ClinicDetails> findByClinicStatusIsTrue();

	List<ClinicDetails> findByClinicStatusIsFalse();

	List<ClinicDetails> findBySalesRepId(Long salesRepId);

	ClinicDetails findByClinicOwner_Id(Long clinicOwnerId);

	ClinicDetails findByClinicOwner_IdAndEmail(Long clinicOwnerId,String email);

	List<ClinicDetails> findByClinicOwnerId(Long clinicOwnerId);

	List<ClinicDetails> findByClinicAdminId(Long regId);

	Optional<ClinicDetails> findByStripeAccountId(String stripeAccountId);

	@Query("SELECT c FROM ClinicDetails c JOIN c.clinicAssociate r WHERE r.id = :registerId")
	List<ClinicDetails> findByClinicAssociateId(@Param("registerId") Long registerId);
	
	ClinicDetails findByClinicAdmin_Id(Long clinicAdminId);

	public List<ClinicDetails> findByHeadquaterIsTrueAndClinicStatusIsTrue();
	
	@Query("SELECT c FROM ClinicDetails c WHERE c.clinicStatus = true")
	List<ClinicDetails> findAllActiveClinics();
	
	List<ClinicDetails> findByHeadquaters(String headquaters);

	ClinicDetails findBystripeAccountId(String stripeAccountId);

	boolean existsByEmail(String email);
	
}

