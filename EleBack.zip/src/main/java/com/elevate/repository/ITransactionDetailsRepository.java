package com.elevate.repository;

import com.elevate.entity.TransactionDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface ITransactionDetailsRepository extends JpaRepository<TransactionDetails,Long> {
    @Query("SELECT t FROM TransactionDetails t WHERE t.stripeCustomerId = :customerId ORDER BY t.createdAt DESC")
    List<TransactionDetails> findByStripeCustomerIdAndCreatedAtDesc(String customerId);


    @Query("SELECT t FROM TransactionDetails t WHERE t.paymentStatus=:paymentStatus ORDER BY t.createdAt DESC")
    List<TransactionDetails> findByPaymentStatusAndCreatedAtDesc(String paymentStatus);

    @Query("SELECT t FROM TransactionDetails t WHERE t.stripeConnectedAccountId = :accountId AND t.createdAt BETWEEN :startOfDay AND :endOfDay")
    List<TransactionDetails> findByStripeConnectedAccountIdAndCreatedAtBetween(
            @Param("accountId") String accountId,
            @Param("startOfDay") LocalDateTime startOfDay,
            @Param("endOfDay") LocalDateTime endOfDay
    );

    @Query("SELECT t FROM TransactionDetails t WHERE t.createdAt BETWEEN :startOfDay AND :endOfDay")
    List<TransactionDetails> findByCreatedAtBetween(
            @Param("startOfDay") LocalDateTime startOfDay,
            @Param("endOfDay") LocalDateTime endOfDay
    );


    TransactionDetails findByStripeSubscriptionId(String subscriptionId);

    @Query("SELECT t FROM TransactionDetails t WHERE t.stripeConnectedAccountId = :accountId AND t.paymentStatus=:paymentStatus ORDER BY t.createdAt DESC")
    List<TransactionDetails> findByStripeConnectedAccountIdAndPaymentStatusAndCreatedAtDesc(@Param("accountId")String accountId ,@Param("paymentStatus") String paymentStatus);
    
    TransactionDetails findByStripeCustomerId(String stripeCustomerId);

    TransactionDetails findByInvoiceNumber(String invoiceNumber);

    List<TransactionDetails> findByStripeCustomerIdAndPaymentStatus(String stripeCustomerId,String paymentStatus);

    List<TransactionDetails> findByStripeConnectedAccountId(String stripeConnectedAccountId);

    @Query("SELECT t FROM TransactionDetails t WHERE t.stripeSubscriptionId = :stripeSubscriptionId ORDER BY t.id DESC")
    List<TransactionDetails> findTransactions(@Param("stripeSubscriptionId") String stripeSubscriptionId);

    Optional<TransactionDetails> findById(Long id);

}
