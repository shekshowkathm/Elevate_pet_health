package com.elevate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.elevate.entity.PetBreedAge;

@Repository
public interface IPetBreedAgeRepository extends JpaRepository<PetBreedAge, Long> {

	List<PetBreedAge> findByPetTypeAndBreed(String petType, String Breed);

	List<PetBreedAge> findByPetType(String petType);

	List<PetBreedAge> findByPetTypeAndStatusTrue(String petType);
}
