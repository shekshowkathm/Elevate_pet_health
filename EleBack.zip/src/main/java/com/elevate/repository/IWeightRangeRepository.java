package com.elevate.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.elevate.entity.WeightRange;

@Repository
public interface IWeightRangeRepository extends JpaRepository<WeightRange, Long> {
    
	List<WeightRange> findByStatusIsTrue();
	
	@Query("SELECT w FROM WeightRange w WHERE w.petType = :petType AND w.status = true")
	List<WeightRange> findByPetTypeAndStatusTrue(@Param("petType") String petType);

	@Query("SELECT w.size FROM WeightRange w WHERE w.petType = :petType AND :weight BETWEEN " +
	       "CAST(SUBSTRING(w.weight, 1, LOCATE('lb-', w.weight) - 1) AS double) " +
	       "AND CAST(SUBSTRING(w.weight, LOCATE('-', w.weight) + 1, LOCATE('lb', w.weight, LOCATE('-', w.weight)) - LOCATE('-', w.weight) - 1) AS double) " +
	       "AND w.status = true")
	String findSizeByPetTypeAndWeight(@Param("petType") String petType, @Param("weight") double weight);
}
