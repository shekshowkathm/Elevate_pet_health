package com.elevate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.elevate.entity.Subscribers;

@Repository
public interface ISubscribeRepository extends JpaRepository<Subscribers, Long>{
	
	List<Subscribers> findByStatus(String status);
	
	Subscribers findByEmail(String email);
	
	@Query("SELECT s.email FROM Subscribers s WHERE s.status = 'SUBSCRIBED'")
	List<String> findSubscribedEmails();

}
