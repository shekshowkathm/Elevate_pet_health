package com.elevate.Enum;

public enum ThirtySixtyNinetyStatus {
	TAKEN, ONGOING, NOT_YET
}
