package com.elevate.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class PetDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String petName;
	private String petType;
	private String gender;
	private String petBreed;
	private String petAge;
	private String weight;
	private boolean status;
	private String ageGroup;
	private String image;
	private String dob;
	private LocalDate startDate;
	@ManyToOne
	private ClinicDetails clinic;
	@ManyToOne
	private Register petOwner;
	private String stripeCustomerId;
	private String paymentStatus="pending";


//    private boolean planActive;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public String getPetType() {
		return petType;
	}

	public void setPetType(String petType) {
		this.petType = petType;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPetBreed() {
		return petBreed;
	}

	public void setPetBreed(String petBreed) {
		this.petBreed = petBreed;
	}

	public String getPetAge() {
		return petAge;
	}

	public void setPetAge(String petAge) {
		this.petAge = petAge;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public ClinicDetails getClinic() {
		return clinic;
	}

	public void setClinic(ClinicDetails clinic) {
		this.clinic = clinic;
	}

	public Register getPetOwner() {
		return petOwner;
	}

	public void setPetOwner(Register petOwner) {
		this.petOwner = petOwner;
	}

	public String getStripeCustomerId() {
		return stripeCustomerId;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public void setStripeCustomerId(String stripeCustomerId) {
		this.stripeCustomerId = stripeCustomerId;
	}
//	public boolean isPlanActive() {
//		return planActive;
//	}
//
//	public void setPlanActive(boolean planActive) {
//		this.planActive = planActive;
//	}

	@Override
	public String toString() {
		return "PetDetails [id=" + id + ", petName=" + petName + ", petType=" + petType + ", gender=" + gender
				+ ", petBreed=" + petBreed + ", petAge=" + petAge + ", weight=" + weight + ", status=" + status
				+ ", ageGroup=" + ageGroup + ", image=" + image + ", dob=" + dob + ", startDate=" + startDate
				+ ", clinic=" + clinic.getId() + ", petOwner=" + petOwner + "]";
	}

}
