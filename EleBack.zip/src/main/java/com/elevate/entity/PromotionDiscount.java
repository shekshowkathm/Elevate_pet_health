package com.elevate.entity;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class PromotionDiscount {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@ManyToOne
	private ClinicDetails clinic;
	private String startDate;
	private String endDate;
	private String promotionType;
	private boolean status;
	private String stripeCouponId;

	@ManyToMany(mappedBy = "promotionDiscounts")
	private List<ManagePetWellnessPlans> managePetWellnessPlans;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ClinicDetails getClinic() {
		return clinic;
	}

	public void setClinic(ClinicDetails clinic) {
		this.clinic = clinic;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getPromotionType() {
		return promotionType;
	}

	public void setPromotionType(String promotionType) {
		this.promotionType = promotionType;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getStripeCouponId() {
		return stripeCouponId;
	}

	public void setStripeCouponId(String stripeCouponId) {
		this.stripeCouponId = stripeCouponId;
	}

	public List<ManagePetWellnessPlans> getManagePetWellnessPlans() {
		return managePetWellnessPlans;
	}

	public void setManagePetWellnessPlans(List<ManagePetWellnessPlans> managePetWellnessPlans) {
		this.managePetWellnessPlans = managePetWellnessPlans;
	}
}