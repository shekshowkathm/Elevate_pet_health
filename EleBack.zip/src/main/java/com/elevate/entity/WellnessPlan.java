package com.elevate.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class WellnessPlan {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
    private String petType;
    private String ageGroup;
    private String wellnessPlanName;
    @ManyToOne
    private ServiceList service;
    @OneToMany(mappedBy="wellnessPlan")
    @JsonIgnoreProperties("wellnessPlan") 
    private List<Recommendation> recommendation;
    private boolean status;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPetType() {
		return petType;
	}
	public void setPetType(String petType) {
		this.petType = petType;
	}
	public String getAgeGroup() {
		return ageGroup;
	}
	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}
	public String getWellnessPlanName() {
		return wellnessPlanName;
	}
	public void setWellnessPlanName(String wellnessPlanName) {
		this.wellnessPlanName = wellnessPlanName;
	}
	public ServiceList getService() {
		return service;
	}
	public void setService(ServiceList service) {
		this.service = service;
	}
	public List<Recommendation> getRecommendation() {
		return recommendation;
	}
	public void setRecommendation(List<Recommendation> recommendation) {
		this.recommendation = recommendation;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
}