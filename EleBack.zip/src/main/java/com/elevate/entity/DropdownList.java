package com.elevate.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class DropdownList {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	private String dropdown;
	private String priceBased;
	private String priceForSmall;
	private String priceForMedium;
	private String priceForLarge;
	private String priceForXLarge;
	private String priceForQuantity;
	private String industryStandardPrice;
	
	@ManyToOne
	@JoinColumn(name="service_id")
	private ServiceList service;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDropdown() {
		return dropdown;
	}
	public void setDropdown(String dropdown) {
		this.dropdown = dropdown;
	}
	public String getPriceBased() {
		return priceBased;
	}
	public void setPriceBased(String priceBased) {
		this.priceBased = priceBased;
	}
	public String getIndustryStandardPrice() {
		return industryStandardPrice;
	}
	public void setIndustryStandardPrice(String industryStandardPrice) {
		this.industryStandardPrice = industryStandardPrice;
	}
	public String getPriceForSmall() {
		return priceForSmall;
	}
	public void setPriceForSmall(String priceForSmall) {
		this.priceForSmall = priceForSmall;
	}
	public String getPriceForMedium() {
		return priceForMedium;
	}
	public void setPriceForMedium(String priceForMedium) {
		this.priceForMedium = priceForMedium;
	}
	public String getPriceForLarge() {
		return priceForLarge;
	}
	public void setPriceForLarge(String priceForLarge) {
		this.priceForLarge = priceForLarge;
	}
	public String getPriceForXLarge() {
		return priceForXLarge;
	}
	public void setPriceForXLarge(String priceForXLarge) {
		this.priceForXLarge = priceForXLarge;
	}
	public String getPriceForQuantity() {
		return priceForQuantity;
	}
	public void setPriceForQuantity(String priceForQuantity) {
		this.priceForQuantity = priceForQuantity;
	}
	public ServiceList getService() {
		return service;
	}
	public void setService(ServiceList service) {
		this.service = service;
	}
}