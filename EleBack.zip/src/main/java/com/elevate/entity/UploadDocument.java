package com.elevate.entity;

import jakarta.persistence.*;
import org.springframework.web.bind.annotation.CrossOrigin;

@Entity
@Table(name = "document")
@CrossOrigin("*")
public class UploadDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "document_url", nullable = false)
    private String documentUrl;

    @Column(name = "uploaded_by_role", nullable = false)
    private String uploadedByRole;

    @Column(name = "uploaded_by_id", nullable = false)
    private Long uploadedById;

    @Column(name = "target_type", nullable = false)
    private String targetType;

    @Column(name = "target_id")
    private Long targetId;

    @Column(name = "clinic_id")
    private Long clinicId;

    @Column(name = "upload_date", nullable = false)
    private String uploadDate;

    @Column(name = "description")
    private String description;

    @Column(name = "fileSize")
    private String fileSize;
    
    @ManyToOne
    @JoinColumn(name = "manage_pet_wellness_plan_id", referencedColumnName = "id")
    private ManagePetWellnessPlans managePetWellnessPlan;

    @Column(name = "document_type")
    private String documentType;

    public UploadDocument() {}

    public UploadDocument(String documentUrl, String uploadedByRole, Long uploadedById,
                    String targetType, Long targetId, Long clinicId, String description,String fileSize,String uploadDate) {
        this.documentUrl = documentUrl;
        this.uploadedByRole = uploadedByRole;
        this.uploadedById = uploadedById;
        this.targetType = targetType;
        this.targetId = targetId;
        this.clinicId = clinicId;
        this.uploadDate = uploadDate;
        this.description = description;
        this.fileSize = fileSize;
    }

    public String getTargetType() {
        return targetType;
    }

    public void setTargetType(String targetType) {
        this.targetType = targetType;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocumentUrl() {
        return documentUrl;
    }

    public void setDocumentUrl(String documentUrl) {
        this.documentUrl = documentUrl;
    }

    public String getUploadedByRole() {
        return uploadedByRole;
    }

    public void setUploadedByRole(String uploadedByRole) {
        this.uploadedByRole = uploadedByRole;
    }

    public Long getUploadedById() {
        return uploadedById;
    }

    public void setUploadedById(Long uploadedById) {
        this.uploadedById = uploadedById;
    }

    public Long getTargetId() {
        return targetId;
    }

    public void setTargetId(Long targetId) {
        this.targetId = targetId;
    }

    public Long getClinicId() {
        return clinicId;
    }

    public void setClinicId(Long clinicId) {
        this.clinicId = clinicId;
    }

    public String getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(String uploadDate) {
        this.uploadDate = uploadDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFileSize() {
        return fileSize;
    }

    public void setFileSize(String fileSize) {
        this.fileSize = fileSize;
    }

	public ManagePetWellnessPlans getManagePetWellnessPlan() {
		return managePetWellnessPlan;
	}

	public void setManagePetWellnessPlan(ManagePetWellnessPlans managePetWellnessPlan) {
		this.managePetWellnessPlan = managePetWellnessPlan;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
}