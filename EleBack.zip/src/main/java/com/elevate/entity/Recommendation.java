package com.elevate.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Recommendation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@ManyToOne
	@JoinColumn(name="dropdown_id")
	private DropdownList dropdownList;
	@ManyToOne
	@JoinColumn(name = "wellness_plan_id")
	@JsonIgnoreProperties("recommendations")
	private WellnessPlan wellnessPlan;
	private String recommendation;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public DropdownList getDropdownList() {
		return dropdownList;
	}
	public void setDropdownList(DropdownList dropdownList) {
		this.dropdownList = dropdownList;
	}
	public String getRecommendation() {
		return recommendation;
	}
	public void setRecommendation(String recommendation) {
		this.recommendation = recommendation;
	}
	public WellnessPlan getWellnessPlan() {
		return wellnessPlan;
	}
	public void setWellnessPlan(WellnessPlan wellnessPlan) {
		this.wellnessPlan = wellnessPlan;
	}
}