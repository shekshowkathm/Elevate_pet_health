package com.elevate.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class PetBreedAge {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String petType;
	private String breed;
	private String breedType;
	private String ageForPuppy;
	private String ageForKitten;
	private String ageForAdult;
	private String ageForSenior;
	private boolean status;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPetType() {
		return petType;
	}

	public void setPetType(String petType) {
		this.petType = petType;
	}

	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}

	public String getBreedType() {
		return breedType;
	}

	public void setBreedType(String breedType) {
		this.breedType = breedType;
	}

	public String getAgeForPuppy() {
		return ageForPuppy;
	}

	public void setAgeForPuppy(String ageForPuppy) {
		this.ageForPuppy = ageForPuppy;
	}

	public String getAgeForKitten() {
		return ageForKitten;
	}

	public void setAgeForKitten(String ageForKitten) {
		this.ageForKitten = ageForKitten;
	}

	public String getAgeForAdult() {
		return ageForAdult;
	}

	public void setAgeForAdult(String ageForAdult) {
		this.ageForAdult = ageForAdult;
	}

	public String getAgeForSenior() {
		return ageForSenior;
	}

	public void setAgeForSenior(String ageForSenior) {
		this.ageForSenior = ageForSenior;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "PetBreedAge [id=" + id + ", petType=" + petType + ", breed=" + breed + ", breedType=" + breedType
				+ ", ageForPuppy=" + ageForPuppy + ", ageForKitten=" + ageForKitten + ", ageForAdult=" + ageForAdult
				+ ", ageForSenior=" + ageForSenior + ", status=" + status + "]";
	}
}