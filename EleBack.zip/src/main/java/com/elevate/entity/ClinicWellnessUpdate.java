package com.elevate.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class ClinicWellnessUpdate {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String updateRecommendation;
	private String discountPercentage;
	private String discountPriceForQuantity;
	private String doctorPercentage;
	private String updatedPriceForSmall;
	private String updatedPriceForMedium;
	private String updatedPriceForLarge;
	private String updatedPriceForXLarge;
	private String updatedPriceForQuantity;
	private String discountPriceForSmall;
	private String discountPriceForMedium;
	private String discountPriceForLarge;
	private String discountPriceForXLarge;
	private String stripeProductIdSmall;
	private String stripeProductIdMedium;
	private String stripeProductIdLarge;
	private String stripeProductIdXLarge;
	private String stripePriceIdSmall;
	private String stripePriceIdMedium;
	private String stripePriceIdLarge;
	private String stripePriceIdXLarge;
	private String stripeProductId;
	private String stripePriceId;
	private String stripeAccountId;
	private boolean status;
	@ManyToOne
	private DropdownList dropDown;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUpdateRecommendation() {
		return updateRecommendation;
	}

	public void setUpdateRecommendation(String updateRecommendation) {
		this.updateRecommendation = updateRecommendation;
	}

	public String getDiscountPercentage() {
		return discountPercentage;
	}

	public void setDiscountPercentage(String discountPercentage) {
		this.discountPercentage = discountPercentage;
	}

	public String getDiscountPriceForQuantity() {
		return discountPriceForQuantity;
	}

	public void setDiscountPriceForQuantity(String discountPriceForQuantity) {
		this.discountPriceForQuantity = discountPriceForQuantity;
	}

	public String getDiscountPriceForSmall() {
		return discountPriceForSmall;
	}

	public void setDiscountPriceForSmall(String discountPriceForSmall) {
		this.discountPriceForSmall = discountPriceForSmall;
	}

	public String getDiscountPriceForMedium() {
		return discountPriceForMedium;
	}

	public void setDiscountPriceForMedium(String discountPriceForMedium) {
		this.discountPriceForMedium = discountPriceForMedium;
	}

	public String getDiscountPriceForLarge() {
		return discountPriceForLarge;
	}

	public void setDiscountPriceForLarge(String discountPriceForLarge) {
		this.discountPriceForLarge = discountPriceForLarge;
	}

	public String getDiscountPriceForXLarge() {
		return discountPriceForXLarge;
	}

	public void setDiscountPriceForXLarge(String discountPriceForXLarge) {
		this.discountPriceForXLarge = discountPriceForXLarge;
	}

	public String getDoctorPercentage() {
		return doctorPercentage;
	}

	public void setDoctorPercentage(String doctorPercentage) {
		this.doctorPercentage = doctorPercentage;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public DropdownList getDropDown() {
		return dropDown;
	}

	public String getStripeProductId() {
		return stripeProductId;
	}

	public String getStripePriceId() {
		return stripePriceId;
	}

	public void setStripePriceId(String stripePriceId) {
		this.stripePriceId = stripePriceId;
	}

	public void setStripeProductId(String stripeProductId) {
		this.stripeProductId = stripeProductId;
	}

	public String getStripeAccountId() {
		return stripeAccountId;
	}

	public void setStripeAccountId(String stripeAccountId) {
		this.stripeAccountId = stripeAccountId;
	}

	public void setDropDown(DropdownList dropDown) {
		this.dropDown = dropDown;
	}

	public String getUpdatedPriceForSmall() {
		return updatedPriceForSmall;
	}

	public void setUpdatedPriceForSmall(String updatedPriceForSmall) {
		this.updatedPriceForSmall = updatedPriceForSmall;
	}

	public String getUpdatedPriceForMedium() {
		return updatedPriceForMedium;
	}

	public void setUpdatedPriceForMedium(String updatedPriceForMedium) {
		this.updatedPriceForMedium = updatedPriceForMedium;
	}

	public String getUpdatedPriceForLarge() {
		return updatedPriceForLarge;
	}

	public void setUpdatedPriceForLarge(String updatedPriceForLarge) {
		this.updatedPriceForLarge = updatedPriceForLarge;
	}

	public String getUpdatedPriceForXLarge() {
		return updatedPriceForXLarge;
	}

	public void setUpdatedPriceForXLarge(String updatedPriceForXLarge) {
		this.updatedPriceForXLarge = updatedPriceForXLarge;
	}

	public String getUpdatedPriceForQuantity() {
		return updatedPriceForQuantity;
	}

	public void setUpdatedPriceForQuantity(String updatedPriceForQuantity) {
		this.updatedPriceForQuantity = updatedPriceForQuantity;
	}

	public String getStripeProductIdSmall() {
		return stripeProductIdSmall;
	}

	public void setStripeProductIdSmall(String stripeProductIdSmall) {
		this.stripeProductIdSmall = stripeProductIdSmall;
	}

	public String getStripeProductIdMedium() {
		return stripeProductIdMedium;
	}

	public void setStripeProductIdMedium(String stripeProductIdMedium) {
		this.stripeProductIdMedium = stripeProductIdMedium;
	}

	public String getStripeProductIdLarge() {
		return stripeProductIdLarge;
	}

	public void setStripeProductIdLarge(String stripeProductIdLarge) {
		this.stripeProductIdLarge = stripeProductIdLarge;
	}

	public String getStripeProductIdXLarge() {
		return stripeProductIdXLarge;
	}

	public void setStripeProductIdXLarge(String stripeProductIdXLarge) {
		this.stripeProductIdXLarge = stripeProductIdXLarge;
	}

	public String getStripePriceIdSmall() {
		return stripePriceIdSmall;
	}

	public void setStripePriceIdSmall(String stripePriceIdSmall) {
		this.stripePriceIdSmall = stripePriceIdSmall;
	}

	public String getStripePriceIdMedium() {
		return stripePriceIdMedium;
	}

	public void setStripePriceIdMedium(String stripePriceIdMedium) {
		this.stripePriceIdMedium = stripePriceIdMedium;
	}

	public String getStripePriceIdLarge() {
		return stripePriceIdLarge;
	}

	public void setStripePriceIdLarge(String stripePriceIdLarge) {
		this.stripePriceIdLarge = stripePriceIdLarge;
	}

	public String getStripePriceIdXLarge() {
		return stripePriceIdXLarge;
	}

	public void setStripePriceIdXLarge(String stripePriceIdXLarge) {
		this.stripePriceIdXLarge = stripePriceIdXLarge;
	}
}