package com.elevate.entity;

import java.time.Instant;

import com.elevate.Enum.Status;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class PetWellnessPlan {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@ManyToOne
	private PetDetails petId;
	@ManyToOne
	private ClinicWellnessPlan clinicWellnessPlan;
	@ManyToOne
	private ClinicWellnessUpdate clinicWellnessUpdate;
	@ManyToOne
	private Register petOwnerId;
	@ManyToOne
	private Register assignedBy;
	private Instant scheduledDateAndTime;
	@Enumerated(EnumType.STRING)
	private Status workFlowStatus;
	private Long fulfilledBy;
	@ManyToOne
	@JoinColumn(name = "manage_pet_wellness_plan_id")
	private ManagePetWellnessPlans managePetWellnessPlan;
	private String createdOn;
	private String planStatus="pending";
	private String stripePaymentId;
	private String stripeInvoiceId;
	private String stripeSubscriptionId;
	private String stripeCustomerId;
	private String paymentStatus="pending";



	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public PetDetails getPetId() {
		return petId;
	}
	public void setPetId(PetDetails petId) {
		this.petId = petId;
	}
	public ClinicWellnessPlan getClinicWellnessPlan() {
		return clinicWellnessPlan;
	}
	public void setClinicWellnessPlan(ClinicWellnessPlan clinicWellnessPlan) {
		this.clinicWellnessPlan = clinicWellnessPlan;
	}
	public ClinicWellnessUpdate getClinicWellnessUpdate() {
		return clinicWellnessUpdate;
	}
	public void setClinicWellnessUpdate(ClinicWellnessUpdate clinicWellnessUpdate) {
		this.clinicWellnessUpdate = clinicWellnessUpdate;
	}
	public Register getPetOwnerId() {
		return petOwnerId;
	}
	public void setPetOwnerId(Register petOwnerId) {
		this.petOwnerId = petOwnerId;
	}
	public Register getAssignedBy() {
		return assignedBy;
	}
	public void setAssignedBy(Register assignedBy) {
		this.assignedBy = assignedBy;
	}
	public Instant getScheduledDateAndTime() {
		return scheduledDateAndTime;
	}
	public void setScheduledDateAndTime(Instant scheduledDateAndTime) {
		this.scheduledDateAndTime = scheduledDateAndTime;
	}
	public Status getWorkFlowStatus() {
		return workFlowStatus;
	}
	public void setWorkFlowStatus(Status workFlowStatus) {
		this.workFlowStatus = workFlowStatus;
	}
	public Long getFulfilledBy() {
		return fulfilledBy;
	}
	public void setFulfilledBy(Long fulfilledBy) {
		this.fulfilledBy = fulfilledBy;
	}
	public ManagePetWellnessPlans getManagePetWellnessPlan() {
		return managePetWellnessPlan;
	}
	public void setManagePetWellnessPlan(ManagePetWellnessPlans managePetWellnessPlan) {
		this.managePetWellnessPlan = managePetWellnessPlan;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getPlanStatus() {
		return planStatus;
	}
	public void setPlanStatus(String planStatus) {
		this.planStatus = planStatus;
	}

	public String getStripePaymentId() {
		return stripePaymentId;
	}

	public void setStripePaymentId(String stripePaymentId) {
		this.stripePaymentId = stripePaymentId;
	}

	public String getStripeInvoiceId() {
		return stripeInvoiceId;
	}

	public void setStripeInvoiceId(String stripeInvoiceId) {
		this.stripeInvoiceId = stripeInvoiceId;
	}

	public String getStripeSubscriptionId() {
		return stripeSubscriptionId;
	}

	public void setStripeSubscriptionId(String stripeSubscriptionId) {
		this.stripeSubscriptionId = stripeSubscriptionId;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getStripeCustomerId() {
		return stripeCustomerId;
	}

	public void setStripeCustomerId(String stripeCustomerId) {
		this.stripeCustomerId = stripeCustomerId;
	}
}