package com.elevate.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import java.time.LocalDateTime;

@Entity
public class TransactionDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String stripeCustomerId;
    private String stripeSubscriptionId;
    private String stripeConnectedAccountId;
    private String stripePaymentId;
    private String stripeInvoiceId;
    private double totalAmount;
    private double connectedAccountReceived;
    private double platformReceivedAmount;
    private String stripeTransferId;
    private String transferStatus;
    private long customerPaidDate;
    private long platformReceivedDate;
    private String reccuringCount;
    private double stripeFee;
    private String paymentStatus;
    private String invoiceNumber;
    private String clinicName;
    private String url;
    private String petOwnerName;
    private String paymentFailedMsg;
    private double discountAmount;
    private double StripeFeeClinic;
    private double StripeFeeElevate;
    private LocalDateTime createdAt= LocalDateTime.now();

    public String getStripeCustomerId() {
        return stripeCustomerId;
    }

    public void setStripeCustomerId(String stripeCustomerId) {
        this.stripeCustomerId = stripeCustomerId;
    }

    public String getStripeSubscriptionId() {
        return stripeSubscriptionId;
    }

    public void setStripeSubscriptionId(String stripeSubscriptionId) {
        this.stripeSubscriptionId = stripeSubscriptionId;
    }

    public String getStripeConnectedAccountId() {
        return stripeConnectedAccountId;
    }

    public void setStripeConnectedAccountId(String stripeConnectedAccountId) {
        this.stripeConnectedAccountId = stripeConnectedAccountId;
    }

    public String getStripePaymentId() {
        return stripePaymentId;
    }

    public void setStripePaymentId(String stripePaymentId) {
        this.stripePaymentId = stripePaymentId;
    }

    public String getStripeInvoiceId() {
        return stripeInvoiceId;
    }

    public void setStripeInvoiceId(String stripeInvoiceId) {
        this.stripeInvoiceId = stripeInvoiceId;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public double getConnectedAccountReceived() {
        return connectedAccountReceived;
    }

    public void setConnectedAccountReceived(double connectedAccountReceived) {
        this.connectedAccountReceived = connectedAccountReceived;
    }

    public double getPlatformReceivedAmount() {
        return platformReceivedAmount;
    }

    public void setPlatformReceivedAmount(double platformReceivedAmount) {
        this.platformReceivedAmount = platformReceivedAmount;
    }

    public String getStripeTransferId() {
        return stripeTransferId;
    }

    public void setStripeTransferId(String stripeTransferId) {
        this.stripeTransferId = stripeTransferId;
    }

    public String getTransferStatus() {
        return transferStatus;
    }

    public void setTransferStatus(String transferStatus) {
        this.transferStatus = transferStatus;
    }

    public long getCustomerPaidDate() {
        return customerPaidDate;
    }

    public void setCustomerPaidDate(long customerPaidDate) {
        this.customerPaidDate = customerPaidDate;
    }

    public long getPlatformReceivedDate() {
        return platformReceivedDate;
    }

    public void setPlatformReceivedDate(long platformReceivedDate) {
        this.platformReceivedDate = platformReceivedDate;
    }

    public String getReccuringCount() {
        return reccuringCount;
    }

    public void setReccuringCount(String reccuringCount) {
        this.reccuringCount = reccuringCount;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getStripeFee() {
        return stripeFee;
    }

    public void setStripeFee(double stripeFee) {
        this.stripeFee = stripeFee;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getClinicName() {
        return clinicName;
    }

    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPaymentFailedMsg() {
        return paymentFailedMsg;
    }

    public void setPaymentFailedMsg(String paymentFailedMsg) {
        this.paymentFailedMsg = paymentFailedMsg;
    }

    public String getPetOwnerName() {
        return petOwnerName;
    }

    public void setPetOwnerName(String petOwnerName) {
        this.petOwnerName = petOwnerName;
    }

    public double getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(double discountAmount) {
        this.discountAmount = discountAmount;
    }

    public double getStripeFeeClinic() {
        return StripeFeeClinic;
    }

    public void setStripeFeeClinic(double stripeFeeClinic) {
        StripeFeeClinic = stripeFeeClinic;
    }

    public double getStripeFeeElevate() {
        return StripeFeeElevate;
    }

    public void setStripeFeeElevate(double stripeFeeElevate) {
        StripeFeeElevate = stripeFeeElevate;
    }
}
