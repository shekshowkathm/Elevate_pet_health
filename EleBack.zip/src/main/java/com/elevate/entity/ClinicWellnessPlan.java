package com.elevate.entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class ClinicWellnessPlan {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@ManyToOne
	private WellnessPlan wellnessPlan;
	@ManyToOne
	private ClinicDetails clinic;
	@OneToMany
	private List<ClinicWellnessUpdate> wellnessUpdate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public WellnessPlan getWellnessPlan() {
		return wellnessPlan;
	}

	public void setWellnessPlan(WellnessPlan wellnessPlan) {
		this.wellnessPlan = wellnessPlan;
	}

	public ClinicDetails getClinic() {
		return clinic;
	}

	public void setClinic(ClinicDetails clinic) {
		this.clinic = clinic;
	}

	public List<ClinicWellnessUpdate> getWellnessUpdate() {
		return wellnessUpdate;
	}

	public void setWellnessUpdate(List<ClinicWellnessUpdate> wellnessUpdate) {
		this.wellnessUpdate = wellnessUpdate;
	}

	@Override
	public String toString() {
		return "ClinicWellnessPlan [id=" + id + ", wellnessPlan=" + wellnessPlan + ", clinic=" + clinic
				+ ", wellnessUpdate=" + wellnessUpdate + "]";
	}

}
