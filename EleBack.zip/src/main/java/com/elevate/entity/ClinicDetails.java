package com.elevate.entity;

import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class ClinicDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String email;
	private String clinicImage;
	private String clinicName;
	private String address;
	private String zipCode;
	private String ContactNumber;
	private String createdOn;
	private String startDate;
	private String endDate;
	private boolean clinicStatus;
	private boolean headquater;
	private String headquaters;
	private String city;
	private String state;
	private String qrCode;
	private String stripeAccountId;
	@ManyToOne
	@JoinColumn(name = "clinicOwner_id")
	private Register clinicOwner;
	@ManyToOne
	private Register clinicAdmin;
	@OneToMany
	private List<PetDetails> petDetails;
	@ManyToOne
	@JoinColumn(name = "salesRep_id")
	private Register salesRep;
	@OneToMany
	private List<Register> clinicAssociate;
	private boolean updateWeightRange;
	private boolean updateClinicPrice;
	private boolean updateRecommendation;
	private boolean updateDiscountPercentage;
	private boolean updateDiscountPrice;
	private boolean updateDoctorPercentage;
	private boolean viewPayment;
	private String clinicLogo;
	private String socialLinkOne;
	private String socialLinkTwo;
	private String socialLinkThree;
	private String socialLinkFour;
	private boolean stripeStatus;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getClinicImage() {
		return clinicImage;
	}

	public void setClinicImage(String clinicImage) {
		this.clinicImage = clinicImage;
	}

	public String getClinicName() {
		return clinicName;
	}

	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getContactNumber() {
		return ContactNumber;
	}

	public void setContactNumber(String contactNumber) {
		ContactNumber = contactNumber;
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public boolean isClinicStatus() {
		return clinicStatus;
	}

	public void setClinicStatus(boolean clinicStatus) {
		this.clinicStatus = clinicStatus;
	}

	public boolean isHeadquater() {
		return headquater;
	}

	public void setHeadquater(boolean headquater) {
		this.headquater = headquater;
	}

	public String getHeadquaters() {
		return headquaters;
	}

	public void setHeadquaters(String headquaters) {
		this.headquaters = headquaters;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getQrCode() {
		return qrCode;
	}

	public void setQrCode(String qrCode) {
		this.qrCode = qrCode;
	}

	public String getStripeAccountId() {
		return stripeAccountId;
	}

	public void setStripeAccountId(String stripeAccountId) {
		this.stripeAccountId = stripeAccountId;
	}

	public Register getClinicOwner() {
		return clinicOwner;
	}

	public void setClinicOwner(Register clinicOwner) {
		this.clinicOwner = clinicOwner;
	}

	public Register getClinicAdmin() {
		return clinicAdmin;
	}

	public void setClinicAdmin(Register clinicAdmin) {
		this.clinicAdmin = clinicAdmin;
	}

	public List<PetDetails> getPetDetails() {
		return petDetails;
	}

	public void setPetDetails(List<PetDetails> petDetails) {
		this.petDetails = petDetails;
	}

	public Register getSalesRep() {
		return salesRep;
	}

	public void setSalesRep(Register salesRep) {
		this.salesRep = salesRep;
	}

	public List<Register> getClinicAssociate() {
		return clinicAssociate;
	}

	public void setClinicAssociate(List<Register> clinicAssociate) {
		this.clinicAssociate = clinicAssociate;
	}

	public boolean isUpdateWeightRange() {
		return updateWeightRange;
	}

	public void setUpdateWeightRange(boolean updateWeightRange) {
		this.updateWeightRange = updateWeightRange;
	}

	public boolean isUpdateClinicPrice() {
		return updateClinicPrice;
	}

	public void setUpdateClinicPrice(boolean updateClinicPrice) {
		this.updateClinicPrice = updateClinicPrice;
	}

	public boolean isUpdateRecommendation() {
		return updateRecommendation;
	}

	public void setUpdateRecommendation(boolean updateRecommendation) {
		this.updateRecommendation = updateRecommendation;
	}

	public boolean isUpdateDiscountPercentage() {
		return updateDiscountPercentage;
	}

	public void setUpdateDiscountPercentage(boolean updateDiscountPercentage) {
		this.updateDiscountPercentage = updateDiscountPercentage;
	}

	public boolean isUpdateDiscountPrice() {
		return updateDiscountPrice;
	}

	public void setUpdateDiscountPrice(boolean updateDiscountPrice) {
		this.updateDiscountPrice = updateDiscountPrice;
	}

	public boolean isUpdateDoctorPercentage() {
		return updateDoctorPercentage;
	}

	public void setUpdateDoctorPercentage(boolean updateDoctorPercentage) {
		this.updateDoctorPercentage = updateDoctorPercentage;
	}

	public boolean isViewPayment() {
		return viewPayment;
	}

	public void setViewPayment(boolean viewPayment) {
		this.viewPayment = viewPayment;
	}

	public String getClinicLogo() {
		return clinicLogo;
	}

	public void setClinicLogo(String clinicLogo) {
		this.clinicLogo = clinicLogo;
	}

	public String getSocialLinkOne() {
		return socialLinkOne;
	}

	public void setSocialLinkOne(String socialLinkOne) {
		this.socialLinkOne = socialLinkOne;
	}

	public String getSocialLinkTwo() {
		return socialLinkTwo;
	}

	public void setSocialLinkTwo(String socialLinkTwo) {
		this.socialLinkTwo = socialLinkTwo;
	}

	public String getSocialLinkThree() {
		return socialLinkThree;
	}

	public void setSocialLinkThree(String socialLinkThree) {
		this.socialLinkThree = socialLinkThree;
	}

	public String getSocialLinkFour() {
		return socialLinkFour;
	}

	public void setSocialLinkFour(String socialLinkFour) {
		this.socialLinkFour = socialLinkFour;
	}

	public boolean isStripeStatus() {
		return stripeStatus;
	}

	public void setStripeStatus(boolean stripeStatus) {
		this.stripeStatus = stripeStatus;
	}

	@Override
	public String toString() {
		return "ClinicDetails [id=" + id + ", email=" + email + ", clinicImage=" + clinicImage + ", clinicName="
				+ clinicName + ", address=" + address + ", zipCode=" + zipCode + ", ContactNumber=" + ContactNumber
				+ ", createdOn=" + createdOn + ", startDate=" + startDate + ", endDate=" + endDate + ", clinicStatus="
				+ clinicStatus + ", headquater=" + headquater + ", headquaters=" + headquaters + ", city=" + city
				+ ", state=" + state + ", qrCode=" + qrCode + ", stripeAccountId=" + stripeAccountId + ", clinicOwner="
				+ clinicOwner + ", clinicAdmin=" + clinicAdmin + ", petDetails=" + petDetails + ", salesRep=" + salesRep
				+ ", clinicAssociate=" + clinicAssociate + ", updateWeightRange=" + updateWeightRange
				+ ", updateClinicPrice=" + updateClinicPrice + ", updateRecommendation=" + updateRecommendation
				+ ", updateDiscountPercentage=" + updateDiscountPercentage + ", updateDiscountPrice="
				+ updateDiscountPrice + ", updateDoctorPercentage=" + updateDoctorPercentage + ", viewPayment="
				+ viewPayment + ", clinicLogo=" + clinicLogo + ", socialLinkOne=" + socialLinkOne + ", socialLinkTwo="
				+ socialLinkTwo + ", socialLinkThree=" + socialLinkThree + ", socialLinkFour=" + socialLinkFour + "]";
	}

}