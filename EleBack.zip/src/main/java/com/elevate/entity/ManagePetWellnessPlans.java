package com.elevate.entity;

import java.util.List;

import jakarta.persistence.*;

@Entity
public class ManagePetWellnessPlans {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String startDate;
	private String endDate;
	@OneToMany(mappedBy = "managePetWellnessPlan")
	private List<PetWellnessPlan> petWellnessPlans;
	private String totalAmount;
	private String updatedAmount;
	private boolean planAcceptance;

	@ManyToMany
	@JoinTable(name = "manage_pet_wellness_plan_promotion_discount", joinColumns = @JoinColumn(name = "manage_pet_wellness_plan_id"), inverseJoinColumns = @JoinColumn(name = "promotion_discount_id"))
	private List<PromotionDiscount> promotionDiscounts;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public List<PetWellnessPlan> getPetWellnessPlans() {
		return petWellnessPlans;
	}

	public void setPetWellnessPlans(List<PetWellnessPlan> petWellnessPlans) {
		this.petWellnessPlans = petWellnessPlans;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getUpdatedAmount() {
		return updatedAmount;
	}

	public void setUpdatedAmount(String updatedAmount) {
		this.updatedAmount = updatedAmount;
	}

	public List<PromotionDiscount> getPromotionDiscounts() {
		return promotionDiscounts;
	}

	public void setPromotionDiscounts(List<PromotionDiscount> promotionDiscounts) {
		this.promotionDiscounts = promotionDiscounts;
	}

	public boolean isPlanAcceptance() {
		return planAcceptance;
	}

	public void setPlanAcceptance(boolean planAcceptance) {
		this.planAcceptance = planAcceptance;
	}
}