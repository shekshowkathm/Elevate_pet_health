package com.elevate.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class ClinicWeightRange {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@ManyToOne
	private WeightRange weightRange;
	@ManyToOne
	private ClinicDetails clinic;
	private String updatedWeight;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public WeightRange getWeightRange() {
		return weightRange;
	}

	public void setWeightRange(WeightRange weightRange) {
		this.weightRange = weightRange;
	}

	public ClinicDetails getClinic() {
		return clinic;
	}

	public void setClinic(ClinicDetails clinic) {
		this.clinic = clinic;
	}

	public String getUpdatedWeight() {
		return updatedWeight;
	}

	public void setUpdatedWeight(String updatedWeight) {
		this.updatedWeight = updatedWeight;
	}

	@Override
	public String toString() {
		return "ClinicWeightRange [id=" + id + ", weightRange=" + weightRange + ", clinic=" + clinic
				+ ", updatedWeight=" + updatedWeight + "]";
	}

}
